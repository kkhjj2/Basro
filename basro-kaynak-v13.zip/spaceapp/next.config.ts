import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  experimental: {
    agentFeedback: true,
  },
  // Vercel: dosyadan okunan sayfa ve kayıtlı veri görüntüleri sunucu işlevine dahil edilsin.
  outputFileTracingIncludes: {
    "/": ["./public/index.html"],
    "/api/**/*": ["./data/*.json"],
  },
  cacheComponents: true,
  partialPrefetching: true,
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;
