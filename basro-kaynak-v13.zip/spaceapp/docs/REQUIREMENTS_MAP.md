# Basro — Gereksinim haritası, durum etiketleri ve demo akışı

Challenge: NASA Space Apps 2026 · **Field Shift: Adapting Farms with NASA Data**
Son güncelleme: 14 Kasım 2026 (paket v12) · Yayın: https://basro.vercel.app

Durum etiketleri:

- `implemented` — gerçek veriyle ya da gerçek hesapla çalışır, testi vardır.
- `demo_static` — arayüz ve mantık çalışır, ama veri örnek/sentetiktir ya da yalnızca bu cihazda tutulur. Arayüzde etiketlidir.
- `future_vision` — yapılmadı. Arayüzde ya hiç yoktur ya da sakin bir "yakında" etiketi taşır.

## 1. Yedi modül

| Modül | Ne yapıyor | Dosya | Durum |
|---|---|---|---|
| Earth Intelligence | Dünya haritası, NASA POWER iklim katmanları, konum seçimi | `public/world.js`, `public/world-core.js`, `lib/nasa-power.ts` | implemented |
| | 7 günlük hava (Open-Meteo) ve takvim şeridi | `public/forecast-core.mjs`, `public/forecast-calendar.mjs` | implemented |
| | Mevsimlik öngörü (ECMWF SEAS5, Open-Meteo üzerinden) | `public/season-core.mjs`, `public/season-data.mjs`, `lib/codex/season-service.ts` | implemented |
| | SMAP L4 kök bölgesi nemi | `lib/smap.ts`, `app/api/field-evidence/route.ts` | demo_static (kayıtlı anlık görüntü; yalnızca aynı 9 km hücrede döner) |
| | GPM IMERG, SoilGrids katmanı | — | future_vision |
| AI Intelligence | Fotoğraf incelemesi: bitki, dönem, kullanılabilirlik, güven; düşük güvende çekimser | `lib/codex/farm-api.ts`, `public/photo-evidence.mjs`, `app/api/plant/route.ts` | implemented (reddetme yolu gerçek modelle denendi; kabul yolu yalnızca testle) |
| | Haftalık rapor: önce olgular, sonra sade Türkçe; sayı ve doz denetimi | `public/weekly-report.mjs`, `app/api/report/route.ts` | implemented (gerçek modelle yazım henüz denenmedi; yedek metin test edildi) |
| | Tarım asistanı sohbeti | `public/assistant.js`, `app/api/assistant/route.ts` | implemented |
| Farm Memory | Zaman çizelgesi: fotoğraf, karar değişimi, eklenen bilgi, görev, not | `public/farm-memory.mjs` | demo_static (bu cihazda saklanır) |
| | Sezon karşılaştırma (2026 ve 2027) | — | future_vision ("yakında" etiketli) |
| Farm Twins | Rıza, anonim profil, benzerlik (`twins-1.0`), en az 3 eşleşme kuralı | `public/farm-twins.mjs` | demo_static (eşleşmeler örnek tarlalardır; veri cihazdan çıkmaz) |
| Ground Network | Eksik bilgi önceliği P = 0,35·I + 0,20·U + 0,15·C − 0,15·B − 0,15·E | `public/ground-network.mjs` | implemented |
| | Gönüllü ataması, çelişkide üçüncü okuma, medyan kabulü | `public/ground-network.mjs` | demo_static (7 sentetik gönüllü; pilot kullanıcının hesabını değiştirmez) |
| BAS Social & Progression | Gönderi paylaşma ve silme (Supabase `social_posts`) | `public/bas-social.mjs`, `app/api/social/route.ts` | implemented (giriş yok; herkes "Demo Çiftçi" görünür) |
| | Fotoğraflı gönderi, beğeni, yorum (biçim `social-wire-1`; hepsi `social_posts` içinde) | `public/social-wire.mjs`, `app/api/social/route.ts`, `app/api/social/photo/route.ts` | implemented (giriş yok; sahiplik tarayıcıya özel cihaz anahtarıyla; bulutta sahte sunucuyla denendi) |
| | Haftalık gelişim: girilen boy ölçümlerinden cm/hafta karşılaştırması | `public/social-wire.mjs` `growthBoard()` | implemented (gerçek ölçüm 2'den azsa örnek satırlar etiketli gösterilir) |
| | İlçe / il müdürü paneli: aktif çiftçi, gönderi, sahadan sinyaller, ürün bazında gelişim | `public/mudur.html`, `public/director-panel.mjs`, `regionSummary()` | implemented (yalnızca toplu sayılar; veri azsa örnek veri etiketli; yetkili girişi yok) |
| | Tek dokunuşluk anketler, örnek gönderiler | `public/bas-social.mjs` | demo_static ("Örnek gönderi" etiketli) |
| | XP, seviye (Fide → Veteran), günlük ilerleme | `public/bas-social.mjs` | demo_static (bu cihazda; sunucu defteri yok) |
| | Ligler | — | future_vision |
| Crop Rotation Engine | Rotasyon seçenekleri ve gerekçeleri (`agro-rotation-1.0`) | `public/rotation-lab-core.mjs`, `public/living-lab.mjs` | implemented (puanlar boyutsuz eleme sezgileridir, verim tahmini değildir) |
| | Toprak verilerim: tahlil sonucu girişi, genel sınıflama, önceki sonuca göre değişim; bünye su hesabına işler | `public/soil-lab.mjs` | demo_static (bu cihazda saklanır; doz önermez) |
| | Açılışta tanışma: tarla, ürünler, çiftçinin adı ve deneyimi, öncelik | `public/farmer.js`, `public/farmer-profile.mjs` | implemented |
| | FAO-56 su dengesi, sıradaki en değerli soru, "Ne değişti?" | `public/field-engine.mjs`, `public/field-workspace.mjs` | implemented |
| | Toprak bloğu: kök bölgesindeki kullanılabilir su; şimdi / sulamadan sonra / sulamazsan 7 gün sonra (`soil-block-1`) | `public/soil-block.mjs` | implemented (su dengesi hesabının göstergesidir; tarlada ölçüm değildir) |
| | Ana ekranda sekmeli tarla defteri (Bugün / Bu hafta / Geçmiş) | `public/home-layout.mjs` | implemented |

## 2. Çekirdek zincir (P0)

fotoğraf → yapay zekâ kanıtı → tarla durumu → yeniden hesap → "Ne değişti?" → takip görevi → XP → zaman çizelgesi

| Adım | Karşılığı | Durum |
|---|---|---|
| Fotoğraf yükleme ve inceleme | `/api/plant`, `gradeVision()` | implemented |
| Kanıtın kabulü ya da not olarak kalması | güven ≥ 0,60, kayıtlı ürünle eşleşme, kullanılabilir kare; aynı fotoğraf iki kez sayılmaz | implemented |
| Tarla durumunun güncellenmesi | dönem "fotoğraf kanıtı" etiketiyle yazılır | demo_static (bu cihazda; Supabase'e bağlı değil) |
| Yeniden hesap ve "Ne değişti?" | `explainChange()` önce/sonra | implemented |
| Takip görevi | reddedilince "yeniden çek", kabul edilince sıradaki soru | implemented |
| XP | kanıt +30, fotoğraf +5 (kaynak başına bir kez) | demo_static |
| Zaman çizelgesi | Kayıtlarım → Tarla hafızası | demo_static |

Fotoğraftan asla çıkarılmayanlar: toprak nemi, sulama ihtiyacı, hastalık teşhisi, gübre ya da ilaç dozu.

## 3. Veri kaynakları

| Kaynak | Ne için | Çözünürlük ve not |
|---|---|---|
| NASA POWER (aylık nokta API) | iklim katmanları, uzun dönem ortalamalar | yaklaşık 0,5° ızgara; parsel ölçümü değildir |
| Open-Meteo Forecast | 7 günlük hava | bölgesel model tahmini |
| Open-Meteo Seasonal (ECMWF SEAS5) | aylık eğilim | model uyumu; kesin tahmin değildir |
| NASA SMAP L4 (SPL4SMGP, AppEEARS) | kök bölgesi nemi | 9 km; kayıtlı anlık görüntü |
| Çiftçinin kendi girdileri | toprak, son sulama, dönem, fotoğraf | "senin beyanın" etiketiyle gösterilir |

## 4. Yöntemler

- Referans evapotranspirasyon: Hargreaves (FAO-56 Denklem 52). Bitki su tüketimi: ETc = Kc × ET₀, dönem Kc değerleri FAO-56 tablolarından.
- Su dengesi ve karar: FAO-56 kök bölgesi tükenmesi; karar eşikleri başlangıç değeridir, saha kalibrasyonu yapılmadı.
- Sıradaki soru: kararı değiştirme olasılığı en yüksek eksik bilgi sorulur.
- Haftalık rapor denetimi: metindeki her sayı olgu listesinde geçmelidir; doz içeren ya da üçten fazla adım öneren metin reddedilir.
- Tarla ikizleri: sert filtreler (aynı ürün, aynı iklim kuşağı, en çok bir dönem fark) ve ağırlıklı uzaklık (dönem 0,35, toprak 0,25, su 0,25, uzaklık 0,15). İklim kuşağı bölgeden kaba sınıftır, ölçüm değildir.

## 5. Dört dakikalık demo akışı

| Süre | Ekran | Gösterilecek | Dikkat |
|---|---|---|---|
| 20 sn | Dünya atlası | Malatya / Doğanşehir'e yaklaş, NASA POWER katmanları | canlı |
| 20 sn | Bugün | Filiz, günün bilgisi, hava takvimi, günün küçük işleri | canlı |
| 40 sn | Fotoğraf | domates fotoğrafı yükle; bitki, dönem, güven ve sınırlar | kabul yolunu önceden bir kez dene |
| 60 sn | Tarlam → Sezon / Rotasyon | "Ne değişti?" önce/sonra, SMAP ve su dengesi, rotasyon seçenekleri | SMAP kayıtlı görüntüdür, söyle |
| 30 sn | İkinci tarla | farklı su imkânı, farklı karar ve farklı soru | iki tarlayı önceden kaydet |
| 30 sn | Tarlam → Gözlem ağı | eksik bilgi sırası, pilot okuma, çelişkide üçüncü okuma | pilot sentetiktir, söyle |
| 30 sn | Kayıtlarım + Topluluk | tarla hafızası, tarla ikizleri, anket, haftalık rapor | ikizler örnek veridir; sezon karşılaştırma "yakında" |
| 10 sn | Kapanış | "Farmers shouldn't have to become scientists to contribute to agricultural science." | |

## 6. Dürüst sınırlar

- Tarla durumu, XP, tarla hafızası ve ikiz rızası tarayıcıda saklanır; cihaz değişince taşınmaz.
- Giriş (kimlik doğrulama) yok. Topluluk gönderileri veritabanında tek bir demo kullanıcı adına yazılır; görünen ad çiftçinin yazdığı addır ve doğrulanmaz. Herkese açık adreste isteyen herkes gönderi ve fotoğraf paylaşabilir; yalnızca hız sınırı vardır, içerik denetimi yoktur.
- Sahadan sinyaller anahtar kelime sayımıdır; toprak sınıfları genel sınıflamadır (Ülgen ve Yurtsever 1995 sınırları, laboratuvar yorumu esastır).
- Gözlem ağı gönüllüleri ve tarla ikizleri sentetiktir ve arayüzde işaretlidir.
- Fotoğraf kabul yolu ve haftalık raporun yapay zekâ yazımı gerçek modelle henüz uçtan uca denenmedi.
- Karar eşikleri ve benzerlik ağırlıkları başlangıç değerleridir; sahada doğrulanmadı.
- Sezon karşılaştırma, ligler, GPM IMERG ve SoilGrids katmanı yapılmadı. Arayüz varsayılan İngilizce, TR/EN anahtarı ile Türkçe (public/i18n.mjs, çalışma zamanı sözlüğü; yapay zekâ yanıtları `lang` alanıyla).

## 7. Doğrulama

`npm test` (156 test) ve `npm run build`. Arayüz yamaları `scripts/import-codex.mjs` ile sıfırdan üretilebilir ve yeniden çalıştırılabilir.
