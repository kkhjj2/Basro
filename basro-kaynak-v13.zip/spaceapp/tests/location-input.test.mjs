// Çalıştırma: npm test   (node --experimental-strip-types --test)
import { test } from "node:test";
import assert from "node:assert/strict";
import { haversineKm, parseLocationInput, seasonWindow, SMAP_SAME_CELL_KM } from "../lib/location-input.ts";

test("geçerli girdi yuvarlanır", () => {
  const r = parseLocationInput({ lat: "38.051234", lon: "37.881299", crop: "tomato", sowingDate: "2026-05-10" });
  assert.deepEqual(r, { lat: 38.0512, lon: 37.8813, crop: "tomato", sowingDate: "2026-05-10" });
});

test("geçersiz girdiler çiftçi diliyle reddedilir", () => {
  assert.equal(parseLocationInput({ lat: "abc", lon: 37, crop: "tomato", sowingDate: "2026-05-10" }), "Enlem geçersiz.");
  assert.equal(parseLocationInput({ lat: 38, lon: 200, crop: "tomato", sowingDate: "2026-05-10" }), "Boylam geçersiz.");
  assert.equal(parseLocationInput({ lat: 38, lon: 37, crop: "banana", sowingDate: "2026-05-10" }), "Ürün seçimi geçersiz.");
  assert.equal(parseLocationInput({ lat: 38, lon: 37, crop: "tomato", sowingDate: "10.05.2026" }), "Ekim tarihi geçersiz.");
});

test("haversine: Doğanşehir → Malatya merkez ~45-55 km", () => {
  const d = haversineKm(38.05, 37.88, 38.355, 38.309);
  assert.ok(d > 45 && d < 55, String(d));
  assert.equal(haversineKm(38.05, 37.88, 38.05, 37.88), 0);
});

test("aynı SMAP hücresi eşiği 9 km hücrenin yarı köşegeninden küçük", () => {
  assert.ok(SMAP_SAME_CELL_KM <= (9 * Math.SQRT2) / 2);
});

test("sezon penceresi: bitmiş sezon sezon sonunda, süren sezon bugün − 4 günde biter", () => {
  const now = new Date("2026-11-12T12:00:00Z");
  const done = seasonWindow("tomato", "2026-05-10", now); // 145 gün
  assert.equal(done.end, "2026-10-01");
  assert.equal(done.finished, true);
  const running = seasonWindow("wheat", "2026-10-15", now);
  assert.equal(running.end, "2026-11-08");
  assert.equal(running.finished, false);
  const future = seasonWindow("tomato", "2027-04-01", now);
  assert.ok(future.end < future.start);
});
