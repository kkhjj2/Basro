// Çalıştırma: npm test
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {evaluateWater,chooseQuestion,explainChange,et0Hargreaves,SOILS} from '../public/field-engine.mjs';

const hot=Array.from({length:7},(_,i)=>({date:`2026-07-${String(13+i).padStart(2,'0')}`,min:18,max:34,rain:0}));
const cool=Array.from({length:7},(_,i)=>({date:`2026-10-${String(1+i).padStart(2,'0')}`,min:8,max:22,rain:0}));
const base={crop:'Domates',lat:38.05,water:'var',lastIrrigationDays:null,weather:hot};

test('Hargreaves ET₀ yaz ortası Malatya için makul (5–8 mm/gün)',()=>{
 const e=et0Hargreaves(18,34,38.05,'2026-07-13');assert.ok(e>5&&e<8,String(e));
});

test('kriter 1: iki farklı tarla, koşulları yüzünden farklı soru alır ve neden açıklanır',()=>{
 const dry={...base,weather:cool,stage:'Meyve / dane gelişimi',soil:{value:null,source:'unknown'},moisture:{kind:'smap',theta:0.262}};
 const wet={...base,weather:cool,stage:'Çiçeklenme',soil:{value:null,source:'unknown'},moisture:{kind:'smap',theta:0.33}};
 const a=chooseQuestion(dry),b=chooseQuestion(wet);
 assert.equal(a.question.id,'irrigation'); // uydu kuru gösteriyor: damla sulamayı uydu göremez, önce son sulamayı sor
 assert.equal(b.question.id,'feel');       // uydu ıslak gösteriyor: kararı tarlada doğrula
 assert.match(a.reason,/karar/i);assert.match(b.reason,/karar/i);
});

test('dönem bilinmiyorsa önce dönem sorulur',()=>{
 const s={...base,weather:cool,stage:'Emin değilim',soil:{value:null,source:'unknown'},moisture:null};
 assert.equal(chooseQuestion(s).question.id,'stage');
});

test('aynı durumda aynı soru (rastgele değil)',()=>{
 const s={...base,stage:'Emin değilim',soil:{value:null,source:'unknown'},moisture:null};
 assert.deepEqual(chooseQuestion(s).question.id,chooseQuestion(s).question.id);
});

test('kriter 2: yeni ölçüm kararı değiştirir ve hangi hesabın değiştiği görünür',()=>{
 const s={...base,weather:cool,stage:'Meyve / dane gelişimi',soil:{value:'tinli',source:'farmer'},moisture:{kind:'feel',value:'islak'}};
 const before=evaluateWater(s),after=evaluateWater({...s,moisture:{kind:'feel',value:'kuru'}});
 assert.notEqual(before.action,after.action);
 assert.equal(after.action,'irrigate');
 const c=explainChange(before,after,'Toprak yoklaması: kuru');
 assert.equal(c.decisionChanged,true);
 assert.ok(c.diffs.some(d=>d.key==='Dr0'));
});

test('sulama imkânı yoksa sulama önerilmez',()=>{
 const r=evaluateWater({...base,water:'yok',stage:'Çiçeklenme',soil:{value:'kumlu',source:'farmer'},moisture:{kind:'feel',value:'kuru'}});
 assert.equal(r.action,'conserve');
});

test('toprak türü yarayışlı suyu değiştirir (FAO-56 Tablo 19)',()=>{
 assert.ok(SOILS.killi.fc-SOILS.killi.wp>SOILS.kumlu.fc-SOILS.kumlu.wp);
 const s={...base,stage:'Çiçeklenme',moisture:{kind:'smap',theta:0.2}};
 const sand=evaluateWater({...s,soil:{value:'kumlu',source:'farmer'}}),clay=evaluateWater({...s,soil:{value:'killi',source:'farmer'}});
 assert.ok(clay.TAW>sand.TAW);
});

test('bilgi yetince soru sorulmaz',()=>{
 const s={...base,stage:'Çiçeklenme',soil:{value:'tinli',source:'farmer'},moisture:{kind:'feel',value:'kuru'}};
 const q=chooseQuestion(s);
 assert.equal(q.question,null);
});
