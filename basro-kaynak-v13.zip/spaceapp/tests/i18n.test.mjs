import test from 'node:test';
import assert from 'node:assert/strict';
import { EXACT, WORDS, makePatterns } from '../public/i18n-en.mjs';

test('exact strings translate to English', () => {
  assert.equal(EXACT['← Geri'], '← Back');
  assert.ok(Object.keys(EXACT).length > 500);
});

test('pattern translations keep crop names', () => {
  const tr = t => EXACT[t];
  const pats = makePatterns(tr);
  const hit = s => { for (const [re, f] of pats) { const m = re.exec(s); if (m) return typeof f === 'function' ? f(...m) : s.replace(re, f); } return null; };
  assert.match(hit('Domates için konuşalım'), /^Let's talk about /);
  assert.ok(WORDS['Ocak']);
});
