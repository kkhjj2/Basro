import test from 'node:test';
import assert from 'node:assert/strict';
import {progressOf,levelOf,scopesFor,feedFor,regionOf,XP} from '../public/bas-social.mjs';

test('XP: günlük iş +20, üç iş tamamsa +40 bonus, cevap +10',()=>{
 const p=progressOf({'2026-11-13':{tasks:3,answers:2,posts:1}},'2026-11-13');
 assert.equal(p.xp,3*XP.task+XP.allDaily+2*XP.answer+XP.post);
});
test('Seviye formülü floor(sqrt(xp/50))+1',()=>{assert.equal(levelOf(0),1);assert.equal(levelOf(49),1);assert.equal(levelOf(50),2);assert.equal(levelOf(200),3);});
test('Seri: ardışık etkin günler; bugün boşsa dünden sayılır, boşluk seriyi keser',()=>{
 const log={'2026-11-10':{tasks:1},'2026-11-12':{tasks:1},'2026-11-13':{answers:1}};
 assert.equal(progressOf(log,'2026-11-13').streak,2);
 assert.equal(progressOf(log,'2026-11-14').streak,2);
 assert.equal(progressOf(log,'2026-11-15').streak,0);
});
test('Topluluk katmanları ilçe → il → bölge → Türkiye',()=>{
 const s=scopesFor({district:'Doğanşehir',city:'Malatya',country:'Türkiye'});
 assert.deepEqual(s.map(x=>x.name),['Doğanşehir','Malatya','Doğu Anadolu','Türkiye']);
 assert.equal(regionOf('Konya'),'İç Anadolu');
});
test('Küçük ilçe akışı il gönderilerini de gösterir; kendi paylaşımın en üstte',()=>{
 const farm={district:'Doğanşehir',city:'Malatya',crop:'Domates'};
 const f=feedFor('district',farm,[{id:'p1',scope:'district',text:'x'}]);
 assert.equal(f[0].own,true);
 assert.ok(f.some(p=>p.borrowed&&p.scope==='city'));
 assert.ok(feedFor('country',farm).every(p=>p.scope==='country'));
});
import {masteryHtml} from '../public/bas-social.mjs';
test('ustalık kartı: az gerçek veri örnekle tamamlanır ve etiketlenir; yeterliyse örnek yok',()=>{
 const few=masteryHtml([{crop:'Domates',metric:'yield',rows:[{rank:1,author:'Ozy',value:8000,mine:true}]}],'Domates','');
 assert.ok(few.includes('Örnek satırlar var')&&few.includes('Ozy · sen')&&few.includes('8.000 kg/da')&&few.includes('doğrulanmaz'));
 const many=masteryHtml([{crop:'Domates',metric:'yield',rows:[['A',3],['B',2],['C',1]].map(([author,value],i)=>({rank:i+1,author,value}))}],'Domates','');
 assert.ok(!many.includes('Örnek satırlar var')&&!many.includes('· örnek'));
 assert.ok(masteryHtml([],'Kayısı','').includes('Kayısı sıralaması'));
 assert.ok(masteryHtml([{crop:'Biber',metric:'growth',rows:[{rank:1,author:'A',value:14}]}],'Domates','Biber').includes('cm/hafta'));
});
