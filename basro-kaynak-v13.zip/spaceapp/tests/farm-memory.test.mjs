import test from 'node:test';
import assert from 'node:assert/strict';
import {timelineItems,groupByDay,memoryHtml} from '../public/farm-memory.mjs';
const data={farmId:'f1',notes:[{farmId:'f1',day:'2026-11-12',createdAt:'2026-11-12T09:00:00Z',type:'photo',text:'Fotoğraf kanıtı kabul edildi'},{farmId:'f2',day:'2026-11-12',type:'note',text:'başka tarla'}],
 record:{history:[{day:'2026-11-13',input:{id:'feel'},change:{decisionChanged:true,before:'Bekle',after:'Sula',changedInput:'Toprak yoklaması: kuru'}},{day:'2026-11-13',input:{id:'photo'},change:{decisionChanged:false}}]},
 work:{completedOn:{'f1|2026-11-13|photo':'2026-11-13','f2|x':'2026-11-13'}},tasks:[{key:'f1|2026-11-13|photo',title:'Ürünü fotoğrafla'}]};
test('Zaman çizelgesi yalnızca bu tarlanın olaylarını, en yeni üstte birleştirir',()=>{
 const items=timelineItems(data);
 assert.equal(items.length,3);assert.equal(items[0].day,'2026-11-13');assert.equal(items.at(-1).kind,'photo');
 assert.ok(items.some(i=>i.kind==='decision'&&/Bekle → Sula/.test(i.title)));
 assert.equal(items.find(i=>i.kind==='task').text,'Ürünü fotoğrafla');
 assert.equal(groupByDay(items).length,2);
});
test('Süzgeç ve boş durum',()=>{
 assert.match(memoryHtml(timelineItems(data),'photo'),/Fotoğraf kanıtı kabul edildi/);
 assert.doesNotMatch(memoryHtml(timelineItems(data),'photo'),/İş tamamlandı/);
 assert.match(memoryHtml([]),/Henüz kayıt yok/);
});
