import test from 'node:test';
import assert from 'node:assert/strict';
import {detectGaps,assign,runPilot,contribution,priority,PILOT_READINGS} from '../public/ground-network.mjs';
const weather=Array.from({length:7},(_,i)=>({date:`2026-11-${14+i}`,min:8,max:22,rain:0}));
const base={crop:'Domates',stage:'Çiçeklenme',water:'var',lat:38,soil:{value:null,source:'unknown'},irrigationDays:null,weather};
test('A3: farklı koşullardaki iki tarla farklı ilk görev alır ve nedeni hesaptan gelir',()=>{
 const dry=detectGaps({...base,moisture:{kind:'smap',theta:0.215}},{lastPhotoDay:'2026-11-13',today:'2026-11-13'});
 const unknownStage=detectGaps({...base,stage:'Emin değilim',moisture:{kind:'smap',theta:0.30}},{lastPhotoDay:'2026-11-13',today:'2026-11-13'});
 assert.notEqual(dry[0].id,unknownStage[0].id);
 assert.equal(unknownStage[0].id,'stage');
 assert.match(dry[0].why,/%\d+/);
 for(const g of dry)assert.equal(g.P,priority(g));
});
test('Fotoğraf boşluğu: etkin dönemde 10 günden eski fotoğraf ihtiyaç doğurur; yağış bölgesel ölçüm ister',()=>{
 const st={...base,moisture:{kind:'smap',theta:0.3}};
 assert.ok(!detectGaps(st,{lastPhotoDay:'2026-11-10',today:'2026-11-13'}).some(g=>g.id==='photo'));
 assert.ok(detectGaps(st,{lastPhotoDay:'2026-10-20',today:'2026-11-13'}).some(g=>g.id==='photo'));
 assert.ok(detectGaps(st,{lastPhotoDay:'2026-11-13',today:'2026-11-13',rainSoonMm:8}).some(g=>g.id==='gauge'&&g.scope==='region'));
});
test('Atama: araç ve yük sınırı süzülür; asıl ve yedek farklı kişilerdir',()=>{
 const a=assign('gauge');
 assert.ok(a.ranked.every(v=>v.equipment.includes('gauge')&&v.load<v.cap));
 assert.ok(!a.ranked.some(v=>v.id==='v4'),'yükü dolu gönüllü aday olmaz');
 assert.notEqual(a.primary.id,a.backup.id);
});
test('Pilot: yanıtsız teklif yedeğe geçer, çelişkide üçüncü okuma istenir, ortanca kabul edilir',()=>{
 const p=runPilot({readings:PILOT_READINGS});
 assert.ok(p.steps.some(s=>s.t==='expired'));assert.ok(p.conflict);
 assert.equal(p.values.length,3);assert.equal(p.accepted,6.8);
 const ok=runPilot({readings:{v1:6.4,v5:7.0,v2:6}});assert.equal(ok.conflict,false);assert.equal(ok.accepted,6.7);
 assert.equal(runPilot({readings:{}}).accepted,null,'kaçırılan okuma 0 sayılmaz');
});
test('Katkı: ölçüm tahmini doğrular ya da düzeltir',()=>{
 assert.match(contribution(6,6.8).text,/doğruladı/);assert.match(contribution(2,6.8).text,/fazla/);assert.equal(contribution(6,null),null);
});
