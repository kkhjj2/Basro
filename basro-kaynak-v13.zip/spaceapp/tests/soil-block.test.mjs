import test from 'node:test';import assert from 'node:assert/strict';
import {soilView,soilBlockHtml} from '../public/soil-block.mjs';
const r={TAW:84,RAW:34,Dr0:47,Dr7:58,amountMm:50,rootM:0.6,moistureSource:'smap'};
test('nem bilinmiyorsa blok gösterilmez',()=>{assert.equal(soilView({TAW:84,Dr0:null}),null);assert.equal(soilView(null),null);assert.equal(soilBlockHtml(null),'');});
test('şimdi, sulamadan sonra ve 7 gün sonra durumları motor sayılarından türetilir',()=>{
 const v=soilView(r);assert.deepEqual(v.states.map(s=>s.id),['now','after','week']);
 assert.equal(v.states[0].pct,44);assert.equal(v.states[0].stressed,true);
 assert.equal(v.states[1].pct,100);assert.equal(v.states[1].stressed,false);
 assert.equal(v.states[2].pct,31);assert.equal(v.stressPct,60);assert.equal(v.depthCm,60);});
test('sulama önerisi yoksa "sulamadan sonra" sekmesi yoktur',()=>{const v=soilView({...r,Dr0:10,Dr7:20,amountMm:null});assert.deepEqual(v.states.map(s=>s.id),['now','week']);assert.equal(v.states[0].stressed,false);});
test('html kaynak notunu ve ölçüm olmadığını söyler',()=>{const h=soilBlockHtml(soilView(r));assert.match(h,/NASA SMAP L4/);assert.match(h,/ölçüm değildir/);assert.match(h,/%44/);});
