import test from 'node:test';import assert from 'node:assert/strict';
import {encodeBody,decodeBody,assembleFeed,growthBoard,imageKind,hasExif} from '../public/social-wire.mjs';
const A='11111111-1111-4111-8111-111111111111',B='22222222-2222-4222-8222-222222222222';
const row=(id,body,created_at,extra={})=>({id,body,region_id:null,media_id:null,created_at,...extra});
test('üst bilgi gidip gelir; § ve kontrol karakterleri temizlenir',()=>{const b=encodeBody({k:'post',n:' Bilal§ ',d:'dev1',crop:'Domates',h:42.26},'Merhaba\u0007 §dünya');const {meta,text}=decodeBody(b);assert.equal(meta.n,'Bilal');assert.equal(meta.h,42.3);assert.equal(meta.crop,'Domates');assert.equal(text,'Merhaba dünya');});
test('eski düz gönderi düz gönderi sayılır',()=>{const {meta,text}=decodeBody('Eski gönderi');assert.equal(meta.k,'post');assert.ok(meta.legacy);assert.equal(text,'Eski gönderi');assert.equal(decodeBody('§bozuk\nmetin').meta.legacy,true);});
test('geçersiz üst gönderi kimliği ve saçma boy yazılmaz',()=>{const {meta}=decodeBody(encodeBody({k:'comment',n:'x',d:'d',re:'not-a-uuid',h:5},'a'));assert.equal(meta.re,undefined);assert.equal(meta.h,undefined);assert.equal(decodeBody(encodeBody({k:'post',d:'d',h:-3},'a')).meta.h,undefined);});
test('akış: beğeni sayılır, yorumlar eskiden yeniye, sahiplik cihaza göre',()=>{
 const rows=[row('l2',encodeBody({k:'like',d:'dev2',re:A}),'2026-11-14T10:05:00Z'),row('c2',encodeBody({k:'comment',n:'Mehmet',d:'dev2',re:A},'İkinci'),'2026-11-14T10:04:00Z'),row('c1',encodeBody({k:'comment',n:'Bilal',d:'dev1',re:A},'İlk'),'2026-11-14T10:03:00Z'),row('l1',encodeBody({k:'like',d:'dev1',re:A}),'2026-11-14T10:02:00Z'),row(A,encodeBody({k:'post',n:'Bilal',d:'dev1'},'Gönderi'),'2026-11-14T10:00:00Z',{media_id:'m1'}),row('x',encodeBody({k:'like',d:'dev1',re:B}),'2026-11-14T09:00:00Z')];
 const {posts}=assembleFeed(rows,{device:'dev2'});assert.equal(posts.length,1);const p=posts[0];
 assert.equal(p.likes,2);assert.equal(p.liked,true);assert.equal(p.mine,false);assert.equal(p.photo,true);assert.deepEqual(p.comments.map(c=>c.body),['İlk','İkinci']);assert.equal(p.comments[1].mine,true);
 assert.ok(!('_d' in p)&&!JSON.stringify(posts).includes('dev1'));
 assert.equal(assembleFeed(rows,{device:''}).posts[0].liked,false);});
test('bölge süzgeci yalnız gönderilere uygulanır; yorumlar korunur',()=>{const rows=[row('c',encodeBody({k:'comment',n:'a',d:'d',re:A},'yorum'),'2026-11-14T10:01:00Z'),row(A,encodeBody({k:'post',n:'a',d:'d'},'ilçe'),'2026-11-14T10:00:00Z',{region_id:'dogansehir'}),row(B,encodeBody({k:'post',n:'b',d:'e'},'başka'),'2026-11-14T09:00:00Z',{region_id:'konya'})];const r=assembleFeed(rows,{region:'dogansehir',regionName:id=>id==='dogansehir'?'Doğanşehir, Malatya':null});assert.equal(r.posts.length,1);assert.equal(r.posts[0].region,'Doğanşehir, Malatya');assert.equal(r.posts[0].comments.length,1);});
test('haftalık gelişim: son iki ölçümden cm/hafta, hızlıdan yavaşa',()=>{
 const mk=(id,d,n,h,at,crop='Domates')=>row(id,encodeBody({k:'post',n,d,crop,h},'ölçüm'),at);
 const rows=[mk('1','bilal','Bilal',54,'2026-11-14T08:00:00Z'),mk('2','bilal','Bilal',40,'2026-11-07T08:00:00Z'),mk('3','memed','Memed',47,'2026-11-14T08:00:00Z'),mk('4','memed','Memed',41,'2026-11-11T08:00:00Z'),mk('5','yeni','Ayşe',30,'2026-11-14T08:00:00Z'),mk('6','bilal','Bilal',50,'2026-11-14T02:00:00Z')];
 const g=assembleFeed(rows).growth;assert.deepEqual(g.map(x=>x.author),['Bilal','Memed','Ayşe']);assert.equal(g[0].perWeek,14);assert.equal(g[1].perWeek,14);assert.equal(g[1].days,3);assert.equal(g[2].perWeek,null);});
test('farklı ürünler ayrı izlenir; boy ya da ürün yoksa tabloya girmez',()=>{const g=growthBoard([{_d:'a',crop:'Domates',heightCm:10,createdAt:'2026-11-14T00:00:00Z',author:'A'},{_d:'a',crop:'Biber',heightCm:20,createdAt:'2026-11-14T00:00:00Z',author:'A'},{_d:'a',crop:null,heightCm:5,createdAt:'2026-11-14T00:00:00Z'},{_d:'a',crop:'Domates',heightCm:null,createdAt:'2026-11-14T00:00:00Z'}]);assert.equal(g.length,2);});
test('görsel imzası ve EXIF denetimi',()=>{assert.equal(imageKind(Uint8Array.from([0xFF,0xD8,0xFF,0xE0,0])),'image/jpeg');assert.equal(imageKind(Uint8Array.from([0x89,0x50,0x4E,0x47,0,0,0,0,0])),'image/png');assert.equal(imageKind(Uint8Array.from([1,2,3,4,5])),null);assert.equal(hasExif(Uint8Array.from([0xFF,0xD8,0xFF,0xE1,0,16,0x45,0x78,0x69,0x66,0,0,1,2])),true);assert.equal(hasExif(Uint8Array.from([0xFF,0xD8,0xFF,0xE0,0,16,0x4A,0x46,0x49,0x46,0,1,1,1])),false);});
import {regionSummary,K_PANEL} from '../public/social-wire.mjs';
test('müdür özeti: sayılar, sinyaller, k-anonim ürün ortalaması; kişi verisi yok',()=>{
 const now=Date.parse('2026-11-14T12:00:00Z'),at=d=>new Date(now-d*864e5).toISOString();let n=0;
 const mk=(d,name,h,daysAgo,text,region='dogansehir',crop='Domates',extra={})=>({id:`0000000${++n}-0000-4000-8000-000000000000`.slice(-36),body:encodeBody({k:'post',n:name,d,crop,h},text),region_id:region,media_id:null,created_at:at(daysAgo),...extra});
 const rows=[mk('a','Bilal',54,0.2,'Gece don vurdu, yapraklar üşüdü.',undefined,undefined,{media_id:'m'}),mk('a','Bilal',40,6,'ölçüm'),mk('b','Memed',47,0.5,'Yaprakta leke var, kırağı da düştü.'),mk('b','Memed',41,4,'ölçüm'),mk('c','Ayşe',50,1,'Hasat yaklaştı'),mk('c','Ayşe',44,5,'ölçüm'),mk('d','Ali',30,1,'Konya da yağmur','konya'),mk('e','Eski',20,20,'eski gönderi don')];
 rows.push({id:'c1',body:encodeBody({k:'comment',n:'x',d:'z',re:rows[0].id},'yorum'),region_id:null,media_id:null,created_at:at(0.1)},{id:'l1',body:encodeBody({k:'like',d:'z',re:rows[0].id}),region_id:null,media_id:null,created_at:at(0.1)},{id:'l2',body:encodeBody({k:'like',d:'z',re:rows[6].id}),region_id:null,media_id:null,created_at:at(0.1)});
 const s=regionSummary(rows,{now,region:'dogansehir'});
 assert.equal(s.activeFarmers,3);assert.equal(s.posts,6);assert.equal(s.photos,1);assert.equal(s.measurements,6);assert.equal(s.comments,1);assert.equal(s.likes,1);
 assert.deepEqual(s.signals.map(x=>[x.id,x.posts,x.farmers]),[['don',2,2],['hastalik',1,1],['hasat',1,1]]);
 assert.equal(K_PANEL,3);assert.equal(s.cropGrowth[0].farmers,3);assert.ok(s.cropGrowth[0].avgPerWeek>0);
 assert.equal(s.daily.length,7);assert.equal(s.daily.reduce((a,b)=>a+b.posts,0),6);
 const j=JSON.stringify(s);assert.ok(!j.includes('Bilal')&&!j.includes('"a"'));
 const all=regionSummary(rows,{now});assert.equal(all.activeFarmers,4);assert.equal(all.likes,2);
 const two=regionSummary(rows.filter(r=>!r.body.includes('"d":"c"')),{now,region:'dogansehir'});assert.equal(two.cropGrowth[0].avgPerWeek,null);
});
import {masteryBoard} from '../public/social-wire.mjs';
test('ürün ustalığı: son bildirilen verime göre sıra, unvanlar, cihaz bilgisi sızmaz',()=>{
 const mk=(id,d,n,y,at,crop='Domates',h)=>row(id,encodeBody({k:'post',n,d,crop,y,h},'hasat'),at,{region_id:'dogansehir'});
 const rows=[mk('1','ahmet','Ahmet',7400,'2026-11-14T08:00:00Z'),mk('2','bilal','Bilal',6900,'2026-11-13T08:00:00Z'),mk('3','bilal','Bilal',9999,'2026-11-01T08:00:00Z'),mk('4','memed','Memed',5800,'2026-11-12T08:00:00Z'),mk('5','ayse','Ayşe',undefined,'2026-11-14T08:00:00Z','Biber',30),mk('6','ayse','Ayşe',undefined,'2026-11-07T08:00:00Z','Biber',16),mk('7','x','Kötü',99999999,'2026-11-14T08:00:00Z')];
 const {mastery}=assembleFeed(rows,{device:'bilal'});const dom=mastery.find(m=>m.crop==='Domates'),bib=mastery.find(m=>m.crop==='Biber');
 assert.equal(dom.metric,'yield');assert.deepEqual(dom.rows.map(r=>[r.rank,r.author,r.value,r.title]),[[1,'Ahmet',7400,'Usta'],[2,'Bilal',6900,'Kalfa'],[3,'Memed',5800,'Çırak']]);
 assert.equal(dom.rows[1].mine,true);assert.equal(dom.rows[0].mine,false);
 assert.equal(bib.metric,'growth');assert.equal(bib.rows[0].value,14);assert.equal(bib.rows[0].author,'Ayşe');
 assert.ok(!JSON.stringify(mastery).includes('"ahmet"')&&!JSON.stringify(mastery).includes('_d'));
 assert.equal(masteryBoard([]).length,0);
});
