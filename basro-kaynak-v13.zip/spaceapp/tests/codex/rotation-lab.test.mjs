import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluateRotations,ROTATION_METHOD_VERSION,ROTATION_PROFILES} from '../../public/rotation-lab-core.mjs';
import {validateObservation,acceptedEvidence} from '../../public/observation-core.mjs';

const farm = {crop:'Buğday',water:'yok'};
const fieldEvidence = {previousCrop:'Nohut',soilTexture:'loam',standingWaterHours:0};
const evaluate = extra => evaluateRotations({farm,fieldEvidence,...extra});

test('enumerates deterministic future three-year candidates with stable IDs and explicit previous crop', () => {
  const a = evaluate(), b = evaluate();
  assert.deepEqual(a,b);
  assert.equal(a.methodVersion,ROTATION_METHOD_VERSION);
  assert.equal(a.candidates.length,64);
  assert.equal(new Set(a.candidates.map(c => c.id)).size,64);
  assert.deepEqual(a.previousSequence,['Nohut']);
  assert.ok(a.candidates.every(c => c.sequence.length === 3 && c.sequenceLabels.every(l => l.tr && l.en)));
  assert.ok(a.candidates.some(c => c.feasibility === 'provisional'));
  assert.ok(a.candidates.every(c => c.feasibility !== 'feasible'));
});

test('rejects consecutive cereals, consecutive pulses and a family conflict across the history boundary', () => {
  const result = evaluate();
  const get = id => result.candidates.find(c => c.id === id);
  assert.equal(get('rotation-wheat-barley-lentil').feasibility,'infeasible');
  assert.equal(get('rotation-wheat-chickpea-lentil').feasibility,'infeasible');
  const previousConflict = get('rotation-lentil-wheat-chickpea');
  assert.equal(previousConflict.feasibility,'infeasible');
  assert.ok(previousConflict.excludedReasons.some(r => r.planYear === 1 && r.from === 'chickpea' && r.to === 'lentil'));
  assert.equal(previousConflict.rank,null);
  assert.equal(previousConflict.pareto,false);
  assert.ok(result.preferredIds.every(id => get(id).feasibility !== 'infeasible'));
});

test('missing or malformed evidence stays unknown; season input is never silently promoted to accepted evidence', () => {
  const result = evaluateRotations({farm,seasonPlan:{inputs:{previousCrop:'Nohut',texture:'loam',drainage:'good'}}});
  assert.equal(result.previousSequence.length,0);
  assert.deepEqual(result.missingEvidence.map(m => m.id),['previousCrop','standingWaterHours','soilTexture']);
  assert.ok(result.candidates.filter(c => c.feasibility !== 'infeasible').every(c => c.feasibility === 'needs_evidence'));
  const malformed = evaluate({fieldEvidence:{previousCrop:'not-a-crop',standingWaterHours:'0',soilTexture:'constructor'}});
  assert.equal(malformed.missingEvidence.length,3);
  assert.deepEqual(malformed.candidates.find(c => c.excludedReasons.length === 0).evidence.find(e => e.id === 'field-inputs').values,{previousCrop:null,soilTexture:null,standingWaterHours:null});
});

test('positive accepted ponding triggers review for both pulses without inventing an hours tolerance threshold', () => {
  const result = evaluate({fieldEvidence:{...fieldEvidence,standingWaterHours:2}});
  for (const id of ['rotation-wheat-chickpea-barley','rotation-wheat-lentil-barley']) {
    const candidate = result.candidates.find(c => c.id === id);
    assert.equal(candidate.feasibility,'needs_evidence');
    assert.ok(candidate.tradeoffs.some(t => t.en.includes('Both chickpea and lentil')));
    assert.ok(candidate.criteria.feasibility < evaluate().candidates.find(c => c.id === id).criteria.feasibility);
  }
  assert.ok(result.missingEvidence.some(m => m.id === 'drainageAssessment'));
  assert.equal(evaluate().missingEvidence.length,0);
  assert.equal(evaluate().candidates.find(c => c.id === 'rotation-wheat-lentil-barley').feasibility,'provisional');
});

test('uncertainty spanning zero remains unresolved for zero and positive standing-water reports', () => {
  const observation = validateObservation({observationType:'standing_water_duration',value:0,unit:'hours',sourceType:'farmer_report',method:'visual_after_rain'},{fieldId:'rotation-test-field',now:new Date('2026-11-01T00:00:00Z')});
  const projected = acceptedEvidence([observation],{fieldId:'rotation-test-field'});
  assert.equal(observation.validationStatus,'accepted');
  assert.deepEqual([projected.uncertainty.standingWaterHours.lower,projected.uncertainty.standingWaterHours.upper],[0,2]);
  const integrated = evaluate({fieldEvidence:{...fieldEvidence,...projected}});
  assert.ok(integrated.missingEvidence.some(m => m.id === 'drainageUncertainty'));
  assert.ok(integrated.candidates.filter(c => c.feasibility !== 'infeasible').every(c => c.feasibility === 'needs_evidence'));
  for (const standingWaterHours of [0,1]) {
    const result = evaluate({fieldEvidence:{...fieldEvidence,standingWaterHours,uncertainty:{standingWaterHours:{lower:0,upper:2,kind:'heuristic_report_range'}}}});
    assert.ok(result.missingEvidence.some(m => m.id === 'drainageUncertainty'));
    for (const id of ['rotation-wheat-chickpea-barley','rotation-wheat-lentil-barley']) {
      const candidate = result.candidates.find(c => c.id === id);
      assert.equal(candidate.feasibility,'needs_evidence');
      assert.ok(candidate.tradeoffs.some(t => t.en.includes('Neither safe drainage nor definite waterlogging')));
      assert.deepEqual(candidate.evidence.find(e => e.id === 'field-inputs').uncertainty.standingWaterHours,{lower:0,upper:2,kind:'heuristic_report_range'});
    }
  }
  const invalid = evaluate({fieldEvidence:{...fieldEvidence,uncertainty:{standingWaterHours:{lower:2,upper:1}}}});
  assert.ok(invalid.missingEvidence.some(m => m.id === 'drainageUncertainty'));
  const positiveRange = evaluate({fieldEvidence:{...fieldEvidence,standingWaterHours:10,uncertainty:{standingWaterHours:{lower:8,upper:12}}}});
  assert.ok(positiveRange.missingEvidence.some(m => m.id === 'drainageAssessment'));
});

test('preferences change the preferred Pareto alternatives without changing scores or hard constraints', () => {
  const soil = evaluate({priorities:{water:0,soil:1,feasibility:0}});
  const familiar = evaluate({priorities:{water:0,soil:0,feasibility:1}});
  assert.notDeepEqual(soil.preferredIds,familiar.preferredIds);
  assert.ok(soil.preferredIds.every(id => new Set(soil.candidates.find(c => c.id === id).cropIds).size === 3));
  assert.ok(familiar.preferredIds.every(id => familiar.candidates.find(c => c.id === id).cropIds.filter(c => c === 'wheat').length === 2));
  assert.ok(soil.preferredIds.every(id => soil.candidates.find(c => c.id === id).pareto));
  for (const candidate of soil.candidates) assert.deepEqual(candidate.criteria,familiar.candidates.find(c => c.id === candidate.id).criteria);
  const water = evaluate({priorities:{water:1,soil:0,feasibility:0}});
  assert.ok(water.preferredIds.every(id => water.candidates.find(c => c.id === id).cropIds.includes('lentil')));
});

test('Pareto flags agree with nondominance of the full three-criterion vector', () => {
  const candidates = evaluate().candidates.filter(c => c.feasibility !== 'infeasible');
  for (const candidate of candidates) {
    const dominated = candidates.some(other => ['water','soil','feasibility'].every(k => other.criteria[k] >= candidate.criteria[k]) && ['water','soil','feasibility'].some(k => other.criteria[k] > candidate.criteria[k]));
    assert.equal(candidate.pareto,!dominated,candidate.id);
  }
  assert.ok(candidates.some(c => !c.pareto));
});

test('scenarios remain qualitative stress tests, distinct from regional seasonal model context', () => {
  const result = evaluate({seasonPlan:{available:true,scenario:'model',method:'agro-season-1.0',chosen:{month:'2026-12',temperature:{direction:'warm'},rain:{direction:'dry'}}}});
  assert.deepEqual(result.scenarioDefinitions.map(s => s.id),['reference','dry','warm','combined']);
  assert.ok(result.scenarioDefinitions.every(s => s.probability === null && s.magnitude === null));
  assert.equal(result.scenarioDefinitions[0].reference.kind,'regional_seasonal_context');
  assert.ok(result.candidates.every(c => c.scenarioResults.every(s => s.score === null && s.probability === null)));
  const noForecast = evaluate({seasonPlan:{available:true,scenario:'dry',hypothetical:true,chosen:{month:'2026-12'}}});
  assert.equal(noForecast.scenarioDefinitions[0].reference.kind,'no_validated_climate_reference');
});

test('orchard comparisons retain the existing trees and compare floor management only', () => {
  const result = evaluate({farm:{crop:'Elma',water:'var'}});
  assert.equal(result.kind,'orchard');
  assert.equal(result.candidates.length,3);
  assert.ok(result.candidates.every(c => c.retainsTrees && c.retainedCrop === 'Elma' && c.kind === 'orchard_floor'));
  assert.ok(result.candidates.every(c => c.feasibility === 'needs_evidence'));
  assert.ok(result.preferredIds.length > 0);
});

test('unsupported crops do not receive invented profiles and English crop aliases resolve', () => {
  const result = evaluate({farm:{crop:'Domates'}});
  assert.equal(result.candidates.length,0);
  assert.equal(result.missingEvidence[0].id,'supportedCropProfile');
  assert.equal(evaluate({farm:{crop:'Wheat'},fieldEvidence:{...fieldEvidence,previousCrop:'Chickpea'}}).candidates.length,64);
  assert.ok(Object.values(ROTATION_PROFILES).every(p => p.botanicalFamily && p.sourceIds.length));
});

test('does not mutate inputs and safely handles invalid, zero or very large priorities', () => {
  const input = {farm:{...farm},fieldEvidence:{...fieldEvidence},priorities:{water:0,soil:0,feasibility:0}};
  const before = structuredClone(input);
  evaluateRotations(input);
  assert.deepEqual(input,before);
  for (const priorities of [{water:NaN,soil:-2,feasibility:Infinity},{water:Number.MAX_VALUE,soil:Number.MAX_VALUE,feasibility:Number.MAX_VALUE},null]) {
    const result = evaluate({priorities});
    assert.ok(Object.values(result.priorities).every(Number.isFinite));
    assert.ok(result.candidates.filter(c => c.rank !== null).every(c => Number.isFinite(c.utility)));
  }
});
