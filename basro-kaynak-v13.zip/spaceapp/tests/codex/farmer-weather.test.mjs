import test from 'node:test';
import assert from 'node:assert/strict';
import {weatherParams,weatherCondition,weatherSummary} from '../../public/farmer-core.mjs';

const now=new Date('2026-10-31T11:45:00Z');
function response(){return {timezone:'Europe/Istanbul',utc_offset_seconds:10800,current_units:{temperature_2m:'°C',apparent_temperature:'°C',wind_speed_10m:'km/h'},current:{time:'2026-10-31T14:45',temperature_2m:14.6,apparent_temperature:13.1,weather_code:3,is_day:1,wind_speed_10m:8},daily_units:{temperature_2m_min:'°C',precipitation_sum:'mm',wind_speed_10m_max:'km/h'},daily:{time:['2026-10-31','2026-11-01','2026-11-02'],temperature_2m_min:[5,4,-1],temperature_2m_max:[18,17,12],weather_code:[3,61,71],precipitation_sum:[0,6,2],precipitation_probability_max:[0,80,null],wind_speed_10m_max:[12,15,20]}};}
test('current temperature, cloudy sky and frost are independent facts',()=>{
 const s=weatherSummary(response(),null,now);assert.equal(s.available,true);assert.equal(s.current.temperature,14.6);assert.equal(s.current.apparent,13.1);assert.equal(weatherCondition(s.current.code).label,'Çok bulutlu');assert.equal(s.frost,true);assert.equal(s.frostDay,'2026-11-02');assert.equal(s.rows[0].rainProbability,0);assert.equal(s.rows[2].rainProbability,null);
});
test('old or future current values are not displayed as current weather',()=>{
 for(const stamp of ['2026-10-30T14:45','2026-10-31T11:00','2026-10-31T18:00']){const r=response();r.current.time=stamp;const s=weatherSummary(r,null,now);assert.equal(s.available,true);assert.equal(s.current,null);assert.equal(s.today.max,18);}
});
test('temperature zero is a value and missing data is not zero',()=>{
 const r=response();r.current.temperature_2m=0;r.current.apparent_temperature=null;r.current.weather_code=null;const s=weatherSummary(r,null,now);assert.equal(s.current.temperature,0);assert.equal(s.current.apparent,null);assert.equal(weatherCondition(s.current.code).label,'Gökyüzü bilgisi yok');
});
test('unexpected units cannot be silently labelled as Celsius or kilometres per hour',()=>{
 let r=response();r.current_units.temperature_2m='°F';assert.equal(weatherSummary(r,null,now).current,null);
 r=response();r.daily_units.temperature_2m_min='°F';assert.equal(weatherSummary(r,null,now).available,false);
 r=response();r.daily_units.wind_speed_10m_max='m/s';assert.equal(weatherSummary(r,null,now).available,false);
});
test('the selected location’s date is used across midnight',()=>{
 const r=response();r.timezone='Asia/Tokyo';r.utc_offset_seconds=32400;r.current.time='2026-11-01T08:30';r.daily.time=['2026-11-01','2026-11-02','2026-11-03'];const s=weatherSummary(r,null,new Date('2026-10-31T23:30:00Z'));assert.equal(s.today.date,'2026-11-01');assert.equal(s.current.temperature,14.6);
});
test('WMO rain, snow, fog and night codes use their actual meanings',()=>{
 assert.equal(weatherCondition(0,0).icon,'☾');assert.equal(weatherCondition(2).label,'Parçalı bulutlu');assert.equal(weatherCondition(61).label,'Hafif yağmurlu');assert.equal(weatherCondition(71).label,'Hafif kar yağışlı');assert.equal(weatherCondition(45).label,'Sisli');assert.equal(weatherCondition(97).label,'Gök gürültülü');assert.equal(weatherCondition(999).label,'Gökyüzü bilgisi yok');
});
test('the request explicitly selects current weather, daily sky and expected units',()=>{
 const p=weatherParams(38.08574,37.87116);assert.equal(p.get('latitude'),'38.08574');assert.ok(p.get('current').includes('weather_code'));assert.ok(p.get('daily').includes('weather_code'));assert.equal(p.get('wind_speed_unit'),'kmh');assert.equal(p.get('temperature_unit'),'celsius');assert.equal(p.get('forecast_days'),'7');
});
