import test from 'node:test';
import assert from 'node:assert/strict';
import {validateObservation,acceptedEvidence,OBSERVATION_METHOD} from '../../public/observation-core.mjs';
import {evaluateRotations,ROTATION_METHOD_VERSION,ROTATION_PARAMETER_VERSION} from '../../public/rotation-lab-core.mjs';
import {createDecisionSnapshot,compareDecisions,DECISION_HISTORY_METHOD} from '../../public/decision-history.mjs';
import {selectDiscoveryQuestion,DISCOVERY_METHOD} from '../../public/discovery-core.mjs';

const now=new Date('2026-11-01T12:00:00Z');
const farm={id:'integration-field',userId:'farmer-custom-owner',crop:'Buğday',water:'yok',lat:38.3,lon:38.2};
const equalPriorities={water:1,soil:1,feasibility:1};
const options={fieldId:farm.id,userId:farm.userId,now};
const report=(input,overrides={})=>validateObservation({observedAt:'2026-10-31T10:00:00Z',sourceType:'farmer_report',...input},{...options,...overrides});
const previous=(value='Nohut',overrides={})=>report({id:'crop-history',observationType:'previous_crop',value,unit:'crop',method:'farmer_recall'},overrides);
const ponding=(value=24,overrides={})=>report({id:'ponding-report',observationType:'standing_water_duration',value,unit:'hours',method:'visual_after_rain'},overrides);
const texture=()=>report({id:'texture-report',observationType:'soil_texture',value:'loam',unit:'qualitative',method:'feel'});
const candidate=(result,id)=>result.candidates.find(row=>row.id===id);
function calculate(observations=[],priorities=equalPriorities){
 const fieldEvidence=acceptedEvidence(observations,options);
 const rotationResult=evaluateRotations({farm,fieldEvidence,priorities});
 const snapshot=createDecisionSnapshot({farm,observations,evidence:fieldEvidence,rotationResult,priorities,now});
 return {fieldEvidence,rotationResult,snapshot};
}

test('unknown baseline remains provisional evidence work; pending reports change neither computed comparison nor history',()=>{
 const baseline=calculate();
 assert.deepEqual(baseline.fieldEvidence,{});
 assert.deepEqual(baseline.rotationResult.missingEvidence.map(row=>row.id),['previousCrop','standingWaterHours','soilTexture']);
 assert.equal(baseline.rotationResult.candidates.length,64);
 assert.ok(baseline.rotationResult.candidates.filter(row=>row.feasibility!=='infeasible').every(row=>row.feasibility==='needs_evidence'));
 const pending=[previous('unknown'),ponding('unknown')];
 assert.ok(pending.every(row=>row.validationStatus==='pending'&&!row.influence.eligible));
 const updated=calculate(pending);
 assert.deepEqual(updated.rotationResult,baseline.rotationResult);
 assert.deepEqual(updated.snapshot.evidence,{});
 assert.equal(updated.snapshot.inputFingerprint,baseline.snapshot.inputFingerprint);
 assert.equal(updated.snapshot.decisionFingerprint,baseline.snapshot.decisionFingerprint);
 assert.equal(compareDecisions(baseline.snapshot,updated.snapshot).materiality,'none');
 assert.equal(updated.snapshot.userId,farm.userId);
});

test('accepted crop history changes the real boundary rule; accepted ponding changes screening without certifying drainage',()=>{
 const baseline=calculate(),history=previous(),water=ponding(24);
 assert.equal(history.validationStatus,'accepted');assert.equal(water.validationStatus,'accepted');
 const updated=calculate([history,water]);
 assert.equal(updated.fieldEvidence.previousCrop,'Nohut');assert.equal(updated.fieldEvidence.standingWaterHours,24);
 assert.deepEqual(updated.rotationResult.previousSequence,['Nohut']);
 const boundary='rotation-lentil-wheat-chickpea';
 assert.equal(candidate(baseline.rotationResult,boundary).feasibility,'needs_evidence');
 const excluded=candidate(updated.rotationResult,boundary);
 assert.equal(excluded.feasibility,'infeasible');
 assert.ok(excluded.excludedReasons.some(reason=>reason.code==='consecutive_family'&&reason.planYear===1&&reason.from==='chickpea'&&reason.to==='lentil'));
 const retained='rotation-wheat-lentil-barley';
 assert.ok(candidate(updated.rotationResult,retained).criteria.feasibility<candidate(baseline.rotationResult,retained).criteria.feasibility);
 assert.ok(updated.rotationResult.missingEvidence.some(row=>row.id==='drainageAssessment'));
 assert.ok(!updated.rotationResult.missingEvidence.some(row=>row.id==='previousCrop'||row.id==='standingWaterHours'));
 assert.ok(candidate(updated.rotationResult,retained).tradeoffs.some(row=>row.en.includes('Both chickpea and lentil')));
 assert.deepEqual(updated.snapshot.provenance.observationIds,['crop-history','ponding-report']);
 assert.ok(['moderate','material'].includes(compareDecisions(baseline.snapshot,updated.snapshot).materiality));
 assert.deepEqual(compareDecisions(baseline.snapshot,updated.snapshot).changedInputs,['evidence']);
 assert.equal(updated.fieldEvidence.drainage,undefined);
});

test('custom-owner evidence stays isolated through computation, discovery and immutable snapshots',()=>{
 const owned=previous(),otherOwner=ponding(800,{userId:'another-owner'}),otherField=ponding(400,{fieldId:'another-field'});
 const rows=[owned,otherOwner,otherField],updated=calculate(rows);
 assert.equal(updated.fieldEvidence.previousCrop,'Nohut');assert.equal(updated.fieldEvidence.standingWaterHours,undefined);
 assert.deepEqual(updated.snapshot.observations.map(row=>row.id),['crop-history']);
 assert.equal(selectDiscoveryQuestion({farm,observations:rows,now}).type,'standing_water_duration');
 const resultCopy=structuredClone(updated.rotationResult),farmCopy={...farm};
 const snapshot=createDecisionSnapshot({farm:farmCopy,observations:rows,rotationResult:resultCopy,priorities:equalPriorities,now});
 owned.value='Arpa';resultCopy.candidates[0].criteria.water=0;farmCopy.crop='Domates';
 assert.equal(snapshot.evidence.previousCrop,'Nohut');assert.equal(snapshot.farm.crop,'Buğday');
 assert.deepEqual(snapshot.rotationResult,updated.rotationResult);
 assert.throws(()=>{snapshot.rotationResult.candidates[0].criteria.water=0;},TypeError);
 assert.throws(()=>{snapshot.observations[0].value='Arpa';},TypeError);
 const differentOwner=createDecisionSnapshot({farm:{...farm,userId:'another-owner'},rotationResult:updated.rotationResult,now});
 assert.throws(()=>compareDecisions(snapshot,differentOwner),/different owners or fields/);
});

test('discovery unknown answers suppress repeat prompts while leaving the computed decision unchanged',()=>{
 const baseline=calculate(),rows=[],types=[];
 for(let i=0;i<3;i++){
  const question=selectDiscoveryQuestion({farm,observations:rows,now});
  assert.ok(question.question.tr&&question.question.en&&question.why.tr&&question.why.en);
  assert.equal(question.selectionMethod,DISCOVERY_METHOD);assert.equal(question.userId,farm.userId);
  assert.ok(!types.includes(question.type));types.push(question.type);
  const skipped=report({...question,id:'skipped-'+question.type,observationType:question.type,value:'unknown'});
  assert.equal(skipped.validationStatus,'pending');rows.push(skipped);
  const next=calculate(rows);
  assert.deepEqual(next.rotationResult,baseline.rotationResult);
  assert.equal(compareDecisions(baseline.snapshot,next.snapshot).materiality,'none');
 }
 assert.deepEqual(types,['standing_water_duration','previous_crop','soil_texture']);
 assert.equal(selectDiscoveryQuestion({farm,observations:rows,now:new Date('2027-02-01T12:00:00Z')}),null);
 assert.equal(selectDiscoveryQuestion({farm:{...farm,userId:'another-owner'},observations:rows,now}).type,'standing_water_duration');
});

test('priorities change actual preferred alternatives and history without rewriting evidence or agronomic scores',()=>{
 const rows=[previous(),ponding(0),texture()];
 assert.ok(rows.every(row=>row.validationStatus==='accepted'));
 const diversity=calculate(rows,{water:0,soil:1,feasibility:0}),familiar=calculate(rows,{water:0,soil:0,feasibility:1});
 assert.equal(diversity.fieldEvidence.standingWaterHours,0);
 assert.equal(diversity.fieldEvidence.uncertainty.standingWaterHours.lower,0);
 assert.equal(diversity.fieldEvidence.uncertainty.standingWaterHours.upper,2);
 assert.deepEqual(diversity.rotationResult.missingEvidence.map(row=>row.id),['drainageUncertainty']);
 assert.ok(diversity.rotationResult.candidates.filter(row=>row.feasibility!=='infeasible').every(row=>row.feasibility==='needs_evidence'));
 assert.notDeepEqual(diversity.rotationResult.preferredIds,familiar.rotationResult.preferredIds);
 for(const row of diversity.rotationResult.candidates){const other=candidate(familiar.rotationResult,row.id);assert.deepEqual(row.criteria,other.criteria);assert.equal(row.feasibility,other.feasibility);}
 assert.ok(diversity.rotationResult.preferredIds.every(id=>new Set(candidate(diversity.rotationResult,id).cropIds).size===3));
 assert.ok(familiar.rotationResult.preferredIds.every(id=>candidate(familiar.rotationResult,id).cropIds.filter(crop=>crop==='wheat').length===2));
 const change=compareDecisions(diversity.snapshot,familiar.snapshot);
 assert.equal(change.materiality,'material');assert.equal(change.preferredChanged,true);assert.deepEqual(change.changedInputs,['priorities']);
 assert.deepEqual(diversity.snapshot.evidence,familiar.snapshot.evidence);
});

test('a saved accepted-evidence snapshot can recompute the same comparison with method and parameter provenance intact',()=>{
 const original=calculate([previous(),ponding(0),texture()],{water:2,soil:3,feasibility:1}).snapshot;
 const restored=JSON.parse(JSON.stringify(original));
 const fieldEvidence=acceptedEvidence(restored.observations,{fieldId:restored.fieldId,userId:restored.userId});
 const recalculated=evaluateRotations({farm:restored.farm,fieldEvidence,priorities:restored.priorities});
 const replay=createDecisionSnapshot({farm:restored.farm,observations:restored.observations,rotationResult:recalculated,priorities:restored.priorities,now:new Date('2026-11-02T12:00:00Z')});
 assert.deepEqual(recalculated,original.rotationResult);
 assert.equal(replay.inputFingerprint,original.inputFingerprint);assert.equal(replay.decisionFingerprint,original.decisionFingerprint);
 assert.equal(replay.method,DECISION_HISTORY_METHOD);assert.equal(replay.provenance.rotationMethod,ROTATION_METHOD_VERSION);assert.equal(replay.provenance.parameterVersion,ROTATION_PARAMETER_VERSION);
 assert.ok(Object.values(replay.evidence.provenance).every(row=>row.validationMethod===OBSERVATION_METHOD));
 assert.deepEqual(replay.provenance,original.provenance);
 assert.equal(replay.provenance.forecastModelRun,null);assert.equal(replay.provenance.forecastRunKnown,false);
 assert.equal(compareDecisions(original,replay).materiality,'none');
});
