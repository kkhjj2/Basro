import test from 'node:test';
import assert from 'node:assert/strict';
import {parseSeasonal,parseNasaClimate,buildSeasonPlan,rotationOptions,nextMonths,normalizeSeasonInputs} from '../../public/season-core.mjs';
import {buildWorklist} from '../../public/farmer-core.mjs';
import {fetchSeasonEvidence} from '../../public/season-data.mjs';
const now=new Date('2026-10-31T12:00:00Z'),opts={now,retrievedAt:now.toISOString()};
function rawSeason(){
 const d={time:Array.from({length:30},(_,i)=>'2026-11-'+String(i+1).padStart(2,'0'))},du={time:'iso8601'};
 for(let n=0;n<51;n++){const s=n?'_member'+String(n).padStart(2,'0'):'';d['temperature_2m_mean'+s]=Array(30).fill(6+(n-25)*.1);d['precipitation_sum'+s]=Array(30).fill(1+n*.04);du['temperature_2m_mean'+s]='°C';du['precipitation_sum'+s]='mm';}
 return {latitude:38.08,longitude:38.09,daily:d,daily_units:du,monthly_units:{temperature_2m_mean:'°C',temperature_2m_anomaly:'K',precipitation_mean:'mm',precipitation_anomaly:'mm'},monthly:{time:['2026-11-01'],temperature_2m_mean:[6],temperature_2m_anomaly:[2],precipitation_mean:[60],precipitation_anomaly:[-40]}};
}
function rawNasa(){const p={T2M:{},PRECTOTCORR:{}};for(let y=1991;y<=2020;y++)for(let m=1;m<=12;m++){const k=y+String(m).padStart(2,'0');p.T2M[k]=10;p.PRECTOTCORR[k]=2;}return {parameters:{T2M:{units:'C'},PRECTOTCORR:{units:'mm/day'}},properties:{parameter:p}};}
const farm={id:'farm_demo',landId:'farm_demo',crop:'Buğday',stage:'Henüz ekmedim',water:'kısıtlı',locationKind:'field',goal:'planning'},weather={available:false};
test('future complete months use paired members and model climatology for the anomaly signal',()=>{
 const s=parseSeasonal(rawSeason(),opts),m=s.months[0];assert.equal(m.month,'2026-11');assert.equal(m.members,51);assert.equal(m.modelClimate.temperature,4);assert.equal(m.modelClimate.rain,100);assert.equal(m.rain.change,-40);assert.equal(m.temperature.direction,'warm');assert.equal(m.rain.direction,'dry');assert.equal(m.rain.dry,42/51);assert.ok(m.temperature.low<m.temperature.high);
});
test('null, sentinel and negative precipitation reject that entire member instead of filling zero',()=>{
 const r=rawSeason();r.daily.precipitation_sum[4]=null;r.daily.precipitation_sum_member01[6]=-.1;r.daily.temperature_2m_mean_member02[9]=-999;const m=parseSeasonal(r,opts).months[0];assert.equal(m.members,48);assert.ok(m.rain.mean>0);
 for(let n=3;n<14;n++)r.daily['precipitation_sum_member'+String(n).padStart(2,'0')][1]=null;
 assert.throws(()=>parseSeasonal(r,opts),/yeterli/);
});
test('partial months, duplicate days, wrong units and stale snapshots never create a forecast',()=>{
 const p=rawSeason();p.daily.time.pop();assert.throws(()=>parseSeasonal(p,opts),/tam aylar/);
 const d=rawSeason();d.daily.time[2]=d.daily.time[1];assert.throws(()=>parseSeasonal(d,opts),/sırası/);
 const u=rawSeason();u.monthly_units.precipitation_anomaly='mm/day';assert.throws(()=>parseSeasonal(u,opts),/birimleri/);
 assert.throws(()=>parseSeasonal(rawSeason(),{...opts,retrievedAt:'2026-10-20T12:00:00Z'}),/güncel/);
 assert.throws(()=>parseSeasonal(rawSeason(),{now:new Date('2026-11-01T12:00:00Z'),retrievedAt:'2026-11-01T12:00:00Z'}),/tam aylar/);
});
test('NASA daily rain rates are converted with each actual month length including leap years',()=>{
 const n=parseNasaClimate(rawNasa());assert.equal(n.period,'1991–2020');assert.equal(n.months[0].rain,62);assert.equal(n.months[1].rain,56.5);assert.equal(n.months[1].years,30);
 const bad=rawNasa();for(let y=1991;y<2000;y++)delete bad.properties.parameter.T2M[y+'02'];assert.throws(()=>parseNasaClimate(bad),/yeterli/);
});
test('outside-horizon annual planning never borrows the first forecast month',()=>{
 const p=buildSeasonPlan({farm,season:parseSeasonal(rawSeason(),opts),nasa:parseNasaClimate(rawNasa()),month:'2027-08',now});assert.equal(p.available,false);assert.equal(p.chosen,null);assert.equal(p.signals.warm,false);assert.equal(p.climate.month,8);
 assert.deepEqual(nextMonths(now,3),['2026-11','2026-12','2027-01']);
});
test('orchards keep their trees; custom crops do not receive fabricated rotation profiles',()=>{
 const r=rotationOptions({...farm,crop:'Elma'},normalizeSeasonInputs({}),{dry:true});assert.equal(r.kind,'orchard');assert.equal(r.options.length,3);assert.ok(r.options.every(o=>o.sequence[0]==='Mevcut bahçe'));assert.match(r.options.find(o=>o.id==='winter-cover').tradeoff,/rekabet/);
 assert.equal(rotationOptions({...farm,crop:'Benim özel çeşidim'},{}).options.length,0);
});
test('scenarios, report status, sowing intent and near-term weather change decisions without a chemical dose',()=>{
 const s=parseSeasonal(rawSeason(),opts),p=buildSeasonPlan({farm,season:s,inputs:{sowingMonth:11},now});assert.match(p.actions.find(a=>a.id==='planting').title,/Planladığın/);assert.match(p.actions.find(a=>a.id==='soil').title,/analiz/);
 const high=buildSeasonPlan({farm,season:s,inputs:{soilTestDate:'2026-10-01',nitrogen:'high'},now});assert.match(high.actions.find(a=>a.id==='soil').title,/artırmadan/);
 const heavy=buildSeasonPlan({farm,season:s,inputs:{soilTestDate:'2026-10-01'},weather:{available:true,rows:[{rain:30}]},now});assert.equal(heavy.nearTerm.heavyRain,true);assert.match(heavy.actions.find(a=>a.id==='soil').why,/Doymuş/);
 const hypothetical=buildSeasonPlan({farm,season:s,scenario:'wet',now});assert.equal(hypothetical.hypothetical,true);assert.equal(hypothetical.signals.wet,true);assert.equal(hypothetical.signals.dry,false);
 for(const plan of [p,high,heavy,hypothetical])assert.doesNotMatch(JSON.stringify(plan.actions),/\d+\s*(kg|ml|gr)\s*\//);
});
test('only actual in-horizon evidence can add automatic seasonal tasks; crop state remains separate',()=>{
 const s=parseSeasonal(rawSeason(),opts),p=buildSeasonPlan({farm,season:s,now});const tasks=buildWorklist(farm,weather,[],{},now,p);assert.equal(tasks.filter(t=>t.id.startsWith('season_')).length,2);
 const hypothesis=buildSeasonPlan({farm,season:s,scenario:'dry',now});assert.equal(buildWorklist(farm,weather,[],{},now,hypothesis).filter(t=>t.id.startsWith('season_')).length,0);
 const keys=tasks.filter(t=>t.id.startsWith('season_')).map(t=>t.key);const other=buildWorklist({...farm,id:'farm_other'},weather,[],{done:Object.fromEntries(keys.map(k=>[k,true]))},now,p);assert.ok(other.filter(t=>t.id.startsWith('season_')).every(t=>!t.done));
});
test('source failures are explicit and NASA history can still render without a seasonal forecast',async()=>{
 const fetcher=async url=>url.startsWith('https://power.')?{ok:true,json:async()=>rawNasa()}:{ok:false};const r=await fetchSeasonEvidence(37,35,{fetcher,now,force:true});assert.equal(r.season.available,false);assert.equal(r.nasa.available,true);assert.equal(r.requested.lat,37);
});
