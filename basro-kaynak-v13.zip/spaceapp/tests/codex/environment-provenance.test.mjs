import test from 'node:test';
import assert from 'node:assert/strict';
import {fetchSoilBaseline,soilBaselineUrl,createDatasetProvenance,fetchSmapSoilMoisture,fetchGpmPrecipitation} from '../../public/environment-provenance.mjs';

const now=new Date('2026-11-01T12:00:00Z');
const measures={phh2o:{d_factor:10,mapped_units:'pH*10',target_units:'-'},clay:{d_factor:10,mapped_units:'g/kg',target_units:'g/100g'},sand:{d_factor:10,mapped_units:'g/kg',target_units:'g/100g'},soc:{d_factor:10,mapped_units:'dg/kg',target_units:'g/kg'}};
function fixture(){return {geometry:{coordinates:[32.85,39.93]},properties:{layers:Object.entries(measures).map(([name,unit_measure])=>({name,unit_measure:{...unit_measure},depths:[{label:'0-5cm',range:{top_depth:0,bottom_depth:5,unit_depth:'cm'},values:{mean:name==='phh2o'?72:200,'Q0.05':name==='phh2o'?60:100,'Q0.95':name==='phh2o'?80:300}}]}))}};}
const ok=raw=>async()=>({ok:true,status:200,json:async()=>raw});

test('query requests the four properties and 0–5 cm mean with both uncertainty quantiles in one call',()=>{
 const url=new URL(soilBaselineUrl(39.93,32.85));assert.equal(url.origin,'https://rest.isric.org');assert.deepEqual(url.searchParams.getAll('property'),['phh2o','clay','sand','soc']);assert.deepEqual(url.searchParams.getAll('value'),['mean','Q0.05','Q0.95']);assert.equal(url.searchParams.get('depth'),'0-5cm');assert.equal(url.searchParams.get('lat'),'39.93');
});
test('units use each returned metadata divisor, preserving model interval and provenance',async()=>{
 const raw=fixture();raw.properties.layers.find(l=>l.name==='soc').unit_measure.d_factor=20;
 const r=await fetchSoilBaseline(39.93,32.85,{fetcher:ok(raw),now});assert.equal(r.available,true);assert.equal(r.records.length,4);
 const ph=r.records[0],clay=r.records[1],soc=r.records[3];assert.equal(ph.value,7.2);assert.equal(ph.low,6);assert.equal(ph.high,8);assert.equal(ph.unit,'pH');assert.equal(clay.value,20);assert.equal(clay.unit,'%');assert.equal(soc.value,10);assert.equal(soc.unit,'g/kg');assert.equal(soc.provenance.units.divisor,20);assert.equal(soc.provenance.runId,null);assert.equal(soc.provenance.validPeriod,null);assert.equal(soc.provenance.retrievedAt,now.toISOString());assert.equal(soc.provenance.resolution.value,250);assert.equal(r.source.license,'CC BY 4.0');assert.ok(r.limitations.every(l=>l.tr&&l.en));
});
test('missing, null, string, sentinel and missing unit metadata never become zero',async()=>{
 const raw=fixture();raw.properties.layers[0].depths[0].values={mean:null,'Q0.05':null};raw.properties.layers[1].depths[0].values.mean=-32768;raw.properties.layers[2].depths[0].values.mean='200';delete raw.properties.layers[3].unit_measure.d_factor;
 const r=await fetchSoilBaseline(39,32,{fetcher:ok(raw),now});assert.equal(r.available,false);assert.ok(r.records.every(v=>v.value===null));assert.equal(r.records[0].low,null);assert.equal(r.records[0].high,null);assert.equal(r.records[3].unit,null);assert.match(r.reason,/değeri yok/);
});
test('a genuine numeric zero is retained and missing interval stays explicitly missing',async()=>{
 const raw=fixture();raw.properties.layers[1].depths[0].values={mean:0,'Q0.05':0,'Q0.95':null};
 const r=await fetchSoilBaseline(39,32,{fetcher:ok(raw),now});assert.equal(r.records[1].value,0);assert.equal(r.records[1].low,0);assert.equal(r.records[1].high,null);assert.equal(r.records[1].provenance.quality.intervalAvailable,false);assert.equal(r.provenance.quality.status,'partial');assert.ok(r.reason);
});
test('physically impossible positive fill values are missing after unit conversion',async()=>{
 const raw=fixture();for(const layer of raw.properties.layers)layer.depths[0].values.mean=65535;
 const r=await fetchSoilBaseline(39,32,{fetcher:ok(raw),now});assert.equal(r.available,false);assert.ok(r.records.every(v=>v.value===null));
});
test('unsupported units or depth cannot silently use the published usual factor',async()=>{
 const raw=fixture();raw.properties.layers[0].unit_measure.target_units='mol/L';raw.properties.layers[1].depths[0].range.bottom_depth=15;
 const r=await fetchSoilBaseline(39,32,{fetcher:ok(raw),now});assert.equal(r.available,true);assert.equal(r.provenance.quality.status,'partial');assert.equal(r.records[0].value,null);assert.equal(r.records[1].value,null);
});
test('reversed quantiles are dropped explicitly rather than reordered',async()=>{
 const raw=fixture();raw.properties.layers[0].depths[0].values['Q0.05']=90;
 const r=await fetchSoilBaseline(39,32,{fetcher:ok(raw),now});assert.equal(r.records[0].low,null);assert.equal(r.records[0].high,null);assert.ok(r.records[0].provenance.quality.flags.includes('invalidPredictionInterval'));
});
test('API and network failures are explicit and make at most two requests',async()=>{
 for(const fetcher of [async()=>({ok:false,status:503}),async()=>{throw Error('offline');}]){let calls=0;const r=await fetchSoilBaseline(39,32,{fetcher:async(...args)=>{calls++;return fetcher(...args);},now});assert.equal(calls,2);assert.equal(r.available,false);assert.deepEqual(r.records,[]);assert.equal(r.provenance.quality.attempts,2);assert.ok(r.reason);}
 let calls=0;const bad=await fetchSoilBaseline(39,32,{fetcher:async()=>{calls++;return {ok:false,status:429};},now});assert.equal(calls,1);assert.equal(bad.available,false);
});
test('malformed payload does not retry; caller cancellation propagates',async()=>{
 let calls=0;const r=await fetchSoilBaseline(39,32,{fetcher:async()=>{calls++;return {ok:true,json:async()=>({})};},now});assert.equal(calls,1);assert.equal(r.provenance.quality.failure,'invalidResponse');
 const abort=new AbortController();abort.abort();await assert.rejects(fetchSoilBaseline(39,32,{fetcher:ok(fixture()),signal:abort.signal,now}),{name:'AbortError'});
 await assert.rejects(fetchSoilBaseline(91,32,{fetcher:ok(fixture()),now}),/koordinatı/);
});
test('NASA and ECMWF provenance retains supplied units and never invents a run',()=>{
 for(const provider of ['NASA POWER','ECMWF']){const p=createDatasetProvenance({provider,originalVariable:provider==='ECMWF'?'temperature_2m_mean':'T2M',coords:{requested:{lat:39,lon:32}},units:'°C',validPeriod:{start:'2026-11-01',end:'2026-11-30'},retrievedAt:now.toISOString(),limitations:[{tr:'Kestirim',en:'Prediction'}],quality:{status:'validated'}});assert.equal(p.provider,provider);assert.equal(p.runId,null);assert.equal(p.resolution,null);assert.equal(p.units,'°C');assert.equal(p.validPeriod.start,'2026-11-01');}
 const coords={lat:39,lon:32},p=createDatasetProvenance({coords});coords.lat=40;assert.equal(p.coords.lat,39);
});
test('SMAP/GPM are disconnected adapters with no fabricated records or retrieval timestamp',async()=>{
 for(const fetcher of [fetchSmapSoilMoisture,fetchGpmPrecipitation]){const r=await fetcher();assert.equal(r.status,'notConnected');assert.equal(r.available,false);assert.deepEqual(r.records,[]);assert.equal(r.provenance.retrievedAt,null);assert.equal(r.provenance.runId,null);assert.ok(r.limitations[0].tr&&r.limitations[0].en);}
});
