import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizePortfolio,upsertFarm,buildWorklist} from '../../public/farmer-core.mjs';

const legacy={id:'farm_original',lat:38.08574,lon:37.87116,name:'Dere kenarı',district:'Doğanşehir',city:'Malatya',country:'Türkiye',crop:'Elma',stage:'Hasat sonrası',water:'kısıtlı',goal:'health',locationKind:'field',area:12,ph:6.8};
const migrated=()=>normalizePortfolio({version:1,farm:legacy});

test('legacy farm migrates without changing the ID used by old tasks and observations',()=>{
 const input={version:1,farm:{...legacy}},snapshot=structuredClone(input),p=normalizePortfolio(input);
 assert.equal(p.version,2);assert.equal(p.activeFarmId,legacy.id);assert.equal(p.farms[0].id,legacy.id);assert.equal(p.farms[0].landId,legacy.id);assert.equal(p.farms[0].ph,6.8);assert.deepEqual(input,snapshot);
 const date=new Date('2026-10-31T12:00:00Z');
 assert.deepEqual(buildWorklist(legacy,{available:false},[],{},date).map(t=>t.key),buildWorklist(p.farms[0],{available:false},[],{},date).map(t=>t.key));
});
test('multiple crops on one land preserve their separate stage, area and task state',()=>{
 const p=migrated(),apple=p.farms[0],cherry={...apple,id:'farm_cherry',crop:'Kiraz',stage:'Çiçeklenme',water:'var',area:3};
 const farms=upsertFarm(p.farms,cherry);assert.equal(farms.length,2);assert.equal(farms[0].crop,'Elma');assert.equal(farms[0].area,12);assert.equal(farms[1].area,3);assert.equal(farms[0].landId,farms[1].landId);
 const date=new Date('2026-10-31T12:00:00Z'),a=buildWorklist(farms[0],{available:false},[],{},date),key=a.find(t=>t.id==='scout').key;
 assert.equal(buildWorklist(farms[1],{available:false},[],{done:{[key]:true}},date).find(t=>t.id==='scout').done,false);
 assert.equal(normalizePortfolio({version:2,farms,activeFarmId:'farm_cherry'}).activeFarmId,'farm_cherry');
});
test('a land location update reaches its crops but leaves other land and crop details intact',()=>{
 const apple=migrated().farms[0],cherry={...apple,id:'farm_cherry',crop:'Kiraz',stage:'Çiçeklenme'},other={...apple,id:'farm_other',landId:'farm_other',crop:'Buğday',district:'Yeşilyurt'};
 const updated=upsertFarm([apple,cherry,other],{...apple,name:'Yamaç bahçesi',lat:38.12,lon:37.92},['name','lat','lon']);
 assert.equal(updated[1].name,'Yamaç bahçesi');assert.equal(updated[1].lat,38.12);assert.equal(updated[1].stage,'Çiçeklenme');assert.equal(updated[1].crop,'Kiraz');assert.deepEqual(updated[2],other);assert.equal(apple.name,'Dere kenarı');
});
test('shared soil values can be cleared without changing another field or overwriting crop stages',()=>{
 const apple=migrated().farms[0],cherry={...apple,id:'farm_cherry',crop:'Kiraz'},other={...apple,id:'farm_other',landId:'farm_other'};
 const next={...apple};delete next.ph;
 const updated=upsertFarm([apple,cherry,other],next,['ph','organic','crop']);
 assert.equal(updated[0].ph,undefined);assert.equal(updated[1].ph,undefined);assert.equal(updated[1].crop,'Kiraz');assert.equal(updated[2].ph,6.8);
});
test('invalid and duplicate stored rows do not create duplicate fields or an unusable selection',()=>{
 const p=normalizePortfolio({version:2,farms:[legacy,{...legacy},{...legacy,id:'bad',lat:99}],activeFarmId:'missing'});
 assert.equal(p.farms.length,1);assert.equal(p.activeFarmId,legacy.id);assert.equal(normalizePortfolio(null).activeFarmId,null);
});
test('a photo observation from one crop does not suppress another crop’s weekly inspection',()=>{
 const apple=migrated().farms[0],cherry={...apple,id:'farm_cherry',crop:'Kiraz'},date=new Date('2026-10-31T12:00:00Z'),notes=[{farmId:apple.id,day:'2026-10-30',type:'photo'}];
 assert.equal(buildWorklist(apple,{available:false},notes,{},date).some(t=>t.id==='photo'),false);
 assert.equal(buildWorklist(cherry,{available:false},notes,{},date).some(t=>t.id==='photo'),true);
});
