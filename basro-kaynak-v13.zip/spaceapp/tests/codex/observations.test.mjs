import test from 'node:test';
import assert from 'node:assert/strict';
import {validateObservation, acceptedEvidence, OBSERVATION_METHOD} from '../../public/observation-core.mjs';
import {selectDiscoveryQuestion, DISCOVERY_METHOD} from '../../public/discovery-core.mjs';
import {createDecisionSnapshot, compareDecisions} from '../../public/decision-history.mjs';

const now = new Date('2026-11-01T12:00:00Z');
const farm = {id: 'farm_alpha', crop: 'Buğday', water: 'yok', lat: 38, lon: 38};
const options = {fieldId: farm.id, now};
const ponding = {observationType: 'standing_water_duration', value: 24, unit: 'hours', observedAt: '2026-10-31T10:00:00Z', sourceType: 'farmer_report', method: 'visual_after_rain'};
const result = (preferredIds = ['a'], blocked = false) => ({methodVersion: 'test-rotation-1', parameterVersion: 'test-params-1', kind: 'annual', preferredIds, candidates: [{id: 'a', sequence: ['Buğday', 'Nohut', 'Arpa'], feasibility: blocked ? 'infeasible' : 'provisional', utility: .6, rank: 1, criteria: {water: .8, soil: .4, feasibility: 1}, excludedReasons: []}]});
const snapshot = (overrides = {}) => createDecisionSnapshot({farm, observations: [], rotationResult: result(), now, ...overrides});

test('a safe retrospective report is structurally accepted with uncertainty, private by default', () => {
  const row = validateObservation(ponding, options);
  assert.equal(row.validationStatus, 'accepted');
  assert.equal(row.influence.eligible, true);
  assert.equal(row.sharingConsent, false);
  assert.equal(row.validationMethod, OBSERVATION_METHOD);
  assert.equal(row.userId, 'device-owner');
  assert.equal(row.uncertainty.kind, 'heuristic_report_range');
  assert.ok(row.uncertainty.lower < row.value && row.uncertainty.upper > row.value);
  assert.match(row.validationExplanation.en, /not a scientific drainage/);
  const evidence = acceptedEvidence([row], options);
  assert.equal(evidence.standingWaterHours, 24);
  assert.equal(evidence.provenance.standingWaterHours.observationId, row.id);
  assert.deepEqual(evidence.uncertainty.standingWaterHours, row.uncertainty);
  assert.equal(evidence.drainage, undefined, 'no unsupported safe-drainage cutoff');
});

test('pending and rejected reports do not influence evidence, including a later unknown', () => {
  const accepted = validateObservation(ponding, options);
  const pending = validateObservation({...ponding, value: 'unknown'}, options);
  const rejected = validateObservation({...ponding, value: -1}, options);
  assert.equal(pending.validationStatus, 'pending');
  assert.equal(rejected.validationStatus, 'rejected');
  assert.deepEqual(acceptedEvidence([pending, rejected], options), {});
  assert.equal(acceptedEvidence([accepted, pending], options).standingWaterHours, 24);
});

test('duplicate evidence is rejected and cannot receive extra weight', () => {
  const accepted = validateObservation(ponding, options);
  const duplicate = validateObservation(ponding, {...options, existing: [accepted]});
  assert.equal(duplicate.validationStatus, 'rejected');
  assert.ok(duplicate.qualityFlags.includes('duplicate'));
  assert.deepEqual(acceptedEvidence([accepted, duplicate], options), acceptedEvidence([accepted], options));
});

test('owner and field isolation is enforced during validation and evidence selection', () => {
  const a = validateObservation(ponding, options);
  const b = validateObservation({...ponding, value: 50}, {...options, userId: 'other-owner'});
  assert.equal(acceptedEvidence([a, b], options).standingWaterHours, 24);
  assert.equal(acceptedEvidence([a, b], {...options, userId: 'other-owner'}).standingWaterHours, 50);
  assert.deepEqual(acceptedEvidence([a], {fieldId: 'farm_elsewhere'}), {});
  assert.equal(validateObservation({...ponding, userId: 'other-owner'}, options).validationStatus, 'rejected');
  assert.equal(validateObservation({...ponding, fieldId: 'farm_elsewhere'}, options).validationStatus, 'rejected');
});

test('invalid units, dates, coordinates, depth, numeric type and bounds are rejected', () => {
  for (const changes of [{unit: 'mm'}, {value: '24'}, {observedAt: 'not-a-date'}, {observedAt: '2026-02-30'}, {observedAt: '2026-10-31T24:00:00Z'}, {observedAt: '1'}, {observedAt: '2027-01-01'}, {latitude: 91}, {longitude: 181}, {depthCm: -1}, {value: Number.NaN}, {uncertainty: {lower: 30, upper: 40}}]) {
    assert.equal(validateObservation({...ponding, ...changes}, options).validationStatus, 'rejected', JSON.stringify(changes));
  }
});

test('a satellite discrepancy requests review without accusing the farmer', () => {
  const row = validateObservation(ponding, {...options, regionalReference: {observationType: 'standing_water_duration', value: 0, unit: 'hours', tolerance: 4, source: 'regional satellite pixel'}});
  assert.equal(row.validationStatus, 'needs_review');
  assert.ok(row.qualityFlags.includes('regional_discrepancy'));
  assert.match(row.validationExplanation.en, /not proof of farmer error/);
  assert.equal(row.value, 24);
  assert.deepEqual(acceptedEvidence([row], options), {});
});

test('texture by feel is tentative and crop history retains its method', () => {
  const texture = validateObservation({observationType: 'soil_texture', value: 'clay', unit: 'qualitative', method: 'feel'}, options);
  const history = validateObservation({observationType: 'previous_crop', value: 'Nohut', method: 'farmer_recall'}, options);
  assert.equal(texture.validationStatus, 'accepted');
  assert.ok(texture.qualityFlags.includes('tentative_texture'));
  assert.equal(history.validationStatus, 'accepted');
  const evidence = acceptedEvidence([texture, history], options);
  assert.equal(evidence.soilTexture, 'clay');
  assert.equal(evidence.previousCrop, 'Nohut');
  assert.equal(evidence.provenance.previousCrop.method, 'farmer_recall');
});

test('laboratory pH requires report metadata and sampling depth; photos cannot measure pH', () => {
  const ph = {observationType: 'soil_ph', value: 6.5, unit: 'pH', method: 'laboratory_report', sourceType: 'laboratory'};
  assert.equal(validateObservation(ph, options).validationStatus, 'needs_review');
  const valid = validateObservation({...ph, depthCm: 20, measurementMetadata: {labName: 'Named lab', reportId: 'R-1'}}, options);
  assert.equal(valid.validationStatus, 'accepted');
  const photo = validateObservation({...ph, method: 'soil_photo', sourceType: 'camera_assisted'}, options);
  assert.equal(photo.validationStatus, 'needs_review');
  assert.equal(photo.influence.eligible, false);
});

const rain = {observationType: 'rainfall_measurement', value: 12, unit: 'mm', observedAt: now.toISOString(), sourceType: 'camera_assisted', method: 'manual_rain_gauge_reading', measurementMetadata: {periodStart: '2026-10-31T12:00:00Z', periodEnd: '2026-11-01T11:00:00Z', tool: 'rain_gauge', graduatedScale: true, manualRead: true, scaleIncrementMm: 1, evidenceDigest: 'local-image-digest'}};

test('camera-supported rainfall is manually read with a scale and period, never automated', () => {
  const row = validateObservation(rain, options);
  assert.equal(row.validationStatus, 'accepted');
  assert.equal(row.method, 'manual_gauge_read');
  assert.equal(row.uncertainty.lower, 11.5);
  assert.equal(row.uncertainty.upper, 12.5);
  assert.equal(row.uncertainty.kind, 'scale_reading_resolution');
  assert.equal(row.measurementMetadata.evidenceDigest, 'local-image-digest');
  for (const metadata of [{graduatedScale: false}, {manualRead: false}, {periodStart: 'invalid'}, {tool: ''}]) {
    assert.equal(validateObservation({...rain, measurementMetadata: {...rain.measurementMetadata, ...metadata}}, options).validationStatus, 'needs_review');
  }
  assert.equal(validateObservation({...rain, method: 'automatic_ocr'}, options).validationStatus, 'needs_review');
});

test('blur and poor lighting request review and never supply precise evidence', () => {
  for (const imageQuality of [{blurry: true}, {tooDark: true}, {tooBright: true}]) {
    const row = validateObservation({...rain, imageQuality}, options);
    assert.equal(row.validationStatus, 'needs_review');
    assert.equal(row.influence.eligible, false);
    assert.deepEqual(acceptedEvidence([row], options), {});
  }
});

test('reusing one image under a changed date is correlated duplicate evidence', () => {
  const row = validateObservation(rain, options);
  const duplicate = validateObservation({...rain, observedAt: '2026-11-01T11:59:00Z'}, {...options, existing: [row]});
  assert.equal(duplicate.validationStatus, 'rejected');
  assert.ok(duplicate.qualityFlags.includes('duplicate'));
});

test('Discovery asks a useful safe bilingual drainage question then remembers unknown answers', () => {
  const first = selectDiscoveryQuestion({farm, now});
  assert.equal(first.type, 'standing_water_duration');
  assert.equal(first.selectionMethod, DISCOVERY_METHOD);
  assert.ok(first.question.tr && first.question.en && first.why.tr && first.why.en);
  assert.match(first.effort.en, /do not enter a flooded field/);
  const unknown = validateObservation({...ponding, value: 'unknown'}, options);
  const second = selectDiscoveryQuestion({farm, observations: [unknown], now: new Date('2027-01-01')});
  assert.equal(second.type, 'previous_crop');
  const previousUnknown = validateObservation({observationType: 'previous_crop', value: 'unknown', method: 'farmer_recall'}, options);
  const third = selectDiscoveryQuestion({farm, observations: [unknown, previousUnknown], now});
  assert.equal(third.type, 'soil_texture');
  const all = [unknown, previousUnknown, validateObservation({observationType: 'soil_texture', value: 'unknown', method: 'feel'}, options)];
  assert.equal(selectDiscoveryQuestion({farm, observations: all, now}), null);
});

test('Discovery uses only supported procedures and ignores other owners answers', () => {
  const other = validateObservation(ponding, {...options, userId: 'other-owner'});
  assert.equal(selectDiscoveryQuestion({farm, observations: [other], now}).type, 'standing_water_duration');
  assert.equal(selectDiscoveryQuestion({farm, candidates: [{type: 'soil_texture', method: 'unsafe_procedure'}], now}).method, 'feel');
  assert.equal(selectDiscoveryQuestion({farm, candidates: [{id: 'rotation-a'}], now}).type, 'standing_water_duration');
});

test('pending, duplicate and irrelevant observations do not change the deterministic decision', () => {
  const initial = snapshot();
  const pending = validateObservation({...ponding, value: 'unknown'}, options);
  const rainfall = validateObservation(rain, options);
  const next = snapshot({observations: [pending, rainfall], now: new Date('2026-11-02')});
  assert.equal(next.inputFingerprint, initial.inputFingerprint);
  assert.equal(next.decisionFingerprint, initial.decisionFingerprint);
  assert.equal(compareDecisions(initial, next).materiality, 'none');
});

test('accepted relevant evidence can explain a stable preference or a material preference change', () => {
  const initial = snapshot();
  const row = validateObservation(ponding, options);
  const updated = snapshot({observations: [row]});
  assert.notEqual(initial.inputFingerprint, updated.inputFingerprint);
  assert.equal(compareDecisions(initial, updated).materiality, 'moderate');
  const preferred = snapshot({observations: [row], rotationResult: result(['b'])});
  assert.equal(compareDecisions(initial, preferred).materiality, 'material');
  assert.equal(compareDecisions(initial, preferred).preferredChanged, true);
  assert.deepEqual(compareDecisions(initial, preferred).changedInputs, ['evidence']);
});

test('initial and urgent comparisons describe their actual decision state', () => {
  const initial = snapshot();
  assert.equal(compareDecisions(null, initial).materiality, 'initial');
  const blocked = snapshot({rotationResult: result([], true)});
  assert.equal(compareDecisions(initial, blocked).materiality, 'urgent');
  assert.throws(() => compareDecisions(initial, snapshot({farm: {...farm, id: 'farm_other'}})), /different owners or fields/);
});

test('snapshots are detached, immutable, reproducible and do not invent forecast runs', () => {
  const row = validateObservation(ponding, options), rotationResult = result();
  const forecast = {available: true, model: 'ECMWF SEAS5', retrievedAt: now.toISOString(), months: [{month: '2026-12', temperature: {direction: 'warm'}, rain: {direction: 'dry'}}]};
  const first = snapshot({observations: [row], rotationResult, forecast});
  row.value = 800; rotationResult.candidates[0].utility = .1; forecast.months[0].rain.direction = 'wet';
  assert.equal(first.evidence.standingWaterHours, 24);
  assert.equal(first.rotationResult.candidates[0].utility, .6);
  assert.equal(first.forecast.months[0].rain.direction, 'dry');
  assert.equal(first.provenance.forecastModelRun, null);
  assert.equal(first.provenance.forecastRunKnown, false);
  assert.throws(() => {first.evidence.standingWaterHours = 12;}, TypeError);
  const replay = createDecisionSnapshot({...first, evidence: first.evidence, observations: first.observations, rotationResult: first.rotationResult, now: new Date(first.createdAt)});
  assert.equal(replay.inputFingerprint, first.inputFingerprint);
  assert.equal(replay.decisionFingerprint, first.decisionFingerprint);
  assert.deepEqual(replay.provenance, first.provenance);
  const retrievedAgain = snapshot({observations: first.observations, rotationResult: first.rotationResult, forecast: {...first.forecast, retrievedAt: '2026-11-02T12:00:00Z'}});
  assert.equal(retrievedAgain.inputFingerprint, first.inputFingerprint);
  assert.equal(compareDecisions(first, retrievedAgain).materiality, 'none');
});
