// Çalıştırma: npm test   (node --experimental-strip-types --test)
import { test } from "node:test";
import assert from "node:assert/strict";
import { validateVision, extractJson, isDecisionGrade } from "../lib/vision-schema.ts";

const good = {
  image_quality: { usable: true, blur: "low", lighting: "acceptable", crop_visibility: 0.83 },
  abstain: false,
  abstain_reason: null,
  crop_match: { expected: "tomato", visible: true, confidence: 0.91 },
  phenology: { stage: "fruit_ripening", confidence: 0.76 },
  visible_signals: [{ type: "red_fruit_present", confidence: 0.84 }],
  cannot_infer: ["soil_ph", "exact_soil_moisture", "yield_kg"],
  request_followup_photo: false,
};
const clone = (o) => structuredClone(o);

test("brief örneği geçerli", () => assert.equal(validateVision(good).ok, true));

test("abstain alanı eksikse reddedilir", () => {
  const v = clone(good); delete v.abstain;
  assert.equal(validateVision(v).ok, false);
});

test("abstain=true ve gerekçe yoksa reddedilir", () => {
  const v = clone(good); v.abstain = true; v.abstain_reason = null;
  assert.equal(validateVision(v).ok, false);
});

test("usable=true + abstain=true gerekçeyle geçerlidir", () => {
  const v = clone(good); v.abstain = true; v.abstain_reason = "Bitki kadrajın çok küçük kısmında";
  const r = validateVision(v);
  assert.equal(r.ok, true);
  assert.equal(isDecisionGrade(r.value), false);
});

test("cannot_infer boş olamaz", () => {
  const v = clone(good); v.cannot_infer = [];
  assert.equal(validateVision(v).ok, false);
});

test("görüntüden pH/verim sinyali üretilemez", () => {
  const v = clone(good); v.visible_signals.push({ type: "soil_ph_estimate", confidence: 0.6 });
  assert.equal(validateVision(v).ok, false);
});

test("güven 0–1 dışında reddedilir", () => {
  const v = clone(good); v.phenology.confidence = 1.4;
  assert.equal(validateVision(v).ok, false);
});

test("bilinmeyen evre reddedilir", () => {
  const v = clone(good); v.phenology.stage = "harvest_ready";
  assert.equal(validateVision(v).ok, false);
});

test("kod bloğu içindeki JSON ayıklanır", () => {
  assert.deepEqual(extractJson("```json\n{\"a\":1}\n```"), { a: 1 });
  assert.deepEqual(extractJson("Sonuç: {\"a\":2} tamam"), { a: 2 });
  assert.equal(extractJson("geçersiz"), undefined);
});

test("düşük görünürlük karar kanıtı sayılmaz", () => {
  const v = clone(good); v.image_quality.crop_visibility = 0.3;
  assert.equal(isDecisionGrade(validateVision(v).value), false);
});
