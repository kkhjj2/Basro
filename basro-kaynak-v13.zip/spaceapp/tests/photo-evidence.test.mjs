import test from 'node:test';
import assert from 'node:assert/strict';
import {gradeVision} from '../public/photo-evidence.mjs';
import {applyPhotoEvidence} from '../public/field-workspace.mjs';
import {awardXp,progressOf} from '../public/bas-social.mjs';

const mem=()=>{const m=new Map();return {getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v)};};
globalThis.fetch=async()=>({ok:true,json:async()=>({smap:{available:true,theta:0.24,window:{start:'2026-11-02',end:'2026-11-08'}}})});
const farm={id:'f1',crop:'Domates',stage:'Yapraklanma / büyüme',water:'var',lat:38.05,lon:37.88};
const weather={available:true,rows:Array.from({length:7},(_,i)=>({date:`2026-11-${14+i}`,min:8,max:22,rain:0}))};

test('A1: net domates fotoğrafı karar düzeyinde kanıt olur',()=>{
 const v=gradeVision({usable:true,plant:'Domates',stage:'Çiçeklenme',stageConfidence:0.82},'Domates');
 assert.equal(v.decisionGrade,true);assert.equal(v.stage,'Çiçeklenme');
});
test('A2: bulanık ya da ilgisiz fotoğraf çekimser kalır ve ipucu verir',()=>{
 const blur=gradeVision({usable:false,plant:'Belirsiz',stage:'Belirsiz',stageConfidence:0.9},'Domates');
 assert.equal(blur.abstain,true);assert.equal(blur.decisionGrade,false);assert.ok(blur.tip);
 const other=gradeVision({usable:true,plant:'Gül',stage:'Çiçeklenme',stageConfidence:0.9},'Domates');
 assert.equal(other.decisionGrade,false);assert.match(other.reason,/Gül/);
 assert.equal(gradeVision({usable:true,plant:'Domates',stage:'Çiçeklenme',stageConfidence:0.4},'Domates').decisionGrade,false);
 assert.equal(gradeVision({usable:true,plant:'Domates',stage:'uydurma evre',stageConfidence:0.9},'Domates').stage,null);
});
test('Zincir: kabul edilen kanıt tarla durumunu değiştirir ve önce/sonra kaydı yazar',async()=>{
 const storage=mem(),vision=gradeVision({usable:true,plant:'Domates',stage:'Meyve / dane gelişimi',stageConfidence:0.8},'Domates');
 const r=await applyPhotoEvidence({storage,farm,weather,vision,hash:'h1'});
 assert.equal(r.status,'accepted');assert.equal(r.stageChanged,true);
 assert.ok(r.change.diffs.some(d=>d.key==='kc'),'Kc değişmeli');
 const rec=JSON.parse(storage.getItem('agrobas-field-v1')).f1;
 assert.equal(rec.stage,'Meyve / dane gelişimi');assert.equal(rec.stageSource,'photo');assert.equal(rec.history.length,1);
});
test('A2 zinciri: çekimser fotoğraf durumu ve geçmişi değiştirmez',async()=>{
 const storage=mem(),vision=gradeVision({usable:false},'Domates');
 const r=await applyPhotoEvidence({storage,farm,weather,vision,hash:'h2'});
 assert.equal(r.status,'note');
 const rec=JSON.parse(storage.getItem('agrobas-field-v1')).f1;
 assert.equal(rec.stage,undefined);assert.equal(rec.history.length,0);
});
test('A6: aynı fotoğraf (aynı SHA-256) kanıtı ve XP\'yi iki kez saymaz',async()=>{
 const storage=mem(),vision=gradeVision({usable:true,plant:'Domates',stage:'Çiçeklenme',stageConfidence:0.8},'Domates');
 await applyPhotoEvidence({storage,farm,weather,vision,hash:'same'});
 assert.equal((await applyPhotoEvidence({storage,farm,weather,vision,hash:'same'})).status,'duplicate');
 assert.equal(awardXp(storage,30,'photo:same'),30);assert.equal(awardXp(storage,30,'photo:same'),0);
 const log=JSON.parse(storage.getItem('agrobas-social-v1')).log;
 assert.equal(progressOf(log).xp,30);
});
