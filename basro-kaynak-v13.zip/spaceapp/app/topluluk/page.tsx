import { PageShell } from "@/components/app-header";
import { StatusTag } from "@/components/badges";
import { socialPost } from "@/lib/demo-data";

export default function CommunityPage() {
  const p = socialPost;
  return (
    <PageShell title="Topluluk" lead={`${p.region} · Bu hafta ${p.weeklyTrackedFields} tarla takip edildi`}>
      <div className="card bg-base-100 shadow-sm">
        <div className="card-body">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold">{p.author}</div>
              <div className="text-xs text-base-content/60">
                {p.region} · {p.date}
              </div>
            </div>
            <StatusTag status={p.status} />
          </div>
          <p>{p.text}</p>
          <p className="text-xs text-base-content/50">
            Topluluk gönderileri yalnızca paylaşım içindir; tarla analizinde kanıt olarak kullanılmaz. Konum ve fotoğraf bilgisi (GPS/EXIF) paylaşımda kaldırılır.
          </p>
        </div>
      </div>
    </PageShell>
  );
}
