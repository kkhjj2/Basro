import Link from "next/link";
import { PageShell } from "@/components/app-header";
import { missions, priority, streakDays, trackingLevel, xpLedger } from "@/lib/demo-data";

export default function MissionsPage() {
  const sorted = [...missions].sort((a, b) => priority(b) - priority(a)).slice(0, 2);
  const total = xpLedger.reduce((s, x) => s + x.delta, 0);
  return (
    <PageShell title="Bu haftaki görevlerin" lead="Bu haftaki gelişimi göstermek için 1 fotoğraf yeterli.">
      <div className="space-y-3">
        {sorted.map((m) => (
          <div key={m.id} className="card bg-base-100 shadow-sm">
            <div className="card-body flex-row flex-wrap items-center justify-between gap-4">
              <div className="min-w-0 flex-1">
                <h2 className="font-semibold">{m.title}</h2>
                <p className="text-sm text-base-content/70">{m.detail}</p>
                <p className="mt-1 text-xs text-base-content/50">Neden şimdi: {m.reason}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="badge badge-outline">+{m.rewardXp} puan</span>
                <Link href="/upload" className="btn btn-primary btn-sm">
                  Başla
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="card bg-base-100 shadow-sm">
        <div className="card-body">
          <h2 className="card-title">Tarla takip seviyesi {trackingLevel}</h2>
          <p className="text-base-content/70">
            {streakDays} gündür tarlanı takip ediyorsun · toplam {total} puan
          </p>
          <ul className="divide-y divide-base-300">
            {xpLedger.map((x) => (
              <li key={x.id} className="flex justify-between py-2 text-sm">
                <span>
                  {x.date} · {x.label}
                </span>
                <span className="font-medium">+{x.delta} puan</span>
              </li>
            ))}
          </ul>
          <p className="text-xs text-base-content/50">
            Puanlar tarlan için attığın adımları gösterir. &quot;Doğrulanmış gözlemci&quot; rozeti yalnızca kabul edilmiş fotoğraflarla kazanılır.
          </p>
        </div>
      </div>
    </PageShell>
  );
}
