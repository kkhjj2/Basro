import { notFound } from "next/navigation";
import { Suspense } from "react";
import { PageShell } from "@/components/app-header";
import { SourceNote, StatusTag } from "@/components/badges";
import { MiniChart } from "@/components/line-chart";
import { field, latestVision, phenologyLabels, twinSeasons } from "@/lib/demo-data";
import { analyzeField } from "@/lib/field-analysis";
import { RIPENING_GDD_BAND } from "@/lib/recommendation";
import { availableFraction, SOIL_WATER } from "@/lib/smap";
import { SmapSourceNote } from "@/components/smap-note";

export function generateStaticParams() {
  return [{ id: field.id }];
}

export default async function FieldPage({ params }: PageProps<"/tarla/[id]">) {
  const { id } = await params;
  if (id !== field.id) notFound();
  return (
    <PageShell title={field.name} lead={`${field.season.crop.name} · ${field.season.variety} · ${field.areaHa} ha · ${field.irrigation}`}>
      <Suspense fallback={<div className="skeleton h-96" />}>
        <FieldContent />
      </Suspense>
    </PageShell>
  );
}

async function FieldContent() {
  const a = await analyzeField();
  const d = a.decision;
  const v = latestVision;
  return (
    <>
      {/* Karar değişimi — brief §8.4 */}
      <div className="card border border-base-300 bg-base-100 shadow-sm">
        <div className="card-body">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="card-title">Bu haftaki değerlendirme</h2>
            <span className={`badge ${d.changed ? "badge-primary" : "badge-neutral"}`}>
              {d.changed ? "Tavsiye değişti" : "Tavsiye değişmedi"}
            </span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-box bg-base-200 p-4">
              <div className="text-xs text-base-content/60">Geçen hafta · {d.old.date}</div>
              <div className="font-semibold">{d.old.stage}</div>
              <p className="text-sm text-base-content/70">{d.old.text}</p>
            </div>
            <div className="rounded-box border border-primary/40 bg-primary/5 p-4">
              <div className="text-xs text-base-content/60">Bu hafta · {d.current.date}</div>
              <div className="font-semibold">{d.current.stage}</div>
              <p className="text-sm">{d.current.text}</p>
            </div>
          </div>
          <p className="text-sm">
            <strong>Neden:</strong> {d.reason}
          </p>
          <ul className="mt-1 grid gap-1 text-sm sm:grid-cols-2">
            {d.checks.map((c) => (
              <li key={c.label} className="flex gap-2">
                <span aria-hidden>{c.pass ? "✓" : "✗"}</span>
                <span>
                  {c.label} <span className="text-base-content/60">— {c.detail}</span>
                </span>
              </li>
            ))}
          </ul>
          <p className="text-xs text-base-content/50">
            Eşikler (güven ≥ 0,70) kalibre edilecek başlangıç değerleridir. Fotoğraflar bütün tarlayı göstermediği için toplam hasat hakkında tahmin vermiyoruz.
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="card bg-base-100 shadow-sm">
          <div className="card-body">
            <h2 className="card-title">Sıcaklık birikimi (GDD)</h2>
            {a.gddNow == null ? (
              <p className="text-sm text-base-content/60">NASA POWER verisi alınamadı; GDD hesaplanamadı.</p>
            ) : (
              <>
                <p className="text-3xl font-bold">{a.gddNow} GDD</p>
                <p className="text-sm text-base-content/70">
                  Dikimden ({field.season.sowingDate}) bu yana, taban {field.season.crop.tbase}°C. Bu çeşitte olgunlaşma genelde{" "}
                  {RIPENING_GDD_BAND.low}–{RIPENING_GDD_BAND.high} GDD arasında görülür.
                </p>
                <MiniChart label="Kümülatif GDD" unit="GDD" data={a.gdd.series} />
              </>
            )}
            <SourceNote p={a.season.provenance} />
          </div>
        </div>

        <div className="card bg-base-100 shadow-sm">
          <div className="card-body">
            <h2 className="card-title">Su ihtiyacı (tahmin)</h2>
            {a.water ? (
              <>
                <div className="stats bg-base-200">
                  <div className="stat">
                    <div className="stat-title">Ürün su ihtiyacı (ETc)</div>
                    <div className="stat-value text-2xl">≈ {a.water.etc} mm</div>
                  </div>
                  <div className="stat">
                    <div className="stat-title">Yağış</div>
                    <div className="stat-value text-2xl">{a.water.precip} mm</div>
                  </div>
                </div>
                <p className="text-sm text-base-content/70">
                  ETc = Kc × ET₀ (FAO-56, ET₀ Hargreaves yaklaşımı). Bu gerçekte verdiğin su değil, iklime ve ürüne göre ihtiyaç tahminidir.
                </p>
              </>
            ) : (
              <p className="text-sm text-base-content/60">İklim verisi alınamadı.</p>
            )}
          </div>
        </div>
      </div>

      <div className="card bg-base-100 shadow-sm">
        <div className="card-body">
          <h2 className="card-title">Kök bölgesi nemi (SMAP)</h2>
          {a.rootzone ? (
            <>
              <p className="text-3xl font-bold">
                {a.rootzone.mean.toFixed(2)} m³/m³{" "}
                <span className="text-base font-normal text-base-content/60">
                  ({a.rootzone.low.toFixed(2)}–{a.rootzone.high.toFixed(2)})
                </span>
              </p>
              <p className="text-sm text-base-content/70">
                Son hafta ortalaması. Killi tında bitkiye yarayışlı suyun yaklaşık %{Math.round(availableFraction(a.rootzone.mean) * 100)}&apos;i (solma noktası{" "}
                {SOIL_WATER.wiltingPoint}, tarla kapasitesi {SOIL_WATER.fieldCapacity}). Bu değer 9 km&apos;lik alanın ortalamasıdır; damla sulanan tarlan
                bundan daha nemli olabilir.
              </p>
              <MiniChart
                label="Sezon boyunca kök bölgesi nemi"
                unit="m³/m³"
                color="var(--color-info)"
                data={a.smapSeason.map((d) => ({ date: d.date, value: d.mean }))}
              />
            </>
          ) : (
            <p className="text-sm text-base-content/60">
              SMAP verisi henüz kaydedilmedi. Kaydedilince bu hafta toprağın kök bölgesindeki nemi burada, belirsizlik aralığıyla göreceksin.
            </p>
          )}
          <SmapSourceNote s={a.smap} />
        </div>
      </div>

      <div className="card bg-base-100 shadow-sm">
        <div className="card-body">
          <div className="flex items-center justify-between">
            <h2 className="card-title">Fotoğraftan gördüklerimiz · {v.observed_at}</h2>
            <StatusTag status="demo_static" />
          </div>
          <p>
            Meyvelerde kırmızılaşma geçen haftaya göre daha belirgin görünüyor ({phenologyLabels[v.phenology.stage].toLowerCase()}). Bölgedeki sıcaklık birikimi de
            bununla uyumlu.
          </p>
          <p className="text-sm text-base-content/70">
            Fotoğraftan çıkaramadıklarımız: toprak pH&apos;ı, kesin toprak nemi, verim. Bunları tahmin etmiyoruz.
          </p>
          <details className="collapse-arrow collapse bg-base-200">
            <summary className="collapse-title text-sm font-medium">Teknik çıktı (vision JSON)</summary>
            <pre className="collapse-content overflow-x-auto text-xs">{JSON.stringify(v, null, 2)}</pre>
          </details>
        </div>
      </div>

      <div className="card bg-base-100 shadow-sm">
        <div className="card-body">
          <div className="flex items-center justify-between">
            <h2 className="card-title">Benzer sezonlar</h2>
            <StatusTag status="demo_static" />
          </div>
          <p className="text-sm text-base-content/70">Benzer koşullarda {twinSeasons.length} geçmiş sezon bulduk.</p>
          <ul className="space-y-2">
            {twinSeasons.map((t) => (
              <li key={t.id} className="rounded-box bg-base-200 p-3">
                <div className="flex justify-between text-sm font-medium">
                  <span>{t.label}</span>
                  <span>benzerlik {Math.round(t.similarity * 100)}%</span>
                </div>
                <p className="text-sm text-base-content/70">{t.note}</p>
              </li>
            ))}
          </ul>
          <p className="text-xs text-base-content/50">Benzerlik nedensellik değildir. Benzerlik ağırlıkları uzman sezgisiyle belirlendi, kalibre edilecek.</p>
        </div>
      </div>
    </>
  );
}
