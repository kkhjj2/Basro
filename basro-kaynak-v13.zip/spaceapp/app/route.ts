import { readFile } from "node:fs/promises";
import path from "node:path";

/** Ana deneyim: çiftçi uygulaması (public/index.html, vanilla ES modülleri). Veri ve yapay zekâ /api/* üzerinden. */
export async function GET() {
  const html = await readFile(path.join(process.cwd(), "public", "index.html"), "utf8");
  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache" } });
}
