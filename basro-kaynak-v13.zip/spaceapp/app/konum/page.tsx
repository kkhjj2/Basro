import type { Metadata } from "next";
import { PageShell } from "@/components/app-header";
import { LocationPicker } from "@/components/location-picker";
import { LOCATION_CROPS } from "@/lib/location-analysis";

export const metadata: Metadata = { title: "Tarlan nerede? — Basro" };

export default function LocationPage() {
  return (
    <PageShell
      title="Tarlan nerede?"
      lead="Haritada tarlanın üstüne dokun. O nokta için NASA'nın iklim kayıtlarına birlikte bakalım."
    >
      <LocationPicker crops={LOCATION_CROPS} />
    </PageShell>
  );
}
