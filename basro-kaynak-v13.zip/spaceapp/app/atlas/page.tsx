import { Suspense } from "react";
import { PageShell } from "@/components/app-header";
import { SourceNote } from "@/components/badges";
import { MiniChart } from "@/components/line-chart";
import { mean } from "@/lib/agro";
import { farm } from "@/lib/demo-data";
import { getClimatology, getRecentClimate } from "@/lib/nasa-power";

export default function AtlasPage() {
  return (
    <PageShell title="Atlas" lead={`${farm.region} · bölgenin iklim geçmişi`}>
      <Suspense fallback={<div className="skeleton h-96" />}>
        <AtlasContent />
      </Suspense>
    </PageShell>
  );
}

async function AtlasContent() {
  const { lat, lon } = farm.centroid;
  const [recent, clim] = await Promise.all([getRecentClimate(lat, lon), getClimatology(lat, lon)]);
  if (recent.days.length === 0) {
    return (
      <div className="alert alert-warning">
        <span>NASA POWER verisine şu an ulaşamadık ve kayıtlı veri de yok. Bağlantı gelince bu sayfa kendini güncelleyecek.</span>
      </div>
    );
  }

  // Normal: her günün kendi ayının uzun dönem ortalaması (pencere iki aya yayılabilir).
  const hasClim = clim.t2m.length === 12;
  const monthOf = (date: string) => Number(date.slice(5, 7)) - 1;
  const tMean = mean(recent.days.map((d) => d.t2m));
  const pSum = recent.days.reduce((s, d) => s + (d.precip ?? 0), 0);
  const tNormal = hasClim ? mean(recent.days.map((d) => clim.t2m[monthOf(d.date)])) : null;
  const pNormal = hasClim ? recent.days.reduce((s, d) => s + clim.precip[monthOf(d.date)], 0) : null;
  const dT = tMean != null && tNormal != null ? tMean - tNormal : null;

  const headline =
    dT == null
      ? "Bu bölgede son 30 günün iklim özeti."
      : Math.abs(dT) < 0.5
        ? "Bu bölgede son 30 gün mevsim normallerine yakın geçti."
        : `Bu bölgede son 30 gün normalden ${Math.abs(dT).toFixed(1)}°C daha ${dT > 0 ? "sıcak" : "serin"} geçti.`;

  return (
    <>
      <div className="card bg-base-100 shadow-sm">
        <div className="card-body">
          <h2 className="card-title text-2xl">{headline}</h2>
          <div className="stats stats-vertical bg-base-200 sm:stats-horizontal">
            <div className="stat">
              <div className="stat-title">Ortalama sıcaklık</div>
              <div className="stat-value text-3xl">{tMean?.toFixed(1)}°C</div>
              {tNormal != null && <div className="stat-desc">uzun dönem normali: {tNormal.toFixed(1)}°C</div>}
            </div>
            <div className="stat">
              <div className="stat-title">Toplam yağış</div>
              <div className="stat-value text-3xl">{pSum.toFixed(0)} mm</div>
              {pNormal != null && <div className="stat-desc">normal: ≈ {pNormal.toFixed(0)} mm</div>}
            </div>
          </div>
          <p className="text-sm text-base-content/60">
            Bu değerler ~55 km&apos;lik bir alanın ortalamasıdır; senin tarlanda birkaç derece ve birkaç milimetre fark olabilir.
          </p>
        </div>
      </div>

      <div className="card bg-base-100 shadow-sm">
        <div className="card-body">
          <h2 className="card-title">Günlük ortalama sıcaklık (°C)</h2>
          <MiniChart
            label="Son 30 günün günlük ortalama sıcaklığı"
            unit="°C"
            data={recent.days.map((d) => ({ date: d.date, value: d.t2m }))}
            baseline={tNormal != null ? { value: tNormal, label: "dönemin uzun yıllar ortalaması" } : undefined}
          />
          <h2 className="card-title mt-4">Günlük yağış (mm)</h2>
          <MiniChart
            label="Son 30 günün günlük yağışı"
            unit="mm"
            kind="bar"
            color="var(--color-info)"
            data={recent.days.map((d) => ({ date: d.date, value: d.precip }))}
          />
          <SourceNote p={recent.provenance} />
        </div>
      </div>
    </>
  );
}
