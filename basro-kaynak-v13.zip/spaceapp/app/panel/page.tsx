import Link from "next/link";
import { Suspense } from "react";
import { PageShell } from "@/components/app-header";
import { StatusTag } from "@/components/badges";
import { field, missions, priority, streakDays, trackingLevel } from "@/lib/demo-data";
import { analyzeField } from "@/lib/field-analysis";

export default function PanelPage() {
  const top = [...missions].sort((a, b) => priority(b) - priority(a))[0];
  return (
    <PageShell title="Günaydın" lead="Tarlalarında bugün dikkat etmen gereken 1 şey var.">
      <div className="card border border-primary/30 bg-base-100 shadow-sm">
        <div className="card-body">
          <span className="text-sm text-base-content/60">Bugünkü tek adımın · {field.name}</span>
          <h2 className="card-title text-2xl">{top.title}</h2>
          <p className="text-base-content/70">{top.detail}</p>
          <div className="card-actions mt-2 items-center justify-between">
            <span className="text-sm text-base-content/60">+{top.rewardXp} puan · {top.reason}</span>
            <Link href="/upload" className="btn btn-primary">
              Fotoğrafı çek
            </Link>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Suspense fallback={<div className="skeleton h-40" />}>
          <FieldSummary />
        </Suspense>
        <div className="card bg-base-100 shadow-sm">
          <div className="card-body">
            <h2 className="card-title">İlerlemen</h2>
            <p className="text-3xl font-bold">Tarla takip seviyesi {trackingLevel}</p>
            <p className="text-base-content/70">{streakDays} gündür tarlanı takip ediyorsun.</p>
            <Link href="/gorevler" className="link link-primary text-sm">
              Görevlerin ve puan geçmişin →
            </Link>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

async function FieldSummary() {
  const a = await analyzeField();
  return (
    <div className="card bg-base-100 shadow-sm">
      <div className="card-body">
        <div className="flex items-center justify-between">
          <h2 className="card-title">{field.name}</h2>
          <StatusTag status={a.season.days.length ? "implemented" : "demo_static"} />
        </div>
        <p className="text-base-content/70">
          {field.season.crop.name}lerin {a.weekOfSeason}. haftasında. {a.decision.current.stage}.
        </p>
        <p className="text-sm">{a.decision.current.text}</p>
        <Link href={`/tarla/${field.id}`} className="link link-primary text-sm">
          Neden böyle düşünüyoruz? →
        </Link>
      </div>
    </div>
  );
}
