import { Suspense } from "react";
import { PageShell } from "@/components/app-header";
import { SourceNote, StatusTag } from "@/components/badges";
import { farm } from "@/lib/demo-data";
import { getClimatology } from "@/lib/nasa-power";
import { getSmapRootzone, monthlyRootzone } from "@/lib/smap";
import { SmapSourceNote } from "@/components/smap-note";
import { CROPS, ROTATIONS, scoreRotation, totalScore } from "@/lib/rotation";

export default function RotationPage() {
  return (
    <PageShell title="Rotasyon Lab" lead="Önümüzdeki üç sezon için iki planı yan yana koyalım.">
      <Suspense fallback={<div className="skeleton h-96" />}>
        <RotationContent />
      </Suspense>
    </PageShell>
  );
}

async function RotationContent() {
  const { lat, lon } = farm.centroid;
  const [clim, smap] = await Promise.all([getClimatology(lat, lon), getSmapRootzone()]);
  const smapMonthly = smap.available ? monthlyRootzone(smap) : null;
  const results = ROTATIONS.map((r) => {
    const metrics = scoreRotation(r.crops, clim, lat, smapMonthly);
    return { ...r, metrics, total: totalScore(metrics) };
  });
  const [A, B] = results;

  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2">
        {results.map((r) => (
          <div key={r.id} className="card bg-base-100 shadow-sm">
            <div className="card-body">
              <h2 className="card-title">{r.name}</h2>
              <p className="text-base-content/70">{r.crops.map((c) => CROPS[c].name).join(" → ")}</p>
              <p className="text-3xl font-bold">{r.total ?? "—"} / 100</p>
            </div>
          </div>
        ))}
      </div>

      <div className="card bg-base-100 shadow-sm">
        <div className="card-body overflow-x-auto">
          <table className="table">
            <thead>
              <tr>
                <th>Metrik</th>
                <th className="text-right">A</th>
                <th className="text-right">B</th>
                <th>Kaynak</th>
              </tr>
            </thead>
            <tbody>
              {A.metrics.map((m, i) => {
                const b = B.metrics[i];
                return (
                  <tr key={m.key}>
                    <td>
                      <div className="font-medium">{m.label}</div>
                      <div className="text-xs text-base-content/60">A: {m.detail}</div>
                      <div className="text-xs text-base-content/60">B: {b.detail}</div>
                    </td>
                    <td className="text-right font-mono">
                      {m.score ?? "—"}
                      {m.interval && <div className="text-xs text-base-content/60">{m.interval[0]}–{m.interval[1]}</div>}
                    </td>
                    <td className="text-right font-mono">
                      {b.score ?? "—"}
                      {b.interval && <div className="text-xs text-base-content/60">{b.interval[0]}–{b.interval[1]}</div>}
                    </td>
                    <td className="text-xs">
                      <div className="mb-1">
                        <StatusTag status={m.status} />
                      </div>
                      {m.source}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <p className="text-xs text-base-content/50">
            Su dengesindeki küçük aralık, SMAP&apos;ın ±0,04 m³/m³ belirsizliğinin puana yansımasıdır. Toplam puan ilk dört metriğin ortalamasıdır; pazar opsiyoneldir ve toplama girmez. Kurallar ve ağırlıklar uzman bilgisine dayanır ve pilotla kalibre
            edilecektir. Bu bir öneri değil, karşılaştırmadır; son karar senin.
          </p>
          <div className="grid gap-3 md:grid-cols-2">
            <SourceNote p={clim.provenance} />
            <SmapSourceNote s={smap} />
          </div>
        </div>
      </div>
    </>
  );
}
