"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useId, useRef, useState } from "react";

const PROTOCOL_VERSION = "v1";
const MAX_FILE_SIZE_MB = 10;
const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/webp"];

const captureAngles = [
  {
    value: "nadir",
    label: "Tepeden (dik açı)",
    hint: "Telefonu yere paralel tut, bitki örtüsünü yukarıdan çek.",
  },
  {
    value: "oblique",
    label: "Eğik (yaklaşık 45°)",
    hint: "Sıranın boyunca, ufuk çizgisi kadrajın üst kısmında kalacak şekilde çek.",
  },
  {
    value: "close_up",
    label: "Yakın çekim (yaprak / meyve)",
    hint: "Tek bir yaprağı veya belirtiyi 20–30 cm mesafeden, gölgesiz çek.",
  },
] as const;

type CaptureAngle = (typeof captureAngles)[number]["value"];

const consentOptions = [
  {
    purpose: "personal_analysis",
    label: "Yalnızca bana özel analiz",
    description: "Fotoğrafın yalnızca senin tarlan için değerlendirilir.",
    required: true,
  },
  {
    purpose: "community_sharing",
    label: "Toplulukta paylaş (yer, tarih, fotoğraf)",
    description: "Bölgendeki çiftçiler gönderini görür. GPS/EXIF bilgisi kaldırılır.",
    required: false,
  },
  {
    purpose: "research_anonymized",
    label: "Benzer tarlalarla karşılaştır (konum gizli)",
    description: "Tarlan, konumu gizlenerek benzer tarlalarla karşılaştırılır.",
    required: false,
  },
] as const;

type ConsentPurpose = (typeof consentOptions)[number]["purpose"];

type AnalyzeResponse = {
  status: "ok" | "needs_review" | "not_configured";
  message?: string;
  duplicate?: boolean;
  result?: {
    abstain: boolean;
    abstain_reason: string | null;
    phenology: { stage: string; confidence: number };
    image_quality: { usable: boolean; crop_visibility: number };
  } | null;
  decisionGrade?: boolean;
  usedFallback?: boolean;
  attempts?: { model: string; valid: boolean; latencyMs: number; errors: string[] }[];
  farmerText?: string[];
  persisted?: boolean;
  xp?: { delta: number; label: string } | null;
};

type Status =
  | { kind: "idle" }
  | { kind: "error"; message: string }
  | { kind: "success"; data: AnalyzeResponse };

function validateFile(file: File): string | null {
  if (!ACCEPTED_TYPES.includes(file.type)) {
    return "Bu dosya türünü okuyamıyoruz. Lütfen JPG, PNG veya WEBP formatında bir fotoğraf seç.";
  }
  if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
    return `Fotoğraf ${MAX_FILE_SIZE_MB} MB'tan büyük olmamalı.`;
  }
  return null;
}

function formatSize(bytes: number) {
  return bytes < 1024 * 1024
    ? `${(bytes / 1024).toFixed(0)} KB`
    : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function UploadPage() {
  const inputId = useId();
  const inputRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [captureAngle, setCaptureAngle] = useState<CaptureAngle>("nadir");
  const [observedAt, setObservedAt] = useState("");
  const [note, setNote] = useState("");
  const [consents, setConsents] = useState<Record<ConsentPurpose, boolean>>({
    personal_analysis: true,
    community_sharing: false,
    research_anonymized: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [status, setStatus] = useState<Status>({ kind: "idle" });

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  function selectFile(next: File | undefined) {
    if (!next) return;
    const error = validateFile(next);
    if (error) {
      setStatus({ kind: "error", message: error });
      return;
    }
    setStatus({ kind: "idle" });
    setFile(next);
    setPreview(URL.createObjectURL(next));
  }

  function clearFile() {
    setFile(null);
    setPreview(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  function resetForm() {
    clearFile();
    setCaptureAngle("nadir");
    setObservedAt("");
    setNote("");
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!file) {
      setStatus({ kind: "error", message: "Önce tarlandan bir fotoğraf seçmelisin." });
      return;
    }
    if (!consents.personal_analysis) {
      setStatus({
        kind: "error",
        message: "Fotoğrafını analiz edebilmemiz için kişisel analiz onayı gerekli.",
      });
      return;
    }

    const formData = new FormData();
    formData.append("image", file);
    formData.append("capture_angle", captureAngle);
    formData.append("protocol_version", PROTOCOL_VERSION);
    formData.append(
      "observed_at",
      new Date(observedAt || Date.now()).toISOString(),
    );
    formData.append("note", note);
    formData.append(
      "consents",
      JSON.stringify(
        (Object.keys(consents) as ConsentPurpose[]).filter((p) => consents[p]),
      ),
    );

    setIsSubmitting(true);
    setStatus({ kind: "idle" });
    try {
      const res = await fetch("/api/analyze", { method: "POST", body: formData });
      const data = (await res.json()) as AnalyzeResponse & { error?: string };
      if (!res.ok && data.error) {
        setStatus({ kind: "error", message: data.error });
        return;
      }
      setStatus({ kind: "success", data });
      resetForm();
    } catch {
      setStatus({
        kind: "error",
        message: "Gözlemin şu an kaydedilemedi. Lütfen biraz sonra tekrar dene.",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  const selectedAngle = captureAngles.find((a) => a.value === captureAngle);

  return (
    <>
      <header className="navbar border-b border-base-300 bg-base-100 px-4 md:px-8">
        <div className="flex-1">
          <Link href="/" className="text-xl font-bold tracking-tight">
            <span className="text-primary">Agro</span>Bas
          </Link>
        </div>
        <Link href="/" className="btn btn-ghost btn-sm">
          ← Ana sayfa
        </Link>
      </header>

      <main className="flex-1 bg-base-200 px-4 py-10 md:px-8">
        <div className="mx-auto max-w-3xl">
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight">Bu hafta tarlan nasıl?</h1>
            <p className="mt-2 text-base-content/70">
              Tarlanı daha iyi tanıyalım. Aynı açıdan bir fotoğraf, gelişimi
              geçen haftayla karşılaştırmamıza yeter.
            </p>
          </div>

          <div role="note" className="alert alert-info alert-soft mb-6">
            <span>
              Fotoğrafın yalnızca aşağıda seçtiğin amaçlar için kullanılır.
              Topluluk paylaşımı tarla analizinden ayrıdır.
            </span>
          </div>

          {status.kind === "success" && <AnalysisResult data={status.data} />}

          {status.kind === "error" && (
            <div role="alert" className="alert alert-error mb-6">
              <span>{status.message}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="card bg-base-100 shadow-sm">
            <div className="card-body gap-6">
              <section>
                <h2 className="mb-3 font-semibold">1. Fotoğraf</h2>
                {preview && file ? (
                  <div className="overflow-hidden rounded-box border border-base-300">
                    <div className="relative aspect-video bg-base-200">
                      <Image
                        src={preview}
                        alt="Seçilen saha fotoğrafının önizlemesi"
                        fill
                        unoptimized
                        className="object-contain"
                      />
                    </div>
                    <div className="flex items-center justify-between gap-4 p-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{file.name}</p>
                        <p className="text-xs text-base-content/60">
                          {formatSize(file.size)}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={clearFile}
                        className="btn btn-ghost btn-sm"
                      >
                        Değiştir
                      </button>
                    </div>
                  </div>
                ) : (
                  <label
                    htmlFor={inputId}
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragging(true);
                    }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setIsDragging(false);
                      selectFile(e.dataTransfer.files[0]);
                    }}
                    className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-box border-2 border-dashed p-10 text-center transition ${
                      isDragging
                        ? "border-primary bg-primary/10"
                        : "border-base-300 hover:border-primary hover:bg-base-200"
                    }`}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth={1.5}
                      className="size-10 text-primary"
                      aria-hidden="true"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.774 48.774 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0Z"
                      />
                    </svg>
                    <span className="font-medium">
                      Fotoğrafı buraya sürükle veya seçmek için dokun
                    </span>
                    <span className="text-sm text-base-content/60">
                      JPG, PNG veya WEBP · en fazla {MAX_FILE_SIZE_MB} MB
                    </span>
                  </label>
                )}
                <input
                  ref={inputRef}
                  id={inputId}
                  type="file"
                  accept={ACCEPTED_TYPES.join(",")}
                  className="sr-only"
                  onChange={(e) => selectFile(e.target.files?.[0])}
                />
              </section>

              <section>
                <h2 className="mb-3 font-semibold">2. Çekim açısı</h2>
                <div className="grid gap-3 sm:grid-cols-3">
                  {captureAngles.map((angle) => (
                    <label
                      key={angle.value}
                      className={`flex cursor-pointer items-start gap-3 rounded-box border p-3 transition ${
                        captureAngle === angle.value
                          ? "border-primary bg-primary/5"
                          : "border-base-300 hover:border-primary/50"
                      }`}
                    >
                      <input
                        type="radio"
                        name="capture_angle"
                        value={angle.value}
                        checked={captureAngle === angle.value}
                        onChange={() => setCaptureAngle(angle.value)}
                        className="radio radio-primary radio-sm mt-0.5"
                      />
                      <span className="text-sm font-medium">{angle.label}</span>
                    </label>
                  ))}
                </div>
                {selectedAngle && (
                  <p className="mt-2 text-sm text-base-content/60">
                    İpucu: {selectedAngle.hint}
                  </p>
                )}
              </section>

              <section className="grid gap-4 sm:grid-cols-2">
                <fieldset className="fieldset">
                  <legend className="fieldset-legend">3. Gözlem zamanı</legend>
                  <input
                    type="datetime-local"
                    value={observedAt}
                    onChange={(e) => setObservedAt(e.target.value)}
                    className="input w-full"
                  />
                  <p className="label">Boş bırakırsan şu anki zaman kullanılır.</p>
                </fieldset>
                <fieldset className="fieldset">
                  <legend className="fieldset-legend">Not (isteğe bağlı)</legend>
                  <textarea
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    maxLength={500}
                    placeholder="Örn. dün akşam sulama yapıldı, kuzey köşede sararma var."
                    className="textarea h-[42px] min-h-[42px] w-full"
                  />
                </fieldset>
              </section>

              <section>
                <h2 className="mb-3 font-semibold">4. Fotoğrafın kimlerle paylaşılsın?</h2>
                <div className="space-y-2">
                  {consentOptions.map((option) => (
                    <label
                      key={option.purpose}
                      className="flex cursor-pointer items-start gap-3 rounded-box border border-base-300 p-3"
                    >
                      <input
                        type="checkbox"
                        checked={consents[option.purpose]}
                        onChange={(e) =>
                          setConsents((prev) => ({
                            ...prev,
                            [option.purpose]: e.target.checked,
                          }))
                        }
                        className="checkbox checkbox-primary checkbox-sm mt-0.5"
                      />
                      <span>
                        <span className="flex items-center gap-2 text-sm font-medium">
                          {option.label}
                          {option.required && (
                            <span className="badge badge-xs badge-primary">
                              gerekli
                            </span>
                          )}
                        </span>
                        <span className="text-sm text-base-content/60">
                          {option.description}
                        </span>
                      </span>
                    </label>
                  ))}
                </div>
              </section>

              <div className="card-actions items-center justify-between border-t border-base-300 pt-4">
                <span className="text-xs text-base-content/50">
                  Protokol sürümü: {PROTOCOL_VERSION}
                </span>
                <button
                  type="submit"
                  disabled={!file || isSubmitting}
                  className="btn btn-primary"
                >
                  {isSubmitting && <span className="loading loading-spinner loading-sm" />}
                  {isSubmitting ? "Gönderiliyor..." : "Fotoğrafı gönder"}
                </button>
              </div>
            </div>
          </form>
        </div>
      </main>
    </>
  );
}

function AnalysisResult({ data }: { data: AnalyzeResponse }) {
  if (data.status === "not_configured") {
    return (
      <div role="status" className="alert alert-warning mb-6">
        <span>
          Fotoğrafın alındı ama otomatik analiz şu an kapalı (yapay zekâ anahtarı tanımlı değil). Demo için tarla sayfasındaki örnek analize
          bakabilirsin.
        </span>
      </div>
    );
  }
  const r = data.result;
  return (
    <div role="status" className="card mb-6 border border-base-300 bg-base-100 shadow-sm">
      <div className="card-body gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="card-title">İşte bu haftaki tarlan</h2>
          <div className="flex flex-wrap gap-1">
            {data.status === "needs_review" && <span className="badge badge-warning">incelemeye ayrıldı</span>}
            {r?.abstain && <span className="badge badge-neutral">karar verilmedi (abstain)</span>}
            {r && !r.abstain && data.decisionGrade && <span className="badge badge-success">tavsiyeye girebilir</span>}
            {r && !r.abstain && !data.decisionGrade && <span className="badge badge-ghost">kalite eşiğinin altında</span>}
            {data.usedFallback && <span className="badge badge-info badge-soft">yedek model kullanıldı</span>}
          </div>
        </div>
        <ul className="space-y-1">
          {data.farmerText?.map((t) => (
            <li key={t}>{t}</li>
          ))}
        </ul>
        {data.xp && (
          <p className="text-sm font-medium text-primary">
            +{data.xp.delta} puan · {data.xp.label}
          </p>
        )}
        <details className="collapse-arrow collapse bg-base-200">
          <summary className="collapse-title text-sm font-medium">Teknik ayrıntı</summary>
          <div className="collapse-content space-y-2 text-xs">
            <ul>
              {data.attempts?.map((a, i) => (
                <li key={i}>
                  {a.model} · {a.valid ? "şema geçerli" : "şema geçersiz"} · {a.latencyMs} ms
                  {a.errors.length > 0 && <span className="text-base-content/60"> — {a.errors.join("; ")}</span>}
                </li>
              ))}
            </ul>
            <p>{data.persisted ? "Supabase'e kaydedildi." : "Kayıt yapılmadı (Supabase bağlı değil)."}</p>
            {r && <pre className="overflow-x-auto">{JSON.stringify(r, null, 2)}</pre>}
          </div>
        </details>
      </div>
    </div>
  );
}
