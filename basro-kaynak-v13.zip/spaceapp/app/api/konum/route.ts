import { analyzeLocation } from "@/lib/location-analysis";
import { parseLocationInput } from "@/lib/location-input";
import { demoIds, insert, SupabaseError, supabaseConfigured } from "@/lib/supabase-rest";

/**
 * GET  /api/konum?lat&lon&crop&sowingDate → seçilen nokta için NASA POWER (canlı) + SMAP (kayıtlı hücre ise) analizi
 * POST /api/konum {lat, lon, crop, sowingDate, farmName, fieldName, areaHa, irrigation} → Supabase'e çiftlik + tarla + sezon
 */

const json = (body: unknown, status = 200) => Response.json(body, { status });
const IRRIGATION = ["drip", "sprinkler", "furrow", "rainfed", "other"];

export async function GET(req: Request) {
  const q = new URL(req.url).searchParams;
  const input = parseLocationInput({ lat: q.get("lat"), lon: q.get("lon"), crop: q.get("crop"), sowingDate: q.get("sowingDate") });
  if (typeof input === "string") return json({ error: input }, 400);
  return json(await analyzeLocation(input));
}

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return json({ error: "İstek okunamadı." }, 400);
  }
  const input = parseLocationInput({ lat: body.lat, lon: body.lon, crop: body.crop, sowingDate: body.sowingDate });
  if (typeof input === "string") return json({ error: input }, 400);
  if (!supabaseConfigured()) return json({ error: "Kayıt şu an kapalı (veritabanı ayarlı değil). Analiz yine de çalışır." }, 503);

  const text = (v: unknown, fallback: string) => {
    const s = typeof v === "string" ? v.trim().slice(0, 80) : "";
    return s || fallback;
  };
  const area = Number(body.areaHa);
  const areaHa = Number.isFinite(area) && area > 0 && area < 10_000 ? area : null;
  const irrigation = IRRIGATION.includes(String(body.irrigation)) ? String(body.irrigation) : "other";

  try {
    const [farm] = await insert<{ id: string }>("farms", {
      owner_id: demoIds.userId,
      name: text(body.farmName, "Çiftliğim"),
      centroid_lat: input.lat,
      centroid_lon: input.lon,
      area_ha: areaHa,
    });
    const [field] = await insert<{ id: string }>("fields", {
      farm_id: farm.id,
      owner_id: demoIds.userId,
      name: text(body.fieldName, "Tarlam"),
      geometry: { type: "Point", coordinates: [input.lon, input.lat] },
      area_ha: areaHa,
      irrigation_type: irrigation,
    });
    const [season] = await insert<{ id: string }>("seasons", {
      field_id: field.id,
      owner_id: demoIds.userId,
      crop_id: input.crop,
      sowing_date: input.sowingDate,
    });
    return json({ saved: true, farmId: farm.id, fieldId: field.id, seasonId: season.id });
  } catch (e) {
    const detail = e instanceof SupabaseError ? `${e.table} ${e.status}` : "bilinmeyen";
    console.error("konum kaydı başarısız:", e);
    return json({ error: `Tarla kaydedilemedi (${detail}). Analiz sonuçların kaybolmadı.` }, 502);
  }
}
