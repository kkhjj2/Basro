import { handleFarmPost } from "@/lib/codex/farm-api";

export function POST(req: Request) {
  return handleFarmPost(req, true);
}
