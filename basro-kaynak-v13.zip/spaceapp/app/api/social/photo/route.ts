import { downloadObject, select, supabaseConfigured } from "@/lib/supabase-rest";

/** GET /api/social/photo?id=<gönderi> → yalnızca toplulukla paylaşılmış bir gönderiye bağlı fotoğrafı döndürür. */
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function GET(req: Request) {
  const id = new URL(req.url).searchParams.get("id") ?? "";
  if (!supabaseConfigured() || !UUID.test(id)) return new Response("Bulunamadı", { status: 404 });
  try {
    const posts = await select<{ media_id: string | null }>("social_posts", `select=media_id&id=eq.${id}&visibility=eq.community&limit=1`);
    const mediaId = posts[0]?.media_id;
    if (!mediaId) return new Response("Bulunamadı", { status: 404 });
    const media = await select<{ storage_key: string; mime: string }>("media_objects", `select=storage_key,mime&id=eq.${mediaId}&limit=1`);
    if (!media.length || !/^image\/(jpeg|png|webp)$/.test(media[0].mime)) return new Response("Bulunamadı", { status: 404 });
    const { bytes } = await downloadObject(media[0].storage_key);
    return new Response(bytes, { headers: { "Content-Type": media[0].mime, "Cache-Control": "public, max-age=86400, immutable", "X-Content-Type-Options": "nosniff" } });
  } catch (e) {
    console.error("social photo:", e);
    return new Response("Fotoğraf yüklenemedi", { status: 502 });
  }
}
