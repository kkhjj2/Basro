import { createHash, randomUUID } from "node:crypto";
import { demoIds, insert, insertIgnore, remove, select, SupabaseError, supabaseConfigured, uploadObject } from "@/lib/supabase-rest";
import { assembleFeed, decodeBody, encodeBody, hasExif, imageKind, regionSummary } from "../../../public/social-wire.mjs";

/**
 * BAS Social — gönderi, fotoğraf, beğeni ve yorum (hepsi social_posts tablosunda; biçim: public/social-wire.mjs).
 * GET    /api/social?region=<ilçe>&scope=region|all → akış + haftalık gelişim tablosu (summary=1 → müdür paneli özeti)
 * POST   /api/social  JSON ya da multipart {kind:'post'|'comment'|'like', body, re, name, crop, heightCm, yieldKgDa, photo, consent, district, city, lat, lon}
 * DELETE /api/social?id=<uuid> → yalnızca aynı cihazın yazdığı gönderi ya da yorum
 * Giriş sistemi yok: sahiplik, tarayıcının ürettiği cihaz anahtarının özetiyle (x-agrobas-device) belirlenir.
 * Topluluk gönderileri tarla analizinde kanıt olarak kullanılmaz (social_posts ≠ ground_observations).
 */

const json = (body: unknown, status = 200) => Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CONSENT_VERSION = "bas-social-1";
const MAX_PHOTO = 1_500_000;

function regionSlug(s: string) {
  return s
    .toLocaleLowerCase("tr")
    .replace(/[çğıöşü]/g, (c) => ({ ç: "c", ğ: "g", ı: "i", ö: "o", ş: "s", ü: "u" })[c as "ç"] ?? c)
    .normalize("NFKD")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
}
/** Ham cihaz anahtarı saklanmaz; yalnızca özeti gövdeye yazılır. */
function deviceOf(req: Request) {
  const raw = (req.headers.get("x-agrobas-device") ?? "").trim();
  return /^[A-Za-z0-9_-]{16,64}$/.test(raw) ? createHash("sha256").update("agrobas:" + raw).digest("hex").slice(0, 16) : "";
}

type Row = { id: string; author_id: string; body: string; region_id: string | null; media_id: string | null; created_at: string };

export async function GET(req: Request) {
  if (!supabaseConfigured()) return json({ configured: false, posts: [], growth: [], mastery: [] });
  const q = new URL(req.url).searchParams;
  const region = q.get("scope") === "region" ? regionSlug(q.get("region") ?? "") : "";
  try {
    const rows = await select<Row>("social_posts", "select=id,author_id,body,region_id,media_id,created_at&visibility=eq.community&order=created_at.desc&limit=400");
    // Müdür paneli: yalnızca toplu sayılar (kişi adı ya da cihaz bilgisi dönmez).
    if (q.get("summary") === "1") return json({ configured: true, region: region || null, summary: regionSummary(rows, { region: region || null }) });
    const regions = [...new Set(rows.map((p) => p.region_id).filter(Boolean))] as string[];
    const regionRows = regions.length ? await select<{ id: string; name: string }>("regions", `select=id,name&id=in.(${regions.join(",")})`) : [];
    const names = new Map(regionRows.map((r) => [r.id, r.name]));
    const feed = assembleFeed(rows, { device: deviceOf(req), region: region || null, regionName: (id: string) => names.get(id) ?? null });
    return json({ configured: true, posts: feed.posts.slice(0, 40), growth: feed.growth.slice(0, 20), mastery: feed.mastery.slice(0, 12) });
  } catch (e) {
    console.error("social GET:", e);
    return json({ configured: true, error: "Gönderiler şu an yüklenemedi.", posts: [], growth: [] }, 502);
  }
}

const recent = new Map<string, number[]>();
function rateLimited(key: string, max: number) {
  const now = Date.now(), list = (recent.get(key) ?? []).filter((t) => now - t < 60_000);
  list.push(now);
  recent.set(key, list);
  return list.length > max;
}

async function storePhoto(file: File): Promise<string> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const mime = imageKind(bytes);
  if (!mime) throw new UserError("Fotoğraf JPEG, PNG ya da WebP olmalı.");
  if (bytes.length > MAX_PHOTO) throw new UserError("Fotoğraf çok büyük.");
  if (hasExif(bytes)) throw new UserError("Fotoğraf konum bilgisi taşıyor olabilir; uygulama içinden yeniden seç.");
  const sha256 = createHash("sha256").update(bytes).digest("hex");
  const uid = demoIds.userId;
  const existing = await select<{ id: string }>("media_objects", `select=id&owner_id=eq.${uid}&sha256=eq.${sha256}&limit=1`);
  if (existing.length) return existing[0].id;
  const key = `${uid}/social/${randomUUID()}.${mime.split("/")[1]}`;
  await uploadObject("field-photos", key, bytes.buffer as ArrayBuffer, mime);
  const [media] = await insert<{ id: string }>("media_objects", { owner_id: uid, provider: "supabase", storage_key: `field-photos/${key}`, sha256, mime, exif_scrubbed: true });
  return media.id;
}
class UserError extends Error {}

export async function POST(req: Request) {
  if (!supabaseConfigured()) return json({ error: "Paylaşım şu an kapalı (veritabanı ayarlı değil)." }, 503);
  let b: Record<string, unknown>, photo: File | null = null;
  try {
    if ((req.headers.get("content-type") ?? "").includes("multipart/form-data")) {
      const f = await req.formData();
      b = Object.fromEntries([...f.entries()].filter(([, v]) => typeof v === "string"));
      const p = f.get("photo");
      photo = p instanceof File && p.size > 0 ? p : null;
      if (b.consent === "true") b.consent = true;
    } else b = await req.json();
  } catch {
    return json({ error: "İstek okunamadı." }, 400);
  }
  const device = deviceOf(req);
  if (!device) return json({ error: "Cihaz anahtarı eksik; sayfayı yenileyip tekrar dene." }, 400);
  const kind = b.kind === "comment" || b.kind === "like" ? b.kind : "post";
  const re = typeof b.re === "string" && UUID.test(b.re) ? b.re.toLowerCase() : "";
  const text = typeof b.body === "string" ? b.body.replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, "").trim() : "";
  const ip = req.headers.get("x-forwarded-for") ?? "local";
  const uid = demoIds.userId;
  try {
    if (kind !== "post") {
      if (!re) return json({ error: "Gönderi bulunamadı." }, 400);
      const parent = await select<Row>("social_posts", `select=id,body&id=eq.${re}&visibility=eq.community&limit=1`);
      if (!parent.length || decodeBody(parent[0].body).meta.k !== "post") return json({ error: "Gönderi bulunamadı." }, 404);
    }
    if (kind === "like") {
      if (rateLimited("like:" + ip, 40)) return json({ error: "Biraz yavaş." }, 429);
      const mine = (await select<Row>("social_posts", `select=id,body&author_id=eq.${uid}&body=like.*${re}*&limit=400`)).filter((r) => {
        const m = decodeBody(r.body).meta;
        return m.k === "like" && m.re === re && m.d === device;
      });
      if (mine.length) {
        for (const r of mine) await remove("social_posts", `id=eq.${r.id}&author_id=eq.${uid}`);
        return json({ liked: false });
      }
      await insert("social_posts", { author_id: uid, body: encodeBody({ k: "like", d: device, re }), visibility: "community" });
      return json({ liked: true });
    }
    if (b.consent !== true) return json({ error: "Paylaşmak için topluluk paylaşım iznini onaylaman gerekiyor." }, 400);
    if (kind === "comment") {
      if (text.length < 1) return json({ error: "Yorum boş olamaz." }, 400);
      if (text.length > 300) return json({ error: "Yorum en fazla 300 karakter olabilir." }, 400);
    } else {
      if (text.length < 3 && !photo) return json({ error: "Gönderi en az 3 karakter olmalı." }, 400);
      if (text.length > 500) return json({ error: "Gönderi en fazla 500 karakter olabilir." }, 400);
    }
    if (rateLimited("post:" + ip, 6)) return json({ error: "Çok hızlı paylaşıyorsun; bir dakika sonra tekrar dene." }, 429);

    const active = await select("consents", `select=id&user_id=eq.${uid}&purpose=eq.community_sharing&revoked_at=is.null&limit=1`);
    if (!active.length) await insert("consents", { user_id: uid, purpose: "community_sharing", version: CONSENT_VERSION, scope: { source: "bas-social" } });

    const name = typeof b.name === "string" ? b.name : "";
    if (kind === "comment") {
      const [row] = await insert<Row>("social_posts", { author_id: uid, body: encodeBody({ k: "comment", n: name, d: device, re }, text), visibility: "community" });
      return json({ saved: true, id: row.id, createdAt: row.created_at });
    }
    const district = typeof b.district === "string" ? b.district.trim().slice(0, 60) : "";
    const city = typeof b.city === "string" ? b.city.trim().slice(0, 60) : "";
    const lat = Number(b.lat), lon = Number(b.lon);
    const regionId = district ? regionSlug(district) : null;
    const regionReady = Boolean(regionId) && Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180;
    // Bölge merkezi kaba tutulur (0,1°); tarlanın tam konumu paylaşılmaz.
    if (regionReady) await insertIgnore("regions", { id: regionId, name: city ? `${district}, ${city}` : district, centroid_lat: Math.round(lat * 10) / 10, centroid_lon: Math.round(lon * 10) / 10 });
    const mediaId = photo ? await storePhoto(photo) : null;
    const body = encodeBody({ k: "post", n: name, d: device, crop: b.crop, h: b.heightCm, y: b.yieldKgDa }, text);
    const [post] = await insert<Row>("social_posts", { author_id: uid, body, media_id: mediaId, region_id: regionReady ? regionId : null, visibility: "community" });
    return json({ saved: true, id: post.id, createdAt: post.created_at });
  } catch (e) {
    if (e instanceof UserError) return json({ error: e.message }, 400);
    const detail = e instanceof SupabaseError ? `${e.table} ${e.status}` : "bilinmeyen";
    console.error("social POST:", e);
    return json({ error: `Paylaşılamadı (${detail}).` }, 502);
  }
}

export async function DELETE(req: Request) {
  if (!supabaseConfigured()) return json({ error: "Veritabanı ayarlı değil." }, 503);
  const id = (new URL(req.url).searchParams.get("id") ?? "").toLowerCase();
  if (!UUID.test(id)) return json({ error: "Geçersiz gönderi." }, 400);
  const device = deviceOf(req), uid = demoIds.userId;
  try {
    const rows = await select<Row>("social_posts", `select=id,body&id=eq.${id}&author_id=eq.${uid}&limit=1`);
    if (!rows.length) return json({ error: "Gönderi bulunamadı." }, 404);
    const meta = decodeBody(rows[0].body).meta;
    // Eski (üst bilgisiz) gönderiler önceki davranışla silinebilir; yenilerde cihaz eşleşmesi şart.
    if (!meta.legacy && (!device || meta.d !== device)) return json({ error: "Bu gönderiyi yalnızca yazan cihaz silebilir." }, 403);
    await remove("social_posts", `id=eq.${id}&author_id=eq.${uid}`);
    if (meta.k === "post") {
      const kids = (await select<Row>("social_posts", `select=id,body&author_id=eq.${uid}&body=like.*${id}*&limit=400`)).filter((r) => decodeBody(r.body).meta.re === id);
      for (const k of kids) await remove("social_posts", `id=eq.${k.id}&author_id=eq.${uid}`);
    }
    return json({ deleted: true });
  } catch (e) {
    console.error("social DELETE:", e);
    return json({ error: "Gönderi silinemedi." }, 502);
  }
}
