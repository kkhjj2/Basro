import { assistantStatus, handleFarmPost } from "@/lib/codex/farm-api";

export function GET() {
  return assistantStatus();
}

export function POST(req: Request) {
  return handleFarmPost(req, false);
}
