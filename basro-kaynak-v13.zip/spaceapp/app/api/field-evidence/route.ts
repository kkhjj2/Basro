import { haversineKm, SMAP_SAME_CELL_KM } from "@/lib/location-input";
import { getSmapRootzone, SMAP_UNCERTAINTY, windowMean } from "@/lib/smap";

/**
 * GET /api/field-evidence?lat&lon → tarla motoru için uydu kanıtı.
 * SMAP L4 kök bölgesi nemi yalnızca kaydedilen 9 km hücrenin içindeyse döner; başka noktanın verisi ödünç verilmez.
 */
export async function GET(req: Request) {
  const q = new URL(req.url).searchParams;
  const lat = Number(q.get("lat"));
  const lon = Number(q.get("lon"));
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180)
    return Response.json({ error: "Konum geçersiz." }, { status: 400 });
  const smap = await getSmapRootzone();
  const p = smap.provenance;
  const distanceKm = p.lat != null && p.lon != null ? haversineKm(lat, lon, p.lat, p.lon) : null;
  const last = smap.daily.at(-1)?.date ?? null;
  if (!smap.available || distanceKm == null || distanceKm > SMAP_SAME_CELL_KM || !last) {
    return Response.json({
      smap: { available: false, distanceKm: distanceKm == null ? null : Math.round(distanceKm * 10) / 10, reason: "Bu konum için kayıtlı SMAP verisi yok." },
    });
  }
  const start = new Date(Date.parse(last) - 6 * 86_400_000).toISOString().slice(0, 10);
  const theta = windowMean(smap, start, last);
  return Response.json({
    smap: {
      available: theta != null,
      theta,
      uncertainty: SMAP_UNCERTAINTY,
      window: { start, end: last },
      recordedAt: p.recordedAt,
      product: `${p.product} ${p.layer}`,
      resolution: p.resolution,
      distanceKm: Math.round(distanceKm * 10) / 10,
      sourceType: "model_estimate",
    },
  });
}
