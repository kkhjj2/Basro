import { createHash, randomUUID } from "node:crypto";
import { field, previousVision } from "@/lib/demo-data";
import { farmerSummary } from "@/lib/farmer-text";
import { demoIds, insert, select, SupabaseError, supabaseConfigured, uploadObject } from "@/lib/supabase-rest";
import { analyzeImage, VERSIONS } from "@/lib/vision";
import { isDecisionGrade, type VisionResult } from "@/lib/vision-schema";

/**
 * POST /api/analyze — fotoğraf → rıza kontrolü → tekrar/limit korumaları → vision (abstain zorunlu)
 * → (Supabase yapılandırıldıysa) Storage + consents + ground_observations + ai_runs + validated_evidence + xp_ledger.
 */

const DAILY_AI_LIMIT = Number(process.env.AGROBAS_DAILY_AI_LIMIT ?? 10);
const ACCEPTED = ["image/jpeg", "image/png", "image/webp"];
const MAX_BYTES = 10 * 1024 * 1024;
const PURPOSES = ["personal_analysis", "community_sharing", "research_anonymized"] as const;
const CONSENT_VERSION = "consent-v1";

// Sunucu belleğinde basit korumalar (Supabase yoksa da çalışır).
const dailyCount = new Map<string, number>();
const seenHashes = new Map<string, unknown>();

const json = (body: unknown, status = 200) => Response.json(body, { status });

export async function POST(req: Request) {
  const form = await req.formData();
  const image = form.get("image");
  if (!(image instanceof File)) return json({ error: "Fotoğraf bulunamadı." }, 400);
  if (!ACCEPTED.includes(image.type))
    return json({ error: "Bu dosya türünü analiz edemiyoruz. JPG, PNG veya WEBP kullan (HEIC desteklenmiyor)." }, 415);
  if (image.size > MAX_BYTES) return json({ error: "Fotoğraf 10 MB'tan büyük olmamalı." }, 413);

  let consents: string[] = [];
  try {
    consents = JSON.parse(String(form.get("consents") ?? "[]"));
  } catch {}
  consents = consents.filter((c) => (PURPOSES as readonly string[]).includes(c));
  if (!consents.includes("personal_analysis"))
    return json({ error: "Fotoğrafını analiz edebilmemiz için “Yalnızca bana özel analiz” onayı gerekli." }, 400);

  const captureAngle = String(form.get("capture_angle") ?? "nadir");
  const protocolVersion = String(form.get("protocol_version") ?? "v1");
  const observedAt = new Date(String(form.get("observed_at") || Date.now()));
  const observedIso = (isNaN(observedAt.getTime()) ? new Date() : observedAt).toISOString();
  const serverReceivedAt = new Date().toISOString(); // EXIF zamanı tek kaynak değil

  // Günlük AI çağrısı limiti
  const userKey = demoIds.userId || req.headers.get("x-forwarded-for") || "local";
  const dayKey = `${userKey}:${serverReceivedAt.slice(0, 10)}`;
  if ((dailyCount.get(dayKey) ?? 0) >= DAILY_AI_LIMIT)
    return json({ error: `Bugün için ${DAILY_AI_LIMIT} analiz hakkını kullandın. Yarın tekrar deneyebilirsin.` }, 429);

  const bytes = await image.arrayBuffer();
  const sha256 = createHash("sha256").update(Buffer.from(bytes)).digest("hex");

  // Aynı fotoğraf ikinci kez analiz edilmez
  if (seenHashes.has(sha256)) return json({ duplicate: true, ...(seenHashes.get(sha256) as object) });
  const db = supabaseConfigured();
  if (db) {
    const prev = await select("media_objects", `owner_id=eq.${demoIds.userId}&sha256=eq.${sha256}&select=id`);
    if (prev.length) return json({ error: "Bu fotoğrafı daha önce yüklemişsin. Bu hafta için yeni bir fotoğraf çek." }, 409);
    const day = observedIso.slice(0, 10);
    const sameDay = await select("ground_observations", `field_id=eq.${demoIds.fieldId}&observed_day=eq.${day}&select=id`);
    if (sameDay.length) return json({ error: "Bu tarla için bugünkü analiz zaten yapıldı. Yarın yeni bir fotoğrafla devam edebilirsin." }, 409);
  }

  // Önceki gözlem (karşılaştırma bağlamı)
  let previous: { stage: string; confidence: number } | null = previousVision.phenology;
  if (db) {
    const last = await select<{ value: { stage: string }; confidence: number }>(
      "validated_evidence",
      `user_id=eq.${demoIds.userId}&evidence_type=eq.phenology&abstain=eq.false&order=created_at.desc&limit=1&select=value,confidence`,
    );
    if (last[0]) previous = { stage: last[0].value.stage, confidence: last[0].confidence };
  }

  dailyCount.set(dayKey, (dailyCount.get(dayKey) ?? 0) + 1);
  const outcome = await analyzeImage(Buffer.from(bytes).toString("base64"), image.type, {
    cropId: field.season.crop.id,
    cropName: field.season.crop.name,
    fieldId: field.id,
    observedAt: observedIso.slice(0, 10),
    previous,
  });

  if (outcome.status === "not_configured") {
    return json({
      status: "not_configured",
      message: "Fotoğraf analizi için yapay zekâ anahtarı tanımlı değil (GROQ_API_KEY / GEMINI_API_KEY).",
    });
  }

  const result: VisionResult | null = outcome.status === "ok" ? outcome.result : null;
  const response = {
    status: outcome.status,
    result,
    decisionGrade: result ? isDecisionGrade(result) : false,
    usedFallback: outcome.status === "ok" ? outcome.usedFallback : false,
    attempts: outcome.attempts.map((a) => ({ model: a.model_id, valid: a.schema_valid, latencyMs: a.latency_ms, errors: a.errors.slice(0, 3) })),
    farmerText: result
      ? farmerSummary(result, previous?.stage)
      : outcome.attempts.every((a) => a.output_json == null)
        ? ["Analiz servisi şu an çok yoğun, fotoğrafını değerlendiremedik. Birkaç dakika sonra tekrar dener misin? Bu arada tahmin yürütmüyoruz."]
        : ["Fotoğrafını otomatik olarak değerlendiremedik; bir uzmanın bakması için ayırdık. Bu arada tahmin yürütmüyoruz."],
    persisted: false,
    xp: null as null | { delta: number; label: string },
  };

  if (db) {
    try {
      await persist({ bytes, mime: image.type, sha256, consents, captureAngle, protocolVersion, observedIso, outcome, result, response });
      response.persisted = true;
    } catch (err) {
      const conflict = err instanceof SupabaseError && err.isConflict;
      return json({ ...response, persistError: conflict ? "Bu kayıt zaten var." : String(err) }, conflict ? 409 : 500);
    }
  }

  if (outcome.status === "ok") seenHashes.set(sha256, response);
  return json(response);
}

async function persist(p: {
  bytes: ArrayBuffer;
  mime: string;
  sha256: string;
  consents: string[];
  captureAngle: string;
  protocolVersion: string;
  observedIso: string;
  outcome: Awaited<ReturnType<typeof analyzeImage>>;
  result: VisionResult | null;
  response: { xp: null | { delta: number; label: string } };
}) {
  const uid = demoIds.userId;
  const ext = p.mime.split("/")[1] ?? "jpg";
  const key = `${uid}/${randomUUID()}.${ext}`;
  await uploadObject("field-photos", key, p.bytes, p.mime);

  const [media] = await insert<{ id: string }>("media_objects", {
    owner_id: uid,
    provider: "supabase",
    storage_key: `field-photos/${key}`,
    sha256: p.sha256,
    mime: p.mime,
    exif_scrubbed: false, // MVP: topluluk paylaşımı yapılmadığı için orijinal saklanır
  });

  await insert(
    "consents",
    p.consents.map((purpose) => ({ user_id: uid, purpose, scope: { media_id: media.id }, version: CONSENT_VERSION })),
  );

  const [obs] = await insert<{ id: string }>("ground_observations", {
    user_id: uid,
    field_id: demoIds.fieldId,
    season_id: demoIds.seasonId || null,
    media_id: media.id,
    observed_at: p.observedIso,
    method: "photo",
    protocol_version: p.protocolVersion,
    capture_angle: p.captureAngle,
    raw_signal: p.result,
  });

  if (p.outcome.status === "not_configured") return;
  const runs = await insert<{ id: string; schema_valid: boolean }>(
    "ai_runs",
    p.outcome.attempts.map((a, i) => ({
      user_id: uid,
      model_id: a.model_id,
      prompt_version: VERSIONS.prompt,
      output_schema_version: VERSIONS.schema,
      input_refs: { media_id: media.id, observation_id: obs.id },
      input_hash: p.sha256,
      output_json: a.output_json,
      schema_valid: a.schema_valid,
      status: a.schema_valid ? (i > 0 ? "fallback" : "ok") : p.outcome.status === "needs_review" && i === p.outcome.attempts.length - 1 ? "needs_review" : "invalid_json",
      latency_ms: a.latency_ms,
    })),
  );

  if (!p.result) return;
  const run = runs.find((r) => r.schema_valid)!;
  const validator = p.outcome.status === "ok" ? p.outcome.attempts.find((a) => a.schema_valid)!.model_id : "";
  await insert("validated_evidence", [
    {
      user_id: uid,
      observation_id: obs.id,
      ai_run_id: run.id,
      evidence_type: "phenology",
      value: { stage: p.result.phenology.stage, cannot_infer: p.result.cannot_infer },
      confidence: p.result.phenology.confidence,
      validator_model: validator,
      validator_version: VERSIONS.schema,
      abstain: p.result.abstain,
      abstain_reason: p.result.abstain_reason,
    },
    ...p.result.visible_signals.map((s) => ({
      user_id: uid,
      observation_id: obs.id,
      ai_run_id: run.id,
      evidence_type: "visible_signal",
      value: { type: s.type },
      confidence: s.confidence,
      validator_model: validator,
      validator_version: VERSIONS.schema,
      abstain: p.result!.abstain,
      abstain_reason: p.result!.abstain_reason,
    })),
  ]);

  // Katılım puanı: kontrol yapıldığı için hemen verilir; "Doğrulanmış gözlemci" rozeti ayrı ve kanıta bağlıdır.
  const label = "Haftalık kontrolü tamamladın";
  await insert("xp_ledger", {
    user_id: uid,
    source_type: "mission",
    source_id: obs.id,
    delta: 50,
    label,
    idempotency_key: `weekly_check:${demoIds.fieldId}:${p.observedIso.slice(0, 10)}`,
  });
  p.response.xp = { delta: 50, label };
}
