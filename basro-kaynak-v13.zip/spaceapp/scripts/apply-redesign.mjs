// AgroBas koyu arayüz: yan menü kabuğu, ana ekran düzeni ve tahmin takvimi bağlantıları.
// import-codex.mjs sonunda çağrılır; tek başına da çalışır: node scripts/apply-redesign.mjs
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=path.join(path.dirname(fileURLToPath(import.meta.url)),'..');
function patch(file,pairs){
 const p=path.join(root,file);let s=fs.readFileSync(p,'utf8');
 for(const [a,b] of pairs){if(s.includes(b))continue;if(!s.includes(a))throw new Error(`${file}: beklenen metin yok → ${a.slice(0,70)}`);s=s.replace(a,b);}
 fs.writeFileSync(p,s);
}
const OLD_SHELL_START="root.innerHTML=`<header class=\"farm-top farm-wrap\">";
const OLD_SHELL_END="</nav>`;\n root.querySelectorAll('[data-farm-view]')";
{
 const p=path.join(root,'public/farmer.js');let s=fs.readFileSync(p,'utf8');
 const i=s.indexOf(OLD_SHELL_START),j=s.indexOf(OLD_SHELL_END,i);
 if(i>=0&&j>i){
  const views="${view==='today'?todayView():view==='lab'?'<div id=\"living-lab-host\"></div>':view==='season'?seasonView(farm,seasonState,ownSeasonInputs(),weather):view==='photo'?photoView():view==='farm'?farmView():journalView()}";
  const shell="root.innerHTML=`<div class=\"ab-shell\" data-view=\"${view}\"><aside class=\"ab-side\" aria-label=\"AgroBas menüsü\"><div class=\"ab-brand\">${brand}<small>Tarla yardımcın</small></div><nav class=\"ab-nav\" aria-label=\"Çiftçi menüsü\">${nav.map(([id,i,label])=>`<button data-farm-view=\"${id}\" ${(view===id||view==='lab'&&id==='season')?'aria-current=\"page\"':''}>${icon(i)}<span>${label}</span></button>`).join('')}</nav><button class=\"farm-place ab-land\" id=\"farm-place\" aria-haspopup=\"dialog\"><span class=\"ab-land-ico\" aria-hidden=\"true\">${cropIcon(farm.crop)}</span><span class=\"ab-land-text\"><small>SEÇİLİ ARAZİN</small><strong>${esc(farm.name)}</strong><em>${esc(farm.district)} · ${esc(farm.crop)}</em></span><b aria-hidden=\"true\">⌄</b></button><div class=\"ab-side-foot\"><button id=\"farm-sources\">Veri ve kaynaklar</button><button id=\"farm-atlas\">Dünya atlası ↗</button><a class=\"ab-foot-a\" href=\"/mudur.html\">Müdür paneli ↗</a><p>NASA POWER · SMAP · ECMWF SEAS5 · Open-Meteo</p></div></aside><main class=\"farm-main ab-main\" id=\"farmer-main\">${cropSelection()}"+views+"<footer class=\"farm-footer\"><span>Toprağın için, her gün bir adım.</span></footer></main></div>`;\n root.querySelectorAll('[data-farm-view]')";
  s=s.slice(0,i)+shell+s.slice(j+OLD_SHELL_END.length);fs.writeFileSync(p,s);
 }else if(!s.includes('class=\"ab-shell\"'))throw new Error('farmer.js: kabuk bulunamadı');
}
patch('public/farmer.js',[
 ["import {workspaceHtml,mountWorkspace,teaserHtml,mountTeaser} from './field-workspace.mjs';","import {workspaceHtml,mountWorkspace,teaserHtml,mountTeaser,applyPhotoEvidence,currentState} from './field-workspace.mjs';\nimport {detectGaps,mountNetwork} from './ground-network.mjs';\nimport {buildDays,buildMonths,calendarHtml,bindCalendar} from './forecast-calendar.mjs';\nimport {dailyInfoHtml,mountDailyInfo} from './daily-info.mjs';\nimport {socialHtml,mountSocial,syncProgress,progressChip,awardXp,XP} from './bas-social.mjs';\nimport {timelineItems,mountMemory} from './farm-memory.mjs';\nimport {buildReportFacts,mountReport} from './weekly-report.mjs';\nimport {twinProfile,mountTwins} from './farm-twins.mjs';\nimport {mountSoil,entriesOf as soilEntries,soilFact} from './soil-lab.mjs';\nimport {readMe,meStepHtml,bindMeStep,greetMe} from './farmer-profile.mjs';\nimport {arrangeToday} from './home-layout.mjs';"],
 ["${teaserHtml()}${seasonTeaser(farm,seasonState,ownSeasonInputs(),weather)}<div class=\"farm-layout\">","<div id=\"fc-host\">${calendarHtml([],[],{weatherAvailable:!weather.error,seasonStatus:'loading'})}</div><div class=\"ab-pulse\">${teaserHtml()}${seasonTeaser(farm,seasonState,ownSeasonInputs(),weather)}</div><div class=\"farm-layout\">"],
 ["mountTeaser($('#fw-teaser'),{farm,weather,storage:storage(),onOpen:()=>selectView('farm')});}","renderCalendar(null);mountTeaser($('#fw-teaser'),{farm,weather,storage:storage(),onOpen:()=>selectView('farm'),onDecision:r=>renderCalendar(r)});if(seasonState.status==='idle')loadSeason();}"],
 ["<div id=\"fc-host\">${calendarHtml(","${dailyInfoHtml(farm)}<div id=\"fc-host\">${calendarHtml("],
 ["renderCalendar(null);mountTeaser(","mountDailyInfo($('#daily-info'),farm);renderCalendar(null);mountTeaser("],
 ["['journal','i-book','Kayıtlarım']]","['journal','i-book','Kayıtlarım'],['social','i-people','Topluluk']]"],
 ["view==='farm'?farmView():journalView()}","view==='farm'?farmView():view==='social'?socialHtml():journalView()}"],
 ["else if(view==='farm')bindFarm();else bindJournal();","else if(view==='farm')bindFarm();else if(view==='social')mountSocial($('#bas-social'),{farm,storage:storage(),work,onObservation:t=>{notes.push({id:'note_'+Date.now().toString(36),farmId:farm.id,day:dayKey(),createdAt:new Date().toISOString(),type:'note',text:t});notes=notes.slice(-150);write(JOURNAL,notes);},onChange:()=>{const c=$('#ab-xp');if(c)c.innerHTML=progressChip(syncProgress(storage(),work));}});else bindJournal();"],
 ["</nav><button class=\"farm-place ab-land\"","</nav><button class=\"ab-xp\" id=\"ab-xp\" data-farm-view=\"social\" aria-label=\"Seviyen ve topluluk\">${progressChip(syncProgress(storage(),work))}</button><button class=\"farm-place ab-land\""],
 ["if(!response.ok)throw Error(data.error||'Fotoğraf incelenemedi.');photoResult=data;","if(!response.ok)throw Error(data.error||'Fotoğraf incelenemedi.');photoResult=data;await photoChain(data);"],
 ["function openTask(t){if(t?.action==='season')","function openTask(t){if(t?.action==='farm'){selectView('farm');return;}if(t?.action==='season')"],
 ["<div class=\"farm-result-body\">${esc(photoResult.text)}</div>","<div class=\"farm-result-body\">${esc(photoResult.text)}</div>${photoChainHtml(photoResult.chain)}"],
 ["· Yerel model gözlemi. Doğrulanmış teşhis değildir;","· Yapay zekâ gözlemi. Doğrulanmış teşhis değildir;"],
 ["function invalidatePhoto(){","// Çekirdek zincir: fotoğraf → kanıt → tarla durumu → yeniden hesap → \"Ne değişti?\" → görev → XP → kayıt.\nasync function photoChain(data){\n try{\n  const v=data.vision;if(!v||!photo)return;\n  const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(photo)),hash=[...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('');\n  const r=await applyPhotoEvidence({storage:storage(),farm,weather,vision:v,hash}),chain={...r,vision:v,xp:0,task:null};\n  const addTask=(title,action)=>{if(!work.custom.some(t=>t.farmId===farm.id&&t.title===title&&t.day===dayKey())){work.custom.push({id:'custom_'+Date.now().toString(36),farmId:farm.id,title,day:dayKey(),action});work.custom=work.custom.slice(-100);write(WORK,work);}chain.task=title;};\n  if(r.status==='accepted'){\n   chain.xp=awardXp(storage(),XP.evidence,'photo:'+hash);\n   if(r.stageChanged){farms=upsertFarm(farms,{...farm,stage:r.stage});farm=farms.find(f=>f.id===farm.id)||farm;savePortfolio();}\n   if(r.nextQuestion)addTask('Tarlam için sıradaki bilgi: '+r.nextQuestion.title,'farm');\n   notes.push({id:'note_'+Date.now().toString(36),farmId:farm.id,day:dayKey(),createdAt:new Date().toISOString(),type:'photo',text:`Fotoğraf kanıtı kabul edildi: ${v.plant}, ${v.stage} (güven %${Math.round(v.confidence*100)}). ${r.change.summary}`});notes=notes.slice(-150);write(JOURNAL,notes);\n  }else if(r.status==='note'){\n   chain.xp=awardXp(storage(),XP.photo,'photo:'+hash);\n   if(r.tip)addTask('Fotoğrafı yeniden çek: '+r.tip,'photo');\n  }\n  data.chain=chain;\n }catch(e){console.warn('photo chain',e);}\n}\nfunction photoChainHtml(c){\n if(!c)return '';\n const v=c.vision,row=(n,t,b)=>`<li><span>${n}</span><div><strong>${t}</strong>${b}</div></li>`,ch=c.change;\n const ev=c.status==='accepted'?row(1,'Kanıt kabul edildi',`<p>${esc(v.plant)} · ${esc(v.stage)} · güven %${Math.round(v.confidence*100)}</p>`):c.status==='duplicate'?row(1,'Bu fotoğraf daha önce işlendi','<p>Kanıt ve puan ikinci kez sayılmadı.</p>'):row(1,'Gözlem notu olarak kaldı; hesaba girmedi',`<p>${esc(c.reason)}</p>${c.tip?`<p><b>İpucu:</b> ${esc(c.tip)}</p>`:''}`);\n const diff=ch?row(2,'Ne değişti?',`<p>${esc(ch.summary)}</p><div class=\"fw-before-after\"><div><span>Önce</span><strong>${esc(ch.before)}</strong></div><span aria-hidden=\"true\">→</span><div class=\"${ch.decisionChanged?'fw-changed':''}\"><span>Sonra</span><strong>${esc(ch.after)}</strong></div></div>${ch.diffs.length?`<table class=\"fw-diff\"><thead><tr><th>Hesap</th><th>Önce</th><th>Sonra</th></tr></thead><tbody>${ch.diffs.map(d=>`<tr><td>${esc(d.label)}</td><td>${esc(d.before)}</td><td>${esc(d.after)}</td></tr>`).join('')}</tbody></table>`:''}`):'';\n const task=c.task?row(ch?3:2,'Yeni görev',`<p>${esc(c.task)}</p>`):'';\n const xp=c.xp?row('★',`+${c.xp} XP`,`<p>${c.status==='accepted'?'Karar düzeyinde kanıt.':'Deneme için teşekkürler; net bir fotoğrafla daha fazlası gelir.'}</p>`):'';\n return `<div class=\"pc-chain\"><span class=\"farm-eyebrow\">BU FOTOĞRAF TARLANDA NEYİ DEĞİŞTİRDİ?</span><ol>${ev}${diff}${task}${xp}</ol>${c.status==='accepted'?'<button class=\"farm-quiet-btn\" data-farm-view=\"farm\">Tarlamda gör →</button>':''}<small>Fotoğraftan çıkarılmayanlar: toprak pH, besin düzeyi, kesin toprak nemi, sulama miktarı, verim, kesin hastalık teşhisi.</small></div>`;\n}\nfunction invalidatePhoto(){"],
 ["<button class=\"farm-quiet-btn\" id=\"farm-journal-note\">+ Gözlem ekle</button></div>${rows.length?","<button class=\"farm-quiet-btn\" id=\"farm-journal-note\">+ Gözlem ekle</button></div><div id=\"fm-host\"></div><div id=\"tw-host\"></div><h2 class=\"fm-list-title\">Notların</h2>${rows.length?"],
 ["function bindJournal(){","function bindJournal(){twinsMount();mountMemory($('#fm-host'),()=>{let record={};try{record=(JSON.parse(storage().getItem('agrobas-field-v1')||'{}')||{})[farm.id]||{};}catch{}return timelineItems({notes,record,work,tasks:currentTasks(),farmId:farm.id});});"],
 ["function farmView(){return workspaceHtml()+`","function farmView(){return workspaceHtml()+`<div id=\"sl-host\"></div><div id=\"gn-host\"></div>"],
 ["onStage:st=>{farms=upsertFarm(farms,{...farm,stage:st});farm=farms.find(f=>f.id===farm.id)||farm;savePortfolio();}});","onStage:st=>{farms=upsertFarm(farms,{...farm,stage:st});farm=farms.find(f=>f.id===farm.id)||farm;savePortfolio();},onChange:()=>networkRefresh()});networkRefresh();mountSoil($('#sl-host'),{farm,storage:storage(),onChange:e=>{if(e&&e.texture)render();else networkRefresh();}});"],
 ["function workspaceSeason(){","let networkDraw=null;\nasync function networkRefresh(){\n const host=$('#gn-host');if(!host)return;const f=farm;\n const state=await currentState(f,storage(),weather);if(f!==farm||!host.isConnected)return;\n const rain=weather.available?Math.max(...weather.rows.slice(0,4).map(r=>r.rain)):0,last=ownNotes().filter(n=>n.type==='photo').at(-1)?.day||null;\n const ctx={gaps:detectGaps(state,{lastPhotoDay:last,today:dayKey(),rainSoonMm:rain}),forecastMm:rain>=1?Math.round(rain*10)/10:6};\n if(host.firstElementChild&&networkDraw){networkCtx=ctx;networkDraw();}else{networkCtx=ctx;networkDraw=mountNetwork(host,()=>networkCtx);}\n}\nlet networkCtx={gaps:[],forecastMm:6};\nfunction workspaceSeason(){"],
 ["function todayView(){","function renderCalendar(irrigation){\n const host=$('#fc-host');if(!host)return;\n const days=weather.available?buildDays(weather.rows,{stage:farm.stage,water:farm.water,irrigation}):[];\n const months=buildMonths(seasonState.data?.season,{water:farm.water});\n host.innerHTML=calendarHtml(days,months,{weatherAvailable:!weather.error,seasonStatus:seasonState.status==='loading'||seasonState.status==='idle'?'loading':'done'});\n bindCalendar(host.firstElementChild,days,{onAddTask:(title,date)=>{if(work.custom.some(t=>t.farmId===farm.id&&t.title===title&&t.day===date))return false;work.custom.push({id:'custom_'+Date.now().toString(36),farmId:farm.id,title,day:date});work.custom=work.custom.slice(-100);write(WORK,work);toast('İş listene eklendi.');return true;}});\n}\nfunction todayView(){"],
]);
// Çiftçiyi tanıma (farmer-profile.mjs)
patch('public/farmer.js',[
 ["function goalStep(){return `<div class=\"farm-goal-grid\">","function goalStep(){return `${meStepHtml(readMe(storage()))}<div class=\"farm-goal-grid\">"],
 [":'Şu an en çok neye ihtiyacın var?';",":'Son olarak seni tanıyalım.';"],
 ["function bindGoalStep(){","function bindGoalStep(){bindMeStep(root,storage());"],
]);
// Haftalık rapor (weekly-report.mjs)
patch('public/farmer.js',[
 ["<div class=\"farm-layout\">${weatherCard()}<section class=\"farm-card farm-tasks\"","<div class=\"farm-layout\">${weatherCard()}<section id=\"wr-host\" class=\"wr-slot\"></section><section class=\"farm-card farm-tasks\""],
 ["else if(view==='today'){bindToday();","else if(view==='today'){bindToday();arrangeToday($('#farmer-main'));reportMount();greetMe($('.garden-welcome h1'),storage());"],
 ["function bindToday(){","function reportMount(){const f=farm;mountReport($('#wr-host'),{farm:f,storage:storage(),getFacts:async()=>{const state=await currentState(f,storage(),weather);let history=[];try{history=(JSON.parse(storage().getItem('agrobas-field-v1')||'{}')[f.id]||{}).history||[];}catch{}const rain=weather.available?Math.max(...weather.rows.slice(0,4).map(r=>r.rain)):0,last=ownNotes().filter(n=>n.type==='photo').at(-1)?.day||null;return buildReportFacts({farm:f,state,weather,season:seasonState.data?.season,notes,history,gaps:detectGaps(state,{lastPhotoDay:last,today:dayKey(),rainSoonMm:rain}),soil:soilFact(soilEntries(storage(),f.id)),today:dayKey()});}});}\nfunction twinsMount(){const f=farm;mountTwins($('#tw-host'),{farm:f,storage:storage(),getProfile:async()=>twinProfile(f,await currentState(f,storage(),weather))});}\nfunction bindToday(){"],
]);
patch('public/field-workspace.mjs',[
 ["host.querySelector('h2').textContent='Su kararı: '+a.title;","host.querySelector('h2').textContent='Su kararı: '+a.title;ctx.onDecision?.(q.base);"],
]);
patch('public/farmer.js',[["body:JSON.stringify({context,image:photo,note:photoNote})","body:JSON.stringify({context,image:photo,note:photoNote,lang:window.BASRO_LANG||'tr'})"]]);
patch('public/assistant.js',[["body:JSON.stringify({context:c,messages:history})","body:JSON.stringify({context:c,messages:history,lang:window.BASRO_LANG||'tr'})"]]);
patch('public/index.html',[
 ['  <script src="farmer.js" type="module"></script>','  <script src="i18n.mjs" type="module"></script>\n  <script src="farmer.js" type="module"></script>'],
 ['<symbol id="i-leaf"','<symbol id="i-people" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3 20c.4-3.6 2.7-5.6 6-5.6s5.6 2 6 5.6"/><circle cx="17" cy="9" r="2.6"/><path d="M16.5 14.5c2.6.2 4.2 2 4.5 5"/></symbol><symbol id="i-leaf"'],
 ['<meta name="theme-color" content="#173f35">','<meta name="theme-color" content="#0b1f19">\n  <meta name="color-scheme" content="dark">\n  <link rel="preconnect" href="https://fonts.googleapis.com">\n  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,650&family=Manrope:wght@400;500;600;700;800&display=swap">'],
]);
// Stil dosyaları: açık temayı koyu kopyalarla değiştir, en sona yeni arayüz katmanını ekle
{
 const p=path.join(root,'public/index.html');let s=fs.readFileSync(p,'utf8');
 if(!s.includes('agrobas-ui.css')){
  s=s.replace(/<link rel="stylesheet" href="(styles|tasks|world|assistant|forecast|farmer|farmer-delight|crop-picker|season|living-lab|field-workspace)\.css">/g,'<link rel="stylesheet" href="dark/$1.css">');
  s=s.replace('<link rel="stylesheet" href="dark/field-workspace.css">','<link rel="stylesheet" href="dark/field-workspace.css">\n  <link rel="stylesheet" href="daily-info.css">\n  <link rel="stylesheet" href="agrobas-ui.css">\n  <link rel="stylesheet" href="bas-social.css">');
  fs.writeFileSync(p,s);
 }
}
// Ürün adı: AgroBas → Basro (yalnızca görünen metin; depolama anahtarları, dosya ve ortam değişkeni adları değişmez).
{
 const rename=s=>s.replaceAll('Agro<span>Bas</span>','Bas<span>ro</span>').replaceAll("AgroBas'ın","Basro'nun").replaceAll('AgroBas','Basro').replaceAll('AGROBAS ·','BASRO ·').replaceAll('AGROBAS /','BASRO /');
 const pub=path.join(root,'public'),files=fs.readdirSync(pub).filter(f=>/\.(js|mjs|html|css)$/.test(f)).map(f=>path.join(pub,f));
 for(const f of ['lib/codex/forecast.ts','lib/codex/agro-assistant.ts','lib/codex/farmer-advice.ts','lib/vision.ts','app/layout.tsx','app/konum/page.tsx'])if(fs.existsSync(path.join(root,f)))files.push(path.join(root,f));
 for(const f of files){const s=fs.readFileSync(f,'utf8'),t=rename(s);if(t!==s)fs.writeFileSync(f,t);}
}
execFileSync(process.execPath,[path.join(root,'scripts/darken-css.mjs')],{stdio:'inherit'});
console.log('Koyu arayüz uygulandı.');
