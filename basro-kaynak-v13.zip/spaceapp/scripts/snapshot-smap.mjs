// SMAP L4 (SPL4SMGP, 9 km, 3 saatlik) kök bölgesi nemini NASA AppEEARS üzerinden kaydeder.
// Gerekli: ücretsiz NASA Earthdata hesabı (https://urs.earthdata.nasa.gov).
// .env.local içine: EARTHDATA_USERNAME=... ve EARTHDATA_PASSWORD=...
// Çalıştırma: npm run snapshot:smap   (AppEEARS isteği kuyruğa alır; genelde 2–15 dk sürer)
import { readFile, writeFile, mkdir } from "node:fs/promises";

const LAT = 38.05, LON = 37.88; // lib/demo-data.ts → farm.centroid
const API = "https://appeears.earthdatacloud.nasa.gov/api";

async function loadEnv() {
  try {
    const raw = await readFile(".env.local", "utf8");
    for (const line of raw.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
    }
  } catch {}
}
await loadEnv();
const { EARTHDATA_USERNAME: user, EARTHDATA_PASSWORD: pass } = process.env;
if (!user || !pass) {
  console.error("EARTHDATA_USERNAME ve EARTHDATA_PASSWORD .env.local içinde olmalı.");
  process.exit(1);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const mdy = (d) => `${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}-${d.getUTCFullYear()}`;

async function api(path, init = {}, token) {
  const res = await fetch(API + path, {
    ...init,
    headers: { ...(init.headers ?? {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  if (!res.ok) throw new Error(`${res.status} ${path}: ${await res.text()}`);
  return res;
}

// 1) Giriş
const { token } = await (
  await api("/login", { method: "POST", headers: { Authorization: "Basic " + Buffer.from(`${user}:${pass}`).toString("base64") } })
).json();

// 2) En güncel SPL4SMGP sürümü ve kök bölgesi katmanı
const products = await (await api("/product")).json();
const product = products
  .map((p) => p.ProductAndVersion)
  .filter((p) => p.startsWith("SPL4SMGP."))
  .sort()
  .at(-1);
if (!product) throw new Error("AppEEARS'ta SPL4SMGP bulunamadı");
const layers = Object.keys(await (await api(`/product/${product}`)).json());
const layer = layers.find((l) => /sm_rootzone$/.test(l));
if (!layer) throw new Error(`Kök bölgesi katmanı bulunamadı: ${layers.join(", ")}`);
console.log("Ürün:", product, "Katman:", layer);

// 3) Nokta görevi: 2025-10-01 → bugün − 4 gün (rotasyon için tüm aylar + demo sezonu)
const end = new Date(Date.now() - 4 * 86_400_000);
const task = {
  task_type: "point",
  task_name: "agrobas-smap-rootzone",
  params: {
    dates: [{ startDate: "10-01-2025", endDate: mdy(end) }],
    layers: [{ product, layer }],
    coordinates: [{ id: "dogansehir", category: "field", latitude: LAT, longitude: LON }],
  },
};
const { task_id } = await (
  await api("/task", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(task) }, token)
).json();
console.log("Görev:", task_id, "— işleniyor...");

// 4) Bekle
for (;;) {
  const t = await (await api(`/task/${task_id}`, {}, token)).json();
  if (t.status === "done") break;
  if (t.status === "error") throw new Error("AppEEARS görevi hata verdi: " + JSON.stringify(t.error ?? t));
  process.stdout.write(`  durum: ${t.status}\r`);
  await sleep(20_000);
}

// 5) CSV'yi indir ve günlük ortalamaya çevir
const bundle = await (await api(`/bundle/${task_id}`, {}, token)).json();
const csvFile = bundle.files.find((f) => f.file_type === "csv" && f.file_name.includes(product.replace(".", "-")))
  ?? bundle.files.find((f) => f.file_type === "csv" && !f.file_name.includes("granule"));
const csv = await (await api(`/bundle/${task_id}/${csvFile.file_id}`, {}, token)).text();
const [header, ...rows] = csv.trim().split(/\r?\n/);
const cols = header.split(",");
const dateIdx = cols.indexOf("Date");
const valIdx = cols.findIndex((c) => /sm_rootzone$/.test(c));
const byDay = new Map();
for (const r of rows) {
  const c = r.split(",");
  const v = Number(c[valIdx]);
  if (!Number.isFinite(v) || v < 0 || v > 1) continue; // dolgu değerleri (-9999)
  const day = c[dateIdx].slice(0, 10);
  const a = byDay.get(day) ?? [];
  a.push(v);
  byDay.set(day, a);
}
const daily = [...byDay.entries()]
  .sort(([a], [b]) => a.localeCompare(b))
  .map(([date, v]) => ({
    date,
    mean: +(v.reduce((s, x) => s + x, 0) / v.length).toFixed(4),
    min: +Math.min(...v).toFixed(4),
    max: +Math.max(...v).toFixed(4),
    n: v.length,
  }));

await mkdir("data", { recursive: true });
await writeFile(
  "data/smap-snapshot.json",
  JSON.stringify({
    recordedAt: new Date().toISOString().slice(0, 16) + "Z",
    product,
    layer,
    lat: LAT,
    lon: LON,
    via: "NASA AppEEARS point sample",
    daily,
  }),
);
console.log(`Kaydedildi: data/smap-snapshot.json (${daily.length} gün)`);
