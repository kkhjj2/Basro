// Demo kullanıcısı + Kuzey Bahçe / Dere kenarı parsel (domates) kayıtlarını Supabase'e ekler.
// Önce: supabase/migrations/*.sql dosyasını SQL Editor'da çalıştır, .env'e Supabase anahtarlarını yaz.
// Çalıştırma: npm run seed:demo  → çıktıdaki 3 satırı .env'e ekle.
import { readFile } from "node:fs/promises";

for (const f of [".env.local", ".env"]) {
  try {
    for (const line of (await readFile(f, "utf8")).split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
    }
  } catch {}
}
const URL_ = process.env.NEXT_PUBLIC_SUPABASE_URL;
const KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!URL_ || !KEY) {
  console.error("NEXT_PUBLIC_SUPABASE_URL ve SUPABASE_SERVICE_ROLE_KEY .env içinde olmalı.");
  process.exit(1);
}
// Yeni sb_secret_ anahtarları JWT değildir: yalnızca apikey başlığı.
const h = { apikey: KEY, ...(KEY.startsWith("sb_") ? {} : { Authorization: `Bearer ${KEY}` }), "Content-Type": "application/json" };

async function call(path, body) {
  const res = await fetch(URL_ + path, { method: "POST", headers: { ...h, Prefer: "return=representation" }, body: JSON.stringify(body) });
  const text = await res.text();
  if (!res.ok) throw new Error(`${path} ${res.status}: ${text}`);
  return JSON.parse(text);
}

const email = "demo@agrobas.local";
let userId;
try {
  const u = await call("/auth/v1/admin/users", { email, password: crypto.randomUUID(), email_confirm: true });
  userId = u.id;
} catch (e) {
  if (!String(e).includes("already")) throw e;
  const list = await (await fetch(`${URL_}/auth/v1/admin/users?per_page=1000`, { headers: h })).json();
  userId = list.users.find((u) => u.email === email).id;
}

const [profile] = await call("/rest/v1/profiles?on_conflict=user_id", { user_id: userId, display_name: "Demo Çiftçi", region_id: "dogansehir" }).catch(() => [null]);
const [farm] = await call("/rest/v1/farms", { owner_id: userId, name: "Kuzey Bahçe", centroid_lat: 38.05, centroid_lon: 37.88, area_ha: 3.2 });
const [fieldRow] = await call("/rest/v1/fields", {
  farm_id: farm.id,
  owner_id: userId,
  name: "Dere kenarı parsel",
  area_ha: 1.4,
  soil_source: "soilgrids_250m",
  irrigation_type: "drip",
});
const [season] = await call("/rest/v1/seasons", {
  field_id: fieldRow.id,
  owner_id: userId,
  crop_id: "tomato",
  variety: "H-2274",
  sowing_date: "2026-05-10",
});

console.log("\n.env dosyasına ekle:\n");
console.log(`AGROBAS_DEMO_USER_ID=${userId}`);
console.log(`AGROBAS_DEMO_FIELD_ID=${fieldRow.id}`);
console.log(`AGROBAS_DEMO_SEASON_ID=${season.id}`);
void profile;
