// Codex açık tema CSS dosyalarından koyu tema kopyaları üretir: public/<f>.css → public/dark/<f>.css
// Kaynaklara dokunmaz; tekrar çalıştırmak aynı sonucu verir. Kullanım: node scripts/darken-css.mjs
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';

const pub=join(dirname(fileURLToPath(import.meta.url)),'..','public');
export const FILES=['styles.css','tasks.css','world.css','assistant.css','forecast.css','farmer.css','farmer-delight.css','crop-picker.css','season.css','living-lab.css','field-workspace.css'];
const NAMED={white:'#ffffff',black:'#000000',whitesmoke:'#f5f5f5',ivory:'#fffff0',beige:'#f5f5dc',linen:'#faf0e6',snow:'#fffafa'};

const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v));
function hexToRgb(h){h=h.slice(1);if(h.length<=4)h=[...h].map(c=>c+c).join('');const n=parseInt(h.slice(0,6),16);return {r:n>>16&255,g:n>>8&255,b:n&255,a:h.length===8?parseInt(h.slice(6),16)/255:1};}
function rgbToHsl({r,g,b}){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);h=mx===r?(g-b)/d+(g<b?6:0):mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;}return {h,s,l};}
function hslToRgb({h,s,l}){const k=n=>(n+h/30)%12,a=s*Math.min(l,1-l),f=n=>l-a*Math.max(-1,Math.min(k(n)-3,9-k(n),1));return {r:Math.round(f(0)*255),g:Math.round(f(8)*255),b:Math.round(f(4)*255)};}
const hex=({r,g,b})=>'#'+[r,g,b].map(v=>clamp(v,0,255).toString(16).padStart(2,'0')).join('');
const out=(rgb,a)=>a<1?`rgba(${rgb.r},${rgb.g},${rgb.b},${+a.toFixed(3)})`:hex(rgb);

// role: 'text' | 'bg' | 'line'
function mapColor(c,role){
 const hsl=rgbToHsl(c);let {h,s,l}=hsl;
 const tintH=156,chroma=(Math.max(c.r,c.g,c.b)-Math.min(c.r,c.g,c.b))/255,tint=chroma<.09;               // gri/krem tonları orman yeşiline çek
 if(role==='text'){
  if(l>=.62)return out(c,c.a);             // zaten açık
  if(s>.5&&l>.4)return out(hslToRgb({h,s,l:clamp(l+.18,0,.78)}),c.a); // canlı vurgu: biraz aç
  const nl=clamp(.95-l*.55,.62,.95);
  return out(hslToRgb({h:tint?tintH:h,s:tint?.12:Math.min(s,.35),l:nl}),c.a);
 }
 // bg / line: açık renkleri koyulaştır; canlı vurgular (kayısı, yeşil butonlar) kalsın
 if(l<.55)return out(c,c.a);
 if(s>.45&&l<.75)return out(c,c.a);
 const base=role==='line'?.19:.115;
 const nl=clamp(base+(1-l)*.45,.08,.34);
 const ns=tint?.28:clamp(s*.45,.12,.4);
 return out(hslToRgb({h:tint?tintH:h,s:ns,l:nl}),c.a);
}
function parse(tok){
 tok=tok.toLowerCase();
 if(NAMED[tok])return hexToRgb(NAMED[tok]);
 if(tok[0]==='#')return hexToRgb(tok);
 const m=tok.match(/rgba?\(([^)]+)\)/);if(!m)return null;
 const p=m[1].split(/[\s,/]+/).filter(Boolean).map(x=>x.endsWith('%')?parseFloat(x)/100:parseFloat(x));
 return {r:p[0],g:p[1],b:p[2],a:p[3]??1};
}
const COLOR_RE=/#[0-9a-fA-F]{8}\b|#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3,4}\b|rgba?\([^)]*\)|\b(?:white|black|whitesmoke|ivory|beige|linen|snow)\b/g;
function roleOf(prop){
 if(prop==='color'||prop==='caret-color'||prop==='-webkit-text-fill-color'||prop==='text-decoration-color'||prop==='outline-color')return 'text';
 if(/^border|^outline|column-rule/.test(prop))return 'line';
 if(prop.startsWith('--')){
  if(/ink|text|muted|fg|forest|green(?!-bg)/.test(prop))return 'varText';
  if(/line|border|rule/.test(prop))return 'line';
  return 'bg';
 }
 if(/background|^fill$|^stroke$|accent-color|scrollbar-color/.test(prop))return 'bg';
 return null;
}
function transformValue(prop,value){
 if(/url\(/.test(value)&&!/,/.test(value))return value; // data URI içindeki renklere dokunma
 const role=roleOf(prop);
 if(prop==='box-shadow'||prop==='text-shadow'||prop==='filter')return value; // gölgeler
 if(!role)return value;
 if(role==='text')value=value.replace(/var\((--(?:forest|green|farm-green|farm-ink|ink))\)/g,'var($1-fg,var($1))');
 return value.replace(COLOR_RE,tok=>{
  const c=parse(tok);if(!c||Number.isNaN(c.r))return tok;
  // değişken: koyu metin rengi ise "metin" gibi davran, açıksa zemin
  if(role==='varText')return rgbToHsl(c).l<.5&&/ink|text|muted|fg/.test(prop)?mapColor(c,'text'):tok;
  return mapColor(c,role);
 });
}
export function darken(css){
 // "prop:value" çiftleri (minified dahil). Seçicilerdeki ":hover" gibi parçalar renk içermediğinden değişmez.
 return css.replace(/([{;]\s*)(--[\w-]+|[a-z-]+)\s*:\s*([^;{}]+)/g,(m,pre,prop,value)=>pre+prop+':'+transformValue(prop,value));
}
if(import.meta.url===`file://${process.argv[1]}`||process.argv[1]?.endsWith('darken-css.mjs')){
 mkdirSync(join(pub,'dark'),{recursive:true});
 for(const f of FILES){writeFileSync(join(pub,'dark',f),darken(readFileSync(join(pub,f),'utf8')));}
 console.log('dark css:',FILES.length,'dosya');
}
