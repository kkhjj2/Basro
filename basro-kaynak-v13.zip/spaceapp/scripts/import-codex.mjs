// Codex AgroBas (vanilla) arayüzünü spaceapp'e alır ve sunucu yapay zekâsına bağlar.
// Kullanım: node scripts/import-codex.mjs "C:/Users/torun/Documents/Codex/2026-10-25/referenced-chatgpt-conversation-this-is-an/work/agroatlas"
import fs from "node:fs";
import path from "node:path";

const src = process.argv[2];
if (!src || !fs.existsSync(path.join(src, "public", "farmer.js"))) {
  console.error("Codex klasörü bulunamadı:", src);
  process.exit(1);
}
const root = process.cwd();
const copyDir = (a, b) => fs.cpSync(a, b, { recursive: true, force: true });

copyDir(path.join(src, "public"), path.join(root, "public"));
fs.mkdirSync(path.join(root, "lib", "codex"), { recursive: true });
for (const f of ["agro-assistant.ts", "farmer-advice.ts", "season-service.ts", "forecast.ts", "power-cache.json", "climate-grid.json", "forecast-cache.json"])
  fs.copyFileSync(path.join(src, "lib", f), path.join(root, "lib", "codex", f));
for (const f of ["farmer-advice.ts", "season-service.ts", "forecast.ts"]) {
  const p = path.join(root, "lib", "codex", f);
  fs.writeFileSync(p, fs.readFileSync(p, "utf8").replaceAll("'../public/", "'../../public/"));
}
fs.mkdirSync(path.join(root, "tests", "codex"), { recursive: true });
for (const f of fs.readdirSync(path.join(src, "tests")).filter((f) => f.endsWith(".test.mjs"))) {
  const s = fs.readFileSync(path.join(src, "tests", f), "utf8").replaceAll("'../public/", "'../../public/");
  fs.writeFileSync(path.join(root, "tests", "codex", f), s);
}

function patch(file, pairs) {
  const p = path.join(root, file);
  let s = fs.readFileSync(p, "utf8");
  for (const [a, b] of pairs) {
    if (!s.includes(a)) throw new Error(`${file}: beklenen metin yok → ${a.slice(0, 60)}`);
    s = s.replace(a, b);
  }
  fs.writeFileSync(p, s);
}

const linkStart = "${!['127.0.0.1','localhost'].includes(location.hostname)?'<a class=\"farm-primary\" href=\"http://127.0.0.1:4173/\"";
const linkEnd = "Ücretsiz yerel uygulamayı aç ↗</a>':''}";
{
  const p = path.join(root, "public", "farmer.js");
  let s = fs.readFileSync(p, "utf8");
  const i = s.indexOf(linkStart);
  const j = s.indexOf(linkEnd, i);
  if (i < 0 || j < 0) throw new Error("farmer.js: yerel uygulama bağlantısı bulunamadı");
  s = s.slice(0, i) + s.slice(j + linkEnd.length);
  fs.writeFileSync(p, s);
}
patch("public/farmer.js", [
  ["if(!['127.0.0.1','localhost'].includes(location.hostname)){$('#farm-photo-error').textContent='Fotoğrafı dışarıdaki bir servise göndermiyoruz. Ücretsiz inceleme için bilgisayarındaki AgroBas uygulamasını aç.';return;}", ""],
  ["${location.hostname==='127.0.0.1'||location.hostname==='localhost'?'Fotoğraf bu bilgisayardaki ücretsiz modelle incelenir. Sunucuda saklanmaz.':'Ücretsiz fotoğraf incelemesi, bilgisayarındaki yerel sürümde çalışır.'}", "Fotoğraf ücretsiz yapay zekâ katmanıyla incelenir; emin olamazsa tahmin etmez."],
]);
patch("public/assistant.js", [
  ["Yanıt ücretsiz yerel modelle hazırlanır.", "Yanıt ücretsiz yapay zekâ katmanıyla hazırlanır."],
  ["${isFarmer()?'Ücretsiz yerel asistan':esc(m.model||'Qwen3-VL-8B')+' · '+esc(m.year)}", "${isFarmer()?'Tarım asistanı':esc(m.model||'Asistan')+' · '+esc(m.year)}"],
  ["${s.code==='LOCAL_REQUIRED'?'<a href=\"http://127.0.0.1:4173/\" target=\"_blank\" rel=\"noopener\">Ücretsiz yerel uygulamayı aç ↗</a>':''}", ""],
  ["data.configured?'Ücretsiz · Bilgisayarında çalışıyor':data.requiresLocal?'Ücretsiz yerel sürüm':'Yerel model henüz hazır değil'", "data.configured?'Ücretsiz · Hazır':'Asistan şu an kapalı'"],
  ["if(!data.configured){session().code=data.requiresLocal?'LOCAL_REQUIRED':'LOCAL_UNAVAILABLE';session().error=data.requiresLocal?'Ücretsiz asistan bilgisayarında çalışır. AgroBas başlatıcısını çalıştır, ardından yerel uygulamayı aç.':'Yerel model henüz hazır değil. AgroBas başlatıcısını çalıştırıp asistanı yeniden aç.';render();}", "if(!data.configured){session().code='NOT_CONFIGURED';session().error='Asistan şu an kapalı. Yapay zekâ anahtarı ayarlanınca açılır.';render();}"],
  ["catch{status={configured:false};$('#assistant-state span').textContent='Yerel bağlantı kurulamadı';session().code='LOCAL_REQUIRED';session().error='Ücretsiz sohbet için AgroBas başlatıcısını çalıştır ve yerel uygulamayı aç.';render();}", "catch{status={configured:false};$('#assistant-state span').textContent='Bağlantı kurulamadı';session().code='OFFLINE';session().error='Asistana şu an ulaşılamıyor. İnternet bağlantını kontrol edip tekrar dene.';render();}"],
]);

// AgroBas 2.0 tarla çalışma alanı (public/field-*.mjs) bağlantıları
patch("public/index.html", [['<link rel="stylesheet" href="living-lab.css">', '<link rel="stylesheet" href="living-lab.css">\n  <link rel="stylesheet" href="field-workspace.css">']]);
patch("public/farmer.js", [
  ["import {mountLivingLab} from './living-lab.mjs';", "import {mountLivingLab} from './living-lab.mjs';\nimport {workspaceHtml,mountWorkspace,teaserHtml,mountTeaser} from './field-workspace.mjs';"],
  ["function farmView(){return `<div class=\"farm-intro\">", "function farmView(){return workspaceHtml()+`<div class=\"farm-intro\">"],
  ["function bindFarm(){mountMap('farm-profile-map',{lat:farm.lat,lon:farm.lon},false);", "function workspaceSeason(){const p=activeSeasonPlan({scenario:'model',month:null});if(!p)return null;const r=p.rotation?.options?.[0];return {title:p.summary,text:r?`Sonraki ürün için öne çıkan seçenek: ${r.sequence.join(' → ')}. ${r.tradeoff||''}`:'',actions:(p.actions||[]).slice(0,3).map(a=>a.title)};}\nfunction bindFarm(){disposeLab=mountWorkspace($('#field-workspace'),{farm,weather,storage:storage(),seasonSummary:workspaceSeason(),onOpen:v=>selectView(v==='lab'?'lab':'season'),onStage:st=>{farms=upsertFarm(farms,{...farm,stage:st});farm=farms.find(f=>f.id===farm.id)||farm;savePortfolio();}});if(seasonState.status==='idle')loadSeason();mountMap('farm-profile-map',{lat:farm.lat,lon:farm.lon},false);"],
  ["\n if(view==='season'||view==='today')render();else if(view==='lab')", "\n if(view==='season'||view==='today'||view==='farm')render();else if(view==='lab')"],
  ["return `${welcomeGarden({crop:farm.crop,district:farm.district,date:compactDate(dayKey()),completed:done})}${seasonTeaser(", "return `${welcomeGarden({crop:farm.crop,district:farm.district,date:compactDate(dayKey()),completed:done})}${teaserHtml()}${seasonTeaser("],
  ["else if(view==='today')bindToday();", "else if(view==='today'){bindToday();mountTeaser($('#fw-teaser'),{farm,weather,storage:storage(),onOpen:()=>selectView('farm')});}"],
]);
await import("./apply-redesign.mjs");
console.log("Codex arayüzü alındı ve sunucu yapay zekâsına bağlandı.");
