// Demo öncesi NASA POWER verisini kaydeder: node scripts/snapshot-power.mjs
// Canlı API demo sırasında erişilemezse uygulama bu dosyayı "kayıtlı veri" etiketiyle gösterir.
import { writeFile, mkdir } from "node:fs/promises";

const LAT = 38.05, LON = 37.88; // lib/demo-data.ts → farm.centroid
const SEASON = { start: "2026-05-10", end: "2026-07-13" }; // ekim → DEMO_DATE
const BASE = "https://power.larc.nasa.gov/api/temporal";
const ymd = (s) => s.replaceAll("-", "");
const iso = (d) => d.toISOString().slice(0, 10);

const end = new Date(Date.now() - 4 * 86_400_000);
const RECENT = { start: iso(new Date(end.getTime() - 29 * 86_400_000)), end: iso(end) };

const daily = (w) =>
  `${BASE}/daily/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR&community=AG&latitude=${LAT}&longitude=${LON}&start=${ymd(w.start)}&end=${ymd(w.end)}&format=JSON`;
const clim = `${BASE}/climatology/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR&community=AG&latitude=${LAT}&longitude=${LON}&format=JSON`;

async function get(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${r.status} ${url}`);
  return r.json();
}

const snapshot = {
  recordedAt: new Date().toISOString().slice(0, 16) + "Z",
  lat: LAT,
  lon: LON,
  daily: {
    season: { ...SEASON, json: await get(daily(SEASON)) },
    recent: { ...RECENT, json: await get(daily(RECENT)) },
  },
  climatology: await get(clim),
};
await mkdir("data", { recursive: true });
await writeFile("data/power-snapshot.json", JSON.stringify(snapshot));
console.log("Kaydedildi: data/power-snapshot.json", snapshot.recordedAt);
