# Basro

Çiftçinin ekimden hasada kadar yanında olan dijital tarım asistanı. NASA Space Apps 2026 · Field Shift.

## Çalıştırma

```bash
npm install
npm run dev      # http://localhost:3000
npm test         # 150 test
npm run build
```

Anahtarlar yalnızca `.env` dosyasında durur ve depoya girmez. Kullanılan adlar: `GROQ_API_KEY`, `GEMINI_API_KEY`, `NEXT_PUBLIC_SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` ve `AGROBAS_DEMO_*` kimlikleri. Anahtar yoksa fotoğraf incelemesi ve haftalık raporun yapay zekâ yazımı çalışmaz; rapor olgulardan kurulan yedek metne düşer.

## Ekranlar

Tek sayfa uygulama (`public/index.html`, `public/farmer.js`): Bugün, Sezon, Fotoğraf, Tarlam, Kayıtlarım, Topluluk ve Rotasyon laboratuvarı. Dünya atlası kenar çubuğundan açılır.

## Yapı

- `public/field-engine.mjs` — FAO-56 su dengesi, sıradaki soru, "Ne değişti?"
- `public/photo-evidence.mjs`, `lib/codex/farm-api.ts` — fotoğraf kanıtı ve kabul kuralları
- `public/weekly-report.mjs`, `app/api/report/route.ts` — haftalık rapor ve sayı/doz denetimi
- `public/farm-memory.mjs`, `public/farm-twins.mjs`, `public/ground-network.mjs`, `public/bas-social.mjs` — hafıza, ikizler, gözlem ağı, topluluk ve XP
- `public/rotation-lab-core.mjs`, `public/season-core.mjs` — rotasyon ve mevsim planı
- `lib/llm.ts` — ücretsiz katmanlı model istemcisi (Groq, olmazsa Gemini)
- `scripts/import-codex.mjs`, `scripts/apply-redesign.mjs`, `scripts/darken-css.mjs` — arayüz yamaları ve koyu tema üretimi
- `supabase/migrations/` — şema ve RLS

## Durum ve demo

Hangi özelliğin gerçek, hangisinin örnek veri olduğu, veri kaynakları, yöntemler, dört dakikalık demo akışı ve dürüst sınırlar: [docs/REQUIREMENTS_MAP.md](docs/REQUIREMENTS_MAP.md).
