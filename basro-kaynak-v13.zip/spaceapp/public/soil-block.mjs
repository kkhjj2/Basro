// Toprak bloğu (soil-block-1): su dengesi sonucunu üç durumda gösterir — şimdi, sulamadan sonra, sulamazsan 7 gün sonra.
// Sayılar field-engine çıktısından gelir (FAO-56 kök bölgesi su dengesi). Görsel bir göstergedir, parsel ölçümü değildir.
export const SOIL_BLOCK_VERSION='soil-block-1';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SOURCE={smap:'NASA SMAP L4 9 km model kaydı',feel:'senin toprak yoklaman',irrigation:'senin son sulama kaydın'};

/** evaluateWater() sonucundan gösterilecek durumlar. Nem bilinmiyorsa null döner (uydurma değer gösterilmez). */
export function soilView(r){
 if(!r||!Number.isFinite(r.TAW)||r.TAW<=0||!Number.isFinite(r.Dr0))return null;
 const mk=(id,label,Dr,lead)=>{
  const d=Math.max(0,Math.min(r.TAW,Dr)),pct=Math.round(100*(1-d/r.TAW)),stressed=Number.isFinite(r.RAW)&&d>=r.RAW;
  return {id,label,pct,mm:Math.round(r.TAW-d),stressed,
   title:stressed?'Toprak susamış.':pct>=85?'Toprak suya doymuş.':'Kökte su yeterli.',
   text:lead+(stressed?' Bitki suyu zor alıyor; bu seviyenin altında verim etkilenebilir.':pct>=85?' Kök bölgesi dolu; fazlası aşağı süzülür.':' Bitki suyu rahat alıyor.')};
 };
 const states=[mk('now','Şimdi',r.Dr0,'Bugünkü hesap.')];
 if(Number.isFinite(r.amountMm)&&r.amountMm>0)states.push(mk('after','Sulamadan sonra',r.Dr0-r.amountMm,`Yaklaşık ${Math.round(r.amountMm)} mm (dekara ${Math.round(r.amountMm)} ton) su verirsen.`));
 if(Number.isFinite(r.Dr7))states.push(mk('week','Sulamazsan 7 gün sonra',r.Dr7,'Hava tahminindeki yağış ve bitkinin su tüketimiyle.'));
 return {states,stressPct:Number.isFinite(r.RAW)?Math.round(100*(1-r.RAW/r.TAW)):null,depthCm:Math.round((r.rootM||0)*100)||null,
  source:SOURCE[r.moistureSource]||'hesap'};
}

const face=(cls,label)=>`<div class="sb-face ${cls}"><i class="sb-water"></i><i class="sb-line"></i>${label?'<b class="sb-line-label">stres eşiği</b>':''}</div>`;
export function soilBlockHtml(v,active='now'){
 if(!v)return '';
 const s=v.states.find(x=>x.id===active)||v.states[0];
 return `<div class="sb${s.stressed?' sb-dry':''}" data-sb style="--pct:${s.pct};--stress:${v.stressPct??0}">
 <div class="sb-scene" data-sb-scene title="Sürükle, çevir"><div class="sb-cube"><div class="sb-face sb-top"></div>${face('sb-front',v.stressPct!=null)}${face('sb-right',false)}${face('sb-back',false)}${face('sb-left',false)}</div>
 <small>${v.depthCm?`0–${v.depthCm} cm · kök bölgesi · `:''}sürükle, çevir</small></div>
 <div class="sb-info"><div class="sb-tabs" role="tablist" aria-label="Toprak durumu">${v.states.map(x=>`<button type="button" role="tab" data-sb-tab="${x.id}" aria-selected="${x.id===s.id}">${esc(x.label)}</button>`).join('')}</div>
 <h3 data-sb-title>${esc(s.title)}</h3><p class="sb-num" data-sb-num>Kökte kullanılabilir su: <b>%${s.pct}</b> · yaklaşık ${s.mm} mm</p><p data-sb-text>${esc(s.text)}</p>
 <small>Başlangıç nemi: ${esc(v.source)}. FAO-56 su dengesi hesabıdır; tarlada ölçüm değildir.</small></div></div>`;
}

/** host içine bloğu çizer; sekmeler ve sürükleyerek çevirme bağlanır. */
export function mountSoilBlock(host,r){
 if(!host)return false;const v=soilView(r);if(!v){host.innerHTML='';return false;}
 host.innerHTML=soilBlockHtml(v);
 const root=host.querySelector('[data-sb]'),cube=root.querySelector('.sb-cube');
 const show=id=>{const s=v.states.find(x=>x.id===id);if(!s)return;root.style.setProperty('--pct',s.pct);root.classList.toggle('sb-dry',s.stressed);
  root.querySelector('[data-sb-title]').textContent=s.title;root.querySelector('[data-sb-num]').innerHTML=`Kökte kullanılabilir su: <b>%${s.pct}</b> · yaklaşık ${s.mm} mm`;root.querySelector('[data-sb-text]').textContent=s.text;
  root.querySelectorAll('[data-sb-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.sbTab===id)));};
 root.querySelectorAll('[data-sb-tab]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.sbTab)));
 let ry=-38,start=null;const scene=root.querySelector('[data-sb-scene]');
 scene.addEventListener('pointerdown',e=>{start={x:e.clientX,ry};scene.setPointerCapture?.(e.pointerId);});
 scene.addEventListener('pointermove',e=>{if(!start)return;ry=start.ry+(e.clientX-start.x)*0.6;cube.style.setProperty('--ry',ry+'deg');});
 const end=()=>{start=null;};scene.addEventListener('pointerup',end);scene.addEventListener('pointercancel',end);
 return true;
}
