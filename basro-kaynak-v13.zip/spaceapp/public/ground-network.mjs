// Gözlem Ağı (network-1.0): tarlada eksik/eskimiş bilgiyi bulur, önceliklendirir; bölgesel ihtiyaçlar için
// gönüllü ataması yapar (asıl + yedek, çelişkide üçüncü bağımsız okuma). Gönüllü pilotu SENTETİKTİR ve öyle etiketlenir.
// Öncelik bir sezgisel sıralamadır; "ekonomik değer" değildir.
import {chooseQuestion,STAGE_KC} from './field-engine.mjs';
export const NETWORK_VERSION='network-1.0';
export const WEIGHTS={I:0.35,U:0.20,C:0.15,B:0.15,E:0.15};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const r2=v=>Math.round(v*100)/100,clamp=v=>Math.min(1,Math.max(0,v));
export const priority=({I,U,C,B,E})=>r2(WEIGHTS.I*I+WEIGHTS.U*U+WEIGHTS.C*C-WEIGHTS.B*B-WEIGHTS.E*E);
const META={feel:{C:0.2,E:0.35,label:'Toprak yoklaması'},irrigation:{C:0.1,E:0.2,label:'Son sulama tarihi'},soil:{C:0.3,E:0.4,label:'Toprak bünyesi'},stage:{C:0.4,E:0.15,label:'Gelişme dönemi'}};

/** Tarla durumundaki bilgi boşlukları. I (karar etkisi) doğrudan motorun duyarlılık hesabından gelir. */
export function detectGaps(state,{lastPhotoDay=null,today=new Date().toISOString().slice(0,10),rainSoonMm=0}={}){
 const q=chooseQuestion(state),urgent=['irrigate','soon','unknown'].includes(q.base.action),gaps=[];
 for(const c of q.ranked){
  const m=META[c.id];if(!m)continue;
  const I=clamp(q.base.action==='unknown'?Math.max(c.changeProbability,0.6):c.changeProbability),U=c.id==='stage'?0.8:c.id==='soil'?0.3:urgent?0.7:0.4,B=clamp(c.minutes/10);
  gaps.push({id:c.id,scope:'field',title:c.title,label:m.label,minutes:c.minutes,tool:c.tool,I,U,C:m.C,B,E:m.E,why:`Cevabın su kararını değiştirme olasılığı yaklaşık %${Math.round(I*100)}.`});
 }
 const active=STAGE_KC[state.stage]!==undefined&&!['Henüz ekmedim','Hasat sonrası'].includes(state.stage);
 const days=lastPhotoDay?Math.round((Date.parse(today)-Date.parse(lastPhotoDay))/864e5):null;
 if(active&&(days===null||days>=10))gaps.push({id:'photo',scope:'field',title:'Bitkinin güncel bir fotoğrafını çek.',label:'Güncel fotoğraf',minutes:2,tool:'Telefon kamerası',I:0.3,U:clamp((days??20)/20),C:0.5,B:0.2,E:0.25,why:days===null?'Bu tarla için henüz fotoğraf kanıtı yok; gelişme dönemi yalnızca beyana dayanıyor.':`Son fotoğraf ${days} gün önce; gelişme dönemi eskimiş olabilir.`});
 if(rainSoonMm>=5)gaps.push({id:'gauge',scope:'region',title:'Yağıştan sonra yağmurölçeri oku.',label:'Yağış ölçümü (bölge)',minutes:3,tool:'Yağmurölçer ya da düz kenarlı kap ve cetvel',I:0.4,U:0.6,C:0.9,B:0.3,E:0.2,why:`Önümüzdeki günlerde yaklaşık ${String(rainSoonMm).replace('.',',')} mm yağış bekleniyor. Tahmin 9–11 km'lik alan içindir; yerde ölçüm, sulama hesabındaki yağışı doğrular.`});
 return gaps.map(g=>({...g,P:priority(g)})).sort((a,b)=>b.P-a.P);
}

/** Sentetik pilot: Doğanşehir'de 7 gönüllü. Gerçek kişi değildir. */
export const PILOT_VOLUNTEERS=[
 {id:'v1',name:'Gönüllü 1',km:1.2,equipment:['gauge','camera'],load:1,cap:3,reliability:0.9,respondsH:6},
 {id:'v2',name:'Gönüllü 2',km:0.8,equipment:['gauge'],load:0,cap:2,reliability:0.7,respondsH:30},
 {id:'v3',name:'Gönüllü 3',km:3.5,equipment:['camera','spade'],load:0,cap:3,reliability:0.8,respondsH:5},
 {id:'v4',name:'Gönüllü 4',km:2.1,equipment:['gauge','spade'],load:2,cap:2,reliability:0.95,respondsH:4},
 {id:'v5',name:'Gönüllü 5',km:4.8,equipment:['gauge','camera'],load:0,cap:3,reliability:0.85,respondsH:8},
 {id:'v6',name:'Gönüllü 6',km:6.5,equipment:['camera'],load:1,cap:3,reliability:0.6,respondsH:12},
 {id:'v7',name:'Gönüllü 7',km:2.9,equipment:['gauge'],load:1,cap:3,reliability:0.8,respondsH:10},
];
export const fit=v=>r2(0.4*clamp(1-v.km/10)+0.3*v.reliability+0.3*(1-v.load/v.cap));
/** Uygun adaylar: gereken araç var ve haftalık yük sınırının altında. En uygun = asıl, ikinci = yedek. */
export function assign(equipment,volunteers=PILOT_VOLUNTEERS,exclude=[]){
 const ranked=volunteers.filter(v=>v.equipment.includes(equipment)&&v.load<v.cap&&!exclude.includes(v.id)).map(v=>({...v,fit:fit(v)})).sort((a,b)=>b.fit-a.fit||a.km-b.km);
 return {primary:ranked[0]||null,backup:ranked[1]||null,ranked};
}
/**
 * Pilot senaryosu (belirlenimci): teklif 24 saatte yanıtlanmazsa yedeğe geçer; iki okuma tolerans dışındaysa
 * üçüncü bağımsız okuma istenir ve ortanca kabul edilir. Kaçırılan okuma 0 sayılmaz.
 * readings: {volunteerId: mm}. Döner: adım listesi + kabul edilen değer.
 */
export function runPilot({equipment='gauge',readings,toleranceMm=2,expiryH=24,volunteers=PILOT_VOLUNTEERS}){
 const steps=[],used=[],values=[];
 const ask=(role)=>{
  for(;;){
   const {primary}=assign(equipment,volunteers,used);if(!primary)return null;used.push(primary.id);
   if(primary.respondsH>expiryH){steps.push({t:'expired',who:primary.name,text:`${primary.name} ${expiryH} saat içinde yanıt vermedi; görev yedeğe geçti. Kaçırılan okuma 0 sayılmaz.`});continue;}
   const mm=readings[primary.id];if(!Number.isFinite(mm)){steps.push({t:'missing',who:primary.name,text:`${primary.name} okuma gönderemedi; değer boş bırakıldı.`});continue;}
   steps.push({t:'reading',who:primary.name,mm,text:`${role}: ${primary.name} (${String(primary.km).replace('.',',')} km, uygunluk ${String(primary.fit).replace('.',',')}) ${String(mm).replace('.',',')} mm okudu.`});values.push(mm);return mm;
  }
 };
 const first=assign(equipment,volunteers);
 steps.push({t:'offer',text:`Görev önerildi: ${first.primary?.name} (asıl), ${first.backup?.name} (yedek). ${first.ranked.length} uygun aday vardı; aracı olmayanlar ve haftalık yük sınırı dolanlar aday olmadı.`});
 const a=ask('İlk okuma'),b=a===null?null:ask('Doğrulama okuması');
 let accepted=null,conflict=false;
 if(a!==null&&b!==null){
  if(Math.abs(a-b)<=toleranceMm)accepted=r2((a+b)/2);
  else{conflict=true;steps.push({t:'conflict',text:`İki okuma arasında ${String(r2(Math.abs(a-b))).replace('.',',')} mm fark var (tolerans ${toleranceMm} mm). Üçüncü bağımsız okuma istendi.`});const c=ask('Üçüncü okuma');if(c!==null)accepted=[a,b,c].sort((x,y)=>x-y)[1];}
 }
 steps.push(accepted===null?{t:'open',text:'Yeterli okuma toplanamadı; ihtiyaç açık kalıyor.'}:{t:'accepted',mm:accepted,text:`Kabul edilen değer: ${String(accepted).replace('.',',')} mm${conflict?' (üç okumanın ortancası; aykırı okuma hesaba katılmadı)':' (iki okumanın ortalaması)'}.`});
 return {steps,accepted,conflict,values};
}
/** Katkım neyi iyileştirdi: yer ölçümü ile tahmini karşılaştırır. */
export function contribution(forecastMm,acceptedMm){
 if(!Number.isFinite(acceptedMm))return null;
 const d=r2(acceptedMm-forecastMm),f=v=>String(v).replace('.',',');
 return {delta:d,text:Math.abs(d)<=2?`Yer ölçümü tahmini doğruladı (tahmin ${f(forecastMm)} mm, ölçüm ${f(acceptedMm)} mm). Gerçek bir okumada sulama hesabındaki yağış modelden değil ölçümden alınır.`:`Yer ölçümü tahminden ${f(Math.abs(d))} mm ${d>0?'fazla':'az'} çıktı (tahmin ${f(forecastMm)} mm, ölçüm ${f(acceptedMm)} mm). Sulama hesabındaki etkili yağış buna göre düzeltilir.`};
}

const bar=(k,v,neg)=>`<span class="gn-bar${neg?' gn-neg':''}" title="${k}"><b>${k}</b><i style="width:${Math.round(v*100)}%"></i></span>`;
export function networkHtml(gaps,pilot,step,forecastMm){
 const shown=pilot.steps.slice(0,step),done=step>=pilot.steps.length,c=done?contribution(forecastMm,pilot.accepted):null;
 return `<section class="farm-card gn" id="ground-network"><header class="fm-head"><div><span class="farm-eyebrow">GÖZLEM AĞI</span><h2>Hangi bilgi eksik, kim toplayabilir?</h2></div><span class="fm-soon">${NETWORK_VERSION}</span></header>
 <h3 class="gn-sub">Tarlan için eksik bilgiler</h3>
 ${gaps.length?`<ol class="gn-gaps">${gaps.map((g,i)=>`<li><div class="gn-rank">${i+1}</div><div class="gn-body"><strong>${esc(g.title)}</strong><p>${esc(g.why)}</p><small>${esc(g.tool)} · yaklaşık ${g.minutes} dk · ${g.scope==='region'?'bölge için de yararlı':'yalnızca senin tarlan'}</small><div class="gn-bars">${bar('Etki',g.I)}${bar('Aciliyet',g.U)}${bar('Bölge',g.C)}${bar('Zahmet',g.B,1)}${bar('Hata payı',g.E,1)}</div></div><div class="gn-p"><b>${String(g.P).replace('.',',')}</b><small>öncelik</small></div></li>`).join('')}</ol>`:'<p class="fm-empty">Şu an karar için eksik bir bilgi görünmüyor.</p>'}
 <p class="fm-note">Öncelik = 0,35·etki + 0,20·aciliyet + 0,15·bölgeye katkı − 0,15·zahmet − 0,15·hata payı. Etki, su kararının o cevapla değişme olasılığıdır. Görevi yapmamak kendi analizini kısıtlamaz.</p>
 <h3 class="gn-sub">Bölge pilotu: Doğanşehir yağış ölçümü <span class="bs-tag">Pilot · sentetik 7 gönüllü</span></h3>
 <ol class="gn-steps">${shown.map(s=>`<li class="gn-${s.t}">${esc(s.text)}</li>`).join('')||'<li class="gn-idle">Bölgede bir yağış okuması gerekiyor. Sistemin gönüllüyü nasıl seçtiğini, yanıt gelmezse ve okumalar çelişirse ne yaptığını adım adım izle.</li>'}</ol>
 ${c?`<p class="fw-why"><strong>Bu katkı neyi iyileştirdi?</strong> ${esc(c.text)} Bu pilotta okumalar sentetik olduğu için senin tarlanın hesabı değiştirilmedi.</p>`:''}
 <div class="fw-buttons"><button class="farm-primary" data-gn-step ${done?'disabled':''}>${step?done?'Pilot tamamlandı':'Saati ilerlet →':'Pilotu başlat →'}</button>${step?'<button class="farm-quiet-btn" data-gn-reset>Baştan</button>':''}</div>
 <p class="fm-note">Gönüllüler ve okumalar sentetiktir; gerçek kişi ya da ölçüm değildir. Atama kuralı gerçektir: araç, yakınlık, güvenilirlik ve haftalık yük sınırı.</p></section>`;
}
export const PILOT_READINGS={v1:6.4,v5:11.2,v7:6.8,v2:6.0,v4:6.5};
export function mountNetwork(host,getCtx){
 if(!host)return;let step=0;
 const pilot=runPilot({readings:PILOT_READINGS});
 const draw=()=>{const {gaps,forecastMm}=getCtx();host.innerHTML=networkHtml(gaps,pilot,step,forecastMm);
  host.querySelector('[data-gn-step]')?.addEventListener('click',()=>{step=Math.min(pilot.steps.length,step+1);draw();});
  host.querySelector('[data-gn-reset]')?.addEventListener('click',()=>{step=0;draw();});};
 draw();return draw;
}
