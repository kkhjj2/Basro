'use strict';

// Deliberately synthetic fixtures. No measurements, NASA connection, or prediction model.
const DATA_MODE = 'synthetic';
const fields = {
  battalgazi: { id:'01', district:'Battalgazi', name:'Tarla 01', area:'24,8', crop:'Buğday', soil:'Tınlı toprak', kind:'field', x:628,y:337,
    rainFactor:1,tempOffset:0,moistureOffset:0,
    rotations:[
      {name:'Buğday → Nohut → Arpa',note:'3 dönemlik örnek nöbet',detail:'Tahıl ve baklagil dönemlerini karşılaştırmak için hazırlanmış bir arayüz örneği. Çeşit, ekim zamanı, sulama ve toprak analizi değerlendirilmeden uygulanabilirliği belirlenemez.'},
      {name:'Buğday → Mercimek → Buğday',note:'Alternatif örnek döngü',detail:'İkinci bir ürün dizisini planına ekleyip ilk seçenekle karşılaştırabilirsin. Bu sıra bölgeye veya tarlaya uygunluk sonucuna dayanmaz; yalnızca planlama deneyimini gösterir.'}
    ],actions:['Toprak analizi için bir ön görüşme planla','Mevcut sulama düzenini not et'] },
  yesilyurt: { id:'02', district:'Yeşilyurt', name:'Bahçe 02', area:'18,5', crop:'Kayısı', soil:'Killi tınlı toprak', kind:'orchard', x:461,y:545,
    rainFactor:1.12,tempOffset:-.7,moistureOffset:5,
    rotations:[
      {name:'Bahçe örtüsü seçenekleri',note:'Çok yıllık bahçe için örnek başlık',detail:'Kayısı çok yıllık bir bitkidir. Bu nedenle burada ekim nöbeti yerine sıra arası örtü yönetimi seçenekleri gösterilir. Tür seçimi, su rekabeti ve bahçe koşulları için uzman değerlendirmesi gerekir.'},
      {name:'Sulama kayıt planı',note:'Alternatif bahçe yönetimi başlığı',detail:'Sulama tarihlerini ve gözlemlerini kaydetmeye yönelik örnek bir çalışma başlığıdır. Bu demo sulama miktarı, ilaç veya gübre dozu hesaplamaz.'}
    ],actions:['Bahçenin bakım geçmişini kaydet','Sulama kayıtlarını gözden geçir'] },
  akcadag: { id:'03', district:'Akçadağ', name:'Tarla 03', area:'36,2', crop:'Arpa', soil:'Kumlu tınlı toprak', kind:'field', x:254,y:449,
    rainFactor:.82,tempOffset:-1.4,moistureOffset:-4,
    rotations:[
      {name:'Arpa → Nohut → Buğday',note:'3 dönemlik örnek nöbet',detail:'Ürün çeşitliliğini konuşmak için oluşturulmuş temsili bir sıra. Gerçek bir uygunluk analizi yapılmadığı için ürün seçimi veya verim artışı önerisi değildir.'},
      {name:'Arpa → Mercimek → Arpa',note:'Alternatif örnek döngü',detail:'İkinci bir ürün dizisini planına ekleyerek örnek senaryolar arasında geçiş yapabilirsin. Gerçek ekim kararı; toprak, su, çeşit ve işletme koşullarının birlikte değerlendirilmesini gerektirir.'}
    ],actions:['Önceki ürünlerin listesini oluştur','Toprak analizi ihtiyacını değerlendir'] }
};
const layers = {
  rain:{name:'Yağış',title:'Yağış değişimi',unit:'mm',color:'#7397ad',heat:'#6b9ab2',gradient:'linear-gradient(90deg,#edf0df,#bdd0ce,#6694aa)',low:'0 mm',high:'80 mm',key:'Örnek yağış serisi'},
  temp:{name:'Sıcaklık',title:'Sıcaklık değişimi',unit:'°C',color:'#c29b61',heat:'#d2a068',gradient:'linear-gradient(90deg,#eeedce,#e2c98d,#c58e61)',low:'0 °C',high:'35 °C',key:'Örnek sıcaklık serisi'},
  moisture:{name:'Toprak nemi',title:'Toprak nemi değişimi',unit:'%',color:'#8c96b7',heat:'#8496bc',gradient:'linear-gradient(90deg,#e8eaf0,#a5aec8,#667a9d)',low:'%10',high:'%50',key:'Örnek nem serisi'}
};
const periods = {
  past:{caption:'2025 · Örnek geçmiş',range:'Ocak — Aralık 2025',labels:['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'],rain:[48,42,53,59,47,19,4,3,12,31,39,47],temp:[1,3,7,13,18,23,27,27,22,15,8,3],moisture:[35,37,39,40,34,26,18,15,17,24,30,34]},
  season:{caption:'Sonbahar 2026',range:'Ekim — Aralık 2026',labels:['Eki','Kas','Ara'],rain:[32,48,32],temp:[18.1,13.5,11],moisture:[24,28,32]},
  year:{caption:'2026 · Örnek yıl',range:'Ocak — Aralık 2026',labels:['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'],rain:[41,38,54,51,43,17,6,4,13,32,48,32],temp:[2,4,8,14,19,24,28,28,23,18.1,13.5,11],moisture:[32,36,38,41,35,27,20,17,19,24,28,32]},
  decade:{caption:'2027–2036 · Senaryo',range:'2027 — 2036 · Temsili senaryo',labels:['2027','28','29','30','31','32','33','34','35','2036'],rain:[389,412,376,398,361,382,402,368,391,374],temp:[15.6,15.9,16.1,15.8,16.3,16.1,16.5,16.2,16.7,16.4],moisture:[29,31,27,30,26,28,30,25,28,26]}
};
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const format = (n,decimals=0) => Number(n).toLocaleString('tr-TR',{minimumFractionDigits:decimals,maximumFractionDigits:decimals});
const fieldLabel = f => `${f.district} · ${f.name}`;
const mean = a => a.reduce((x,y)=>x+y,0)/a.length;
const sum = a => a.reduce((x,y)=>x+y,0);
const escapeHtml = x => String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state = {field:'battalgazi',layer:'moisture',period:'season',zoom:1,expanded:null,nutritionScenario:'normal',calendarView:'year',calendarMonth:2,pestScenario:'none'};
state.taskCadence='daily';
const soilProfiles={battalgazi:{ph:7.8,organic:1.4},yesilyurt:{ph:7.3,organic:2.6},akcadag:{ph:8.1,organic:1.1}};
Object.values(fields).forEach(f=>f.actions.push('Besleme planı için analiz sonuçlarını hazırla'));
Object.values(fields).forEach(f=>f.actions.push('Don hazırlık planını ve zararlı gözlemlerini gözden geçir'));
// World regions are real coordinate selections, not cadastral parcels.
const savedWorldLocations=[];
try{const saved=JSON.parse(localStorage.getItem('agroatlas-world-locations-v1')||'[]');if(Array.isArray(saved))savedWorldLocations.push(...saved.filter(p=>p&&typeof p.id==='string'&&/^world_[a-z0-9_-]+$/.test(p.id)&&Number.isFinite(p.lat)&&Math.abs(p.lat)<=90&&Number.isFinite(p.lon)&&Math.abs(p.lon)<=180&&typeof p.name==='string'&&p.name.length<=100&&typeof p.country==='string'&&p.country.length<=100).slice(0,250));}catch{}
function registerWorldField(p){const id=p.id.startsWith('world_')?p.id:'world_'+p.id;fields[id]={id,district:p.name,name:p.country||'Seçili koordinat',area:'—',crop:'Ürün seçilmedi',soil:'Analiz yok',kind:'region',rotations:[],actions:['Yerel toprak analizini ve ürün bilgisini ekle','Su ve uygulama kayıtlarını karşılaştır','Besleme kararını analizle doğrula','Yerel don / zararlı duyurularını kontrol et'],lat:p.lat,lon:p.lon,global:true};return id;}
for(const p of [...(window.AGRO_WORLD_DATA?.presets||[]),...savedWorldLocations])registerWorldField(p);
let plan = {};
let storageAvailable = true;
try {
  const parsed = JSON.parse(localStorage.getItem('agroatlas-demo-plan-v1')||'{}');
  if (parsed && typeof parsed==='object' && !Array.isArray(parsed)) {
    for(const [key,entry] of Object.entries(parsed)) if(fields[key] && entry && typeof entry==='object') {
      plan[key]={actions:Array.isArray(entry.actions)?[...new Set(entry.actions.filter(i=>Number.isInteger(i)&&i>=0&&i<fields[key].actions.length))]:[],rotation:Number.isInteger(entry.rotation)&&entry.rotation>=0&&entry.rotation<2?entry.rotation:null};
    }
  }
} catch {storageAvailable=false;}
let taskData={done:{},custom:[]};
try{
  const saved=JSON.parse(localStorage.getItem('agroatlas-tasks-v1')||'{}');
  if(saved&&typeof saved==='object'){
    if(saved.done&&typeof saved.done==='object'&&!Array.isArray(saved.done))taskData.done=Object.fromEntries(Object.entries(saved.done).filter(([k,v])=>k.length<200&&v===true));
    if(Array.isArray(saved.custom))taskData.custom=saved.custom.filter(t=>t&&/^u[0-9a-z-]+$/.test(t.id)&&fields[t.field]&&['daily','weekly','monthly'].includes(t.cadence)&&typeof t.text==='string'&&t.text.trim()&&t.text.length<=160).slice(0,300);
  }
}catch{storageAvailable=false;}
const taskTemplates={
  daily:[{id:'weather',text:'Yerel hava ve resmî uyarıları kontrol et',tag:'Hava takibi'},{id:'observe',text:'Arazideki değişimleri kısa bir notla kaydet',tag:'Saha gözlemi'},{id:'records',text:'Bugünkü su ve uygulama kayıtlarını güncelle',tag:'Girdi kaydı'}],
  weekly:[{id:'scout',text:'Ürüne uygun zararlı gözlemlerini gözden geçir',tag:'Bitki sağlığı'},{id:'water',text:'Haftalık sulama ve yağış kayıtlarını karşılaştır',tag:'Su takibi'},{id:'equipment',text:'Sensör ve ekipman çalışma durumunu kontrol et',tag:'Hazırlık'}],
  monthly:[{id:'nutrients',text:'Besleme planını analiz ve uygulama kayıtlarıyla değerlendir',tag:'Toprak sağlığı'},{id:'rotation',text:'Ürün / bahçe planını ve önceliklerini gözden geçir',tag:'Sezon planı'},{id:'review',text:'Bu ayın gözlem ve girdi özetini çıkar',tag:'Aylık değerlendirme'}]
};
function localDate(){const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());const v=Object.fromEntries(parts.filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));return `${v.year}-${v.month}-${v.day}`;}
function taskPeriod(cadence){const date=localDate();if(cadence==='daily')return date;if(cadence==='monthly')return date.slice(0,7);const d=new Date(date+'T12:00:00Z');const day=d.getUTCDay()||7;d.setUTCDate(d.getUTCDate()-day+1);return d.toISOString().slice(0,10);}
function taskKey(t,cadence){return `${taskPeriod(cadence)}|${cadence}|${state.field}|${t.id}`;}
function tasksFor(cadence){const base=window.AgroGlobal?.isActive()?window.AgroGlobal.taskTemplates(cadence):taskTemplates[cadence];return [...base,...taskData.custom.filter(t=>t.field===state.field&&t.cadence===cadence).map(t=>({...t,tag:'Kendi görevin'}))];}
function saveTasks(){try{localStorage.setItem('agroatlas-tasks-v1',JSON.stringify(taskData));}catch{storageAvailable=false;toast('Görevler bu oturumda saklanıyor; tarayıcı kaydı kullanılamıyor.');}}
function taskRows(cadence,compact=false){return tasksFor(cadence).map(t=>`<div class="routine-task"><label><input type="checkbox" data-task="${t.id}" data-cadence="${cadence}" ${taskData.done[taskKey(t,cadence)]?'checked':''}><span><strong>${escapeHtml(t.text)}</strong>${compact?'':`<small>${t.tag}</small>`}</span></label>${t.id.startsWith('u')&&!compact?`<button data-delete-task="${t.id}" aria-label="${escapeHtml(t.text)} görevini kaldır"><svg><use href="#i-close"/></svg></button>`:''}</div>`).join('');}
function bindTaskChecks(root){root.querySelectorAll('[data-task]').forEach(input=>input.addEventListener('change',()=>{const key=taskKey({id:input.dataset.task},input.dataset.cadence);if(input.checked)taskData.done[key]=true;else delete taskData.done[key];saveTasks();renderDailyTasks();if(modal.open&&$('#routine-task-list'))updateRoutineProgress();}));}
function renderDailyTasks(){const tasks=tasksFor('daily'),done=tasks.filter(t=>taskData.done[taskKey(t,'daily')]).length;$('#daily-progress').textContent=`${done}/${tasks.length}`;$('#daily-progress-bar').style.width=`${done/tasks.length*100}%`;$('#daily-date').textContent=new Intl.DateTimeFormat('tr-TR',{timeZone:'Europe/Istanbul',day:'numeric',month:'long',weekday:'long'}).format(new Date());$('#daily-tasks').innerHTML=taskRows('daily',true);bindTaskChecks($('#daily-tasks'));}
function updateRoutineProgress(){const tasks=tasksFor(state.taskCadence),done=tasks.filter(t=>taskData.done[taskKey(t,state.taskCadence)]).length;$('#routine-progress-label').textContent=`${done} / ${tasks.length} görev tamamlandı`;$('#routine-progress-bar').style.width=`${done/tasks.length*100}%`;}
function renderTasks(){
  const c=state.taskCadence,period=taskPeriod(c),labels={daily:'Günlük',weekly:'Haftalık',monthly:'Aylık'};
  const periodLabel=c==='daily'?new Intl.DateTimeFormat('tr-TR',{timeZone:'Europe/Istanbul',day:'numeric',month:'long',year:'numeric'}).format(new Date()):c==='weekly'?`${period} haftası`:`${monthNames[Number(period.slice(5))-1]} ${period.slice(0,4)}`;
  $('#modal-content').innerHTML=`<h2 id="modal-title">Birlikte, adım adım.</h2><p>${fieldLabel(fields[state.field])} · Görevlerin bu araziye kaydedilir.</p><div class="calendar-tabs" role="tablist" aria-label="Görev tekrarı">${Object.entries(labels).map(([key,label])=>`<button role="tab" data-task-cadence="${key}" aria-selected="${key===c}">${label}</button>`).join('')}</div><div class="routine-period"><strong>${periodLabel}</strong><span>${labels[c]} rutin</span></div><div class="routine-progress-label" id="routine-progress-label"></div><div class="task-progress-track"><span id="routine-progress-bar"></span></div><div id="routine-task-list">${taskRows(c)}</div><form id="new-task-form"><label for="new-task-input">${c==='daily'?'Bugüne':c==='weekly'?'Bu haftaya':'Bu aya'} kendi görevini ekle</label><div><input id="new-task-input" name="task" type="text" maxlength="160" placeholder="Örn. sulama sayacını kontrol et" required autocomplete="off"><button type="submit" aria-label="Görevi ekle">+</button></div></form><p class="modal-footer-note">Hazır görevler örnek kontrol başlıklarıdır; tarımsal uygulama talimatı değildir. Günlük kayıt gün değişince, haftalık kayıt pazartesi, aylık kayıt ay başında yeni dönem olarak açılır. Kendi görevlerin aynı sıklıkta tekrar görünür. Bu cihazda saklanır; otomatik bildirim gönderilmez.</p>`;
  updateRoutineProgress();bindTaskChecks($('#routine-task-list'));
  $$('[data-task-cadence]').forEach(b=>b.addEventListener('click',()=>{state.taskCadence=b.dataset.taskCadence;renderTasks();}));
  $$('[data-delete-task]').forEach(b=>b.addEventListener('click',()=>{taskData.custom=taskData.custom.filter(t=>t.id!==b.dataset.deleteTask);saveTasks();renderTasks();renderDailyTasks();}));
  $('#new-task-form').addEventListener('submit',event=>{event.preventDefault();const input=$('#new-task-input'),text=input.value.trim();if(!text){input.setCustomValidity('Bir görev yaz.');input.reportValidity();return;}if(taskData.custom.length>=300){toast('En fazla 300 özel görev saklanabilir.');return;}taskData.custom.push({id:`u${Date.now().toString(36)}-${Math.random().toString(36).slice(2,6)}`,field:state.field,cadence:c,text:text.slice(0,160)});saveTasks();renderTasks();renderDailyTasks();$('#new-task-input').focus();toast('Görev rutinine eklendi.');});
  $('#new-task-input').addEventListener('input',event=>event.target.setCustomValidity(''));
}
let toastTimer;
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),3300);}
function persist(){try{localStorage.setItem('agroatlas-demo-plan-v1',JSON.stringify(plan));}catch{storageAvailable=false;toast('Tarayıcı kaydı kapalı. Seçimlerin bu oturum boyunca korunacak.');}updatePlanCount();}
function entry(id=state.field){return plan[id]||{actions:[],rotation:null};}
function ensureEntry(id=state.field){return plan[id]||(plan[id]={actions:[],rotation:null});}
function updatePlanCount(){const count=Object.values(plan).reduce((n,p)=>n+p.actions.length+(p.rotation!==null?1:0),0);$('#plan-count').textContent=count;$('.rail-dot').hidden=!count;}
function series(layer=state.layer){const f=fields[state.field],p=periods[state.period];return p[layer].map(v=>Math.round((layer==='rain'?v*f.rainFactor:layer==='temp'?v+f.tempOffset:v+f.moistureOffset)*10)/10);}
function metricValue(layer){const values=series(layer);return layer==='rain'&&state.period!=='decade'?sum(values):mean(values);}
function pickField(id){state.field=id;state.expanded=null;state.zoom=1;closeLocation();render();toast(`${fieldLabel(fields[id])} seçildi · Temsili profil`);}
function pickLayer(layer){state.layer=layer;render();}
function pickPeriod(period){state.period=period;render();}

function makeMapTexture(){
  let seed=937;
  const rand=()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646;};
  let patches='';
  for(let y=-20;y<830;y+=50){for(let x=-20;x<1050;x+=63){
    const px=x+(rand()-.5)*26,py=y+(rand()-.5)*20,w=30+rand()*42,h=21+rand()*34;
    const palette=['#c8d4ae','#dce0bf','#d3d9bb','#c3d0a8','#d2d8c3','#dddcc2','#becaa6','#e1dfc4'];
    const c=palette[Math.floor(rand()*palette.length)];
    patches+=`<path d="M${px.toFixed(1)} ${py.toFixed(1)}l${w.toFixed(1)} -6 6 ${h.toFixed(1)} -${(w-3).toFixed(1)} 9Z" fill="${c}" opacity="${(.2+rand()*.35).toFixed(2)}" stroke="#edf0df" stroke-width="1.4"/>`;
    if(rand()>.66)patches+=`<path d="M${px.toFixed(1)} ${py.toFixed(1)}l${w.toFixed(1)} -6 6 ${h.toFixed(1)} -${(w-3).toFixed(1)} 9Z" fill="url(#groves)" opacity=".6"/>`;
  }}
  $('#field-texture').innerHTML=patches;
  let contours='';
  for(let n=0;n<17;n++){const y=610+n*13;contours+=`<path d="M-100 ${y}C30 ${y-67} 150 ${y+15} 266 ${y-35}S420 ${y-43} 521 ${y+16} 697 ${y-54} 827 ${y-4} 955 ${y-50} 1100 ${y+30}" fill="none" stroke="#acbb98" stroke-width=".8"/>`;}
  for(let n=0;n<12;n++){const y=10+n*14;contours+=`<path d="M-100 ${y}C30 ${y+77} 150 ${y+5} 276 ${y+45}S450 ${y+73} 580 ${y+16} 750 ${y+54} 827 ${y-4}" fill="none" stroke="#c5cdb2" stroke-width=".7"/>`;}
  $('#terrain').innerHTML=contours;
  $('#atlas-map').setAttribute('preserveAspectRatio','xMidYMid slice');
  $('#markers').innerHTML=Object.entries(fields).map(([id,f])=>`<button class="marker" data-field="${id}" aria-label="${escapeHtml(fieldLabel(f))} seç" aria-pressed="${state.field===id}"><span><b>${f.id}</b></span><em class="marker-label">${escapeHtml(f.district)}</em></button>`).join('');
  $$('.marker').forEach(b=>b.addEventListener('click',()=>pickField(b.dataset.field)));
}
function positionMarkers(){
  const rect=$('#map-stage').getBoundingClientRect();
  const scale=Math.max(rect.width/1000,rect.height/780);
  const offsetX=(rect.width-1000*scale)/2,offsetY=(rect.height-780*scale)/2;
  const shiftX=rect.width<310?45:0;
  $$('.marker').forEach(b=>{
    const f=fields[b.dataset.field];
    b.style.left=`${offsetX+(shiftX+500+(f.x-500)*state.zoom)*scale}px`;
    b.style.top=`${offsetY+(390+(f.y-390)*state.zoom)*scale}px`;
    b.classList.toggle('is-selected',b.dataset.field===state.field);b.setAttribute('aria-pressed',String(b.dataset.field===state.field));
  });
  $('#map-world').style.transform=`translateX(${shiftX}px) scale(${state.zoom})`;
  $$('.parcel').forEach(p=>p.classList.toggle('is-selected',p.dataset.parcel===state.field));
  $('#zoom-label').textContent=`Görünüm ×${format(state.zoom,1)}`;
  $('#zoom-in').disabled=state.zoom>=1.8;$('#zoom-out').disabled=state.zoom<=1;
}

function drawChart(){
  const l=layers[state.layer],p=periods[state.period],values=series(),n=values.length;
  const w=296,h=122,left=27,right=9,top=10,bottom=25;
  let min=Math.floor(Math.min(...values)*.6),max=Math.ceil(Math.max(...values)*1.15);
  if(state.layer==='rain')min=0;
  if(state.layer==='moisture'){min=10;max=50;}
  if(max<=min)max=min+1;
  const step=(w-left-right)/(n-1);
  const xx=i=>left+i*step, yy=v=>top+(max-v)/(max-min)*(h-top-bottom);
  const points=values.map((v,i)=>`${xx(i).toFixed(1)},${yy(v).toFixed(1)}`);
  const endY=h-bottom;
  let grid='';
  for(let i=0;i<3;i++){
    const v=min+(max-min)*i/2,y=yy(v);
    grid+=`<line class="chart-grid" x1="${left}" y1="${y}" x2="${w-right}" y2="${y}"/><text x="${left-7}" y="${y+3}" text-anchor="end">${format(v,0)}</text>`;
  }
  let ticks='';
  p.labels.forEach((label,i)=>{
    const show=n<=6||i===0||i===n-1||i%2===0;
    if(show)ticks+=`<text x="${xx(i)}" y="${h-5}" text-anchor="middle">${label}</text>`;
  });
  const pointsMarkup=values.map((v,i)=>`<circle class="chart-point" cx="${xx(i)}" cy="${yy(v)}" r="${n<=3?3.5:2.5}" tabindex="0" data-point="${i}" aria-label="${escapeHtml(p.labels[i])}: ${format(v,1)} ${l.unit}, temsili"><title>${p.labels[i]}: ${format(v,1)} ${l.unit} · Temsili</title></circle>`).join('');
  $('#chart').innerHTML=`<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${escapeHtml(l.title)}; ${escapeHtml(p.range)}; tüm değerler temsili">${grid}<path class="chart-area" d="M${left} ${endY} L${points.join(' L')} L${w-right} ${endY}Z"/><polyline class="chart-line" points="${points.join(' ')}" ${state.period==='decade'?'stroke-dasharray="5 4"':''}/>${pointsMarkup}${ticks}</svg><div class="chart-tooltip" hidden></div>`;
  $$('.chart-point').forEach(point=>{
    const show=()=>{const index=Number(point.dataset.point),tt=$('.chart-tooltip');tt.textContent=`${p.labels[index]} · ${format(values[index],1)} ${l.unit} · Temsili`;tt.hidden=false;};
    const hide=()=>$('.chart-tooltip').hidden=true;
    point.addEventListener('pointerenter',show);point.addEventListener('pointerleave',hide);point.addEventListener('focus',show);point.addEventListener('blur',hide);
  });
  $('#chart-title').textContent=l.title;
  $('#chart').setAttribute('aria-label',`Temsili ${l.name.toLocaleLowerCase('tr-TR')} grafiği`);
  const value=metricValue(state.layer);
  $('#chart-value').innerHTML=`${format(value,state.layer==='temp'?1:0)}<span>${l.unit}</span>`;
  $('#chart-summary').textContent=state.layer==='rain'?(state.period==='decade'?'Örnek yıllık ortalama':'Örnek dönem toplamı'):'Örnek dönem ortalaması';
  $('#chart-range').textContent=p.range;
  $('#chart-key-text').textContent=state.period==='decade'?'Temsili senaryo · Tahmin değil':l.key;
  $('#scenario-notice').hidden=state.period!=='decade';
}

function renderRotations(){
  const f=fields[state.field],saved=entry().rotation;
  $('#rotation-title').textContent=f.kind==='orchard'?'Bahçe yönetimi alternatifleri':'Ekim nöbeti alternatifleri';
  $('#rotation-desc').textContent=f.kind==='orchard'?'Kayısı bahçesinde ekim nöbeti yerine yönetim başlıkları.':'Tarlanın geleceğini farklı seçeneklerle düşün.';
  $('#rotation-options').innerHTML=f.rotations.map((r,i)=>`<div class="rotation-option ${saved===i?'selected':''}"><button data-rotation="${i}" aria-expanded="${state.expanded===i}" aria-controls="rotation-detail-${i}"><span class="rotation-number">${String(i+1).padStart(2,'0')}</span><span><strong>${r.name}</strong><small>${saved===i?'Planına eklendi · ':''}${r.note}</small></span><svg><use href="${state.expanded===i?'#i-down':'#i-chevron'}"/></svg></button><div class="rotation-detail" id="rotation-detail-${i}" ${state.expanded===i?'':'hidden'}>${r.detail}<button data-save-rotation="${i}">${saved===i?'Plandan çıkar':'Bu seçeneği planıma ekle'}<svg><use href="#i-arrow"/></svg></button></div></div>`).join('');
  $$('[data-rotation]').forEach(b=>b.addEventListener('click',()=>{state.expanded=state.expanded===Number(b.dataset.rotation)?null:Number(b.dataset.rotation);renderRotations();}));
  $$('[data-save-rotation]').forEach(b=>b.addEventListener('click',()=>{const i=Number(b.dataset.saveRotation),e=ensureEntry();e.rotation=e.rotation===i?null:i;persist();renderRotations();toast(e.rotation===null?'Seçenek plandan çıkarıldı.':'Örnek seçenek çalışma planına eklendi.');}));
}
function actionMarkup(id,modal=false){return fields[id].actions.map((text,i)=>`<label class="action-item"><input type="checkbox" data-action="${i}" data-action-field="${id}" ${entry(id).actions.includes(i)?'checked':''}><span>${text}</span></label>`).join('');}
function bindActions(root=document){root.querySelectorAll('[data-action]').forEach(input=>input.addEventListener('change',()=>{
  const id=input.dataset.actionField,i=Number(input.dataset.action),e=ensureEntry(id);
  if(input.checked&&!e.actions.includes(i))e.actions.push(i);else if(!input.checked)e.actions=e.actions.filter(x=>x!==i);
  persist();renderActions();
}));}
function renderActions(){$('#action-list').innerHTML=actionMarkup(state.field);$('#action-counter').textContent=`${entry().actions.length}/${fields[state.field].actions.length}`;bindActions($('#action-list'));}
function nutritionAdvice(){
  const f=fields[state.field],s=soilProfiles[state.field],scenario=state.nutritionScenario;
  const nitrogen=scenario==='wet'?{title:'Azot planını gözden geçir',why:'Örnek koşul: yağışlı yıl',text:'Fazla su, koşullara bağlı olarak azot kaybını artırabilir. Kalan azotu ve önceki uygulamaları kontrol ederek bölünmüş uygulama seçeneğini değerlendir.',missing:'Eksik: mineral azot, drenaj, önceki gübreleme'}:scenario==='dry'?{title:'Azotu su durumuyla birlikte planla',why:'Örnek koşul: kurak yıl',text:'Azot miktarını otomatik artırma. Kalan toprak azotu, kullanılabilir su ve gerçekçi verim hedefiyle uygulama zamanını birlikte değerlendir.',missing:'Eksik: mineral azot, sulama, verim hedefi'}:{title:'Azot ihtiyacını analizle belirle',why:`Örnek ürün: ${f.crop}`,text:'Önceki ürün, toprakta kalan azot, organik materyal ve verim hedefini birlikte değerlendir. Bu profil için azot eksikliği saptanmış değildir.',missing:'Eksik: mineral azot, önceki ürün ve uygulamalar'};
  const organic={title:s.organic<2?'Organik madde desteğini değerlendir':'Organik madde dengesini koru',why:`Örnek organik madde: %${format(s.organic,1)}`,text:s.organic<2?'Olgun kompost veya uygun organik materyal, değerlendirilebilecek destek seçenekleridir. Materyalin besin içeriği ve tuzluluğu kontrol edilmeden miktar belirlenmez.':'Mevcut organik maddeyi, ürün artıklarını ve önceki organik gübre girdilerini birlikte değerlendir. Ek kompost ihtiyacı bu örnek değerden tek başına belirlenmez.',missing:'Eksik: EC / tuzluluk, materyal ve besin analizi'};
  const micro={title:s.ph>7.5?'pH ve besin alımını kontrol et':'Fosfor ve potasyumu doğrula',why:`Örnek pH: ${format(s.ph,1)}`,text:s.ph>7.5?'Yüksek pH bazı besinlerin alımını sınırlayabilir. Demir, çinko ve fosfor için analiz / belirti kontrolü planla; eksiklik doğrulanırsa uygun destek değerlendirilir.':'Fosfor ve potasyum desteğini ürünün ihtiyacı ve toprak analizine göre değerlendir. Kayısıda gerektiğinde yaprak analizi de değerlendirmeye eklenebilir.',missing:s.ph>7.5?'Eksik: kireç, yarayışlı besinler, yaprak analizi':'Eksik: yarayışlı P / K ve ürün besleme geçmişi'};
  return [nitrogen,organic,micro];
}
function renderNutrition(){
  const s=soilProfiles[state.field];
  $('#soil-facts').innerHTML=`<span>Toprak pH <strong>${format(s.ph,1)}</strong><small>Örnek</small></span><span>Organik madde <strong>%${format(s.organic,1)}</strong><small>Örnek</small></span><span>Azot durumu <strong>Analiz gerekli</strong><small>Ölçüm yok</small></span>`;
  $('#nutrition-cards').innerHTML=nutritionAdvice().map((n,i)=>`<article class="nutrition-card"><div class="nutrition-card-top"><b>${['N','OM','P/K'][i]}</b><span>${n.why}</span></div><h3>${n.title}</h3><p>${n.text}</p><small>${n.missing}</small></article>`).join('');
}
function render(){
  const f=fields[state.field],l=layers[state.layer],p=periods[state.period];
  document.documentElement.style.setProperty('--layer',l.color);document.documentElement.style.setProperty('--heat',l.heat);
  $$('[data-layer]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.layer===state.layer)));
  $$('[data-period]').forEach(b=>{b.setAttribute('aria-selected',String(b.dataset.period===state.period));b.tabIndex=b.dataset.period===state.period?0:-1;});
  $$('[data-metric]').forEach(b=>b.classList.toggle('metric-selected',b.dataset.metric===state.layer));
  $('#period-caption').textContent=p.caption;$('#map-field-name').textContent=fieldLabel(f);$('#map-field-meta').textContent=`${f.area} dekar · ${f.crop}`;
  $('#field-title').textContent=fieldLabel(f);$('#field-subtitle').textContent=`Malatya · Temsili ${f.kind==='orchard'?'bahçe':'tarla'} profili`;
  $('#field-area').textContent=`${f.area} dekar`;$('#field-crop').innerHTML=`<svg><use href="#i-sprout"/></svg>${f.crop}`;$('#field-soil').textContent=f.soil;
  $('#legend-title').textContent=l.name;$('#legend-gradient').style.background=l.gradient;
  $('#legend-low').textContent=state.layer==='rain'&&state.period==='decade'?'300 mm':l.low;
  $('#legend-high').textContent=state.layer==='rain'&&state.period==='decade'?'500 mm':l.high;
  $('#legend-gradient').setAttribute('aria-label','Dekoratif temsili katman renkleri');
  $('#rain-label').textContent=state.period==='decade'?'Ort. yıllık yağış':'Toplam yağış';
  $('#stat-rain').textContent=format(metricValue('rain'));$('#stat-temp').textContent=format(metricValue('temp'),1);$('#stat-moisture').textContent=format(metricValue('moisture'));
  $('#rain-detail').textContent=state.period==='decade'?'2027–2036 · senaryo ortalaması':`${p.caption} · temsili toplam`;
  $('#temp-detail').textContent=state.period==='decade'?'2027–2036 · senaryo ortalaması':`${p.caption} · temsili ortalama`;
  $('#moisture-detail').textContent=state.period==='decade'?'Temsili senaryo · Tahmin değildir':'Ölçüm değil · örnek gösterge';
  drawChart();renderRotations();renderActions();renderNutrition();renderDailyTasks();positionMarkers();updatePlanCount();
}

function fieldOptions(){const q=$('#field-search').value.toLocaleLowerCase('tr-TR').trim();const matching=Object.entries(fields).filter(([id,f])=>`${fieldLabel(f)} ${f.crop}`.toLocaleLowerCase('tr-TR').includes(q));$('#field-options').innerHTML=matching.length?matching.map(([id,f])=>`<button class="field-option" data-option="${id}"><b>${f.id}</b><span><strong>${fieldLabel(f)}</strong><small>${f.crop} · ${f.area} dekar · Temsili</small></span></button>`).join(''):'<div class="no-results">Eşleşen örnek arazi yok.</div>';$$('[data-option]').forEach(b=>b.addEventListener('click',()=>pickField(b.dataset.option)));}
function openLocation(){const wasHidden=$('#location-menu').hidden;$('#location-menu').hidden=!wasHidden;$('#location-button').setAttribute('aria-expanded',String(wasHidden));if(wasHidden){$('#field-search').value='';fieldOptions();$('#field-search').focus();}}
function closeLocation(){$('#location-menu').hidden=true;$('#location-button').setAttribute('aria-expanded','false');}
const modal=$('#modal');
function openDialog(type){
  if(window.AgroGlobal?.isActive()&&['data','guide','calendar','nutrition','table'].includes(type))return window.AgroGlobal.openDialog(type);
  const f=fields[state.field];
  closeLocation();
  if(type==='data'){
    $('#modal-content').innerHTML=`<h2 id="modal-title">Bu demoda neye bakıyorum?</h2><div class="info-box"><strong>Tüm sayılar, renkli katmanlar, arazi profilleri ve öneriler kurgusaldır.</strong> NASA verisi kullanılmaz. Ölçüm, gerçek analiz, risk değerlendirmesi veya tahmin sunulmaz.</div><h3>Harita ve dönemler</h3><p>Malatya'daki ilçe adları bir keşif senaryosuna bağlam sağlar. Harita şematiktir; parsellerin konumu, sınırları, büyüklüğü ve ürünleri gerçek kayıtları temsil etmez. Katman renkleri dekoratif dağılımlardır; bir mekânsal modelin çıktısı değildir.</p><p>Geçmiş (2025), mevsimlik (Ekim–Aralık 2026) ve yıllık (2026) değerleri de temsili sayılardır. <strong>2027–2036 görünümü yalnızca arayüz senaryosudur; 10 yıllık iklim tahmini değildir.</strong> Toprak nemi, fiziksel bir ölçüm tanımı olmayan örnek yüzde göstergesidir.</p><h3>Öneriler nasıl hazırlanıyor?</h3><p>Üç örnek profile ait önceden yazılmış fikirler gösterilir. Verilerden hesaplanmış öneri, verim garantisi, ürün uygunluk puanı, ilaç ya da gübre dozu içermez. Kayısı bahçesinde ekim nöbeti yerine yönetim başlıkları gösterilir.</p><h3>Bir sonraki geliştirme adımı</h3><p>NASA POWER gibi kaynaklardan doğrulanmış geçmiş iklim verileri bağlanabilir. Bu bağlantı, toprak nemi ölçümü veya mevsimlik / 10 yıllık tahmin özelliği sağlamış sayılmaz; her biri ayrıca doğrulanmalıdır.</p><p class="modal-footer-note">Basro bağımsız bir Space Apps konsept projesidir; NASA ile resmî bağlantısı yoktur. Bu sürüm dış bir veri hizmetine istek göndermez. Yalnızca arayüz yazı tipleri internetten yüklenebilir.</p>`;
  } else if(type==='tasks'){
    renderTasks();
  } else if(type==='calendar'){
    renderCalendar();
  } else if(type==='nutrition'){
    const s=soilProfiles[state.field];
    $('#modal-content').innerHTML=`<h2 id="modal-title">Besleme önerisinin gerekçesi</h2><div class="info-box">${fieldLabel(f)} için pH ${format(s.ph,1)} ve organik madde %${format(s.organic,1)} <strong>kurgusal örneklerdir.</strong> NASA ölçümü veya gerçek laboratuvar sonucu değildir. Yıl koşulu menüsü bir hava tahmini değildir.</div><h3>Neyi değerlendiriyoruz?</h3><p>Seçilen örnek ürün, toprak profili ve yıl senaryosu üzerinden önceden yazılmış kontrol başlıkları gösterilir. Azot ihtiyacındaki yıllık değişim yalnızca yağıştan veya toprak neminden hesaplanamaz. Gerçek uygulama için analiz, verim hedefi, önceki ürün, sulama ve önceki gübre girdileri gerekir.</p>${nutritionAdvice().map(n=>`<h3>${n.title}</h3><p>${n.text}<br><strong>${n.missing}</strong></p>`).join('')}<h3>Yaklaşımın kaynakları</h3><p><a href="https://www.tarimorman.gov.tr/Konular/Bitkisel-Uretim/Bitki-Besleme-ve-Tarimsal-Teknolojiler" target="_blank" rel="noopener">Tarım ve Orman Bakanlığı: analize dayalı gübreleme</a><br><a href="https://extension.psu.edu/nutrient-management-to-improve-nitrogen-efficiency-and-reduce-environmental-loss" target="_blank" rel="noopener">Penn State Extension: azot bütçesi ve uygulama planı</a><br><a href="https://extension.missouri.edu/publications/g9077" target="_blank" rel="noopener">University of Missouri Extension: pH ve besin alımı</a><br><a href="https://extension.umn.edu/agriculture/specialty-crops/too-much-compost-and-manure" target="_blank" rel="noopener">University of Minnesota Extension: kompost ve tuzluluk</a></p><p class="modal-footer-note">Bu kaynaklar genel yaklaşımı destekler. Prototipteki sayısal profilleri ve Malatya için özel bir gübre reçetesini doğrulamaz.</p><button class="button button-green" id="nutrition-add">Besleme kontrolünü planıma ekle <svg><use href="#i-arrow"/></svg></button>`;
    $('#nutrition-add').addEventListener('click',()=>{const e=ensureEntry();if(!e.actions.includes(2))e.actions.push(2);persist();renderActions();modal.close();toast('Besleme analizi kontrolü planına eklendi.');});
  } else if(type==='guide'){
    $('#modal-content').innerHTML=`<h2 id="modal-title">İlk keşfin, dört küçük adım.</h2><div class="guide-step"><b>1</b><strong>Bir arazi seç</strong><p>Haritadaki 01, 02 ve 03 işaretlerini veya Malatya konum menüsünü kullan.</p></div><div class="guide-step"><b>2</b><strong>Katmanı ve dönemi değiştir</strong><p>Yağış, sıcaklık ve toprak nemini keşfet. Grafikteki noktalar üzerinde örnek değerleri görebilirsin.</p></div><div class="guide-step"><b>3</b><strong>Olasılıkları karşılaştır</strong><p>Ekim nöbeti kartlarını aç. Bir örnek alternatifi çalışma planına ekle.</p></div><div class="guide-step"><b>4</b><strong>Kendi listeni oluştur</strong><p>Kontrol listesi kutularını işaretle; seçimin bu tarayıcıda saklanır. Demo özetini metin dosyası olarak indirebilirsin.</p></div><p class="modal-footer-note">Her ekran temsili veri içerir. Senaryo geleceği tahmin etmez; planlama deneyimini gösterir.</p><button id="guide-start" class="button button-green">Haritayı keşfet <svg><use href="#i-arrow"/></svg></button>`;
    $('#guide-start').addEventListener('click',()=>modal.close());
  } else if(type==='table'){
    const l=layers[state.layer],p=periods[state.period],values=series();
    $('#modal-content').innerHTML=`<h2 id="modal-title">${l.name} · Örnek veri tablosu</h2><p>${fieldLabel(f)} · ${p.range}</p><div class="info-box">${state.period==='decade'?'Yalnızca temsili senaryo; tahmin değildir.':'Kurgusal değerler; gözlem veya ölçüm değildir.'}</div><table><thead><tr><th scope="col">Dönem</th><th scope="col">${l.name} (${l.unit})</th><th scope="col">Veri türü</th></tr></thead><tbody>${values.map((v,i)=>`<tr><td>${state.period==='decade'?2027+i:p.labels[i]}</td><td>${format(v,1)}</td><td>Temsili</td></tr>`).join('')}</tbody></table><p class="data-note">Grafik ve özet kartları aynı temsili seriden hesaplanır.</p>`;
  } else if(type==='plan'){
    renderPlan();
  }
  if(!modal.open)modal.showModal();
}
function renderPlan(){
  const entries=Object.entries(plan).filter(([id,e])=>e.actions.length||e.rotation!==null);
  $('#modal-content').innerHTML=`<h2 id="modal-title">Çalışma planım</h2><p>Örnek alternatiflerin ve işaretlediğin kontrol adımları. Gerçek bir tarımsal tavsiye veya uygulama takvimi değildir.</p>${entries.length?entries.map(([id,e])=>{const f=fields[id];return `<div class="plan-field"><h3>${fieldLabel(f)}</h3>${actionMarkup(id,true)}${e.rotation!==null?`<div class="plan-alt">Örnek seçenek: <strong>${f.rotations[e.rotation].name}</strong><button class="remove-rotation" data-remove-rotation="${id}" aria-label="${fieldLabel(f)} seçeneğini plandan çıkar"> ×</button></div>`:''}</div>`;}).join(''):`<div class="empty-state"><svg><use href="#i-plan"/></svg><p>Henüz bir seçimin yok.<br>Bir alternatifi planına ekle veya bir kontrol adımını işaretle.</p><button class="button button-green" id="back-to-map">Arazime dön <svg><use href="#i-arrow"/></svg></button></div>`}<p class="modal-footer-note">${storageAvailable?'Plan bu tarayıcıda saklanır; hesapla eşitlenmez.':'Tarayıcı kaydı kullanılamıyor; plan bu oturum boyunca korunur.'}</p>${entries.length?'<button class="clear-plan" id="clear-plan">Planı temizle</button>':''}`;
  bindActions($('#modal-content'));
  $$('[data-remove-rotation]').forEach(b=>b.addEventListener('click',()=>{ensureEntry(b.dataset.removeRotation).rotation=null;persist();renderRotations();renderPlan();}));
  $('#back-to-map')?.addEventListener('click',()=>{modal.close();$('#insights').scrollIntoView({behavior:'smooth',block:'start'});});
  $('#clear-plan')?.addEventListener('click',()=>{plan={};persist();renderActions();renderRotations();renderPlan();toast('Örnek çalışma planı temizlendi.');});
}

const monthNames=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
const monthTasks=[['Geçen sezonun ürün ve uygulama kayıtlarını gözden geçir.','Ekipman ve ölçüm ihtiyaçlarını listele.'],['Ürünün gelişme evresini izlemek için kayıt planı oluştur.','Donla mücadele ekipmanının bakımını değerlendir.'],['MGM zirai don uyarılarını ve yerel sıcaklığı takip et.','Ürüne uygun zararlı gözlem / tuzak planını uzmanla belirle.'],['Ürün gelişimini ve varsa çiçeklenmeyi kaydet.','Besleme kararından önce güncel analiz ihtiyacını değerlendir.'],['Saha ve tuzak gözlemlerini düzenli kaydet.','Sulama kayıtlarını ve toprak nemini birlikte değerlendir.'],['Uygulanan besin girdilerini ve bitki gözlemlerini karşılaştır.','Zararlı türü ve yoğunluğunu resmî teknik talimatla değerlendir.'],['Su durumu ve sıcaklıkla ilgili saha gözlemlerini kaydet.','Gereksiz uygulamayı önlemek için müdahale eşiğini doğrula.'],['Ürünün evresine göre hasat hazırlığını değerlendir.','Varsa bitki koruma uygulamalarının etiket ve bekleme sürelerini kontrol et.'],['Ürün artıkları ve toprak örneklemesi için plan hazırla.','Geçen dönemin verim ve uygulama kayıtlarını toparla.'],['Sonraki ürün veya bahçe yönetimi alternatiflerini karşılaştır.','Analiz sonuçlarına göre besleme görüşmesi planla.'],['Organik materyal seçeneklerini analiz ve tuzluluk açısından değerlendir.','Ekipman ve saha kayıtlarını güncelle.'],['Yıllık planı ve eksik verileri gözden geçir.','Sonraki sezonun gözlem ve bakım başlıklarını oluştur.']];
function renderCalendar(){
  const f=fields[state.field],view=state.calendarView;
  let body='';
  if(view==='year')body=`<p class="calendar-context">${fieldLabel(f)} · ${f.crop} · 2027 örnek çalışma planı</p><div class="info-box">Bu takvim bir hazırlık şablonudur. Tarihler ve takip başlıkları gerçek tahmin veya araziye özel uygulama takvimi değildir. Bildirim gönderilmez.</div><div class="month-grid">${monthNames.map((m,i)=>`<button data-month="${i}" aria-pressed="${state.calendarMonth===i}">${m.slice(0,3)}${i===2?'<i></i>':''}</button>`).join('')}</div><div class="calendar-month"><h3>${monthNames[state.calendarMonth]} 2027 <span>ÖRNEK PLAN</span></h3>${monthTasks[state.calendarMonth].map(t=>`<p><svg><use href="#i-check"/></svg>${t}</p>`).join('')}${state.calendarMonth===2?'<button class="calendar-event" id="calendar-frost-event"><b>24 MART</b><span>Don hazırlık tatbikatı <small>Tahmin değil · Temsili olay</small></span><svg><use href="#i-arrow"/></svg></button>':''}</div><button class="button button-outline" id="export-calendar"><svg><use href="#i-download"/></svg>Örnek yıllık takvimi indir (.ics)</button>`;
  if(view==='frost')body=`<div class="frost-scenario"><div><span>24 MART 2027 · 03.00–06.00</span><strong>Don hazırlık tatbikatı</strong><p>Bu tarih ve saat bir kullanım örneğidir. Gerçek bir don tahmini yapılmadı.</p></div><b>DEMO</b></div><p class="calendar-context">${fieldLabel(f)} · ${f.crop}. Hassasiyet ürünün çeşidine ve gelişme evresine göre değişir. Yıllık plan riskli dönemleri hatırlatabilir; belirli güne ait uyarı güncel tahminle doğrulanır.</p><h3>Öncelik sırasıyla ne yapmalı?</h3><p class="data-note">Bu sıra hazırlık adımlarını düzenler; yöntemlerin her arazideki etkinlik sıralaması değildir.</p><ol class="frost-steps"><li><strong>Uyarıyı ve ürün evresini doğrula</strong><p>MGM'nin güncel uyarısını, yerel ölçümü ve ürünün gelişme evresini birlikte kontrol et. Bahçe içi sıcaklık, bölgesel tahminden farklı olabilir.</p></li><li><strong>Hazırlığı ve kaynakları kontrol et</strong><p>İletişim listesini, sensörleri, enerji / su sürekliliğini ve varsa mevcut koruma sisteminin çalışma durumunu gözden geçir.</p></li><li><strong>Koşula uygun korumayı belirle</strong><p>Don tipi, rüzgâr, arazi ve ürün özelliklerine göre uzmanla yöntem seç. Tek bir yöntem her don olayına uygun değildir.</p><details><summary>Yöntem seçenekleri ve koşulları</summary><p><b>Örtü:</b> Ürün ve ölçek uygunsa değerlendirilebilir.<br><b>Hava karıştırma:</b> Üstte sıcak hava tabakası bulunan uygun koşullarda değerlendirilir.<br><b>Donla mücadele yağmurlaması:</b> Yeterli ve kesintisiz su, uygun sistem ve uzman planı gerektirir. Yanlış uygulama zararı artırabilir.</p></details></li><li><strong>Olay boyunca yerel durumu izle</strong><p>Seçilen yöntemi onaylı çalışma planına göre yönet; sıcaklık ve sistem kesintilerini kaydet.</p></li><li><strong>Sonrasında hasarı değerlendir</strong><p>Gözlemlerini kaydet ve uzmanla hasar değerlendirmesi yap. Hasar belirlenmeden ek gübre veya ilaç uygulaması kararı verme.</p></li></ol><p class="source-line">Kaynak yaklaşımı: <a href="https://www.mgm.gov.tr/genel/sss.aspx?s=dondankorunma-" target="_blank" rel="noopener">MGM don önlemleri</a> · <a href="https://www.mgm.gov.tr/tarim/zirai-don-uyari-sistemi-harita.aspx" target="_blank" rel="noopener">Güncel 5 günlük don haritaları</a></p>`;
  if(view==='pest'){
    const scenario=state.pestScenario;
    const title=scenario==='rise'?'Gözlemi doğrula, müdahale eşiğini kontrol et':scenario==='low'?'Düşük yoğunluk senaryosu: izlemeyi sürdür':'İlaçlama kararı için veri eksik';
    const text=scenario==='rise'?'Örnek sayımların arttığını varsayıyoruz. Artış tek başına ilaçlama gerekçesi değildir. Tür, bitki evresi, faydalı böcekler ve ilgili teknik talimattaki müdahale eşiği birlikte değerlendirilmelidir.':scenario==='low'?'Düşük yoğunluk otomatik olarak koruyucu ilaçlama veya düşük doz uygulama gerekçesi oluşturmaz. İlgili eşik ve saha değerlendirmesi doğrultusunda gereksiz uygulama önlenebilir.':'Uydu sıcaklık ve nem verileri böcek sayımı yerine geçmez. Tür teşhisi, tarihli saha / tuzak gözlemleri ve ürüne özgü eşik bilgisi olmadan ilaç önerisi oluşturulmaz.';
    body=`<p class="calendar-context">${fieldLabel(f)} · ${f.crop} için örnek zararlı takip akışı</p><label class="pest-select-label" for="pest-scenario">Etkileşimli gözlem senaryosu<select id="pest-scenario"><option value="none" ${scenario==='none'?'selected':''}>Gözlem verisi yok</option><option value="rise" ${scenario==='rise'?'selected':''}>Örnek: yoğunluk artıyor</option><option value="low" ${scenario==='low'?'selected':''}>Örnek: düşük yoğunluk</option></select></label><div class="pest-result"><span>TEMSİLİ KARAR AKIŞI</span><h3>${title}</h3><p>${text}</p></div><div class="pest-requirements"><span>Tür teşhisi <b>Eksik</b></span><span>Gerçek saha / tuzak sayımı <b>Eksik</b></span><span>Ürüne özgü müdahale eşiği <b>Doğrulanmadı</b></span><span>Gün-derece modeli <b>Bağlanmadı</b></span></div><h3>İlaç kararı nasıl oluşacak?</h3><p>İklim verisi gelişme zamanını değerlendirmeye yardımcı olabilir. Saha gözlemi, bitkinin evresi ve resmî talimatla müdahale ihtiyacı doğrulanır. Gerekliyse ürün / zararlı için ruhsatlı seçenekler uzmanla değerlendirilir; doz ve bekleme süresi etikete göre ele alınır.</p><div class="info-box">Bu sürüm ilaç veya doz önermez. Yoğunluk artınca etiketteki dozu artırmak, azalınca dozu düşürmek bu karar akışının parçası değildir.</div><p class="source-line">Örnek resmî sistem: <a href="https://sunetahminuyari.tarimorman.gov.tr/" target="_blank" rel="noopener">Süne Tahmin Uyarı Sistemi</a>. Bu bağlantı ${f.crop} için doğrulanmış bir uyarı veya entegrasyon değildir.</p>`;
  }
  $('#modal-content').innerHTML=`<h2 id="modal-title">Sezon takvimi ve uyarılar</h2><div class="calendar-tabs" role="tablist" aria-label="Sezon takip görünümü"><button role="tab" data-calendar-view="year" aria-selected="${view==='year'}">Yıllık plan</button><button role="tab" data-calendar-view="frost" aria-selected="${view==='frost'}">Don önlemleri</button><button role="tab" data-calendar-view="pest" aria-selected="${view==='pest'}">Zararlı takibi</button></div>${body}<button class="button button-green" id="add-season-plan">Sezon kontrolünü çalışma planıma ekle <svg><use href="#i-arrow"/></svg></button>`;
  $$('[data-calendar-view]').forEach(b=>b.addEventListener('click',()=>{state.calendarView=b.dataset.calendarView;renderCalendar();}));
  $$('[data-month]').forEach(b=>b.addEventListener('click',()=>{state.calendarMonth=Number(b.dataset.month);renderCalendar();}));
  $('#pest-scenario')?.addEventListener('change',event=>{state.pestScenario=event.target.value;renderCalendar();});
  $('#calendar-frost-event')?.addEventListener('click',()=>{state.calendarView='frost';renderCalendar();});
  $('#export-calendar')?.addEventListener('click',exportCalendar);
  $('#add-season-plan').addEventListener('click',()=>{const e=ensureEntry();if(!e.actions.includes(3))e.actions.push(3);persist();renderActions();modal.close();toast('Don ve zararlı takip kontrolü planına eklendi.');});
}
function exportCalendar(){
  const f=fields[state.field];
  const icsEscape=v=>v.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/;/g,'\\;').replace(/,/g,'\\,');
  let rows=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Basro//Synthetic Demo//TR','CALSCALE:GREGORIAN','X-WR-CALNAME:Basro DEMO - Gerçek tahmin değil'];
  monthNames.forEach((m,i)=>{const month=String(i+1).padStart(2,'0');rows.push('BEGIN:VEVENT',`UID:demo-${state.field}-2027-${month}@Basro.invalid`,'DTSTAMP:20261025T000000Z',`DTSTART;VALUE=DATE:2027${month}15`,`DTEND;VALUE=DATE:2027${month}16`,`SUMMARY:${icsEscape(`[DEMO] ${m} örnek sezon kontrolü - ${f.crop}`)}`,`DESCRIPTION:${icsEscape('Hazırlık şablonu; gerçek analiz veya tahmin değildir. 15. gün yalnızca örnek plan tarihidir. '+fieldLabel(f)+'. '+monthTasks[i].join(' '))}`,'END:VEVENT');});
  rows.push('BEGIN:VEVENT',`UID:demo-frost-${state.field}-20270324@Basro.invalid`,'DTSTAMP:20261025T000000Z','DTSTART;VALUE=DATE:20270324','DTEND;VALUE=DATE:20270325','SUMMARY:[DEMO] Don hazirlik tatbikati - TAHMIN DEGIL','DESCRIPTION:24 Mart tarihi kurgusal ornektir. Gercek don uyarisi yoktur. MGM guncel uyarisini takip edin.','END:VEVENT','END:VCALENDAR');
  const url=URL.createObjectURL(new Blob([rows.join('\r\n')+'\r\n'],{type:'text/calendar;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=`agroatlas-DEMO-takvim-2027-${state.field}.ics`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);toast('Temsili yıllık takvim hazırlandı.');
}

function exportSummary(){
  const f=fields[state.field],p=periods[state.period],e=entry();
  const content=`BASRO · GÖRSEL PROTOTİP V0.1\n\nTEMSİLİ VERİ — GERÇEK ANALİZ VEYA TAHMİN DEĞİLDİR.\nNASA veri bağlantısı yoktur. Harita ve arazi profilleri şematiktir.\n\nSeçili örnek arazi: ${fieldLabel(f)}\nTemsili alan: ${f.area} dekar\nÖrnek ürün: ${f.crop}\nDönem: ${p.range}\n\nÖRNEK GÖSTERGELER\n${state.period==='decade'?'Yıllık ortalama':'Toplam'} yağış: ${format(metricValue('rain'))} mm\nOrtalama sıcaklık: ${format(metricValue('temp'),1)} °C\nOrtalama toprak nemi göstergesi: %${format(metricValue('moisture'))}\n${state.period==='decade'?'2027–2036 değerleri yalnızca kurgusal senaryodur. İklim tahmini değildir.\n':''}\nSEÇİLİ ÖRNEK ALTERNATİF\n${e.rotation!==null?f.rotations[e.rotation].name:'Henüz seçilmedi.'}\n\nTOPRAK VE BESLEME — ÖRNEK SENARYO\nToprak pH: ${format(soilProfiles[state.field].ph,1)} (temsili)\nOrganik madde: %${format(soilProfiles[state.field].organic,1)} (temsili)\nYıl koşulu: ${{normal:'Olağan yıl',wet:'Yağışlı yıl',dry:'Kurak yıl'}[state.nutritionScenario]} (temsili)\n${nutritionAdvice().map(n=>n.title+'\n'+n.text+'\n'+n.missing).join('\n\n')}\nGübre türü veya dozu hesaplanmamıştır.\n\nÖRNEK KONTROL LİSTESİ\n${f.actions.map((a,i)=>`[${e.actions.includes(i)?'x':' '}] ${a}`).join('\n')}\n\nÖneriler önceden yazılmış örnek fikirlerdir; araziye özel analiz yapılmamıştır.\nBasro bağımsız bir Space Apps konsept projesidir. NASA ile resmî bağlantısı yoktur.\n`;
  const url=URL.createObjectURL(new Blob(['\ufeff'+content],{type:'text/plain;charset=utf-8'}));
  const anchor=document.createElement('a');anchor.href=url;anchor.download=`agroatlas-demo-${state.field}-${state.period}.txt`;document.body.appendChild(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);toast('Temsili demo özeti hazırlandı.');
}

$$('[data-layer]').forEach(b=>b.addEventListener('click',()=>pickLayer(b.dataset.layer)));
$$('[data-metric]').forEach(b=>b.addEventListener('click',()=>pickLayer(b.dataset.metric)));
$$('[data-period]').forEach(b=>{
  b.addEventListener('click',()=>pickPeriod(b.dataset.period));
  b.addEventListener('keydown',event=>{
    const tabs=$$('[data-period]'),index=tabs.indexOf(b);let next;
    if(event.key==='ArrowRight')next=(index+1)%tabs.length;if(event.key==='ArrowLeft')next=(index-1+tabs.length)%tabs.length;if(event.key==='Home')next=0;if(event.key==='End')next=tabs.length-1;
    if(next!==undefined){event.preventDefault();pickPeriod(tabs[next].dataset.period);tabs[next].focus();}
  });
});
$('#location-button').addEventListener('click',openLocation);$('#field-search').addEventListener('input',fieldOptions);
document.addEventListener('click',event=>{if(!event.target.closest('.location-picker')&&!event.target.closest('#rail-fields'))closeLocation();});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('#location-menu').hidden){closeLocation();$('#location-button').focus();}});
$('#zoom-in').addEventListener('click',()=>{state.zoom=Math.min(1.8,Math.round((state.zoom+.2)*10)/10);positionMarkers();});
$('#zoom-out').addEventListener('click',()=>{state.zoom=Math.max(1,Math.round((state.zoom-.2)*10)/10);positionMarkers();});
$('#recenter').addEventListener('click',()=>{state.zoom=1;positionMarkers();toast('Harita başlangıç görünümüne getirildi.');});
$('#inspect-field').addEventListener('click',()=>{$('#insights').scrollIntoView({behavior:'smooth',block:'start'});$('#insights').focus({preventScroll:true});});
$$('[data-dialog]').forEach(b=>b.addEventListener('click',()=>openDialog(b.dataset.dialog)));
$('#chart-data-button').addEventListener('click',()=>openDialog('table'));
['nav-plan','rail-plan','open-plan'].forEach(id=>$('#'+id).addEventListener('click',()=>openDialog('plan')));
$('#close-modal').addEventListener('click',()=>modal.close());
modal.addEventListener('click',event=>{const r=modal.getBoundingClientRect();if(event.target===modal&&(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom))modal.close();});
$('#nav-map').addEventListener('click',()=>{$('#map-wrap').scrollIntoView({behavior:'smooth',block:'center'});});
$('#rail-map').addEventListener('click',()=>{$('#map-wrap').scrollIntoView({behavior:'smooth',block:'center'});});
$('#rail-fields').addEventListener('click',()=>{$('#map-wrap').scrollIntoView({behavior:'smooth',block:'center'});openLocation();});
$('.brand').addEventListener('click',event=>{event.preventDefault();window.scrollTo({top:0,behavior:'smooth'});});
$('#export').addEventListener('click',exportSummary);
$('#nutrition-scenario').addEventListener('change',event=>{state.nutritionScenario=event.target.value;renderNutrition();});
$('#nutrition-details').addEventListener('click',()=>openDialog('nutrition'));
$('#nav-calendar').addEventListener('click',()=>{state.calendarView='year';openDialog('calendar');});
$('#frost-alert').addEventListener('click',()=>{state.calendarView='frost';openDialog('calendar');});
$('#pest-alert').addEventListener('click',()=>{state.calendarView='pest';openDialog('calendar');});
$('#nav-tasks').addEventListener('click',()=>openDialog('tasks'));
$('#all-tasks').addEventListener('click',()=>openDialog('tasks'));
makeMapTexture();render();
new ResizeObserver(positionMarkers).observe($('#map-stage'));
if(!storageAvailable)$$('.local-note').forEach(el=>el.textContent='Tarayıcı kaydı kapalı; seçimler bu oturumda korunur.');
