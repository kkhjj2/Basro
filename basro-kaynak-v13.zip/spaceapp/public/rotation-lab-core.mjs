// Transparent preference screening. Scores are dimensionless heuristics, never crop outcomes.
import {cropFamily, foldCrop} from './crop-catalog.mjs';

export const ROTATION_METHOD_VERSION = 'agro-rotation-1.0';
export const ROTATION_PARAMETER_VERSION = 'qualitative-four-crops-1.0';
const text = (tr, en) => ({tr, en});
export const ROTATION_CROP_IDS = Object.freeze(['wheat', 'chickpea', 'barley', 'lentil']);
export const ROTATION_SOURCES = Object.freeze({
  families: {id:'families', title:'University of Minnesota Extension · Plant families', url:'https://extension.umn.edu/garden-and-home/yard-and-garden/gardening-in-minnesota/living-soil-healthy-garden', scope:'Botanical grouping; garden guidance is not a field-specific rotation prescription.'},
  chickpeaFamily: {id:'chickpeaFamily', title:'Royal Botanic Gardens, Kew · Chickpea', url:'https://www.kew.org/plants/chickpea', scope:'Botanical identity of Cicer arietinum in Fabaceae.'},
  smallGrains: {id:'smallGrains', title:'University of Minnesota / NDSU Extension · Small grain crop rotations', url:'https://extension.umn.edu/agriculture/crop-production/small-grains/small-grain-crop-rotations', scope:'Small-grain disease and rotation guidance from Minnesota and North Dakota; local transfer requires review.'},
  chickpea: {id:'chickpea', title:'Government of Saskatchewan · Chickpea: Adaptation and Varieties', url:'https://www.saskatchewan.ca/business/agriculture-natural-resources-and-industry/agribusiness-farmers-and-ranchers/crops-and-irrigation/field-crops/pulse-crop-bean-chickpea-faba-bean-lentils/chickpea/adaptation-and-varieties', scope:'Regional chickpea adaptation, cereal residues, moisture extraction and waterlogging sensitivity; no local numeric requirements transferred.'},
  lentil: {id:'lentil', title:'Government of Saskatchewan · Red lentils', url:'https://www.saskatchewan.ca/business/agriculture-natural-resources-and-industry/agribusiness-farmers-and-ranchers/crops-and-irrigation/field-crops/pulse-crop-bean-chickpea-faba-bean-lentils/red-lentils', scope:'Regional lentil adaptation and waterlogging sensitivity; not a locally calibrated cultivar profile.'},
  pulseStress: {id:'pulseStress', title:'Montana State University Extension · Chickpea Production', url:'https://extension-store.montana.edu/montguides/chickpea-production', scope:'Qualitative chickpea-versus-lentil heat/drought comparison; no field loss magnitude or probability.'},
  pulseBreaks: {id:'pulseBreaks', title:'Agriculture Victoria · Growing lentil in Victoria', url:'https://agriculture.vic.gov.au/crops-and-horticulture/grains-pulses-and-cereals/growing-grains-pulses-and-cereals/growing-lentil-in-victoria', scope:'Longer pulse disease breaks may be needed; one previous crop and a three-year horizon cannot certify disease control.'},
  orchard: {id:'orchard', title:'UC Statewide IPM · Prune integrated weed management', url:'https://ipm.ucanr.edu/agriculture/prune/integrated-weed-management/', scope:'Orchard-floor cover benefits, mowing needs and water competition; species and timing remain site-specific.'},
  seasonal: {id:'seasonal', title:'Open-Meteo · Seasonal forecast documentation', url:'https://open-meteo.com/en/docs/seasonal-forecast-api', scope:'Regional seasonal model context only; not a three-year or field-scale forecast.'}
});

export const ROTATION_PROFILES = Object.freeze({
  wheat: {id:'wheat', label:text('Buğday','Wheat'), botanicalFamily:'Poaceae', sourceIds:['families','smallGrains'], aliases:['wheat','bugday','ekmeklik bugday','makarnalik bugday','siyez bugdayi','kavilca bugdayi']},
  chickpea: {id:'chickpea', label:text('Nohut','Chickpea'), botanicalFamily:'Fabaceae', sourceIds:['chickpeaFamily','chickpea','pulseStress'], aliases:['chickpea','nohut']},
  barley: {id:'barley', label:text('Arpa','Barley'), botanicalFamily:'Poaceae', sourceIds:['families','smallGrains'], aliases:['barley','arpa']},
  lentil: {id:'lentil', label:text('Mercimek','Lentil'), botanicalFamily:'Fabaceae', sourceIds:['families','lentil','pulseBreaks'], aliases:['lentil','mercimek','kirmizi mercimek','yesil mercimek']}
});
const profileFor = value => Object.values(ROTATION_PROFILES).find(p => p.aliases.includes(foldCrop(value))) || null;
const reason = (code, tr, en, sourceIds = [], details = {}) => ({code, label:text(tr,en), sourceIds, ...details});
const missing = (id, tr, en) => ({id, label:text(tr,en)});
const round = n => Number(n.toFixed(6));
const sourceRows = ids => [...new Set(ids)].map(id => ({...ROTATION_SOURCES[id]}));
const STATUS = {
  infeasible:text('Kural dışı','Excluded by screening rule'),
  needs_evidence:text('Ek kanıt gerekiyor','More evidence needed'),
  provisional:text('Ön karşılaştırma; yerelde doğrulanmalı','Provisional comparison; verify locally')
};
export const ROTATION_CRITERIA = Object.freeze({
  water: {label:text('Su koruma tercihi göstergesi','Water-conservation preference proxy'), unit:'dimensionless_heuristic', higherIsPreferred:true, range:[0,1]},
  soil: {label:text('Ürün çeşitliliği göstergesi','Crop-diversity proxy'), unit:'dimensionless_heuristic', higherIsPreferred:true, range:[0,1]},
  feasibility: {label:text('Mevcut ürüne aşinalık göstergesi','Existing-crop familiarity proxy'), unit:'dimensionless_heuristic', higherIsPreferred:true, range:[0,1]}
});
const LIMITATIONS = [
  text('Bu sonuç ekim onayı değildir. Yerel çeşit, ekim zamanı, hastalık geçmişi, toprak analizi ve su bütçesi doğrulanmalıdır.','This result is not planting approval. Verify local cultivar, sowing window, disease history, soil tests and water budget.'),
  text('Puanlar boyutsuz tercih göstergeleridir; verim, su tüketimi, toprak sağlığı ölçümü veya başarı olasılığı değildir.','Scores are dimensionless preference proxies, not yield, water consumption, measured soil health or success probability.'),
  text('Tek önceki ürün daha uzun hastalık aralarını doğrulamaz. Aile değişimi ortak hastalıkları tamamen önlemez.','One preceding crop cannot verify longer disease breaks. Changing families does not eliminate shared pathogens.'),
  text('Kuzey Amerika ve Avustralya kaynakları nitel tarama içindir; yerel uygunluk kalibrasyonu yapılmadı.','North American and Australian sources support qualitative screening; local suitability is not calibrated.'),
  text('Verim, Kc, azot kredisi, kâr, beklenen kayıp ve ekonomik risk hesaplanmaz; güvenilir yerel parametreler yoktur.','Yield, Kc, nitrogen credits, profit, expected loss and financial risk are not calculated; reliable local parameters are unavailable.'),
  text('Üç yıllık sıra sonlu bir plandır; üçüncü yıldan birinci yıla otomatik döngü sayılmaz.','The three-year sequence is finite; an automatic third-to-first-year cycle is not assumed.')
];

function normalizePriorities(value) {
  const weights = Object.fromEntries(['water','soil','feasibility'].map(key => [key, typeof value?.[key] === 'number' && Number.isFinite(value[key]) && value[key] >= 0 ? value[key] : 1]));
  const max = Math.max(...Object.values(weights));
  // Scale before summation to handle even very large finite user weights safely.
  if (max === 0) return {water:1/3, soil:1/3, feasibility:1/3};
  const scaled = Object.fromEntries(Object.entries(weights).map(([key,n]) => [key,n/max]));
  const total = Object.values(scaled).reduce((sum,n) => sum+n,0);
  return Object.fromEntries(Object.entries(scaled).map(([key,n]) => [key,n/total]));
}

function normalizeEvidence(input) {
  const value = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  const hours = typeof value.standingWaterHours === 'number' && Number.isFinite(value.standingWaterHours) && value.standingWaterHours >= 0 ? value.standingWaterHours : null;
  const texture = ['sandy','loam','clay'].includes(value.soilTexture) ? value.soilTexture : null;
  const supplied = value.uncertainty?.standingWaterHours;
  const validRange = supplied && typeof supplied.lower === 'number' && Number.isFinite(supplied.lower) && typeof supplied.upper === 'number' && Number.isFinite(supplied.upper) && hours !== null && supplied.lower >= 0 && supplied.lower <= hours && supplied.upper >= hours;
  const range = validRange ? {lower:supplied.lower,upper:supplied.upper,kind:typeof supplied.kind === 'string' ? supplied.kind : 'accepted_range'} : null;
  const invalidRange = supplied !== undefined && !validRange;
  const uncertainPonding = invalidRange || !!(range && range.lower === 0 && range.upper > 0);
  const pondingReported = hours > 0 && !uncertainPonding;
  return {standingWaterHours:hours, standingWaterRange:range, uncertainPonding, pondingReported, invalidRange, soilTexture:texture, previousCrop:profileFor(value.previousCrop), previousCropInput:typeof value.previousCrop === 'string' ? value.previousCrop : null};
}

function scenarios(seasonPlan) {
  const chosen = seasonPlan?.chosen;
  const modelContext = seasonPlan?.available === true && seasonPlan?.hypothetical !== true && seasonPlan?.scenario === 'model' && chosen && typeof chosen.month === 'string';
  const reference = modelContext ? {kind:'regional_seasonal_context', month:chosen.month, method:seasonPlan.method || null, temperatureDirection:chosen.temperature?.direction || null, precipitationDirection:chosen.rain?.direction || null, sourceIds:['seasonal']} : {kind:'no_validated_climate_reference', sourceIds:[]};
  return [
    {id:'reference',label:text('Referans tarama','Reference screen'), precipitation:'unchanged', temperature:'unchanged'},
    {id:'dry',label:text('Daha kurak koşul','Drier conditions'), precipitation:'lower', temperature:'unchanged'},
    {id:'warm',label:text('Daha sıcak koşul','Warmer conditions'), precipitation:'unchanged', temperature:'higher'},
    {id:'combined',label:text('Birleşik sıcaklık ve kuraklık stresi','Combined heat and precipitation stress'), precipitation:'lower', temperature:'higher'}
  ].map(s => ({...s, kind:s.id === 'reference' ? 'reference_screen' : 'qualitative_sensitivity_scenario', reference, magnitude:null, probability:null, numericOutcomeAvailable:false, note:text('Yönsel duyarlılık deneyi; artış/azalış büyüklüğü, gerçekleşme olasılığı veya üç yıllık tahmin verilmez.','Directional sensitivity exercise; no change magnitude, event probability or three-year forecast is assigned.')}));
}

function scenarioResults(cropIds, definitions, feasibility, orchard = false) {
  return definitions.map(s => {
    const flags = [];
    const dry = s.precipitation === 'lower', warm = s.temperature === 'higher';
    if (s.id !== 'reference') flags.push(reason('local_exposure_unknown','Yerel maruziyet ve ürün evresi bilinmiyor; sonuç büyüklüğü hesaplanamaz.','Local exposure and crop stage are unknown; outcome magnitude cannot be estimated.'));
    if (!orchard && (dry || warm) && cropIds.includes('chickpea')) flags.push(reason('chickpea_relative_stress_context','Kaynak, nohutu mercimeğe göre sıcak/kurak streste daha dayanıklı tanımlar; bu yerel başarı güvencesi değildir.','The source describes chickpea as relatively more tolerant than lentil under heat/drought stress; this does not guarantee local performance.',['pulseStress']));
    if (!orchard && (dry || warm) && cropIds.includes('lentil')) flags.push(reason('lentil_stress_review','Mercimekte sıcak/kurak koşullar için çeşit ve çiçeklenme dönemi incelenmeli.','Review lentil cultivar and flowering-stage exposure under heat/drought.',['lentil','pulseStress']));
    if (orchard && dry && cropIds[0] !== 'mulch') flags.push(reason('living_cover_water_competition','Canlı örtünün ağaçlarla su rekabetini ve sonlandırma zamanını incele.','Review living-cover water competition with trees and termination timing.',['orchard']));
    return {id:s.id, label:s.label, status:feasibility === 'infeasible' ? 'excluded' : s.id === 'reference' ? 'qualitative_screen_only' : 'needs_evidence', flags, score:null, numericOutcomeAvailable:false, probability:null};
  });
}

function annualCriteria(ids, currentCrop, evidence) {
  const n = ids.length;
  // Neutral cereal contribution is a scoring convention, not an equal-water-use claim.
  const water = (1 + (ids.filter(id => id === 'lentil').length - ids.filter(id => id === 'chickpea').length)/n)/2;
  const soil = new Set(ids).size/n;
  // Reuse of a recorded crop is only a transparent proxy for operational familiarity.
  const familiarity = ids.filter(id => id === currentCrop.id).length/n;
  const drainageFactor = (evidence.pondingReported || evidence.uncertainPonding) && ids.some(id => ROTATION_PROFILES[id].botanicalFamily === 'Fabaceae') ? .5 : 1;
  return {water:round(water), soil:round(soil), feasibility:round(familiarity*drainageFactor)};
}

function assignRanking(candidates, priorities) {
  const eligible = candidates.filter(c => c.feasibility !== 'infeasible');
  const dimensions = ['water','soil','feasibility'];
  for (const candidate of eligible) {
    candidate.pareto = !eligible.some(other => other !== candidate && dimensions.every(key => other.criteria[key] >= candidate.criteria[key]) && dimensions.some(key => other.criteria[key] > candidate.criteria[key]));
    candidate.utility = round(dimensions.reduce((sum,key) => sum+candidate.criteria[key]*priorities[key],0));
  }
  eligible.sort((a,b) => b.utility-a.utility || a.id.localeCompare(b.id,'en'));
  let rank = 0, lastUtility = null;
  eligible.forEach((candidate,index) => {if (candidate.utility !== lastUtility) rank = index+1; candidate.rank=rank; lastUtility=candidate.utility;});
  const preferredIds = eligible.filter(c => c.pareto && c.utility === eligible[0]?.utility).map(c => c.id);
  return {preferredIds, candidates:[...eligible, ...candidates.filter(c => c.feasibility === 'infeasible').sort((a,b) => a.id.localeCompare(b.id,'en'))]};
}

function orchardCandidates(farm, definitions, evidence) {
  const plans = [
    {id:'mulch', title:text('Ölü organik örtü','Non-living organic mulch'), criteria:{water:1,soil:.5,feasibility:1}, tradeoff:text('Malzeme, gövde açıklığı ve yerel zararlı/yangın koşulları doğrulanmalı.','Verify material, trunk clearance and local pest/fire conditions.')},
    {id:'winter-cover', title:text('Geçici kış örtüsü','Temporary winter cover'), criteria:{water:.5,soil:1,feasibility:.5}, tradeoff:text('Canlı örtü su kullanır; tür ve sonlandırma zamanı için yerel plan gerekir.','Living cover uses water; species and termination timing need a local plan.')},
    {id:'mown-cover', title:text('Biçilen mevcut örtü','Mown resident cover'), criteria:{water:.25,soil:1,feasibility:.75}, tradeoff:text('Türleri tanımla; biçim, don riski ve su rekabetini izle.','Identify species; monitor mowing, frost risk and water competition.')}
  ];
  return plans.map(p => ({id:`orchard-floor-${p.id}`,kind:'orchard_floor', title:p.title, retainsTrees:true, retainedCrop:farm.crop, sequence:[farm.crop,p.title.tr,farm.crop], sequenceLabels:[text(farm.crop,farm.crop),p.title,text(farm.crop,farm.crop)],cropIds:[p.id],feasibility:'needs_evidence',feasibilityLabel:STATUS.needs_evidence,excludedReasons:[],criteria:p.criteria,criteriaUnit:'dimensionless_heuristic',tradeoffs:[p.tradeoff,text('Mevcut çok yıllık bitkiler korunur; yıllık ürün değişimi önerilmez.','Existing perennial plants are retained; annual replacement is not proposed.')],scenarioResults:scenarioResults([p.id],definitions,'needs_evidence',true),evidence:[...sourceRows(['orchard']),{id:'field-inputs',kind:'accepted_local_evidence',values:{soilTexture:evidence.soilTexture,standingWaterHours:evidence.standingWaterHours}}],pareto:false,rank:null,utility:null}));
}

/**
 * fieldEvidence contains accepted values ONLY. The observation validation layer owns status,
 * provenance and uncertainty. Pending/rejected observations must never be passed here.
 * Previous crop is the crop immediately BEFORE the first of three future plan slots.
 */
export function evaluateRotations({farm = {}, seasonPlan = {}, fieldEvidence = {}, priorities = {water:1,soil:1,feasibility:1}} = {}) {
  farm = farm && typeof farm === 'object' && !Array.isArray(farm) ? farm : {};
  const evidence = normalizeEvidence(fieldEvidence), weights = normalizePriorities(priorities), definitions = scenarios(seasonPlan);
  const base = {methodVersion:ROTATION_METHOD_VERSION,parameterVersion:ROTATION_PARAMETER_VERSION,criteriaDefinitions:ROTATION_CRITERIA,priorities:weights,previousSequence:evidence.previousCrop ? [evidence.previousCrop.label.tr] : [],previousSequenceComplete:false,scenarioDefinitions:definitions,limitations:[...LIMITATIONS],missingEvidence:[],preferredIds:[],candidates:[]};
  if (['orchard','vine','bush'].includes(cropFamily(farm.crop))) {
    const candidates = orchardCandidates(farm,definitions,evidence);
    return {...base,kind:'orchard',...assignRanking(candidates,weights),missingEvidence:[missing('orchardSpeciesTiming','Örtü türü, bahçe yaşı ve sonlandırma zamanı','Cover species, orchard age and termination timing'),missing('waterBudget','Ağaç ve örtü için doğrulanmış su bütçesi','Verified water budget for trees and cover')],limitations:[...base.limitations,text('Bahçe puanları yönetim karmaşıklığı ve canlı örtü rekabeti için açık tasarım tercihleridir; deneysel üstünlük sırası değildir.','Orchard scores are explicit design preferences for management complexity and living-cover competition, not an experimental performance ranking.')]};
  }
  const currentCrop = profileFor(farm.crop);
  if (!currentCrop) return {...base,kind:'annual',missingEvidence:[missing('supportedCropProfile','Bu ürün için kaynaklı rotasyon profili yok. Desteklenenler: buğday, nohut, arpa ve mercimek.','No sourced rotation profile for this crop. Supported: wheat, chickpea, barley and lentil.')]};
  const gaps = [];
  if (!evidence.previousCrop) gaps.push(missing('previousCrop','İlk plan yılından hemen önceki ürünün kabul edilmiş kaydı','Accepted record of the crop immediately before plan year one'));
  if (evidence.standingWaterHours === null) gaps.push(missing('standingWaterHours','Yağış sonrası su birikme süresinin kabul edilmiş gözlemi','Accepted observation of standing-water duration after rain'));
  if (!evidence.soilTexture) gaps.push(missing('soilTexture','Yöntemi belirtilmiş yaklaşık toprak bünyesi','Approximate soil texture with a recorded method'));
  if (evidence.pondingReported) gaps.push(missing('drainageAssessment','Bildirilen su birikmesinin konumu, kök bölgesi etkisi ve ürün döneminde drenaj değerlendirmesi','Assessment of reported ponding location, root-zone effect and drainage during the crop season'));
  if (evidence.uncertainPonding) gaps.push(missing('drainageUncertainty','Su birikmesi aralığı sıfırı ve pozitif süreleri kapsıyor veya geçersiz; drenaj belirsizliği çözülmedi.','The standing-water range includes zero and positive durations, or is invalid; drainage uncertainty remains unresolved.'));
  const candidates = [];
  for (const first of ROTATION_CROP_IDS) for (const second of ROTATION_CROP_IDS) for (const third of ROTATION_CROP_IDS) {
    const ids = [first,second,third], profiles = ids.map(id => ROTATION_PROFILES[id]), excludedReasons = [];
    const history = evidence.previousCrop ? [evidence.previousCrop,...profiles] : profiles;
    for (let i=1; i<history.length; i++) if (history[i-1].botanicalFamily === history[i].botanicalFamily) excludedReasons.push(reason('consecutive_family','Ardışık aynı bitki ailesi, koruyucu tarama kuralını ihlal ediyor.','Consecutive crops in the same botanical family violate the conservative screening rule.',['families','chickpeaFamily','smallGrains'],{family:history[i].botanicalFamily,from:history[i-1].id,to:history[i].id,planYear:evidence.previousCrop ? i : i+1}));
    const ponding = evidence.pondingReported && profiles.some(p => p.botanicalFamily === 'Fabaceae');
    const feasibility = excludedReasons.length ? 'infeasible' : gaps.length ? 'needs_evidence' : 'provisional';
    const tradeoffs = [
      text('Aile değişimi yararlı bir taramadır; ortak hastalıklar ve daha uzun baklagil araları ayrıca incelenmelidir.','Family changes are a useful screen; shared diseases and longer pulse breaks require separate review.'),
      text('Mercimek su puanında nemi sonraki ürüne bırakma tercihinin göstergesidir; nohutun kuraklığa dayanımıyla aynı ölçüt değildir.','The lentil water score represents a preference for leaving moisture for the next crop; it is a different criterion from chickpea drought tolerance.'),
      text('Toprak puanı yalnızca ürün çeşitliliğidir. Azot kazancı veya organik karbon değişimi tahmin edilmez.','The soil score represents crop diversity only. No nitrogen gain or soil-carbon change is predicted.')
    ];
    if (ponding) tradeoffs.unshift(text('Kabul edilmiş gözlem su birikmesi bildiriyor. Hem nohut hem mercimek su basmasına hassastır; yerel drenaj doğrulanmadan ekim uygunluğu onaylanamaz.','An accepted observation reports ponding. Both chickpea and lentil are waterlogging-sensitive; planting suitability cannot be approved without local drainage verification.'));
    if (evidence.uncertainPonding) tradeoffs.unshift(text('Su birikmesi belirsizliği korunuyor; sıfır saatlik bir beyanın aralığı pozitif süreleri de içerebilir. Ne güvenli drenaj ne kesin su basması varsayılır; hem nohut hem mercimek için yerel kontrol gerekir.','Standing-water uncertainty is retained; a zero-hour report can have a range including positive durations. Neither safe drainage nor definite waterlogging is assumed; both chickpea and lentil require local review.'));
    const criteria = annualCriteria(ids,currentCrop,evidence);
    candidates.push({id:`rotation-${ids.join('-')}`,kind:'annual_rotation',sequence:profiles.map(p => p.label.tr),sequenceLabels:profiles.map(p => p.label),cropIds:ids,botanicalFamilies:profiles.map(p => p.botanicalFamily),feasibility,feasibilityLabel:STATUS[feasibility],excludedReasons,criteria,criteriaUnit:'dimensionless_heuristic',tradeoffs,scenarioResults:scenarioResults(ids,definitions,feasibility),evidence:[...sourceRows(['families','chickpeaFamily','smallGrains','chickpea','lentil','pulseStress','pulseBreaks']),{id:'field-inputs',kind:'accepted_local_evidence',values:{previousCrop:evidence.previousCrop?.label.tr || null,soilTexture:evidence.soilTexture,standingWaterHours:evidence.standingWaterHours},uncertainty:{standingWaterHours:evidence.standingWaterRange}},{id:'crop-record',kind:'farmer_crop_record',value:currentCrop.label.tr}],pareto:false,rank:null,utility:null});
  }
  return {...base,kind:'annual',...assignRanking(candidates,weights),missingEvidence:gaps};
}
