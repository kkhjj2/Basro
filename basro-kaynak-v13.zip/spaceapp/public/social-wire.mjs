// BAS Social tel biçimi (social-wire-1): gönderi, yorum ve beğeni aynı tabloda (social_posts) durur.
// Gövdenin ilk satırı "§{json}" üst bilgisidir: {k:'post'|'comment'|'like', n:ad, d:cihaz özeti, re:üst gönderi, crop, h:boy cm}.
// Üst bilgisi olmayan eski gönderiler düz gönderi sayılır. Saf işlevler; sunucu ve testler aynı kodu kullanır.
export const WIRE_VERSION='social-wire-1';
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const clean=(s,n)=>String(s??'').replace(/[\u0000-\u0008\u000b-\u001f\u007f§]/g,'').trim().slice(0,n);
export function encodeBody(meta,text=''){
 const m={v:1,k:['comment','like'].includes(meta.k)?meta.k:'post',n:clean(meta.n,30)||'Basro çiftçisi',d:clean(meta.d,32)};
 if(meta.re&&UUID.test(meta.re))m.re=meta.re.toLowerCase();
 if(m.k==='post'){const crop=clean(meta.crop,40);if(crop)m.crop=crop;const h=Number(meta.h);if(Number.isFinite(h)&&h>0&&h<=1000)m.h=Math.round(h*10)/10;const y=Number(meta.y);if(Number.isFinite(y)&&y>0&&y<=50000)m.y=Math.round(y);}
 return '§'+JSON.stringify(m)+'\n'+clean(text,700);
}
export function decodeBody(body){
 const s=String(body??'');
 if(s[0]==='§'){const i=s.indexOf('\n'),head=s.slice(1,i<0?undefined:i);try{const meta=JSON.parse(head);if(meta&&typeof meta==='object')return {meta,text:i<0?'':s.slice(i+1)};}catch{}}
 return {meta:{k:'post',legacy:true},text:s};
}
/**
 * rows: [{id, body, region_id, media_id, created_at}] (yeniden eskiye). device: isteği yapan cihazın özeti.
 * @param {any[]} rows
 * @param {{device?:string, regionName?:(id:string)=>string|null, region?:string|null}} [opts]
 */
export function assembleFeed(rows,{device='',regionName=()=>null,region=null}={}){
 const posts=[],byId=new Map(),pending=[];
 for(const r of rows){
  const {meta,text}=decodeBody(r.body);
  if(meta.k==='post'){
   const p={id:r.id,body:text,author:meta.n||'Basro çiftçisi',region:r.region_id?regionName(r.region_id)||r.region_id:null,regionId:r.region_id||null,createdAt:r.created_at,mine:meta.legacy?null:!!device&&meta.d===device,photo:!!r.media_id,crop:meta.crop||null,heightCm:meta.h??null,yieldKgDa:meta.y??null,likes:0,liked:false,comments:[],_d:meta.d||null};
   posts.push(p);byId.set(r.id,p);
  }else pending.push({r,meta,text});
 }
 for(const {r,meta,text} of pending){
  const p=byId.get(meta.re);if(!p)continue;
  if(meta.k==='like'){p.likes++;if(device&&meta.d===device)p.liked=true;}
  else p.comments.unshift({id:r.id,body:text,author:meta.n||'Basro çiftçisi',createdAt:r.created_at,mine:!!device&&meta.d===device});
 }
 const growth=growthBoard(posts),mastery=masteryBoard(posts,device);
 const shown=(region?posts.filter(p=>p.regionId===region):posts).map(({_d,regionId,...p})=>p);
 return {posts:shown,growth,mastery};
}
/** Haftalık gelişim: aynı kişi + aynı ürün için en az 1 gün arayla girilmiş son iki boy ölçümünden cm/hafta. */
export function growthBoard(posts){
 const groups=new Map();
 for(const p of posts){if(p.heightCm==null||!p._d||!p.crop)continue;const k=p._d+'|'+p.crop.toLocaleLowerCase('tr');(groups.get(k)||groups.set(k,[]).get(k)).push(p);}
 const out=[];
 for(const list of groups.values()){
  const s=[...list].sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt)),last=s[0],prev=s.find(x=>Date.parse(last.createdAt)-Date.parse(x.createdAt)>=864e5);
  if(!prev){out.push({author:last.author,crop:last.crop,region:last.region,heightCm:last.heightCm,perWeek:null,days:0,at:last.createdAt});continue;}
  const days=(Date.parse(last.createdAt)-Date.parse(prev.createdAt))/864e5;
  out.push({author:last.author,crop:last.crop,region:last.region,heightCm:last.heightCm,perWeek:Math.round((last.heightCm-prev.heightCm)/days*7*10)/10,days:Math.round(days),at:last.createdAt});
 }
 return out.sort((a,b)=>(b.perWeek??-1e9)-(a.perWeek??-1e9));
}
/** JPEG/PNG/WebP imzası; EXIF taşıyan dosyayı reddetmek için hasExif. */
export function imageKind(bytes){
 const b=bytes;if(b.length>3&&b[0]===0xFF&&b[1]===0xD8&&b[2]===0xFF)return 'image/jpeg';
 if(b.length>8&&b[0]===0x89&&b[1]===0x50&&b[2]===0x4E&&b[3]===0x47)return 'image/png';
 if(b.length>12&&b[0]===0x52&&b[1]===0x49&&b[2]===0x46&&b[3]===0x46&&b[8]===0x57&&b[9]===0x45&&b[10]===0x42&&b[11]===0x50)return 'image/webp';
 return null;
}
export function hasExif(bytes){const n=Math.min(bytes.length,65536)-5;for(let i=0;i<n;i++)if(bytes[i]===0x45&&bytes[i+1]===0x78&&bytes[i+2]===0x69&&bytes[i+3]===0x66&&bytes[i+4]===0&&bytes[i+5]===0)return true;return false;}

// ── İlçe/il müdürü paneli için özet (yalnızca toplu sayılar; kişi düzeyinde veri döndürmez) ──
export const SIGNALS={
 don:{label:'Don / kırağı',words:['don','kırağı','dondu','üşüdü']},
 su:{label:'Su ve kuraklık',words:['kurak','susuz','su seviyesi','kuyu','sulama','su yok']},
 yagis:{label:'Yağış / dolu',words:['yağmur','yağış','dolu yağ','dolu vur','sağanak']},
 hastalik:{label:'Hastalık belirtisi',words:['leke','küf','hastalık','sarar','çürü','mildiyö','külleme']},
 zararli:{label:'Zararlı',words:['böcek','zararlı','kurt','yaprak biti','akar','tuta','sinek']},
 hasat:{label:'Hasat',words:['hasat','topladık','kızardı','olgunlaş','söküm']},
};
export const K_PANEL=3;
/**
 * @param {any[]} rows social_posts satırları
 * @param {{now?:number, region?:string|null, days?:number}} [opts]
 */
export function regionSummary(rows,{now=Date.now(),region=null,days=7}={}){
 const since=now-days*864e5,posts=[],byId=new Map();
 for(const r of rows){const {meta,text}=decodeBody(r.body);if(meta.k==='post'&&(!region||r.region_id===region)){const p={id:r.id,text,meta,at:Date.parse(r.created_at),photo:!!r.media_id,region:r.region_id};posts.push(p);byId.set(r.id,p);}}
 let comments=0,likes=0;
 for(const r of rows){const {meta}=decodeBody(r.body);if(meta.k==='post'||!byId.has(meta.re)||Date.parse(r.created_at)<since)continue;meta.k==='like'?likes++:comments++;}
 const week=posts.filter(p=>p.at>=since),farmers=new Set(week.map(p=>p.meta.d).filter(Boolean));
 const signals=Object.entries(SIGNALS).map(([id,s])=>{const hit=week.filter(p=>{const t=p.text.toLocaleLowerCase('tr');return s.words.some(w=>t.includes(w));});return {id,label:s.label,posts:hit.length,farmers:new Set(hit.map(p=>p.meta.d||p.id)).size};}).filter(s=>s.posts).sort((a,b)=>b.posts-a.posts);
 // Ürün bazında haftalık gelişim ortalaması: en az K_PANEL çiftçi varsa gösterilir.
 const growth=growthBoard(posts.map(p=>({_d:p.meta.d,crop:p.meta.crop,heightCm:p.meta.h??null,createdAt:new Date(p.at).toISOString(),author:''}))).filter(g=>g.perWeek!=null);
 const crops=new Map();for(const g of growth){const k=g.crop;(crops.get(k)||crops.set(k,[]).get(k)).push(g.perWeek);}
 const cropGrowth=[...crops.entries()].map(([crop,v])=>v.length>=K_PANEL?{crop,farmers:v.length,avgPerWeek:Math.round(v.reduce((a,b)=>a+b,0)/v.length*10)/10,min:Math.min(...v),max:Math.max(...v)}:{crop,farmers:v.length,avgPerWeek:null}).sort((a,b)=>b.farmers-a.farmers);
 const cropCounts=new Map();for(const p of week)if(p.meta.crop)cropCounts.set(p.meta.crop,(cropCounts.get(p.meta.crop)||0)+1);
 const daily=Array.from({length:days},(_,i)=>{const a=now-(days-i)*864e5,b=a+864e5;return {day:new Date(b-1).toISOString().slice(0,10),posts:posts.filter(p=>p.at>=a&&p.at<b).length};});
 return {days,activeFarmers:farmers.size,posts:week.length,photos:week.filter(p=>p.photo).length,measurements:week.filter(p=>p.meta.h!=null).length,comments,likes,signals,cropGrowth,crops:[...cropCounts.entries()].map(([crop,posts])=>({crop,posts})).sort((a,b)=>b.posts-a.posts),daily};
}

// ── Ürün ustalığı: ürün bazında sıralama ──
export const MASTERY_TITLES=['Usta','Kalfa','Çırak'];
/**
 * Her ürün için çiftçilerin en son bildirdiği verime (kg/da) göre sıralama; verim bildiren yoksa haftalık gelişime göre.
 * Değerler çiftçinin kendi beyanıdır. Dönen satırlarda cihaz bilgisi yoktur; yalnızca "mine" işareti vardır.
 * @param {any[]} posts assembleFeed içindeki gönderiler (_d alanıyla)
 * @param {string} [device]
 */
export function masteryBoard(posts,device=''){
 const crops=new Map();
 for(const p of posts){if(!p.crop||!p._d)continue;const k=p.crop.toLocaleLowerCase('tr');(crops.get(k)||crops.set(k,{crop:p.crop,posts:[]}).get(k)).posts.push(p);}
 const out=[];
 for(const {crop,posts:list} of crops.values()){
  const latest=new Map();
  for(const p of [...list].sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt)))if(p.yieldKgDa!=null&&!latest.has(p._d))latest.set(p._d,p);
  let metric='yield',rows=[...latest.values()].map(p=>({author:p.author,region:p.region,value:p.yieldKgDa,mine:!!device&&p._d===device,at:p.createdAt}));
  if(!rows.length){metric='growth';rows=growthBoard(list).filter(g=>g.perWeek!=null).map(g=>{const src=list.find(p=>p.author===g.author&&p.createdAt===g.at);return {author:g.author,region:g.region,value:g.perWeek,mine:!!device&&src?._d===device,at:g.at};});}
  if(!rows.length)continue;
  rows.sort((a,b)=>b.value-a.value||Date.parse(a.at)-Date.parse(b.at));
  out.push({crop,metric,rows:rows.slice(0,10).map((r,i)=>({rank:i+1,title:MASTERY_TITLES[i]||null,...r}))});
 }
 return out.sort((a,b)=>b.rows.length-a.rows.length||a.crop.localeCompare(b.crop,'tr'));
}
