// Basro dil katmanı (i18n-1): arayüz Türkçe yazılmıştır; İngilizce seçiliyken görünen metinler sözlükle çevrilir.
// Varsayılan dil İngilizce'dir; seçim bu cihazda saklanır. Kullanıcının yazdığı içerik (gönderi, not, ad) çevrilmez.
import {EXACT,WORDS,makePatterns} from './i18n-en.mjs';
let PATTERNS=[];
const KEY='basro-lang';
export function getLang(){try{const v=localStorage.getItem(KEY);return v==='tr'?'tr':'en';}catch{return 'en';}}
export function setLang(v){try{localStorage.setItem(KEY,v==='tr'?'tr':'en');}catch{}}
const norm=s=>s.replace(/\s+/g,' ').trim();
const WORD_RE=WORDS&&Object.keys(WORDS).length?new RegExp('(?<![\\p{L}\\d])('+Object.keys(WORDS).sort((a,b)=>b.length-a.length).map(w=>w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')(?![\\p{L}\\d])','gu'):null;
PATTERNS=makePatterns(t=>translate(t));
function one(core){
 if(Object.hasOwn(EXACT,core))return EXACT[core];
 for(const [re,rep] of PATTERNS){if(re.test(core))return core.replace(re,rep);}
 return null;
}
/** Bir metni İngilizceye çevirir; karşılığı yoksa null döner. */
export function translate(text){
 const core=norm(text);if(!core||!/\p{L}/u.test(core))return null;
 let out=one(core);
 if(out===null&&core.includes(' → ')){const parts=core.split(' → ');const tr=parts.map(p=>one(p)??p);if(tr.join()!==parts.join())out=tr.join(' → ');}
 if(out===null&&/[.!?]\s+\S/.test(core)){const sents=core.split(/(?<=[.!?])\s+/);if(sents.length>1){const tr=sents.map(x=>one(x));if(tr.every(x=>x!==null))out=tr.join(' ');}}
 if(out===null&&core.includes(' · ')){const parts=core.split(' · ');let hit=false;const tr=parts.map(p=>{const r=one(p)??words(p);if(r!==null&&r!==p)hit=true;return r??p;});if(hit)out=tr.join(' · ');}
 if(out===null)out=words(core);
 if(out===null||out===core)return null;
 return out;
}
function words(s){if(!WORD_RE)return null;const r=s.replace(WORD_RE,m=>WORDS[m]);return r===s?null:r;}
const SKIP='script,style,textarea,[data-i18n-skip],[contenteditable=true],.leaflet-control-attribution';
const ATTRS=['placeholder','aria-label','title','alt'];
const miss=new Set();
const written=new WeakMap();
function textNode(n){
 const v=n.nodeValue;if(!v||!v.trim()||written.get(n)===v)return;const p=n.parentElement;if(!p||p.closest(SKIP))return;
 const core0=norm(v);const t=core0==='Ara'&&p.closest('svg')?'Dec':translate(v);
 if(t===null){const c=norm(v);if(/[çğıöşüÇĞİÖŞÜ]/.test(c)||/\p{L}{3}/u.test(c))miss.add(c);return;}
 const lead=v.match(/^\s*/)[0],tail=v.match(/\s*$/)[0],nv=lead+t+tail;n.nodeValue=nv;written.set(n,nv);
}
function element(el){
 if(el.closest?.(SKIP))return;
 const wa=written.get(el)||{};
 for(const a of ATTRS){const v=el.getAttribute?.(a);if(v&&wa[a]!==v){const t=translate(v);if(t!==null){el.setAttribute(a,t);wa[a]=t;written.set(el,wa);}else if(/[çğıöşüÇĞİÖŞÜ]/.test(v))miss.add('@'+a+' '+norm(v));}}
 if(el.tagName==='INPUT'&&/^(button|submit)$/.test(el.type)&&el.value){const t=translate(el.value);if(t!==null)el.value=t;}
}
function walk(root){
 if(root.nodeType===3){textNode(root);return;}
 if(root.nodeType!==1)return;if(root.matches?.(SKIP))return;
 element(root);root.querySelectorAll('*').forEach(element);
 const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n;const list=[];while((n=w.nextNode()))list.push(n);list.forEach(textNode);
}
function toggle(lang){
 if(document.getElementById('lang-switch'))return;
 const b=document.createElement('div');b.id='lang-switch';b.setAttribute('data-i18n-skip','');b.setAttribute('role','group');b.setAttribute('aria-label','Language / Dil');
 b.innerHTML=['en','tr'].map(l=>`<button type="button" data-lang="${l}" aria-pressed="${l===lang}">${l.toUpperCase()}</button>`).join('');
 b.addEventListener('click',e=>{const l=e.target.closest('[data-lang]')?.dataset.lang;if(!l||l===lang)return;setLang(l);location.reload();});
 document.body.append(b);
}
export function startI18n(){
 const lang=getLang();window.BASRO_LANG=lang;document.documentElement.lang=lang;
 const ready=()=>{toggle(lang);if(lang!=='en')return;
  const t=translate(document.title);if(t)document.title=t;walk(document.body);
  new MutationObserver(ms=>{for(const m of ms){if(m.type==='characterData')textNode(m.target);else if(m.type==='attributes')element(m.target);else m.addedNodes.forEach(walk);}})
   .observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:ATTRS});
  window.__i18nMiss=miss;};
 if(document.body)ready();else document.addEventListener('DOMContentLoaded',ready);
}
if(typeof document!=='undefined')startI18n();
