/* Statistical planning forecasts; NASA supplies the history, not the forecast. */
const finite=v=>typeof v==='number'&&Number.isFinite(v)&&v>-900;
const mean=a=>a.reduce((s,x)=>s+x,0)/a.length;
export const METHOD_VERSION='agro-annual-1.0';
export function annualHistory(raw){
  if(raw?.parameters?.T2M?.units!=='C'||raw?.parameters?.PRECTOTCORR?.units!=='mm/day')throw Error('NASA birimleri doğrulanamadı.');
  const p=raw.properties?.parameter||{},years=[...new Set(Object.keys(p.T2M||{}).filter(k=>/^\d{6}$/.test(k)).map(k=>Number(k.slice(0,4))))].sort((a,b)=>a-b),out=[];
  for(const year of years){let temp=0,rain=0,dayCount=0,complete=true;for(let m=1;m<=12;m++){const key=year+String(m).padStart(2,'0'),t=p.T2M?.[key],r=p.PRECTOTCORR?.[key],days=new Date(Date.UTC(year,m,0)).getUTCDate();if(!finite(t)||!finite(r)||r<0){complete=false;break;}temp+=t*days;rain+=r*days;dayCount+=days;}if(complete)out.push({year,temperature:finite(p.T2M[year+'13'])?p.T2M[year+'13']:temp/dayCount,rain});}
  // Use a contiguous tail: a missing year must not become a shorter time step.
  let start=out.length-1;while(start>0&&out[start].year-out[start-1].year===1)start--;
  return out.slice(Math.max(0,start));
}
function predict(data,key,target,model){
  const rows=data.slice(model==='trend20'?-20:-15),avg=mean(rows.map(r=>r[key]));
  if(model!=='trend20')return avg;
  const xbar=mean(rows.map(r=>r.year)),sxx=rows.reduce((s,r)=>s+(r.year-xbar)**2,0),sxy=rows.reduce((s,r)=>s+(r.year-xbar)*(r[key]-avg),0);
  return avg+(sxx?sxy/sxx:0)*(target-xbar);
}
function selectModel(data,key,horizon){
  if(key==='rain')return 'mean15';
  const errors={mean15:[],trend20:[]};
  for(let n=Math.max(12,data.length-horizon-6);n+horizon<=data.length;n++){
    const training=data.slice(0,n),actual=data[n+horizon-1];
    for(const model of Object.keys(errors))errors[model].push(Math.abs(actual[key]-predict(training,key,actual.year,model)));
  }
  if(errors.mean15.length<4)return 'mean15';
  return mean(errors.trend20)<mean(errors.mean15)*.95?'trend20':'mean15';
}
export function rollingErrors(data,key,horizon){
  const errors=[],baseline=[];
  for(let n=20;n+horizon<=data.length;n++){
    const training=data.slice(0,n),actual=data[n+horizon-1],model=selectModel(training,key,horizon);
    errors.push(actual[key]-predict(training,key,actual.year,model));baseline.push(actual[key]-predict(training,key,actual.year,'mean15'));
  }
  return {errors,baseline};
}
function quantile(a,p){const x=[...a].sort((a,b)=>a-b),at=(x.length-1)*p,i=Math.floor(at);return x[i]+(x[Math.min(x.length-1,i+1)]-x[i])*(at-i);}
function metric(data,key,target){
  const horizon=target-data.at(-1).year,model=selectModel(data,key,horizon),tested=rollingErrors(data,key,horizon);
  if(tested.errors.length<8)throw Error('Bu ufukta en az 8 geçmiş sınama gerekir. Daha uzun NASA serisi gerekli.');
  let point=predict(data,key,target,model),low=point+Math.min(0,quantile(tested.errors,.1)),high=point+Math.max(0,quantile(tested.errors,.9));
  if(key==='rain'){point=Math.max(0,point);low=Math.max(0,low);high=Math.max(0,high);}
  const mae=mean(tested.errors.map(Math.abs)),baselineMae=mean(tested.baseline.map(Math.abs));
  return {point,low,high,mae,baselineMae,skill:baselineMae>0?1-mae/baselineMae:null,tests:tested.errors.length,model,method:model==='trend20'?'Son 20 yıl eğilimi':'Son 15 yıl iklim ortalaması'};
}
export function buildForecast(raw,targets=[2027,2028]){
  const history=annualHistory(raw);if(history.length<28)throw Error('Öngörü için en az 28 ardışık, tam NASA yılı gerekiyor.');
  if(targets.some(y=>!Number.isInteger(y)||y<=history.at(-1).year||y-history.at(-1).year>4))throw Error('Öngörü ufku son tam kayıttan en fazla 4 yıl olabilir.');
  return {methodVersion:METHOD_VERSION,history,firstYear:history[0].year,lastYear:history.at(-1).year,years:history.length,forecasts:targets.map(year=>({year,horizon:year-history.at(-1).year,temperature:metric(history,'temperature',year),rain:metric(history,'rain',year)})),intervalLabel:'Geçmiş sınama hatalarına dayalı aralık; geleceğe ait kapsama garantisi değildir.',kind:'Basro istatistiksel planlama öngörüsü; NASA gelecek tahmini değildir.'};
}
