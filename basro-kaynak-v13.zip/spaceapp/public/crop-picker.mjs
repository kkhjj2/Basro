import {CROP_GROUPS,findCrop,normalizeCropName,sameCrop,cropIcon,searchCrops} from './crop-catalog.mjs';
const states=new Map(),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function resetCropPicker(id){states.delete(id);}
export function cropPickerHTML({id,selected=[],label='Yetiştirdiğin ürünü bul'}){
 if(!/^[a-z0-9-]+$/.test(id))throw Error('Invalid crop picker ID');
 const state=states.get(id)||{query:'',group:'all',limit:12};states.set(id,state);
 return `<section class="crop-picker" id="${id}"><div class="crop-picker-selected" aria-label="Seçili ürünler"></div><div class="crop-picker-fields"><label><span class="farm-label">${esc(label)}</span><input class="farm-input crop-search" type="search" maxlength="60" autocomplete="off" placeholder="Kabak, karpuz, çilek…" value="${esc(state.query)}" aria-controls="${id}-results"></label><label><span class="farm-label">Ürün grubu</span><select class="farm-input crop-group"><option value="all">Tüm ürünler</option>${CROP_GROUPS.map(g=>`<option value="${g.id}" ${state.group===g.id?'selected':''}>${esc(g.label)}</option>`).join('')}</select></label></div><div class="crop-picker-results" id="${id}-results" role="group" aria-label="Ürün seçenekleri"></div><p class="crop-picker-status" role="status" aria-live="polite"></p><div class="crop-picker-actions"><button type="button" class="crop-more">Daha fazla ürün göster ↓</button><button type="button" class="crop-own">+ Ürün adını kendim yazacağım</button></div><div class="crop-custom" hidden></div><div class="crop-undecided"></div></section>`;
}
export function bindCropPicker({id,selected=[],exclude=[],multiple=false,allowUndecided=false,onSelect}){
 const root=document.getElementById(id);if(!root)return;const query=root.querySelector('.crop-search'),group=root.querySelector('.crop-group'),results=root.querySelector('.crop-picker-results'),status=root.querySelector('.crop-picker-status'),more=root.querySelector('.crop-more'),custom=root.querySelector('.crop-custom'),state=states.get(id);
 let current=[...selected],customOpen=false;
 const isExcluded=name=>exclude.some(c=>sameCrop(c,name)),isSelected=name=>current.some(c=>sameCrop(c,name));
 function choose(raw){const name=normalizeCropName(raw);if(!name||isExcluded(name))return;
  if(multiple){current=isSelected(name)?current.filter(c=>!sameCrop(c,name)):[...current,name];}else current=[name];
  render();onSelect(name);
 }
 function customPanel(){
  const raw=state.query.trim(),name=normalizeCropName(raw),known=findCrop(raw),otherGroup=known&&state.group!=='all'&&known.group!==state.group&&!isExcluded(known.name),show=customOpen||(!known&&raw.length>=2)||otherGroup;
  custom.hidden=!show;if(!show){custom.innerHTML='';return;}
  const valid=name&&!known&&!isExcluded(name)&&!isSelected(name)&&!['Diğer','Henüz seçmedim'].includes(name);
  custom.innerHTML=`<p>${isExcluded(name)?'Bu ürün arazine zaten ekli.':isSelected(name)?'Bu ürün seçili.':otherGroup?`Bu ürün “${esc(known.groupLabel)}” grubunda.`:known?'Bu ürün yukarıdaki listede var.':valid?'Listede yoksa bu adı kendi ürünün olarak kaydedebilirsin.':'Ürünün veya çeşidinin adını yukarıdaki arama alanına yaz.'}</p>${otherGroup?'<button type="button" class="crop-show-all">Tüm ürünlerde göster</button>':''}${valid?`<button type="button" class="crop-create">🌱 “${esc(name)}” adını ekle</button><small>Bu adı sen ekliyorsun; ürüne özel doğrulanmış rehber bulunmayabilir.</small>`:''}`;
  custom.querySelector('.crop-show-all')?.addEventListener('click',()=>{state.group='all';group.value='all';render();});
  custom.querySelector('.crop-create')?.addEventListener('click',()=>choose(name));
 }
 function render(){
  const list=searchCrops(state.query,state.group).filter(c=>!isExcluded(c.name)),visible=list.slice(0,state.limit);
  root.querySelector('.crop-picker-selected').innerHTML=current.filter(c=>c!=='Henüz seçmedim').map(c=>`<button type="button" data-crop-picked="${esc(c)}" aria-label="${esc(c)} ${multiple?'seçimini kaldır':'seçili'}">${cropIcon(c)} ${esc(c)}${multiple?'<span aria-hidden="true">×</span>':''}</button>`).join('');
  root.querySelectorAll('[data-crop-picked]').forEach(b=>b.addEventListener('click',()=>{if(multiple)choose(b.dataset.cropPicked);}));
  results.innerHTML=visible.map(c=>`<button type="button" class="crop-result" data-crop-choice="${esc(c.name)}" aria-pressed="${isSelected(c.name)}"><span class="crop-result-icon" aria-hidden="true">${c.icon}</span><span>${esc(c.name)}</span>${isSelected(c.name)?'<i aria-hidden="true">✓</i>':''}</button>`).join('');
  root.querySelectorAll('[data-crop-choice]').forEach(b=>b.addEventListener('click',()=>choose(b.dataset.cropChoice)));
  status.textContent=!list.length?'Eşleşen ürün yok. Adını kendin ekleyebilirsin.':state.query?`${list.length} ürün bulundu.`:state.group==='all'?'İsmiyle ara veya ürün grubunu seç.':`${list.length} ürün. İsmiyle de arayabilirsin.`;
  more.hidden=list.length<=state.limit;
  const undecided=root.querySelector('.crop-undecided');undecided.innerHTML=allowUndecided?`<button type="button" aria-pressed="${isSelected('Henüz seçmedim')}">Henüz ne ekeceğime karar vermedim</button>`:'';undecided.querySelector('button')?.addEventListener('click',()=>choose('Henüz seçmedim'));
  customPanel();
 }
 query.addEventListener('input',()=>{state.query=query.value;state.limit=12;render();});
 query.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const first=searchCrops(state.query,state.group).find(c=>!isExcluded(c.name));if(first)choose(first.name);else custom.querySelector('.crop-create')?.focus();}else if(e.key==='ArrowDown'){e.preventDefault();results.querySelector('button')?.focus();}});
 group.addEventListener('change',()=>{state.group=group.value;state.limit=12;render();});
 more.addEventListener('click',()=>{state.limit+=24;render();});
 root.querySelector('.crop-own').addEventListener('click',()=>{customOpen=true;customPanel();query.focus();});render();
}
