import {acceptedEvidence} from './observation-core.mjs';

export const DISCOVERY_METHOD = 'agro-discovery-heuristic-1.0';
const text = (tr, en) => ({tr, en});
const unknown = {value: 'unknown', label: text('Bilmiyorum / atla', "I don't know / skip")};
const templates = {
  standing_water_duration: {
    id: 'standing-water-after-rain', type: 'standing_water_duration',
    question: text('Kuvvetli yağmurdan sonra tarlada biriken su yaklaşık ne kadar süre kalır?', 'After heavy rain, approximately how long does standing water remain in your field?'),
    options: [{value: 0, label: text('Su birikmesi gözlemlemedim', 'I have not noticed standing water')}, {value: 6, label: text('Birkaç saat (yaklaşık 6)', 'A few hours (about 6)')}, {value: 24, label: text('Yaklaşık bir gün', 'About one day')}, {value: 48, label: text('Yaklaşık iki gün', 'About two days')}, unknown],
    method: 'visual_after_rain', sourceType: 'farmer_report', unit: 'hours', effort: text('Düşük · yalnız geçmiş gözlemini hatırla; su basmış tarlaya girme.', 'Low · recall an earlier observation only; do not enter a flooded field.'),
    why: text('Su birikmesi belirsizliği, baklagil içeren rotasyonların yerel kontrol gereksinimini değiştirebilir. Bu yaklaşık beyan drenaj ölçümü değildir.', 'Uncertain ponding can change which pulse rotations need local checking. This approximate report is not a drainage measurement.'),
    factors: {decisionSensitivity: 1, uncertainty: 1, relevance: 1, reliability: .55, effort: .1, burden: .1}
  },
  previous_crop: {
    id: 'previous-crop', type: 'previous_crop', question: text('Bu karşılaştırmanın ilk ekiminden hemen önceki son ürün hangisi?', 'Which crop immediately precedes the first planting in this comparison?'),
    options: ['Buğday', 'Arpa', 'Nohut', 'Mercimek', 'Fiğ'].map((value, i) => ({value, label: text(value, ['Wheat', 'Barley', 'Chickpea', 'Lentil', 'Vetch'][i])})).concat(unknown),
    method: 'farmer_recall', sourceType: 'farmer_report', unit: 'crop', effort: text('Düşük · önceki sezon kaydına bak veya hatırla.', 'Low · recall or check the previous season’s record.'),
    why: text('İlk planlanan ekimden hemen önceki ürün, sıranın başında aynı bitki ailesinin tekrarı ve rotasyon çeşitliliği karşılaştırmasını etkiler.', 'The crop immediately before the first planned planting affects the comparison of repeated crop families at the start of the sequence and rotation diversity.'),
    factors: {decisionSensitivity: .85, uncertainty: 1, relevance: .95, reliability: .8, effort: .1, burden: .1}
  },
  soil_texture: {
    id: 'soil-texture-feel', type: 'soil_texture', question: text('Toprağın elle tahmin edilen bünyesi hangisine daha yakın?', 'Which approximate soil texture best matches your texture-by-feel observation?'),
    options: [{value: 'sandy', label: text('Kumlu', 'Sandy')}, {value: 'loam', label: text('Tınlı', 'Loam')}, {value: 'clay', label: text('Killi', 'Clay')}, unknown],
    method: 'feel', sourceType: 'farmer_report', unit: 'qualitative', effort: text('Orta · güvenli yerde temiz bir örnekle nitel tahmin; laboratuvar sonucu değildir.', 'Medium · a qualitative estimate from a clean sample at a safe location; not a laboratory result.'),
    why: text('Bünye bilgisi toprakla ilgili belirsizliği görünür kılar; bu sürüm kesin su tutma kapasitesi hesaplamaz.', 'Texture makes soil uncertainty visible; this version does not calculate precise water-holding capacity.'),
    factors: {decisionSensitivity: .55, uncertainty: 1, relevance: .6, reliability: .5, effort: .35, burden: .25}
  }
};

/** Select one safe, bilingual question, or null. Scores are heuristic, not money or formal VOI. */
export function selectDiscoveryQuestion({farm, observations = [], candidates = [], now = new Date()} = {}) {
  if (!farm?.id) return null;
  const userId = farm.userId || 'device-owner', evidence = acceptedEvidence(observations, {fieldId: farm.id, userId});
  const answered = new Set(observations.filter(row => row?.fieldId === farm.id && row.userId === userId && row.validationStatus !== 'rejected').map(row => row.observationType));
  // Unknown/skipped answers and pending review suppress repetition too. No automatic
  // re-prompt: the farmer can explicitly open a new observation when ready.
  const present = {standing_water_duration: evidence.standingWaterHours !== undefined, previous_crop: !!evidence.previousCrop, soil_texture: !!evidence.soilTexture};
  const allowed = new Set(Object.keys(templates));
  // Candidate names constrain supported templates only; arbitrary LLM output never
  // supplies a procedure or changes numerical fields.
  const supportedCandidates = candidates.map(row => typeof row === 'string' ? row : row.type || row.observationType || row.id).filter(type => allowed.has(type));
  const requested = supportedCandidates.length ? [...new Set(supportedCandidates)] : [...allowed];
  const questions = requested.filter(type => !answered.has(type) && !present[type]).map(type => {
    const template = templates[type], factors = {...template.factors};
    if (type === 'standing_water_duration' && farm.drainage && farm.drainage !== 'unknown') factors.uncertainty = .2;
    const heuristicPriority = Math.round(100 * (factors.decisionSensitivity * .35 + factors.uncertainty * .2 + factors.relevance * .25 + factors.reliability * .2 - factors.effort * .1 - factors.burden * .1));
    return {...JSON.parse(JSON.stringify(template)), fieldId: farm.id, userId, heuristicPriority, heuristicFactors: factors, selectionMethod: DISCOVERY_METHOD, selectedAt: new Date(now).toISOString(), scoreMeaning: text('Bilgi değeri için sezgisel öncelik; ekonomik değer veya kalibre edilmiş olasılık değildir.', 'Heuristic information priority; not economic value or a calibrated probability.'), cooldown: 'until_user_reopens'};
  });
  return questions.sort((a, b) => b.heuristicPriority - a.heuristicPriority || a.id.localeCompare(b.id))[0] || null;
}
