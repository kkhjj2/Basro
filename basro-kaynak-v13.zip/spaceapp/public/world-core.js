(function(root){
  'use strict';
  const finite=v=>typeof v==='number'&&Number.isFinite(v)&&v>-900;
  function gridIndex(lat,lon){if(!Number.isFinite(lat)||!Number.isFinite(lon)||lat< -90||lat>90||lon< -180||lon>180)return -1;return Math.min(359,Math.max(0,Math.floor((90-lat)*2)))*720+Math.min(719,Math.max(0,Math.floor((lon+180)*2)));}
  function days(year,month){return new Date(Date.UTC(year,month,0)).getUTCDate();}
  function powerYear(raw,year){
    const p=raw?.properties?.parameter||{},units=raw?.parameters||{};
    if(units.PRECTOTCORR?.units!=='mm/day'||units.T2M?.units!=='C')throw new Error('NASA yanıtındaki birimler beklenen biçimde değil.');
    const result={year,months:[],temperature:null,precipitation:null,humidity:null,complete:false};
    for(let m=1;m<=12;m++){
      const key=String(year)+String(m).padStart(2,'0'),t=p.T2M?.[key],rate=p.PRECTOTCORR?.[key],low=p.T2M_MIN?.[key],high=p.T2M_MAX?.[key],rh=p.RH2M?.[key];
      result.months.push({month:m,days:days(year,m),temperature:finite(t)?t:null,rainRate:finite(rate)&&rate>=0?rate:null,precipitation:finite(rate)&&rate>=0?rate*days(year,m):null,low:finite(low)?low:null,high:finite(high)?high:null,humidity:finite(rh)&&rh>=0&&rh<=100?rh:null});
    }
    const ts=result.months.filter(v=>v.temperature!==null),ps=result.months.filter(v=>v.precipitation!==null),hs=result.months.filter(v=>v.humidity!==null);
    result.validTemperatureMonths=ts.length;result.validPrecipitationMonths=ps.length;
    if(ts.length===12){const ann=p.T2M?.[String(year)+'13'];result.temperature=finite(ann)?ann:ts.reduce((n,v)=>n+v.temperature*v.days,0)/ts.reduce((n,v)=>n+v.days,0);}
    if(ps.length===12)result.precipitation=ps.reduce((n,v)=>n+v.precipitation,0);
    if(hs.length===12){const ann=p.RH2M?.[String(year)+'13'];result.humidity=finite(ann)?ann:hs.reduce((n,v)=>n+v.humidity*v.days,0)/hs.reduce((n,v)=>n+v.days,0);}
    result.complete=ts.length===12&&ps.length===12;
    return result;
  }
  function matches(values,filters){
    if(!values.climate)return false;
    if(filters.groups?.length&&!filters.groups.includes(values.group))return false;
    if(filters.classId&&values.climate!==filters.classId)return false;
    for(const [key,min,max] of [['temperature',filters.tempMin,filters.tempMax],['rain',filters.rainMin,filters.rainMax]]){
      if((min!==null&&min!==undefined)||(max!==null&&max!==undefined)){
        const value=values[key];if(value===null||!Number.isFinite(value))return false;
        if(min!==null&&min!==undefined&&value<min)return false;if(max!==null&&max!==undefined&&value>max)return false;
      }
    }
    return true;
  }
  const api={finite,gridIndex,days,powerYear,matches};
  if(typeof module==='object'&&module.exports)module.exports=api;else root.AgroClimateCore=api;
})(typeof window==='object'?window:globalThis);
