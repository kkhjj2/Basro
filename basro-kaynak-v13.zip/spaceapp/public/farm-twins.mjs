// Tarla ikizleri (twins-1.0): rıza → anonim profil → benzerlik → en az 3 eşleşme varsa karşılaştırma.
// Bu sürümde eşleşmeler ÖRNEK tarlalardır (demo_static) ve hiçbir veri cihazdan çıkmaz.
import {STAGE_KC,SOILS} from './field-engine.mjs';
import {regionOf} from './bas-social.mjs';
export const TWINS_VERSION='twins-1.0';
export const K_MIN=3;
export const STAGES=Object.keys(STAGE_KC);
const SOIL_ORDER=Object.keys(SOILS);
// Bölgeden kaba iklim kuşağı (Köppen ana sınıfı yaklaşımı; ölçüm değildir).
const CLIMATE={'Akdeniz':'C','Ege':'C','Marmara':'C','Karadeniz':'C','İç Anadolu':'B','Güneydoğu Anadolu':'B','Doğu Anadolu':'D'};
const CLIMATE_LABEL={C:'ılıman kuşak',B:'yarı kurak kuşak',D:'karasal kuşak'};
export const WEIGHTS={stage:.35,soil:.25,water:.25,distance:.15};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

/** Anonim profil: ad, tam konum, fotoğraf içermez. Konum yalnızca bölge düzeyindedir. */
export function twinProfile(farm,state={}){
 const region=regionOf(farm.city);
 return {crop:farm.crop,region,climate:CLIMATE[region]||null,stageIdx:Math.max(0,STAGES.indexOf(state.stage||farm.stage)),soil:state.soil?.value||null,water:farm.water||null};
}
/** Sert filtreler + ağırlıklı uzaklık. Eşleşmezse null. */
export function similarity(me,other){
 if(me.crop!==other.crop||!me.climate||me.climate!==other.climate)return null;
 const ds=Math.abs(me.stageIdx-other.stageIdx);if(ds>1)return null;
 const soil=me.soil&&other.soil?Math.abs(SOIL_ORDER.indexOf(me.soil)-SOIL_ORDER.indexOf(other.soil))/(SOIL_ORDER.length-1):.5;
 const water=me.water&&other.water?(me.water===other.water?0:1):.5;
 const distance=other.band==='near'?0:other.band==='region'?.5:1;
 const d=WEIGHTS.stage*ds+WEIGHTS.soil*soil+WEIGHTS.water*water+WEIGHTS.distance*distance;
 const why=['Aynı ürün','Aynı '+(CLIMATE_LABEL[me.climate]||'iklim kuşağı'),ds?(other.stageIdx>me.stageIdx?'Bir dönem ileride':'Bir dönem geride'):'Aynı dönem'];
 if(soil===0)why.push('Aynı toprak');if(water===0)why.push('Aynı su imkânı');if(distance===0)why.push('Yakın çevre');
 return {score:Math.round((1-d)*100),why};
}
/** En iyi 5 eşleşme; k-anonimlik: 3'ten azsa hiçbiri gösterilmez. */
export function matchTwins(me,pool,k=K_MIN){
 const all=pool.map(t=>({twin:t,sim:similarity(me,t)})).filter(x=>x.sim).sort((a,b)=>b.sim.score-a.sim.score||a.twin.id.localeCompare(b.twin.id)).slice(0,5);
 return all.length>=k?{ok:true,matches:all}:{ok:false,matches:[],found:all.length};
}
const DID={
 1:'Dikimden sonraki ilk hafta toprağı her sabah eliyle yokladı.',
 2:'Sulamayı sabah erkene aldı; yaprak altlarına haftada bir baktı.',
 3:'Çiçeklenmede sulama aralığını kısalttı; don uyarısında örtü kullandı.',
 4:'Meyve tutumundan sonra toprağı malçla kapattı; su kaybının azaldığını yazdı.',
 5:'Hasadı serin saatlere böldü.',
 6:'Hasattan sonra artıkları toprağa karıştırdı; sıradaki ürün için baklagil düşündü.'};
/** ÖRNEK ikizler (demo_static). Gerçek çiftçi verisi değildir; arayüzde açıkça işaretlenir. */
export function demoTwins(me){
 const s=me.stageIdx,cl=me.climate,soils=SOIL_ORDER,si=Math.max(0,soils.indexOf(me.soil||'killi_tin')),clamp=i=>Math.min(STAGES.length-1,Math.max(0,i));
 const mk=(n,o)=>({id:'demo-'+n,label:'Benzer tarla '+'ABCDEFG'[n-1],source:'demo_static',crop:me.crop,climate:cl,place:(me.region||'Aynı bölge')+' · konum yaklaşık 10 km yuvarlanmış',...o,did:Array.from({length:o.stageIdx},(_,i)=>i+1).filter(i=>DID[i]).slice(-2).map(i=>({stage:STAGES[i],text:DID[i]}))});
 return [
  mk(1,{stageIdx:clamp(s+1),soil:soils[si],water:me.water||'var',band:'near'}),
  mk(2,{stageIdx:s,soil:soils[si],water:me.water||'var',band:'region'}),
  mk(3,{stageIdx:clamp(s+1),soil:soils[Math.min(soils.length-1,si+1)],water:'var',band:'region'}),
  mk(4,{stageIdx:s,soil:soils[Math.max(0,si-1)],water:'kisitli',band:'far'}),
  mk(5,{stageIdx:clamp(s-1),soil:soils[si],water:'var',band:'region'}),
  mk(6,{stageIdx:clamp(s+3),soil:soils[si],water:'var',band:'near'}),            // dönem farkı büyük → elenir
  mk(7,{stageIdx:s,soil:soils[si],water:'var',band:'far',climate:cl==='C'?'D':'C'}) // farklı iklim → elenir
 ];
}
const KEY='agrobas-twins-v1';
const readAll=st=>{try{return JSON.parse(st.getItem(KEY)||'{}')||{};}catch{return {};}};
export const hasConsent=(st,farmId)=>!!readAll(st).consent?.[farmId];
export function setConsent(st,farmId,on){const a=readAll(st);a.consent={...(a.consent||{}),[farmId]:!!on};if(!on)delete a.consent[farmId];try{st.setItem(KEY,JSON.stringify(a));}catch{}}

const track=(idx,me)=>`<div class="tw-track" aria-hidden="true">${STAGES.slice(1).map((_,i)=>`<i class="${i+1<idx?'past':i+1===idx?'now':''}${me?' me':''}"></i>`).join('')}</div>`;
export function twinsHtml({consent,me,result}){
 const head=`<header class="fm-head"><div><span class="farm-eyebrow">TARLA İKİZLERİ</span><h2>Sana benzeyen tarlalar ne yaptı?</h2></div><span class="fm-soon tw-demo">Örnek veri · demo_static</span></header>`;
 const toggle=`<label class="tw-consent"><input type="checkbox" id="tw-consent"${consent?' checked':''}> <span>Tarlamın anonim gelişim verisini benzer çiftçilerle paylaş</span></label>`;
 if(!consent)return `<section class="farm-card tw" id="farm-twins">${head}<p>Aynı ürünü, benzer iklimde ve benzer dönemde yetiştiren tarlalarla kendi tarlanı yan yana görürsün. Varsayılan olarak kapalıdır; istediğin an geri alabilirsin.</p><ul class="tw-shared"><li><b>Paylaşılır:</b> ürün, gelişme dönemi, toprak sınıfı, su imkânı, bölge.</li><li><b>Paylaşılmaz:</b> adın, tarlanın tam yeri, fotoğrafların, notların.</li></ul>${toggle}<p class="fw-small">Bu sürümde eşleşmeler örnek tarlalardır ve verin cihazından çıkmaz. ${esc(TWINS_VERSION)}</p></section>`;
 if(!result.ok)return `<section class="farm-card tw" id="farm-twins">${head}<p>Şu an en az ${K_MIN} benzer tarla yok${result.found?` (${result.found} bulundu)`:''}. Gizlilik için bu sayının altında karşılaştırma gösterilmez.</p>${toggle}</section>`;
 const rows=result.matches.slice(0,4),ahead=result.matches.filter(m=>m.twin.stageIdx>=me.stageIdx&&m.twin.did.length);
 return `<section class="farm-card tw" id="farm-twins">${head}
 <div class="tw-rows"><div class="tw-row tw-me"><div><strong>Senin tarlan</strong><small>${esc(STAGES[me.stageIdx])}</small></div>${track(me.stageIdx,true)}<span></span></div>
 ${rows.map(({twin:t,sim})=>`<div class="tw-row"><div><strong>${esc(t.label)}</strong><small>${esc(STAGES[t.stageIdx])} · ${esc(t.place)}</small><div class="tw-chips">${sim.why.map(w=>`<span>${esc(w)}</span>`).join('')}</div></div>${track(t.stageIdx,false)}<span class="tw-score" title="Benzerlik puanı">%${sim.score}</span></div>`).join('')}</div>
 <h3 class="tw-sub">Benzer tarlalarda yapılanlar <span class="fw-tag fw-tag-unknown">deneyim, tavsiye değil</span></h3>
 <ul class="tw-did">${ahead.flatMap(({twin:t})=>t.did.slice(-1).map(d=>({t,d}))).filter((x,i,a)=>a.findIndex(y=>y.d.text===x.d.text)===i).slice(0,3).map(({t,d})=>`<li><b>${esc(t.label)}</b> · ${esc(d.stage)}: ${esc(d.text)}</li>`).join('')||'<li>Henüz paylaşılmış bir kayıt yok.</li>'}</ul>
 <p class="fw-small">Karşılaştırma en az ${K_MIN} eşleşme olduğunda gösterilir; tam konum, ad ve fotoğraf hiçbir zaman gösterilmez. Buradaki tarlalar gerçek çiftçi değil, örnek veridir. ${esc(TWINS_VERSION)}</p>${toggle}</section>`;
}
export function mountTwins(host,ctx){
 if(!host)return;
 const draw=async()=>{
  const consent=hasConsent(ctx.storage,ctx.farm.id);let me=null,result=null;
  if(consent){me=await ctx.getProfile();if(!host.isConnected)return;result=matchTwins(me,demoTwins(me));}
  host.innerHTML=twinsHtml({consent,me,result});
  host.querySelector('#tw-consent')?.addEventListener('change',e=>{setConsent(ctx.storage,ctx.farm.id,e.target.checked);draw();});
 };
 draw();
}
