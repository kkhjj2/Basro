// Optional evidence adapters. Values are never inferred from a failed connection.
export const ENVIRONMENT_SOURCES=Object.freeze({
 soilgrids:Object.freeze({provider:'ISRIC — World Soil Information',dataset:'SoilGrids 2.0',endpoint:'https://rest.isric.org/soilgrids/v2.0/properties/query',url:'https://isric.org/explore/soilgrids',documentation:'https://docs.isric.org/globaldata/soilgrids/SoilGrids_faqs_01.html',statusUrl:'https://docs.isric.org/globaldata/soilgrids/index.html',license:'CC BY 4.0',licenseUrl:'https://creativecommons.org/licenses/by/4.0/',resolution:{value:250,unit:'m'},apiStatusAtVerification:'temporarilyPaused',verifiedAt:'2026-11-01'}),
 nasaPower:Object.freeze({provider:'NASA POWER',dataset:'POWER monthly point',url:'https://power.larc.nasa.gov/docs/services/api/temporal/monthly/'}),
 ecmwf:Object.freeze({provider:'ECMWF',dataset:'SEAS5',via:'Open-Meteo',url:'https://open-meteo.com/en/docs/seasonal-forecast-api'}),
 smap:Object.freeze({provider:'NASA',dataset:'SMAP',url:'https://smap.jpl.nasa.gov/data/'}),
 gpm:Object.freeze({provider:'NASA',dataset:'GPM IMERG',url:'https://gpm.nasa.gov/data/imerg'})
});

const bilingual=(tr,en)=>Object.freeze({tr,en});
export const SOIL_LIMITATIONS=Object.freeze([
 bilingual('250 m küresel model kestirimi; parselde ölçülmüş toprak veya laboratuvar analizi değildir. ISRIC yerel/tarla düzeyinde kullanımını önermez.','A 250 m global model prediction, not a field measurement or laboratory test. ISRIC does not advise local/farm-level use.'),
 bilingual('Yalnızca 0–5 cm üst toprak katmanı; güncel kök bölgesi nemini veya toprağın besin ihtiyacını ölçmez.','Only the 0–5 cm surface layer; it does not measure current root-zone moisture or nutrient requirements.'),
 bilingual('Organik karbon organik maddeyle aynı ölçüm değildir. Bu kayıtlardan NPK, gübre, kireç veya ilaç dozu hesaplanmaz.','Organic carbon is not the same measurement as organic matter. These records do not determine NPK, fertiliser, lime or pesticide doses.'),
 bilingual('Q0.05–Q0.95, modelin %90 kestirim aralığıdır; parsel doğruluğu garantisi değildir. Eksik değerler sıfır sayılmaz.','Q0.05–Q0.95 is the model’s 90% prediction interval, not a guarantee of field accuracy. Missing values are not zero.'),
 bilingual('REST hizmeti beta aşamasındadır ve kesintiye uğrayabilir; doğrulama sırasında ISRIC hizmetin geçici olarak duraklatıldığını bildiriyor.','The REST service is beta and can be interrupted; at verification ISRIC reports it temporarily paused.')
]);

/** Copy only supplied metadata; retrieval time never substitutes for model run time. */
export function createDatasetProvenance({provider=null,dataset=null,originalVariable=null,coords=null,resolution=null,validPeriod=null,retrievedAt=null,runId=null,units=null,limitations=[],quality={},sourceUrl=null,via=null}={}){
 return {provider,dataset,originalVariable,coords:coords?structuredClone(coords):null,resolution:resolution?structuredClone(resolution):null,validPeriod:validPeriod?structuredClone(validPeriod):null,retrievedAt,runId:runId??null,units:units??null,limitations:structuredClone(limitations),quality:structuredClone(quality),sourceUrl,via};
}

const properties=['phh2o','clay','sand','soc'];
const finite=v=>typeof v==='number'&&Number.isFinite(v);
const textUnit=v=>typeof v==='string'?v.replace(/\s/g,'').toLowerCase():'';
const labels={phh2o:{tr:'pH (suda)',en:'pH in water'},clay:{tr:'Kil',en:'Clay'},sand:{tr:'Kum',en:'Sand'},soc:{tr:'Toprak organik karbonu',en:'Soil organic carbon'}};

export function soilBaselineUrl(lat,lon){
 const p=new URLSearchParams({lat:String(lat),lon:String(lon)});
 for(const property of properties)p.append('property',property);
 p.append('depth','0-5cm');
 for(const value of ['mean','Q0.05','Q0.95'])p.append('value',value);
 return ENVIRONMENT_SOURCES.soilgrids.endpoint+'?'+p;
}

function conversion(property,metadata){
 // The API d_factor is a DIVISOR. Never default to the documented typical 10.
 const divisor=metadata?.d_factor,mappedUnit=metadata?.mapped_units,targetUnit=metadata?.target_units;
 if(!finite(divisor)||divisor<=0||!mappedUnit||!targetUnit)return null;
 const mapped=textUnit(mappedUnit),target=textUnit(targetUnit);
 const supported=property==='phh2o'?['phx10','ph*10','ph×10','ph'].includes(mapped)&&['-','ph','1'].includes(target):property==='soc'?mapped==='dg/kg'&&target==='g/kg':mapped==='g/kg'&&['g/100g','g/100g(%)','%'].includes(target);
 if(!supported)return null;
 return {divisor,mappedUnit,targetUnit,unit:property==='phh2o'?'pH':property==='soc'?'g/kg':'%'};
}

function parseSoilRecords(raw,{lat,lon,retrievedAt,url}){
 const layers=raw?.properties?.layers;
 if(!Array.isArray(layers))throw Error('invalidResponse');
 return properties.map(property=>{
  const layer=layers.find(v=>v?.name===property),scale=conversion(property,layer?.unit_measure);
  const depth=layer?.depths?.find(v=>v?.label==='0-5cm'&&v?.range?.top_depth===0&&v?.range?.bottom_depth===5&&v?.range?.unit_depth==='cm');
  const normalize=v=>{
   if(!scale||!finite(v)||v<0)return null;
   const normalized=v/scale.divisor,max=property==='phh2o'?14:property==='soc'?1000:100;
   return normalized<=max?normalized:null;
  };
  const value=normalize(depth?.values?.mean),rawLow=normalize(depth?.values?.['Q0.05']),rawHigh=normalize(depth?.values?.['Q0.95']);
  const reversed=rawLow!==null&&rawHigh!==null&&rawLow>rawHigh;
  const low=reversed?null:rawLow,high=reversed?null:rawHigh;
  const quality={kind:'modelPrediction',available:value!==null,unitsVerified:!!scale,depthVerified:!!depth,intervalAvailable:low!==null&&high!==null,flags:[...(!scale?['missingOrUnsupportedUnitMetadata']:[]),...(!depth?['missingOrUnsupportedDepth']:[]),...(value===null?['missingMean']:[]),...(low===null||high===null?['missingPredictionInterval']:[]),...(reversed?['invalidPredictionInterval']:[])]};
  const provenance=createDatasetProvenance({provider:ENVIRONMENT_SOURCES.soilgrids.provider,dataset:ENVIRONMENT_SOURCES.soilgrids.dataset,originalVariable:property,coords:{requested:{lat,lon},returned:raw.geometry?.coordinates??null},resolution:ENVIRONMENT_SOURCES.soilgrids.resolution,validPeriod:null,retrievedAt,runId:null,units:scale?{mapped:scale.mappedUnit,target:scale.targetUnit,display:scale.unit,divisor:scale.divisor}:null,limitations:SOIL_LIMITATIONS,quality,sourceUrl:url});
  return {property,label:labels[property],available:value!==null,depth:{top:0,bottom:5,unit:'cm'},value,low,high,unit:scale?.unit??null,rawValues:depth?.values?{mean:depth.values.mean??null,'Q0.05':depth.values['Q0.05']??null,'Q0.95':depth.values['Q0.95']??null}:null,provenance};
 });
}

/** At most two requests, each bounded to 8 seconds; no substitute data source. */
export async function fetchSoilBaseline(lat,lon,{fetcher=fetch,signal,now=new Date()}={}){
 if(!finite(lat)||!finite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw Error('Arazi koordinatı geçersiz.');
 signal?.throwIfAborted();
 const retrievedAt=new Date(now).toISOString(),url=soilBaselineUrl(lat,lon),source={...ENVIRONMENT_SOURCES.soilgrids,queryUrl:url};
 const provenance=createDatasetProvenance({provider:source.provider,dataset:source.dataset,originalVariable:[...properties],coords:{requested:{lat,lon},returned:null},resolution:source.resolution,validPeriod:null,retrievedAt,runId:null,units:null,limitations:SOIL_LIMITATIONS,quality:{status:'unavailable',attempts:0},sourceUrl:url});
 const result={available:false,reason:'SoilGrids toprak başlangıç verisi alınamadı.',reasonEn:'SoilGrids soil baseline could not be retrieved.',records:[],source,limitations:SOIL_LIMITATIONS,provenance};
 let failure='networkError';
 for(let attempt=1;attempt<=2;attempt++){
  provenance.quality.attempts=attempt;
  const timeout=AbortSignal.timeout(8000),requestSignal=signal?AbortSignal.any([signal,timeout]):timeout;
  try{
   const response=await fetcher(url,{signal:requestSignal});
   if(!response.ok){
    provenance.quality.httpStatus=response.status??null;failure='httpError';
    if(response.status>=500&&attempt<2)continue;
    break;
   }
   const records=parseSoilRecords(await response.json(),{lat,lon,retrievedAt,url});
   const available=records.some(r=>r.available),complete=records.every(r=>r.available&&r.provenance.quality.intervalAvailable);
   provenance.quality={status:available?(complete?'available':'partial'):'unavailable',attempts:attempt,recordsAvailable:records.filter(r=>r.available).length};
   return {...result,available,reason:complete?null:available?'Bazı toprak özellikleri veya belirsizlik bilgileri eksik.':'Doğrulanmış birim ve derinlikle kullanılabilir toprak değeri yok.',reasonEn:complete?null:available?'Some soil properties or uncertainty information are missing.':'No usable soil values with verified units and depth.',records,provenance};
  }catch(error){
   signal?.throwIfAborted();
   failure=error?.message==='invalidResponse'?'invalidResponse':error instanceof SyntaxError?'invalidResponse':requestSignal.aborted?'timeout':'networkError';
   if(failure==='invalidResponse')break;
  }
 }
 provenance.quality.failure=failure;
 return result;
}

export const DISCONNECTED_DATA_ADAPTERS=Object.freeze({
 smap:Object.freeze({status:'notConnected',available:false,source:ENVIRONMENT_SOURCES.smap,limitations:[bilingual('SMAP veri ürünü ve erişim bağlantısı henüz seçilmedi; canlı toprak nemi verisi yok.','A SMAP product and access connection have not been selected; no live soil-moisture data are connected.')]}),
 gpm:Object.freeze({status:'notConnected',available:false,source:ENVIRONMENT_SOURCES.gpm,limitations:[bilingual('GPM IMERG veri ürünü ve erişim bağlantısı henüz seçilmedi; canlı yağış verisi yok.','A GPM IMERG product and access connection have not been selected; no live precipitation data are connected.')]})
});
function disconnected(key){const adapter=structuredClone(DISCONNECTED_DATA_ADAPTERS[key]);return {...adapter,reason:adapter.limitations[0].tr,reasonEn:adapter.limitations[0].en,records:[],provenance:createDatasetProvenance({provider:adapter.source.provider,dataset:adapter.source.dataset,limitations:adapter.limitations,quality:{status:'notConnected'},sourceUrl:adapter.source.url})};}
export async function fetchSmapSoilMoisture(){return disconnected('smap');}
export async function fetchGpmPrecipitation(){return disconnected('gpm');}
