import {acceptedEvidence} from './observation-core.mjs';

export const DECISION_HISTORY_METHOD = 'agro-decision-history-1.0';
const text = (tr, en) => ({tr, en});
const clone = value => JSON.parse(JSON.stringify(value ?? null));
const canonical = value => value === undefined ? null : Array.isArray(value) ? value.map(canonical) : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().filter(key => value[key] !== undefined).map(key => [key, canonical(value[key])])) : value;
const serialize = value => JSON.stringify(canonical(value));
function fingerprint(value) {
  // Stable change identifier, not a cryptographic signature or security boundary.
  let hash = 2166136261;
  for (const char of serialize(value)) { hash ^= char.codePointAt(0); hash = Math.imul(hash, 16777619); }
  return 'fnv1a-' + (hash >>> 0).toString(16).padStart(8, '0');
}
function freeze(value) { if (value && typeof value === 'object' && !Object.isFrozen(value)) { Object.freeze(value); Object.values(value).forEach(freeze); } return value; }
function decisionState(result = {}) {
  const rows = result.candidates || result.options || [];
  return {
    methodVersion: result.methodVersion || result.method || null, parameterVersion: result.parameterVersion || null, kind: result.kind || null,
    preferredIds: [...(result.preferredIds || (result.preferredId ? [result.preferredId] : []))].sort(),
    candidates: rows.map(row => ({id: row.id, sequence: row.sequence, feasibility: row.feasibility || null, criteria: row.criteria || null, utility: row.utility ?? null, rank: row.rank ?? null, pareto: row.pareto ?? null, excludedReasons: (row.excludedReasons || []).map(reason => reason.code || reason).sort(), scenarioResults: row.scenarioResults || []})).sort((a, b) => String(a.id).localeCompare(String(b.id)))
  };
}
function forecastState(forecast) {
  if (!forecast?.available) return {available: false};
  return {
    available: true, model: forecast.model || null, method: forecast.method || null, gridKm: forecast.gridKm ?? null,
    // Keep provided run provenance separately. retrievedAt is never invented as a model run.
    months: (forecast.months || []).map(month => ({month: month.month, members: month.members, temperature: month.temperature, rain: month.rain, modelClimate: month.modelClimate})).sort((a, b) => String(a.month).localeCompare(String(b.month)))
  };
}
function relevantEvidence(evidence) {
  const out = {}, uncertainty = {};
  for (const key of ['standingWaterHours', 'soilTexture', 'previousCrop']) if (evidence[key] !== undefined) {
    out[key] = evidence[key];
    if (evidence.uncertainty?.[key]) uncertainty[key] = evidence.uncertainty[key];
  }
  if (Object.keys(uncertainty).length) out.uncertainty = uncertainty;
  return out;
}

/** A detached, deeply frozen local replay record. No external persistence or notification. */
export function createDecisionSnapshot({farm, evidence, observations = [], rotationResult = {}, forecast = null, priorities = {}, now = new Date()} = {}) {
  if (!farm?.id) throw new TypeError('A field ID is required for decision history.');
  const userId = farm.userId || 'device-owner';
  // When observation records are supplied, only validated owner/field evidence can
  // enter a production snapshot. With no records, caller-supplied evidence is kept
  // for explicit replay/import and marked as caller-provided provenance.
  const scopedObservations = observations.filter(row => row?.fieldId === farm.id && row.userId === userId);
  const effectiveEvidence = observations.length ? acceptedEvidence(scopedObservations, {fieldId: farm.id, userId}) : clone(evidence || {});
  const effectiveInputs = {
    farm: Object.fromEntries(['id', 'crop', 'water', 'lat', 'lon', 'area'].filter(key => farm[key] !== undefined).map(key => [key, farm[key]])),
    evidence: relevantEvidence(effectiveEvidence), priorities: clone(priorities), forecast: forecastState(forecast)
  };
  const state = decisionState(rotationResult), inputFingerprint = fingerprint(effectiveInputs), decisionFingerprint = fingerprint(state);
  return freeze({
    id: 'decision_' + (globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`),
    fieldId: farm.id, userId, createdAt: new Date(now).toISOString(), method: DECISION_HISTORY_METHOD,
    inputFingerprint, decisionFingerprint, fingerprint: inputFingerprint + ':' + decisionFingerprint,
    effectiveInputs: clone(effectiveInputs), evidence: clone(effectiveEvidence), observations: clone(scopedObservations),
    farm: clone(farm), rotationResult: clone(rotationResult), decisionState: clone(state), forecast: clone(forecast), priorities: clone(priorities),
    provenance: {observationIds: Object.values(effectiveEvidence.provenance || {}).map(row => row.observationId).sort(), evidenceOrigin: observations.length ? 'validated_local_observations' : 'caller_provided', forecastModelRun: forecast?.modelRun ?? forecast?.run ?? forecast?.issuedAt ?? null, forecastRetrievedAt: forecast?.retrievedAt ?? null, forecastRunKnown: !!(forecast?.modelRun || forecast?.run || forecast?.issuedAt), rotationMethod: state.methodVersion, parameterVersion: state.parameterVersion}
  });
}

/** Explain whether a recalculation changes the screening decision. */
export function compareDecisions(previous, next) {
  if (!next) throw new TypeError('A next decision snapshot is required.');
  if (!previous) return {materiality: 'initial', explanation: text('Bu tarlanın ilk karşılaştırması kaydedildi; belirsizlikler ve kaynaklar birlikte saklandı.', 'The field’s first comparison was recorded with its uncertainty and provenance.'), changedInputs: [], preferredChanged: false};
  if (previous.fieldId !== next.fieldId || previous.userId !== next.userId) throw new TypeError('Decision history cannot compare different owners or fields.');
  const changedInputs = ['farm', 'evidence', 'priorities', 'forecast'].filter(key => serialize(previous.effectiveInputs?.[key]) !== serialize(next.effectiveInputs?.[key]));
  const preferredChanged = serialize(previous.decisionState?.preferredIds || []) !== serialize(next.decisionState?.preferredIds || []);
  const sameInputs = serialize(previous.effectiveInputs) === serialize(next.effectiveInputs), sameDecision = serialize(previous.decisionState) === serialize(next.decisionState);
  if (sameInputs && sameDecision) return {materiality: 'none', explanation: text('İlgili kabul edilmiş girdiler ve seçenek karşılaştırması değişmedi. Bekleyen, yinelenen veya ilgisiz kayıtlar ek ağırlık oluşturmaz.', 'Relevant accepted inputs and the option comparison are unchanged. Pending, duplicate or irrelevant records add no weight.'), changedInputs, preferredChanged};
  const previousPreferred = previous.decisionState?.preferredIds || [], nextCandidates = next.decisionState?.candidates || [];
  const blockedPreferred = previousPreferred.some(id => nextCandidates.find(row => row.id === id)?.feasibility === 'infeasible');
  const noFeasible = nextCandidates.length > 0 && nextCandidates.every(row => row.feasibility === 'infeasible');
  if (blockedPreferred && noFeasible) return {materiality: 'urgent', explanation: text('Önceki tercih artık karşılaştırmadaki kısıtları karşılamıyor ve kalan uygun seçenek yok. Ekim kararından önce yerel uzmanla yeniden değerlendir.', 'The previous preference no longer satisfies the comparison constraints and no feasible option remains. Reassess with a local adviser before planting.'), changedInputs, preferredChanged};
  if (preferredChanged || blockedPreferred) return {materiality: 'material', explanation: text('İlgili kanıt veya öncelikler seçeneklerin tercih sırasını ya da uygulanabilirliğini değiştirdi. Bu bir tarama karşılaştırmasıdır; yerel uygunluk kontrolü sürer.', 'Relevant evidence or priorities changed option preferences or feasibility. This is a screening comparison; local suitability checks remain necessary.'), changedInputs, preferredChanged};
  return {materiality: 'moderate', explanation: text('İlgili girdi veya karşılaştırma ayrıntısı güncellendi; tercih edilen rotasyon değişmedi. Yeni kanıtın belirsizliği korunuyor.', 'A relevant input or comparison detail was updated; the preferred rotation is unchanged. The new evidence’s uncertainty is retained.'), changedInputs, preferredChanged};
}
