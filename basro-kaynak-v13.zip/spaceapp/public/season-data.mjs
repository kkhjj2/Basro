import {seasonalParams,nasaSeasonParams,parseSeasonal,parseNasaClimate} from './season-core.mjs';
const cache=new Map();
export async function fetchSeasonEvidence(lat,lon,{signal,fetcher=fetch,now=new Date(),force=false}={}){
 if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw Error('Arazi koordinatı geçersiz.');
 const key=lat.toFixed(4)+','+lon.toFixed(4)+','+new Date(now).toISOString().slice(0,7),hit=cache.get(key);
 if(!force&&hit&&Date.now()-hit.saved<6*3600000)return hit.data;
 const urls={season:'https://seasonal-api.open-meteo.com/v1/seasonal?'+seasonalParams(lat,lon),nasa:'https://power.larc.nasa.gov/api/temporal/monthly/point?'+nasaSeasonParams(lat,lon)};
 const get=async url=>{const r=await fetcher(url,{signal:signal?AbortSignal.any([signal,AbortSignal.timeout(35000)]):AbortSignal.timeout(35000)});if(!r.ok)throw Error('Veri kaynağı şu an yanıt vermiyor.');return r.json();};
 const [s,n]=await Promise.allSettled([get(urls.season),get(urls.nasa)]),retrievedAt=new Date(now).toISOString();
 const data={season:{available:false,reason:'Mevsimlik tahmin alınamadı.'},nasa:{available:false,reason:'NASA iklim geçmişi alınamadı.'},urls,retrievedAt,requested:{lat,lon}};
 if(s.status==='fulfilled')try{data.season=parseSeasonal(s.value,{now,retrievedAt});}catch(e){data.season.reason=e.message;}
 if(n.status==='fulfilled')try{data.nasa=parseNasaClimate(n.value);}catch(e){data.nasa.reason=e.message;}
 if(signal?.aborted)throw signal.reason;
 if(data.season.available||data.nasa.available){if(cache.size>=40)cache.delete(cache.keys().next().value);cache.set(key,{saved:Date.now(),data});}
 return data;
}
