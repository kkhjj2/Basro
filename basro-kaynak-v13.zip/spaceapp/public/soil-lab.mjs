// Toprak verilerim (soil-1.0): çiftçinin kendi tahlil sonuçlarını ve ölçümlerini girdiği yer.
// Sınıflar genel sınıflamadır (Türkiye'de yaygın kullanılan Ülgen ve Yurtsever 1995 sınırları); laboratuvar yorumu esastır.
// Bu modül gübre ya da ilaç dozu ÖNERMEZ. Veri bu cihazda saklanır.
export const SOIL_VERSION='soil-1.0';
const KEY='agrobas-soil-v1',FIELD_KEY='agrobas-field-v1';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const f=v=>String(v).replace('.',',');
// [üst sınır (dahil değil), etiket, ton]
export const FIELDS={
 ph:{label:'pH',unit:'',min:3,max:10.5,step:.1,bands:[[5.5,'kuvvetli asit','warn'],[6.5,'hafif asit','ok'],[7.5,'nötr','good'],[8.5,'hafif alkali','ok'],[Infinity,'kuvvetli alkali','warn']]},
 om:{label:'Organik madde',unit:'%',min:0,max:30,step:.1,bands:[[1,'çok az','warn'],[2,'az','warn'],[3,'orta','ok'],[4,'iyi','good'],[Infinity,'yüksek','good']]},
 ec:{label:'Tuzluluk (EC)',unit:'dS/m',min:0,max:40,step:.1,bands:[[2,'tuzsuz','good'],[4,'hafif tuzlu','ok'],[8,'orta tuzlu','warn'],[Infinity,'çok tuzlu','warn']]},
 lime:{label:'Kireç (CaCO₃)',unit:'%',min:0,max:80,step:.1,bands:[[1,'az kireçli','ok'],[5,'kireçli','good'],[15,'orta kireçli','ok'],[25,'fazla kireçli','warn'],[Infinity,'çok fazla kireçli','warn']]},
 p:{label:'Fosfor (P₂O₅)',unit:'kg/da',min:0,max:100,step:.1,bands:[[3,'çok az','warn'],[6,'az','warn'],[9,'orta','ok'],[12,'yüksek','good'],[Infinity,'çok yüksek','ok']]},
 k:{label:'Potasyum (K₂O)',unit:'kg/da',min:0,max:400,step:1,bands:[[20,'az','warn'],[30,'orta','ok'],[40,'yeterli','good'],[Infinity,'fazla','ok']]},
};
export const TEXTURES={kumlu:'Kumlu',tinli:'Tınlı',killi_tin:'Killi tın',killi:'Killi'};
export function classify(id,value){const d=FIELDS[id],v=Number(value);if(!d||!Number.isFinite(v))return null;const b=d.bands.find(x=>v<x[0]);return {label:b[1],tone:b[2]};}
/** Girdiyi doğrular: {ok, entry} ya da {ok:false, error}. En az bir değer gerekir; aralık dışı değer reddedilir. */
export function validateEntry(raw,today=new Date().toISOString().slice(0,10)){
 const e={id:'soil_'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),day:/^\d{4}-\d{2}-\d{2}$/.test(raw.day||'')?raw.day:today,source:raw.source==='own'?'own':'lab',values:{}};
 if(e.day>today)return {ok:false,error:'Tarih gelecekte olamaz.'};
 for(const [id,d] of Object.entries(FIELDS)){
  const s=String(raw[id]??'').trim().replace(',','.');if(!s)continue;const v=Number(s);
  if(!Number.isFinite(v)||v<d.min||v>d.max)return {ok:false,error:`${d.label} ${f(d.min)} ile ${f(d.max)} arasında olmalı.`};
  e.values[id]=Math.round(v*100)/100;
 }
 if(raw.texture&&TEXTURES[raw.texture])e.texture=raw.texture;
 const note=String(raw.note??'').trim().slice(0,200);if(note)e.note=note;
 if(!Object.keys(e.values).length&&!e.texture)return {ok:false,error:'En az bir değer gir.'};
 return {ok:true,entry:e};
}
const read=st=>{try{return JSON.parse(st.getItem(KEY)||'{}')||{};}catch{return {};}};
export const entriesOf=(st,farmId)=>(read(st)[farmId]||[]).slice().sort((a,b)=>b.day.localeCompare(a.day));
export function addEntry(st,farmId,entry){
 const all=read(st);all[farmId]=[...(all[farmId]||[]),entry].slice(-40);try{st.setItem(KEY,JSON.stringify(all));}catch{}
 // Bünye girildiyse su dengesi hesabı da bu toprağı kullanır.
 if(entry.texture){try{const fw=JSON.parse(st.getItem(FIELD_KEY)||'{}')||{};fw[farmId]={history:[],...(fw[farmId]||{}),soil:entry.texture};st.setItem(FIELD_KEY,JSON.stringify(fw));}catch{}}
}
export function removeEntry(st,farmId,id){const all=read(st);all[farmId]=(all[farmId]||[]).filter(e=>e.id!==id);try{st.setItem(KEY,JSON.stringify(all));}catch{}}
/** Bir önceki sonuca göre değişim: {ph:+0.3,...}. */
export function deltas(entries){const [a,b]=entries;const out={};if(!a||!b)return out;for(const id of Object.keys(a.values))if(b.values[id]!=null)out[id]=Math.round((a.values[id]-b.values[id])*100)/100;return out;}
/** Haftalık rapor için tek cümlelik olgu (sayılar girilen değerlerdir). */
export function soilFact(entries){
 const e=entries[0];if(!e)return null;
 const parts=Object.entries(e.values).slice(0,3).map(([id,v])=>`${FIELDS[id].label} ${f(v)}${FIELDS[id].unit?' '+FIELDS[id].unit:''} (${classify(id,v).label})`);
 if(!parts.length)return null;
 return {id:'soil',text:`Toprak tahlilin (${e.day}): ${parts.join(', ')}.`,source:e.source==='lab'?'Senin girdiğin laboratuvar sonucu':'Senin ölçümün'};
}
export function soilHtml(entries,{form=false,error=''}={}){
 const last=entries[0],d=deltas(entries);
 const chips=last?Object.entries(last.values).map(([id,v])=>{const c=classify(id,v),dl=d[id];return `<div class="sl-val sl-${c.tone}"><small>${esc(FIELDS[id].label)}</small><strong>${f(v)}${FIELDS[id].unit?` <em>${esc(FIELDS[id].unit)}</em>`:''}</strong><span>${esc(c.label)}</span>${dl?`<i>${dl>0?'▲':'▼'} ${f(Math.abs(dl))} önceki sonuca göre</i>`:''}</div>`;}).join(''):'';
 const formHtml=`<form class="sl-form" id="sl-form" novalidate><div class="sl-grid"><label>Tarih<input class="farm-input" type="date" name="day" max="${new Date().toISOString().slice(0,10)}" value="${new Date().toISOString().slice(0,10)}"></label><label>Kaynak<select class="farm-input" name="source"><option value="lab">Laboratuvar tahlili</option><option value="own">Kendi ölçümüm</option></select></label>${Object.entries(FIELDS).map(([id,x])=>`<label>${esc(x.label)}${x.unit?` <em>(${esc(x.unit)})</em>`:''}<input class="farm-input" name="${id}" inputmode="decimal" placeholder="boş bırakabilirsin"></label>`).join('')}<label>Bünye<select class="farm-input" name="texture"><option value="">Seçme</option>${Object.entries(TEXTURES).map(([k,v])=>`<option value="${k}">${esc(v)}</option>`).join('')}</select></label><label class="sl-wide">Not<input class="farm-input" name="note" maxlength="200" placeholder="Örn. numune tarlanın alt kısmından, 0–30 cm"></label></div><p class="farm-form-error" id="sl-error">${esc(error)}</p><div class="sl-form-actions"><button class="farm-primary">Kaydet</button><button type="button" class="farm-quiet-btn" id="sl-cancel">Vazgeç</button></div></form>`;
 return `<section class="farm-card sl" id="soil-lab"><header class="fm-head"><div><span class="farm-eyebrow">TOPRAK VERİLERİM</span><h2>${last?'Son tahlil sonucun':'Tahlil sonuçlarını buraya gir'}</h2></div>${form?'':'<button class="farm-primary" id="sl-add">+ Sonuç ekle</button>'}</header>
 ${form?formHtml:''}
 ${last?`<p class="sl-meta">${esc(last.day)} · ${last.source==='lab'?'laboratuvar tahlili':'kendi ölçümün'}${last.texture?' · bünye: '+esc(TEXTURES[last.texture]):''}${last.note?' · '+esc(last.note):''}</p><div class="sl-vals">${chips}</div>`:form?'':'<p class="sl-empty">Tahlil raporundaki değerleri ya da kendi ölçümlerini gir. Hepsini doldurman gerekmez; bildiğin kadarı yeter. Bünyeyi girersen su hesabı da bu toprağa göre yapılır.</p>'}
 ${entries.length>1?`<details class="fw-ranked"><summary>Önceki sonuçlar (${entries.length-1})</summary><ul class="sl-hist">${entries.slice(1).map(e=>`<li><span>${esc(e.day)} · ${Object.entries(e.values).map(([id,v])=>`${esc(FIELDS[id].label)} ${f(v)}`).join(' · ')||esc(TEXTURES[e.texture]||'')}</span><button class="bs-del" data-sl-del="${esc(e.id)}">Sil</button></li>`).join('')}</ul></details>`:''}
 ${last?`<button class="farm-quiet-btn sl-del-last" data-sl-del="${esc(last.id)}">Son sonucu sil</button>`:''}
 <p class="fw-small">Sınıflar genel sınıflamadır; laboratuvarının yorumunu esas al. Burada gübre ya da ilaç dozu önerilmez. Veriler bu cihazda saklanır. ${esc(SOIL_VERSION)}</p></section>`;
}
export function mountSoil(host,ctx){
 if(!host)return;let form=false,error='';
 const draw=()=>{
  host.innerHTML=soilHtml(entriesOf(ctx.storage,ctx.farm.id),{form,error});
  host.querySelector('#sl-add')?.addEventListener('click',()=>{form=true;error='';draw();host.querySelector('[name=ph]')?.focus();});
  host.querySelector('#sl-cancel')?.addEventListener('click',()=>{form=false;error='';draw();});
  host.querySelector('#sl-form')?.addEventListener('submit',e=>{
   e.preventDefault();const r=validateEntry(Object.fromEntries(new FormData(e.target)));
   if(!r.ok){error=r.error;host.querySelector('#sl-error').textContent=error;return;}
   addEntry(ctx.storage,ctx.farm.id,r.entry);form=false;error='';draw();ctx.onChange?.(r.entry);
  });
  host.querySelectorAll('[data-sl-del]').forEach(b=>b.addEventListener('click',()=>{removeEntry(ctx.storage,ctx.farm.id,b.dataset.slDel);draw();ctx.onChange?.(null);}));
 };
 draw();
}
