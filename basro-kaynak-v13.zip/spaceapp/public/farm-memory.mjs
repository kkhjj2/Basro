// Tarla hafızası: notlar, fotoğraf kanıtları, karar değişiklikleri ve tamamlanan işler tek zaman çizelgesinde.
// Kaynaklar: Kayıtlarım (notes), tarla çalışma alanı geçmişi (agrobas-field-v1), iş listesi (completedOn).
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const KINDS={photo:['📸','Fotoğraf'],decision:['🔄','Karar değişti'],check:['🧭','Bilgi eklendi'],water:['💧','Sulama'],feeding:['🌿','Besleme'],care:['✂️','Bakım'],note:['📝','Gözlem'],task:['✓','Tamamlanan iş']};

/** Tüm kaynakları {day, kind, title, text, at} olaylarına çevirir; en yeni üstte. */
export function timelineItems({notes=[],record={},work={},tasks=[],farmId}){
 const items=[];
 for(const n of notes.filter(n=>n.farmId===farmId))items.push({day:n.day,at:n.createdAt||n.day,kind:KINDS[n.type]?n.type:'note',title:KINDS[n.type]?.[1]||'Gözlem',text:n.text});
 for(const h of record.history||[]){
  if(h.input?.id==='photo')continue; // fotoğraf kanıtı zaten not olarak yazıldı
  items.push({day:h.day,at:h.day+'T12:00:00Z',kind:h.change?.decisionChanged?'decision':'check',title:h.change?.decisionChanged?`Karar değişti: ${h.change.before} → ${h.change.after}`:'Bilgi eklendi, karar aynı kaldı',text:h.change?.changedInput||''});
 }
 const titleOf=new Map(tasks.map(t=>[t.key,t.title]));
 for(const [key,day] of Object.entries(work.completedOn||{})){
  if(!key.startsWith(farmId+'|'))continue;
  items.push({day,at:day+'T18:00:00Z',kind:'task',title:'İş tamamlandı',text:titleOf.get(key)||''});
 }
 return items.sort((a,b)=>String(b.at).localeCompare(String(a.at)));
}
export function groupByDay(items){const out=[];for(const it of items){const g=out.at(-1);if(g&&g.day===it.day)g.items.push(it);else out.push({day:it.day,items:[it]});}return out;}
const dayLabel=d=>new Intl.DateTimeFormat('tr-TR',{day:'numeric',month:'long',weekday:'long',timeZone:'UTC'}).format(new Date(d+'T12:00:00Z'));

export function memoryHtml(items,filter='all'){
 const counts={};for(const it of items)counts[it.kind]=(counts[it.kind]||0)+1;
 const shown=filter==='all'?items:items.filter(i=>i.kind===filter),groups=groupByDay(shown);
 const chip=(id,label,n)=>`<button data-fm-filter="${id}" aria-pressed="${filter===id}">${label}${n!=null?` <b>${n}</b>`:''}</button>`;
 return `<section class="farm-card fm" id="farm-memory-card" aria-label="Tarla hafızası"><header class="fm-head"><div><span class="farm-eyebrow">TARLA HAFIZASI</span><h2>Bu tarlada neler oldu?</h2></div><span class="fm-soon">Sezon karşılaştırma · yakında</span></header>
 <div class="fm-filters">${chip('all','Hepsi',items.length)}${Object.keys(KINDS).filter(k=>counts[k]).map(k=>chip(k,KINDS[k][0]+' '+KINDS[k][1],counts[k])).join('')}</div>
 ${groups.length?`<ol class="fm-days">${groups.map(g=>`<li><h3>${esc(dayLabel(g.day))}</h3><ul>${g.items.map(it=>`<li class="fm-item fm-${it.kind}"><span aria-hidden="true">${KINDS[it.kind][0]}</span><div><strong>${esc(it.title)}</strong>${it.text?`<p>${esc(it.text)}</p>`:''}</div></li>`).join('')}</ul></li>`).join('')}</ol>`:'<p class="fm-empty">Henüz kayıt yok. Bir fotoğraf yükle, bir iş tamamla ya da Tarlam ekranında bir soruyu cevapla; hepsi burada sıralanır.</p>'}
 <p class="fm-note">Kayıtlar bu cihazda tutulur. Fotoğrafın kendisi saklanmaz; yalnızca incelemenin sonucu yazılır.</p></section>`;
}
export function mountMemory(host,getItems){
 if(!host)return;let filter='all';
 const draw=()=>{host.innerHTML=memoryHtml(getItems(),filter);host.querySelectorAll('[data-fm-filter]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.fmFilter;draw();}));};
 draw();
}
