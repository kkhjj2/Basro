// Deterministic seasonal evidence and decisions. No LLM invents forecast values or application doses.
import {cropFamily,normalizeCropName,findCrop} from './crop-catalog.mjs';
export const SEASON_METHOD='agro-season-1.0';
export const SEASON_SOURCES={
 seasonal:'https://open-meteo.com/en/docs/seasonal-forecast-api',
 nasa:'https://power.larc.nasa.gov/docs/services/api/temporal/monthly/',
 feeding:'https://www.tarimorman.gov.tr/Konular/Bitkisel-Uretim/Bitki-Besleme-ve-Tarimsal-Teknolojiler',
 ipm:'https://www.tarimorman.gov.tr/TAGEM/Sayfalar/Detay.aspx?SayfaId=29',
 rotation:'https://www.fao.org/conservation-agriculture/in-practice/species-diversification/en/',
 orchard:'https://www.fao.org/4/i0007e/i0007e03.pdf',
 challenge:'https://www.spaceappschallenge.org/2026/challenges/field-shift-adapting-farms-with-nasa-data/'
};
const finite=v=>typeof v==='number'&&Number.isFinite(v)&&v>-900;
const mean=a=>a.reduce((s,v)=>s+v,0)/a.length;
const days=(y,m)=>new Date(Date.UTC(y,m,0)).getUTCDate();
const round=(v,n=1)=>Number(v.toFixed(n));
const q=(rows,p)=>{const a=[...rows].sort((a,b)=>a-b),x=(a.length-1)*p,i=Math.floor(x);return a[i]+(a[Math.min(i+1,a.length-1)]-a[i])*(x-i);};
const fraction=(a,test)=>a.filter(test).length/a.length;
export function nextMonths(now=new Date(),count=12){const d=new Date(now);return Array.from({length:count},(_,i)=>new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+i+1,1)).toISOString().slice(0,7));}
export function seasonalParams(lat,lon){return new URLSearchParams({latitude:String(lat),longitude:String(lon),daily:'temperature_2m_mean,precipitation_sum',monthly:'temperature_2m_mean,temperature_2m_anomaly,precipitation_mean,precipitation_anomaly',models:'ecmwf_seas5',forecast_days:'210',timezone:'GMT'});}
export function nasaSeasonParams(lat,lon){return new URLSearchParams({parameters:'T2M,PRECTOTCORR',community:'AG',latitude:String(lat),longitude:String(lon),start:'1991',end:'2020',format:'JSON'});}
export function parseNasaClimate(raw){
 if(raw?.parameters?.T2M?.units!=='C'||raw?.parameters?.PRECTOTCORR?.units!=='mm/day')throw Error('NASA sıcaklık / yağış birimleri doğrulanamadı.');
 const p=raw.properties?.parameter;if(!p)throw Error('NASA geçmişi eksik.');
 const months=Array.from({length:12},(_,i)=>{
  const m=i+1,rows=[];for(let y=1991;y<=2020;y++){const k=String(y)+String(m).padStart(2,'0'),t=p.T2M?.[k],r=p.PRECTOTCORR?.[k];if(finite(t)&&finite(r)&&r>=0)rows.push({year:y,t,r:r*days(y,m)});}
  return {month:m,years:rows.length,temperature:rows.length>=24?round(mean(rows.map(r=>r.t))):null,rain:rows.length>=24?round(mean(rows.map(r=>r.r))):null,rainLow:rows.length>=24?round(q(rows.map(r=>r.r),.2)):null,rainHigh:rows.length>=24?round(q(rows.map(r=>r.r),.8)):null};
 });
 if(months.some(m=>m.temperature===null||m.rain===null))throw Error('NASA iklim referansı için yeterli tam ay yok.');
 return {available:true,period:'1991–2020',months,point:raw.geometry?.coordinates,kind:'NASA POWER geçmiş iklim referansı; gelecek tahmini değil'};
}
export function parseSeasonal(raw,{now=new Date(),retrievedAt=new Date().toISOString()}={}){
 const stamp=Date.parse(retrievedAt),age=new Date(now).getTime()-stamp;
 if(!Number.isFinite(stamp)||age< -300000||age>48*3600000)throw Error('Mevsimlik veri güncel değil. Yeniden al.');
 const d=raw?.daily,m=raw?.monthly,u=raw?.monthly_units,du=raw?.daily_units;
 if(!Array.isArray(d?.time)||!Array.isArray(m?.time)||u?.temperature_2m_mean!=='°C'||u?.temperature_2m_anomaly!=='K'||u?.precipitation_mean!=='mm'||u?.precipitation_anomaly!=='mm')throw Error('Mevsimlik veri birimleri doğrulanamadı.');
 if(new Set(d.time).size!==d.time.length||d.time.some((v,i)=>!/^\d{4}-\d{2}-\d{2}$/.test(v)||(i&&v<=d.time[i-1])))throw Error('Mevsimlik gün sırası doğrulanamadı.');
 const future=nextMonths(now,7),months=[];
 for(let j=0;j<m.time.length;j++){
  const month=String(m.time[j]).slice(0,7);if(!future.includes(month))continue;
  const y=Number(month.slice(0,4)),mo=Number(month.slice(5)),count=days(y,mo),indices=d.time.map((s,i)=>s.slice(0,7)===month?i:-1).filter(i=>i>=0);
  if(indices.length!==count||d.time[indices[0]]!==month+'-01'||d.time[indices.at(-1)]!==month+'-'+count)continue;
  const mt=m.temperature_2m_mean?.[j],ta=m.temperature_2m_anomaly?.[j],mp=m.precipitation_mean?.[j],pa=m.precipitation_anomaly?.[j];
  if(![mt,ta,mp,pa].every(finite)||mp<0)continue;
  const modelClimateT=mt-ta,modelClimateP=mp-pa;if(modelClimateP<0)continue;
  const members=[];
  for(let n=0;n<51;n++){
   const suffix=n?'_member'+String(n).padStart(2,'0'):'',tk='temperature_2m_mean'+suffix,pk='precipitation_sum'+suffix;
   if(du?.[tk]!=='°C'||du?.[pk]!=='mm')continue;
   const ts=indices.map(i=>d[tk]?.[i]),ps=indices.map(i=>d[pk]?.[i]);
   if(ts.every(finite)&&ps.every(v=>finite(v)&&v>=0))members.push({id:n,t:mean(ts),p:ps.reduce((s,v)=>s+v,0)});
  }
  // Paired, complete members only; missing days are never interpreted as zero rain.
  if(members.length<40)continue;
  if(Math.abs(mean(members.map(x=>x.t))-mt)>1||Math.abs(mean(members.map(x=>x.p))-mp)>Math.max(8,mp*.15))continue;
  const dt=members.map(x=>x.t-modelClimateT),pp=members.map(x=>x.p),rainThreshold=Math.max(5,modelClimateP*.2);
  const warm=fraction(dt,v=>v>.5),cold=fraction(dt,v=>v<-.5),dry=fraction(pp,v=>v<modelClimateP-rainThreshold),wet=fraction(pp,v=>v>modelClimateP+rainThreshold);
  months.push({month,members:members.length,temperature:{mean:round(mt),anomaly:round(ta),low:round(q(members.map(x=>x.t),.1)),high:round(q(members.map(x=>x.t),.9)),warm,cold,neutral:1-warm-cold,direction:warm>=.6?'warm':cold>=.6?'cold':'mixed'},rain:{mean:round(mp),anomaly:round(pa),change:modelClimateP>=5?round(pa/modelClimateP*100,0):null,low:round(q(pp,.1)),high:round(q(pp,.9)),dry,wet,neutral:1-dry-wet,direction:dry>=.6?'dry':wet>=.6?'wet':'mixed'},modelClimate:{temperature:round(modelClimateT),rain:round(modelClimateP)},kind:'forecast'});
 }
 if(!months.length)throw Error('Gelecekteki tam aylar için yeterli model senaryosu alınamadı.');
 return {available:true,method:SEASON_METHOD,model:'ECMWF SEAS5',gridKm:36,point:{lat:raw.latitude,lon:raw.longitude,elevation:raw.elevation},retrievedAt,months,firstMonth:months[0].month,lastMonth:months.at(-1).month,uncertainty:'Senaryo payları kalibre edilmiş gerçekleşme olasılığı değildir. Bölgesel model yanlılık düzeltmesi içermez; tarla içi ölçüm veya belirli günün hava tahmini değildir.'};
}
export function normalizeSeasonInputs(value={}){
 value=value&&typeof value==='object'&&!Array.isArray(value)?value:{};
 return {texture:['unknown','sandy','loam','clay'].includes(value.texture)?value.texture:'unknown',drainage:['unknown','good','ponding'].includes(value.drainage)?value.drainage:'unknown',previousCrop:normalizeCropName(value.previousCrop)||'',soilTestDate:typeof value.soilTestDate==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value.soilTestDate)?value.soilTestDate:'',nitrogen:['unknown','low','adequate','high'].includes(value.nitrogen)?value.nitrogen:'unknown',sowingMonth:Number.isInteger(Number(value.sowingMonth))&&Number(value.sowingMonth)>=1&&Number(value.sowingMonth)<=12?Number(value.sowingMonth):null};
}
const botanical=crop=>['Kabak','Sakız kabağı','Bal kabağı','Kestane kabağı','Su kabağı','Karpuz','Kavun','Salatalık','Acur'].includes(crop)?'cucurbit':['Domates','Çeri domates','Patates','Biber','Patlıcan','Kapya biber'].includes(crop)?'solanum':['Nohut','Mercimek','Yeşil mercimek','Kırmızı mercimek','Bezelye','Fasulye','Fiğ','Yonca','Taze fasulye','Taze bakla'].includes(crop)?'legume':cropFamily(crop)==='grain'?'grass':cropFamily(crop);
export function rotationOptions(farm,inputs,signals={}){
 const family=cropFamily(farm.crop),limited=farm.water!=='var'||signals.dry;
 if(['orchard','vine','bush'].includes(family))return {kind:'orchard',title:'Ağaçlarını koru, bahçe tabanını planla.',note:'Çok yıllık bahçede ağaçları her yıl değiştiren ekim nöbeti önerilmez. Seçenekler bahçe tabanı içindir.',options:[
  {id:'mulch',title:'Ölü organik örtü',sequence:['Mevcut bahçe','Yüzey örtüsü','Nem ve gövde kontrolü'],benefit:'Toprağın açıkta kalmasını azaltmayı ve nemi korumayı hedefler.',tradeoff:'Örtüyü gövdeye dayama; materyal, hastalık ve yangın koşullarını yerinde değerlendir.',water:'Canlı örtüden su rekabeti yok'},
  {id:'winter-cover',title:'Geçici kış örtüsü',sequence:['Mevcut bahçe','Uygun kışlık örtü','Zamanında sonlandırma'],benefit:'Uygun türle toprak örtüsü ve organik madde döngüsünü destekleyebilir.',tradeoff:limited?'Su kısıtlı: canlı örtü ağaçlarla rekabet edebilir; tür ve sonlandırma tarihini yerinde belirle.':'Türü ve sonlandırmayı ağacın su-besin ihtiyacına göre belirle.',water:limited?'Su rekabeti öncelikle kontrol edilmeli':'Sulama bütçesiyle birlikte düşün'},
  {id:'mown-cover',title:'Biçilen doğal örtü',sequence:['Mevcut bahçe','Örtüyü gözle','Biçim ve su takibi'],benefit:'Toprağı örter; örtüyü tamamen kaldırmaya alternatif sunar.',tradeoff:'İstenmeyen türleri, biçim zamanını ve su rekabetini izlemek gerekir.',water:'Yaz kuraklığında yeniden değerlendir'}
 ]};
 const first=normalizeCropName(farm.crop);if(!first||!findCrop(first)||family==='herb'||first==='Diğer'||first==='Henüz seçmedim')return {kind:'annual',title:'Önce ürünün yetiştirme koşullarını netleştirelim.',note:'Bu ürün için doğrulanmış rotasyon profili yok. Bitki ailesi ve yerel koşullar bilinmeden uygunluk sıralaması yapılmaz.',options:[]};
 const current=botanical(first),next=current==='legume'?'Buğday':current==='grass'?'Nohut':'Mercimek';
 const candidates=[{id:'diverse',sequence:[first,next,current==='grass'?'Arpa':'Nohut'],title:'Farklı ailelerle bir sıra'},{id:'water',sequence:[first,current==='grass'?'Mercimek':'Arpa',current==='grass'?'Buğday':'Mercimek'],title:'Suyu öncelikleyen alternatif'},{id:'cover',sequence:[first,'Fiğ','Buğday'],title:'Baklagil ve toprak örtüsü'}];
 return {kind:'annual',title:'Gelecek ekimleri yan yana düşün.',note:'Bunlar aile ve su önceliğine göre sıralanmış plan alternatifleridir; çeşit, ekim zamanı ve toprak uygunluğu yerinde doğrulanmalıdır.',options:candidates.map((v,i)=>({...v,benefit:i===0?'Farklı bitki aileleriyle ardışık üretimi çeşitlendirir.':i===1?'Kuru koşullarda değerlendirilebilen ürünleri konuşmaya açar.':'Baklagil ve örtü yönetimini üretim sırasına alır.',water:limited?'Yağışa ve yerel çeşide bağlı; su bütçesini doğrula':'Sulama var; yine de ekim dönemini doğrula',tradeoff:i===2?'Canlı örtü su kullanır; ne zaman sonlandırılacağı belirlenmeli.':'Baklagil sonrası sabit bir azot indirimi varsayılmaz; analiz ve önceki uygulama kaydı gerekir.',repeat:botanical(inputs.previousCrop)===current&&!!inputs.previousCrop?'Önceki ürünle aynı aile tekrarı var; alternatif sırayı özellikle değerlendir.':''}))};
}
export function buildSeasonPlan({farm,inputs={},season={available:false},nasa={available:false},weather={available:false},month=null,scenario='model',now=new Date()}){
 inputs=normalizeSeasonInputs(inputs);const chosen=season.available?(month?season.months.find(m=>m.month===month)||null:season.months[0]):null;
 const dry=scenario==='dry'||scenario==='model'&&chosen?.rain.direction==='dry',wet=scenario==='wet'||scenario==='model'&&chosen?.rain.direction==='wet',warm=scenario==='model'&&chosen?.temperature.direction==='warm';
 const hypothetical=scenario!=='model',limited=farm.water!=='var',orchard=['orchard','vine','bush'].includes(cropFamily(farm.crop)),report=!!inputs.soilTestDate&&inputs.soilTestDate<=new Date(now).toISOString().slice(0,10);
 const signals={dry:!!dry,wet:!!wet,warm:!!warm},actions=[];
 const add=(id,category,title,why,next,missing,source,priority)=>actions.push({id,category,title,why,next,missing,source,priority});
 const heavy=weather.available&&weather.rows?.slice(0,3).some(r=>r.rain>=20),cold=weather.available&&weather.frost;
 add('soil','Besleme',!report?'Besleme planından önce analizini hazırla':heavy||inputs.drainage==='ponding'?'Gübrelemeden önce yağış ve toprağı kontrol et':wet&&inputs.texture==='sandy'?'Azot planını bölünmüş uygulama için değerlendir':'Analizindeki besleme planını ürün dönemiyle kontrol et',!report?'Mevsimlik hava öngörüsü toprağın NPK ihtiyacını ölçmez. pH ve organik madde de besin analizinin yerine geçmez.':heavy||inputs.drainage==='ponding'?'Yakın dönemde kuvvetli yağış sinyali veya beyan ettiğin su birikmesi var. Doymuş, donmuş ve su basmış toprak uygulama penceresi değildir.':wet?'Yağışlı senaryo yıkanma ve yüzey akışı hazırlığını önemli kılar. Toplam azotu otomatik artırma.':'Raporun kullanıcı beyanı; miktar ve gübre türünü ürünün ihtiyacı ve laboratuvar önerisi belirler.',!report?'Ekim / üst gübre öncesi laboratuvarla numune koşullarını netleştir.':'Uygulama tarihinden 48–72 saat önce kısa dönem hava ve tarla nemini yeniden kontrol et.',report?(inputs.nitrogen==='unknown'?'Raporun azot yorumu / ürün önerisi eksik.':'Gübre miktarı hesaplanmadı; ürün bazlı laboratuvar reçetesi gerekir.'):'Analiz tarihi ve ürün bazlı besin sonuçları eksik.',SEASON_SOURCES.feeding,heavy?105:!report?86:80);
 add('water','Su ve toprak',dry||limited?'Sezon öncesi su bütçeni kontrol et':wet||inputs.drainage==='ponding'?'Drenaj ve yüzey akışını kontrol et':'Kök bölgesi nemini düzenli kaydet',dry||limited?'Kurak senaryo veya kısıtlı sulama, nemi koruma ve su rekabetini öncelikli yapıyor.':wet?'Yağışlı senaryo, suyun tarlada nerede biriktiğine bakmayı gerektiriyor.':'Yağış yönü tek başına sulama miktarını belirlemez; ürün evresi ve kök nemiyle birlikte okunur.','Sulamadan önce nemi, son yağışı ve gelişme dönemini yeniden kontrol et.',inputs.texture==='unknown'?'Toprak bünyesi ve kök bölgesi nemi bilinmiyor.':'Ölçülmüş kök nemi ve kullanılabilir su miktarı eklenmedi.',SEASON_SOURCES.nasa,dry||limited?90:78);
 add('health','Bitki sağlığı',warm?'Tuzak ve saha kontrollerini karşılaştır':wet?'Yaprak ve meyve kontrollerini sıklaştır':'Ürününe ait izleme kaydını sürdür',warm?'Daha sıcak senaryolar gelişim zamanını değiştirebilir; zararlı sayısını veya ilaç ihtiyacını tek başına göstermez.':wet?'Yağışlı koşul tek başına hastalık teşhisi değildir. Belirti, ürün evresi ve saha kontrolü birlikte gerekir.':'İlaç kararı tür tanımı, saha sayımı / ekonomik eşik ve ürüne ait resmî talimata bağlıdır.','Haftalık aynı örnek noktaları izle; uygulama öncesi yerel bülten ve kayıtlı etiketi kontrol et.','Zararlı türü / saha sayımı doğrulanmadı; otomatik ilaç veya doz seçilmez.',SEASON_SOURCES.ipm,warm||wet?85:75);
 add('planting','Ekim ve bakım',orchard?'Bahçe tabanı ve örtü zamanını planla':farm.stage==='Henüz ekmedim'?'Ekim penceresini tarla koşuluyla doğrula':'Sonraki ürün sırasını karşılaştır',orchard?'Ağaçların korunur; yağış, örtü ve su rekabetine göre bahçe tabanı seçenekleri karşılaştırılır.':'Önceki ürün, bitki ailesi, toprak ve su imkânı seçenekleri daraltır. Mevsim ortalaması kesin ekim günü vermez.',orchard?'Canlı örtüyü sonlandırmadan önce ağacın su ihtiyacını kontrol et.':'Ekimden önce toprak sıcaklığı / nemi ve 7 günlük havayı yeniden kontrol et.',inputs.previousCrop?'Yerel çeşit, rakım ve parselde ölçülen toprak koşulları eksik.':'Önceki ürün ve yerel çeşit bilgisi eklenmedi.',orchard?SEASON_SOURCES.orchard:SEASON_SOURCES.rotation,76);
 const soil=actions.find(a=>a.id==='soil'),planting=actions.find(a=>a.id==='planting');
 if(report&&inputs.nitrogen!=='unknown'){soil.why+=' Raporda beyan ettiğin azot düzeyi: '+({low:'düşük',adequate:'yeterli',high:'yüksek'}[inputs.nitrogen])+'.';if(inputs.nitrogen==='high'&&!heavy&&inputs.drainage!=='ponding')soil.title='Azot artırmadan ürün bazlı raporunu değerlendir';}
 if(!orchard&&inputs.sowingMonth===Number((chosen?.month||month||'').slice(5))){planting.title='Planladığın ekim ayı için tarla koşulunu doğrula';planting.why='Bu ayı ekim için sen seçtin; bu kayıt bir uygunluk onayı değildir. '+planting.why;planting.priority=89;}
 return {method:SEASON_METHOD,available:!!chosen,month:chosen?.month||month,scenario,hypothetical,signals,chosen,actions:actions.sort((a,b)=>b.priority-a.priority),rotation:rotationOptions(farm,inputs,signals),nearTerm:{available:!!weather.available,frost:!!cold,heavyRain:!!heavy},inputs,climate:nasa.available?nasa.months.find(m=>m.month===Number((chosen?.month||month||nextMonths(now)[0]).slice(5))):null,summary:!chosen?'Mevsimlik tahmin alınamadı; genel hazırlık adımları gösteriliyor.':hypothetical?'Seçtiğin koşullu senaryo; model tahmini değil.':`${chosen.temperature.direction==='warm'?'Daha sıcak':chosen.temperature.direction==='cold'?'Daha serin':'Sıcaklık yönü net değil'} · ${chosen.rain.direction==='dry'?'daha kurak':chosen.rain.direction==='wet'?'daha yağışlı':'yağış yönü net değil'}`};
}
