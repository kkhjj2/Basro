// BAS Social + BAS Progression (pilot): coğrafi topluluk akışı, tek dokunuşla gözlem, XP / seri / rütbe.
// Dürüstlük kuralı: akıştaki hazır gönderiler ÖRNEKTİR ve öyle etiketlenir. Senin cevapların, paylaşımların
// ve puanın gerçektir; şimdilik yalnızca bu cihazda saklanır (topluluk sunucusu pilot aşamasında).
const KEY='agrobas-social-v1';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today=()=>new Date().toISOString().slice(0,10);
const shift=(day,n)=>new Date(Date.parse(day+'T12:00:00Z')+n*864e5).toISOString().slice(0,10);

export const XP={task:20,allDaily:40,answer:10,post:10,evidence:30,photo:5};
// Seviye = floor(sqrt(XP/50))+1; adlar ürün planındaki sırayla.
export const LEVEL_NAMES=[['Fide','🌱'],['Filiz','🌿'],['Fidan','🪴'],['Ağaç','🌳'],['Orman','🌲'],['Usta','🌾'],['Veteran','🏅']];
export const levelOf=xp=>Math.floor(Math.sqrt(Math.max(0,xp)/50))+1;
const levelStart=l=>50*(l-1)**2;
const REGIONS={
 'Doğu Anadolu':['Malatya','Elazığ','Erzurum','Erzincan','Van','Ağrı','Kars','Ardahan','Iğdır','Muş','Bitlis','Bingöl','Tunceli','Hakkâri','Hakkari'],
 'Güneydoğu Anadolu':['Şanlıurfa','Gaziantep','Diyarbakır','Mardin','Adıyaman','Batman','Siirt','Şırnak','Kilis'],
 'İç Anadolu':['Ankara','Konya','Kayseri','Sivas','Eskişehir','Yozgat','Aksaray','Niğde','Nevşehir','Kırşehir','Kırıkkale','Karaman','Çankırı'],
 'Akdeniz':['Antalya','Adana','Mersin','Hatay','Kahramanmaraş','Osmaniye','Isparta','Burdur'],
 'Ege':['İzmir','Manisa','Aydın','Denizli','Muğla','Kütahya','Uşak','Afyonkarahisar'],
 'Marmara':['İstanbul','Bursa','Kocaeli','Sakarya','Balıkesir','Çanakkale','Tekirdağ','Edirne','Kırklareli','Yalova','Bilecik'],
 'Karadeniz':['Samsun','Trabzon','Ordu','Giresun','Rize','Artvin','Gümüşhane','Bayburt','Tokat','Amasya','Çorum','Sinop','Kastamonu','Bartın','Karabük','Zonguldak','Bolu','Düzce'],
};
export const regionOf=city=>Object.keys(REGIONS).find(r=>REGIONS[r].includes(city))||null;

function load(storage){try{const v=JSON.parse(storage.getItem(KEY)||'{}');return {log:v.log||{},answers:v.answers||{},posts:Array.isArray(v.posts)?v.posts:[],sources:Array.isArray(v.sources)?v.sources:[],mine:Array.isArray(v.mine)?v.mine:[],name:typeof v.name==='string'?v.name:'',consent:!!v.consent};}catch{return {log:{},answers:{},posts:[],sources:[],mine:[],name:'',consent:false};}}
function save(storage,v){try{storage.setItem(KEY,JSON.stringify(v));}catch{}}
const entry=(s,day)=>s.log[day]||(s.log[day]={tasks:0,answers:0,posts:0});

/** Bugün tamamlanan işleri günlüğe işler (yalnızca artar) ve ilerlemeyi döndürür. Saf hesap: progressOf. */
export function syncProgress(storage,work){
 const s=load(storage),d=today(),n=Object.values(work?.completedOn||{}).filter(v=>v===d).length,e=entry(s,d);
 if(n>e.tasks){e.tasks=n;save(storage,s);}
 return progressOf(s.log,d);
}
/** Doğrulanmış bir olay için XP (ör. kabul edilen fotoğraf kanıtı). Aynı kaynak (sourceId) iki kez ödüllendirilmez. */
export function awardXp(storage,amount,sourceId){
 const s=load(storage);s.sources=s.sources||[];
 if(sourceId&&s.sources.includes(sourceId))return 0;
 if(sourceId)s.sources=[...s.sources,sourceId].slice(-200);
 const e=entry(s,today());e.bonus=(e.bonus||0)+amount;save(storage,s);return amount;
}
export function progressOf(log,day=today()){
 let xp=0;for(const e of Object.values(log))xp+=(e.tasks||0)*XP.task+((e.tasks||0)>=3?XP.allDaily:0)+(e.answers||0)*XP.answer+(e.posts||0)*XP.post+(e.bonus||0);
 const active=d=>{const e=log[d];return !!e&&(e.tasks||e.answers||e.posts||e.bonus)>0;};
 let streak=0,d=active(day)?day:shift(day,-1);while(active(d)){streak++;d=shift(d,-1);}
 const level=levelOf(xp),[rank,icon]=LEVEL_NAMES[Math.min(level,LEVEL_NAMES.length)-1],a=levelStart(level),b=levelStart(level+1);
 return {xp,streak,level,rank,icon,next:{name:LEVEL_NAMES[Math.min(level+1,LEVEL_NAMES.length)-1][0],at:b,pct:Math.round(100*(xp-a)/(b-a))},today:log[day]||{tasks:0,answers:0,posts:0}};
}
export function progressChip(p){return `<span class="bs-chip-ico" aria-hidden="true">${p.icon}</span><span class="bs-chip-text"><strong>Seviye ${p.level} · ${esc(p.rank)}</strong><em>${p.xp} XP${p.streak?` · 🔥 ${p.streak} gün`:''}</em></span>`;}

/** Topluluk katmanları: ilçe → il → bölge → Türkiye. Küçük ilçe akışı il akışını da gösterir. */
export function scopesFor(farm){
 const r=regionOf(farm.city),out=[];
 if(farm.district)out.push({id:'district',name:farm.district});
 if(farm.city&&farm.city!==farm.district)out.push({id:'city',name:farm.city});
 if(r)out.push({id:'region',name:r});
 out.push({id:'country',name:farm.country||'Türkiye'});
 return out;
}
const O3=['Başladı','Başlamadı','Bilmiyorum'],YN=['Evet','Hayır','Bilmiyorum'];
/** Örnek gönderiler: ürüne ve aya göre seçilir; sayılar örnek dağılımdır. */
export function samplePosts(farm,month=new Date().getMonth()+1){
 const crop=['Diğer','Henüz seçmedim'].includes(farm.crop)?'Ürün':farm.crop,cold=[11,12,1,2,3].includes(month),hot=[6,7,8].includes(month);
 const d=farm.district||farm.city||'Bölge',c=farm.city||d;
 return [
  {id:'s-frost',scope:'district',who:'Hatice',place:d,text:cold?'Dün gece bizim bahçede kırağı vardı. Sizde don oldu mu?':'Bu hafta sabahları çiğ çok. Sizde yaprakta hastalık lekesi başladı mı?',options:cold?YN:O3,counts:cold?[7,4,2]:[3,8,2]},
  {id:'s-crop',scope:'district',who:'Mehmet',place:d,text:hot?`${crop} bizde olgunlaşmaya başladı, sizinkiler?`:cold?`${crop} tarlasında hasat sonrası temizliği yapan var mı?`:`${crop} bizde çiçek açtı, sizinkiler?`,options:O3,counts:[9,5,1]},
  {id:'s-rain',scope:'city',who:'Elif',place:c,text:'Son yağış toprağı bir karış ıslattı mı, yoksa üstte mi kaldı?',options:['Islattı','Üstte kaldı','Bilmiyorum'],counts:[12,15,4]},
  {id:'s-soil',scope:'city',who:'Ziraat Odası gönüllüsü',place:c,text:'Bu sonbahar toprak analizi yaptıran var mı? Sonuçlar geçen yıla göre nasıl?',options:['Yaptırdım','Yaptırmadım','Bilmiyorum'],counts:[6,21,3]},
  {id:'s-water',scope:'region',who:'İbrahim',place:regionOf(farm.city)||c,text:'Kuyularda su seviyesi geçen yıla göre düştü mü?',options:['Düştü','Aynı','Bilmiyorum'],counts:[31,12,9]},
  {id:'s-drip',scope:'country',who:'Zeynep',place:'Konya',text:'Damla sulamaya geçenler: su faturası gerçekten azaldı mı?',options:['Azaldı','Değişmedi','Bilmiyorum'],counts:[48,9,14]},
 ];
}
const ORDER=['district','city','region','country'];
/** Seçilen katmanın akışı. İlçe akışı azsa il gönderileri de eklenir (küçük ilçe kuralı). */
export function feedFor(scope,farm,own=[]){
 const all=[...own.map(p=>({...p,own:true})),...samplePosts(farm)];
 const idx=ORDER.indexOf(scope),mine=all.filter(p=>p.scope===scope);
 if(scope==='district')return [...mine,...all.filter(p=>p.scope==='city').map(p=>({...p,borrowed:true}))];
 return idx<0?all:mine;
}

export function ago(iso,now=Date.now()){const m=Math.max(0,Math.round((now-Date.parse(iso))/6e4));return m<1?'şimdi':m<60?m+' dk önce':m<1440?Math.round(m/60)+' sa önce':Math.round(m/1440)+' gün önce';}
const DEVICE_KEY='agrobas-device-v1';
/** Tarayıcıya özel rastgele anahtar: giriş olmadan "bu gönderi senin" diyebilmek için. Sunucu yalnızca özetini saklar. */
export function deviceKey(storage){
 try{let k=storage.getItem(DEVICE_KEY);if(!/^[A-Za-z0-9_-]{16,64}$/.test(k||'')){const a=new Uint8Array(24);crypto.getRandomValues(a);k=Array.from(a,x=>x.toString(16).padStart(2,'0')).join('');storage.setItem(DEVICE_KEY,k);}return k;}catch{return 'anon-device-0000000000';}
}
/** Fotoğrafı küçültüp yeniden kodlar (en uzun kenar 1280 px, JPEG). Yeniden kodlama konum bilgisini (EXIF) siler. */
export async function shrinkPhoto(file,max=1280){
 const bmp=await createImageBitmap(file),k=Math.min(1,max/Math.max(bmp.width,bmp.height)),c=document.createElement('canvas');
 c.width=Math.round(bmp.width*k);c.height=Math.round(bmp.height*k);c.getContext('2d').drawImage(bmp,0,0,c.width,c.height);
 return new Promise((ok,no)=>c.toBlob(b=>b?ok(b):no(Error('Fotoğraf işlenemedi.')),'image/jpeg',.82));
}
const heart='<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 20.5s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.6a4.3 4.3 0 0 1 7.5 2.9c0 5.4-7.5 10-7.5 10Z" fill="currentColor" fill-opacity="var(--f,0)" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>';
const bubble='<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M4.5 5.5h15v10h-8l-4.5 3.5v-3.5h-2.5z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>';
export function remoteHtml(p,mine,open=false){
 const chips=[p.crop?`<span>${esc(p.crop)}</span>`:'',p.heightCm!=null?`<span class="bs-h">Boy ${String(p.heightCm).replace('.',',')} cm</span>`:'',p.yieldKgDa!=null?`<span class="bs-y">Verim ${Number(p.yieldKgDa).toLocaleString('tr-TR')} kg/da</span>`:''].join('');
 return `<article class="farm-card bs-post bs-real" data-post="${esc(p.id)}"><header><span class="bs-avatar" aria-hidden="true">${esc((p.author||'A').slice(0,1).toLocaleUpperCase('tr'))}</span><div><strong>${esc(p.author)}${mine?' · sen':''}</strong><small>${esc(p.region||'Türkiye')} · ${esc(ago(p.createdAt))}</small></div>${mine?`<button class="bs-del" data-bs-del="${esc(p.id)}">Sil</button>`:''}</header>
 ${p.body?`<p>${esc(p.body)}</p>`:''}${chips?`<div class="bs-chips">${chips}</div>`:''}${p.photo?`<img class="bs-photo" src="/api/social/photo?id=${esc(p.id)}" alt="${esc(p.author)} adlı çiftçinin paylaştığı fotoğraf" loading="lazy">`:''}
 <div class="bs-actions"><button class="bs-act bs-like" data-bs-like="${esc(p.id)}" aria-pressed="${!!p.liked}" aria-label="Beğen">${heart}<span>${p.likes||0}</span></button><button class="bs-act" data-bs-talk="${esc(p.id)}" aria-expanded="${open}" aria-label="Yorumlar">${bubble}<span>${p.comments?.length||0}</span></button></div>
 ${open?`<div class="bs-comments">${(p.comments||[]).map(c=>`<div class="bs-comment"><span class="bs-avatar bs-avatar-s" aria-hidden="true">${esc((c.author||'A').slice(0,1).toLocaleUpperCase('tr'))}</span><div><strong>${esc(c.author)}${c.mine?' · sen':''} <small>${esc(ago(c.createdAt))}</small></strong><p>${esc(c.body)}</p></div>${c.mine?`<button class="bs-del" data-bs-del="${esc(c.id)}">Sil</button>`:''}</div>`).join('')||'<p class="bs-rules">İlk yorumu sen yaz.</p>'}<form class="bs-reply" data-bs-reply="${esc(p.id)}"><input class="farm-input" maxlength="300" required placeholder="Yorum yaz…" aria-label="Yorum yaz"><button class="farm-primary">Gönder</button></form></div>`:''}</article>`;
}
/** Ürün ustalığı: ürün bazında sıralama. Gerçek satır 3'ten azsa örnek satırlarla tamamlanır ve etiketlenir. */
export const MASTERY_SAMPLE=[['Ahmet',7400],['Bilal',6900],['Hatice',6350],['Memed',5800],['Elif',5200]];
export function masteryHtml(mastery,crop,active){
 const boards=[...(mastery||[])],names=boards.map(b=>b.crop);if(crop&&!['Diğer','Henüz seçmedim'].includes(crop)&&!names.some(n=>n.toLocaleLowerCase('tr')===crop.toLocaleLowerCase('tr')))boards.unshift({crop,metric:'yield',rows:[]});
 if(!boards.length)boards.push({crop:'Domates',metric:'yield',rows:[]});
 const cur=boards.find(b=>b.crop===active)||boards.find(b=>b.crop.toLocaleLowerCase('tr')===String(crop||'').toLocaleLowerCase('tr'))||boards[0],real=cur.rows;
 const sample=real.length>=3?[]:MASTERY_SAMPLE.slice(0,5-real.length).map(([author,value])=>({author,value:cur.metric==='yield'?value:Math.round(value/50)/10,sample:true}));
 const rows=[...real,...sample].sort((a,b)=>b.value-a.value).map((r,i)=>({...r,rank:i+1})),unit=cur.metric==='yield'?'kg/da':'cm/hafta',medal=['🥇','🥈','🥉'],titles=['ustası','kalfası','çırağı'];
 const f=v=>cur.metric==='yield'?Number(v).toLocaleString('tr-TR'):String(v).replace('.',',');
 return `<section class="farm-card bs-mastery" id="bs-mastery"><header class="fm-head"><div><span class="farm-eyebrow">ÜRÜN USTALIĞI</span><h2>${esc(cur.crop)} sıralaması</h2></div>${sample.length?'<span class="fm-soon tw-demo">Örnek satırlar var</span>':''}</header>
 ${boards.length>1?`<div class="bs-crops" role="tablist" aria-label="Ürün">${boards.slice(0,8).map(b=>`<button role="tab" aria-selected="${b===cur}" data-bs-crop="${esc(b.crop)}">${esc(b.crop)}</button>`).join('')}</div>`:''}
 <ol class="bs-rank-list">${rows.map(r=>`<li class="bs-rank-row${r.sample?' bs-grow-sample':''}${r.mine?' bs-rank-me':''}"><span class="bs-medal" aria-hidden="true">${medal[r.rank-1]||r.rank}</span><div><strong>${esc(r.author)}${r.mine?' · sen':''}</strong><small>${r.rank<=3?`${esc(cur.crop)} ${titles[r.rank-1]}`:`${r.rank}. sıra`}${r.region?' · '+esc(r.region):''}${r.sample?' · örnek':''}</small></div><b>${f(r.value)} ${unit}</b></li>`).join('')}</ol>
 <p class="fw-small">${cur.metric==='yield'?'Sıralama, çiftçilerin gönderilerinde bildirdiği son verime göredir.':'Bu üründe henüz verim bildiren yok; sıralama haftalık boy artışına göredir.'} Değerler kendi beyanındır ve doğrulanmaz; çeşit, toprak ve sulama farkı hesaba katılmaz. Hasattan sonra gönderine “verim” ekleyerek sıralamaya girersin.</p></section>`;
}
/** Haftalık gelişim tablosu. Gerçek ölçüm azsa örnek satırlar eklenir ve öyle etiketlenir. */
export function growthHtml(growth,crop){
 const real=(growth||[]).filter(g=>g.perWeek!=null),waiting=(growth||[]).filter(g=>g.perWeek==null);
 const sample=real.length>=2?[]:[{author:'Bilal',crop:crop||'Domates',perWeek:14,heightCm:54,sample:true},{author:'Memed',crop:crop||'Domates',perWeek:9.5,heightCm:47,sample:true},{author:'Hatice',crop:crop||'Domates',perWeek:6,heightCm:39,sample:true}];
 const rows=[...real,...sample].sort((a,b)=>b.perWeek-a.perWeek),top=Math.max(1,...rows.map(r=>Math.abs(r.perWeek)));
 const f=v=>String(v).replace('.',',');
 return `<section class="farm-card bs-growth" id="bs-growth"><header class="fm-head"><div><span class="farm-eyebrow">HAFTALIK GELİŞİM</span><h2>Kimin tarlası bu hafta ne kadar büyüdü?</h2></div>${sample.length?'<span class="fm-soon tw-demo">Örnek satırlar var</span>':''}</header>
 <div class="bs-grow-rows">${rows.map(r=>`<div class="bs-grow${r.sample?' bs-grow-sample':''}"><div><strong>${esc(r.author)}</strong><small>${esc(r.crop)}${r.region?' · '+esc(r.region):''} · boy ${f(r.heightCm)} cm${r.sample?' · örnek':r.days?` · ${r.days} günlük ölçüm`:''}</small></div><div class="bs-grow-bar"><i style="width:${Math.max(4,Math.round(100*Math.abs(r.perWeek)/top))}%"></i></div><b>${r.perWeek>0?'+':''}${f(r.perWeek)} cm/hafta</b></div>`).join('')}</div>
 ${waiting.length?`<p class="bs-rules">${waiting.map(w=>esc(w.author)).join(', ')}: ilk ölçüm girildi; en az bir gün sonra ikinci ölçümle hız hesaplanır.</p>`:''}
 <p class="fw-small">Gönderine "bitki boyu" ekle; sistem aynı ürün için son iki ölçümünden haftalık büyümeyi hesaplar. Bu bir boy karşılaştırmasıdır; verim tahmini değildir, çeşit ve ekim tarihi farkını hesaba katmaz.</p></section>`;
}
function postHtml(p,answers){
 const a=answers[p.id],counts=(p.counts||p.options?.map(()=>0)||[]).map((n,i)=>n+(a===i?1:0)),total=counts.reduce((s,n)=>s+n,0)||1;
 const tag=p.own?'<span class="bs-tag bs-own">Senin paylaşımın · bu cihazda</span>':'<span class="bs-tag">Örnek gönderi</span>';
 const body=p.options?(a===undefined
  ?`<div class="bs-options" role="group" aria-label="Tek dokunuşla gözlem">${p.options.map((o,i)=>`<button data-bs-answer="${esc(p.id)}" data-i="${i}">${esc(o)}</button>`).join('')}</div>`
  :`<div class="bs-result">${p.options.map((o,i)=>`<div class="bs-bar${a===i?' bs-mine':''}"><span>${esc(o)}${a===i?' · sen':''}</span><i style="width:${Math.round(100*counts[i]/total)}%"></i><b>${counts[i]}</b></div>`).join('')}<small>Cevabın gözlem olarak kaydedildi (+${XP.answer} XP). ${p.own?'':'Diğer sayılar örnek dağılımdır.'}</small></div>`):'';
 return `<article class="farm-card bs-post"><header><span class="bs-avatar" aria-hidden="true">${esc((p.who||'S').slice(0,1))}</span><div><strong>${esc(p.who)}</strong><small>${esc(p.place)}${p.borrowed?' · il akışından':''}</small></div>${tag}</header><p>${esc(p.text)}</p>${body}</article>`;
}

export function socialHtml(){return `<div class="bs" id="bas-social"></div>`;}
export function mountSocial(host,ctx){
 if(!host)return;
 const {farm,storage,work}=ctx,scopes=scopesFor(farm);let scope=scopes[0].id,remote=[],growth=[],mastery=[],rankCrop='',online=null,error='',photo=null,photoUrl='';const open=new Set(),dev=deviceKey(storage),hdr={'x-agrobas-device':dev};
 // Gerçek gönderiler Supabase'den (/api/social); ilçe sekmesi ilçeyi, diğerleri tüm akışı gösterir.
 const pull=async()=>{try{const r=await fetch(`/api/social?scope=${scope==='district'?'region':'all'}&region=${encodeURIComponent(farm.district||'')}`,{headers:hdr,signal:AbortSignal.timeout(12000)}),d=await r.json();online=!!d.configured;remote=Array.isArray(d.posts)?d.posts:[];growth=Array.isArray(d.growth)?d.growth:[];mastery=Array.isArray(d.mastery)?d.mastery:[];}catch{online=false;remote=[];growth=[];mastery=[];}if(host.isConnected)draw();};
 const draw=()=>{
  const s=load(storage),p=syncProgress(storage,work),feed=feedFor(scope,farm,s.posts.filter(x=>x.farmCity===farm.city||x.scope==='country'));
  host.innerHTML=`<div class="farm-intro"><div><span class="farm-eyebrow">BAS SOCIAL · PİLOT</span><h1>Komşun ne görüyor, <em>sen ne görüyorsun?</em></h1><p>Bir soruya tek dokunuşla cevap ver; cevabın tarlanın kaydına gözlem olarak düşer.</p></div></div>
  <section class="farm-card bs-progress" aria-label="İlerlemen"><div class="bs-rank"><span aria-hidden="true">${p.icon}</span><div><small>SEVİYE ${p.level}</small><strong>${esc(p.rank)}</strong></div></div><div class="bs-xp"><div class="bs-xp-top"><strong>${p.xp} XP</strong><span>Seviye ${p.level+1} için ${p.next.at-p.xp} XP kaldı</span></div><div class="bs-track"><i style="width:${p.next.pct}%"></i></div><small>Bugün: ${p.today.tasks} iş · ${p.today.answers} gözlem cevabı · ${p.today.posts} paylaşım</small></div><div class="bs-streak"><strong>🔥 ${p.streak}</strong><small>günlük seri</small></div></section>
  <p class="bs-rules">Günlük iş +${XP.task} XP · günün üç işi tamamsa +${XP.allDaily} · gözlem cevabı +${XP.answer} · paylaşım +${XP.post}</p>
  <div class="bs-scopes" role="tablist" aria-label="Topluluk katmanı">${scopes.map((x,i)=>`${i?'<span aria-hidden="true">→</span>':''}<button role="tab" aria-selected="${x.id===scope}" data-bs-scope="${x.id}">${esc(x.name)}</button>`).join('')}</div>
  <form class="farm-card bs-compose" id="bs-compose"><div class="bs-compose-top"><span class="bs-avatar" aria-hidden="true">${esc((s.name||'S').slice(0,1).toLocaleUpperCase('tr'))}</span><input class="farm-input bs-name" id="bs-name" maxlength="30" value="${esc(s.name)}" placeholder="Adın (gönderide görünür)" aria-label="Adın"></div><label class="farm-label bs-sr" for="bs-text">Tarlandan bir şey paylaş ya da komşularına sor</label><textarea class="farm-input" id="bs-text" maxlength="500" placeholder="Tarlanda ne var ne yok? Örn. Domatesler kızardı, sizinkiler?"></textarea>${photoUrl?`<div class="bs-preview"><img src="${photoUrl}" alt="Seçilen fotoğraf"><button type="button" id="bs-photo-x" aria-label="Fotoğrafı kaldır">×</button></div>`:''}<div class="bs-tools"><label class="bs-tool" for="bs-photo">📷 Fotoğraf<input type="file" id="bs-photo" accept="image/*" hidden></label><label class="bs-tool bs-height">📏 <input type="number" id="bs-height" min="1" max="1000" step="0.5" inputmode="decimal" placeholder="Bitki boyu (cm)" aria-label="Bitki boyu, santimetre"></label><label class="bs-tool bs-height">⚖️ <input type="number" id="bs-yield" min="1" max="50000" step="1" inputmode="numeric" placeholder="Verim (kg/da)" aria-label="Hasat verimi, dekar başına kilogram"></label><button class="farm-primary">Paylaş</button></div><div class="bs-compose-row"><div><label class="farm-checkline"><input type="checkbox" id="bs-consent"${s.consent?' checked':''}> Toplulukla paylaş: adım ve ilçem görünür, tarlamın konumu paylaşılmaz</label><label class="farm-checkline"><input type="checkbox" id="bs-ask"> Tek dokunuşluk soru olsun (yalnızca bu cihazda)</label></div></div><p class="farm-form-error" id="bs-error">${esc(error)}</p></form>
  ${masteryHtml(mastery,farm.crop,rankCrop)}${growthHtml(growth,farm.crop)}
  <div class="bs-feed">${remote.map(x=>remoteHtml(x,x.mine??s.mine.includes(x.id),open.has(x.id))).join('')}${feed.map(x=>postHtml(x,s.answers)).join('')||'<p class="bs-rules">Bu katmanda henüz gönderi yok.</p>'}</div>
  <p class="bs-panel-link"><a href="/mudur.html">İlçe / il müdürü paneli: bölgenin toplu görünümü →</a></p><p class="bs-note">${online?'Topluluk gönderileri gerçek veritabanına kaydedilir; henüz giriş sistemi yok: yazdığın ad görünür ve bir gönderiyi yalnızca yazıldığı cihaz silebilir.':online===false?'Topluluk sunucusuna şu an ulaşılamıyor; paylaşımların bu cihazda kalır.':''} “Örnek gönderi” etiketli sorular örnektir. Cevapların ve puanın gerçektir, bu cihazda saklanır. Beğeni ya da cevap sayısı bilimsel doğruluk demek değildir; kararlar ölçüm ve tahmine dayanır.</p>`;
  host.querySelectorAll('[data-bs-scope]').forEach(b=>b.addEventListener('click',()=>{scope=b.dataset.bsScope;draw();pull();}));
  host.querySelectorAll('[data-bs-del]').forEach(b=>b.addEventListener('click',async()=>{b.disabled=true;await fetch('/api/social?id='+encodeURIComponent(b.dataset.bsDel),{method:'DELETE',headers:hdr}).catch(()=>null);pull();}));
  const keep=()=>{const t=host.querySelector('#bs-text'),h=host.querySelector('#bs-height'),n=host.querySelector('#bs-name'),y=host.querySelector('#bs-yield');return {t:t?.value||'',h:h?.value||'',n:n?.value||'',y:y?.value||''};},put=v=>{host.querySelector('#bs-text').value=v.t;host.querySelector('#bs-height').value=v.h;host.querySelector('#bs-name').value=v.n;host.querySelector('#bs-yield').value=v.y;};
  host.querySelectorAll('[data-bs-crop]').forEach(b=>b.addEventListener('click',()=>{const v=keep();rankCrop=b.dataset.bsCrop;draw();put(v);}));
  const post=(payload)=>fetch('/api/social',{method:'POST',headers:{'Content-Type':'application/json',...hdr},body:JSON.stringify(payload)});
  host.querySelectorAll('[data-bs-like]').forEach(b=>b.addEventListener('click',async()=>{
   const p=remote.find(x=>x.id===b.dataset.bsLike);if(!p||b.disabled)return;b.disabled=true;
   const was=p.liked;p.liked=!was;p.likes=Math.max(0,(p.likes||0)+(was?-1:1));b.setAttribute('aria-pressed',String(p.liked));b.querySelector('span').textContent=p.likes;
   try{const r=await post({kind:'like',re:p.id});if(!r.ok)throw 0;}catch{p.liked=was;p.likes=Math.max(0,p.likes+(was?1:-1));b.setAttribute('aria-pressed',String(was));b.querySelector('span').textContent=p.likes;}
   b.disabled=false;
  }));
  host.querySelectorAll('[data-bs-talk]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.bsTalk,v=keep();open.has(id)?open.delete(id):open.add(id);draw();put(v);if(open.has(id))host.querySelector(`[data-bs-reply="${id}"] input`)?.focus();}));
  host.querySelectorAll('[data-bs-reply]').forEach(f=>f.addEventListener('submit',async e=>{
   e.preventDefault();const input=f.querySelector('input'),text=input.value.trim(),btn=f.querySelector('button');if(!text)return;
   const st=load(storage),name=(host.querySelector('#bs-name').value||st.name).trim();
   if(!st.consent&&!host.querySelector('#bs-consent').checked){error='Yorum yazmak için önce “Toplulukla paylaş” iznini işaretle.';const v=keep();draw();put(v);host.querySelector('#bs-consent').focus();return;}
   btn.disabled=true;
   try{const r=await post({kind:'comment',re:f.dataset.bsReply,body:text,name,consent:true}),d=await r.json();if(!r.ok)throw Error(d.error||'Yorum gönderilemedi.');st.consent=true;st.name=name;save(storage,st);error='';await pull();}
   catch(err){error=err.message;const v=keep();draw();put(v);}
  }));
  host.querySelector('#bs-photo').addEventListener('change',async e=>{
   const f=e.target.files?.[0];if(!f)return;const v=keep();
   try{photo=await shrinkPhoto(f);if(photoUrl)URL.revokeObjectURL(photoUrl);photoUrl=URL.createObjectURL(photo);error='';}catch{photo=null;photoUrl='';error='Fotoğraf okunamadı; başka bir fotoğraf dene.';}
   draw();put(v);
  });
  host.querySelector('#bs-photo-x')?.addEventListener('click',()=>{const v=keep();if(photoUrl)URL.revokeObjectURL(photoUrl);photo=null;photoUrl='';draw();put(v);});
  host.querySelectorAll('[data-bs-answer]').forEach(b=>b.addEventListener('click',()=>{
   const st=load(storage),id=b.dataset.bsAnswer,i=Number(b.dataset.i),post=feed.find(x=>x.id===id);if(!post||st.answers[id]!==undefined)return;
   st.answers[id]=i;entry(st,today()).answers++;save(storage,st);
   if(post.options[i]!=='Bilmiyorum')ctx.onObservation?.(`Topluluk sorusu: “${post.text}” → ${post.options[i]}`);
   if(host.isConnected)draw();ctx.onChange?.();
  }));
  host.querySelector('#bs-compose').addEventListener('submit',async e=>{
   e.preventDefault();const text=host.querySelector('#bs-text').value.trim(),height=host.querySelector('#bs-height').value,yieldKg=host.querySelector('#bs-yield').value,name=host.querySelector('#bs-name').value.trim();if(!text&&!photo)return;
   const share=host.querySelector('#bs-consent').checked,ask=host.querySelector('#bs-ask').checked,btn=e.target.querySelector('button.farm-primary');error='';
   if((photo||height||yieldKg)&&!share){error='Fotoğraf ya da ölçüm paylaşmak için “Toplulukla paylaş” iznini işaretle.';const v=keep();draw();put(v);return;}
   if(share&&!ask){
    btn.disabled=true;btn.textContent='Paylaşılıyor…';
    try{const fd=new FormData();for(const [k,v] of Object.entries({kind:'post',body:text.slice(0,500),consent:'true',name,district:farm.district||'',city:farm.city||'',lat:farm.lat,lon:farm.lon,crop:['Diğer','Henüz seçmedim'].includes(farm.crop)?'':farm.crop||'',heightCm:height,yieldKgDa:yieldKg}))fd.append(k,String(v??''));if(photo)fd.append('photo',photo,'foto.jpg');
     const r=await fetch('/api/social',{method:'POST',headers:hdr,body:fd}),d=await r.json();
     if(!r.ok)throw Error(d.error||'Gönderi paylaşılamadı.');
     const st=load(storage);st.name=name;st.consent=true;entry(st,today()).posts++;save(storage,st);if(photoUrl)URL.revokeObjectURL(photoUrl);photo=null;photoUrl='';ctx.onChange?.();await pull();return;
    }catch(err){error=err.message+(text?' Yazın bu cihaza kaydedildi.':'');if(!text){const v=keep();draw();put(v);return;}}
   }
   const st=load(storage);st.posts.unshift({id:'p_'+Date.now().toString(36),scope,who:'Sen',place:scopes.find(x=>x.id===scope).name,farmCity:farm.city,text:text.slice(0,240),options:ask?O3:null,counts:ask?[0,0,0]:null,day:today()});
   st.posts=st.posts.slice(0,50);entry(st,today()).posts++;save(storage,st);draw();ctx.onChange?.();
  });
 };
 draw();pull();
}
