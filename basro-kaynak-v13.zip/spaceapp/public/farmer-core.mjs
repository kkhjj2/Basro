import {normalizeCropName} from './crop-catalog.mjs';
export {CROPS} from './crop-catalog.mjs';
export const STAGES=['Henüz ekmedim','Yeni ekim / dikim','Yapraklanma / büyüme','Çiçeklenme','Meyve / dane gelişimi','Hasat','Hasat sonrası','Emin değilim'];
export const GOALS={weather:'Hava ve don',health:'Bitki sağlığı',water:'Sulama',soil:'Toprak ve besleme',planning:'Ne ekeceğime karar vermek'};
export function dayKey(date=new Date(),timeZone='Europe/Istanbul'){const p=Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date).filter(x=>x.type!=='literal').map(x=>[x.type,x.value]));return `${p.year}-${p.month}-${p.day}`;}
export function plusDay(day,n=1){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);}
export function normalizeFarm(f){
 const crop=normalizeCropName(f?.crop);
 if(!f||typeof f!=='object'||!Number.isFinite(f.lat)||Math.abs(f.lat)>90||!Number.isFinite(f.lon)||Math.abs(f.lon)>180||typeof f.id!=='string'||!/^farm_[a-z0-9-]+$/.test(f.id)||!crop)return null;
 const clean={id:f.id,lat:f.lat,lon:f.lon,crop,stage:STAGES.includes(f.stage)?f.stage:'Emin değilim',district:String(f.district||'Seçili bölge').slice(0,70),city:String(f.city||'Malatya').slice(0,70),country:String(f.country||'Türkiye').slice(0,70),name:String(f.name||'Tarlam').slice(0,60),water:['var','yok','kısıtlı'].includes(f.water)?f.water:'var',goal:GOALS[f.goal]?f.goal:'health',locationKind:f.locationKind==='field'?'field':'district',createdAt:typeof f.createdAt==='string'?f.createdAt.slice(0,30):new Date().toISOString()};
 clean.landId=typeof f.landId==='string'&&/^farm_[a-z0-9-]+$/.test(f.landId)?f.landId:f.id;
 if(Number.isFinite(f.area)&&f.area>0&&f.area<=100000)clean.area=f.area;
 if(Number.isFinite(f.ph)&&f.ph>=0&&f.ph<=14)clean.ph=f.ph;
 if(Number.isFinite(f.organic)&&f.organic>=0&&f.organic<=100)clean.organic=f.organic;
 return clean;
}
// Each cultivation retains its own ID so existing tasks, notes and chats stay attached to that crop.
export function normalizePortfolio(value){
 const rows=Array.isArray(value?.farms)?value.farms:value?.farm?[value.farm]:[],seen=new Set(),farms=[];
 for(const row of rows.slice(0,100)){const f=normalizeFarm(row);if(f&&!seen.has(f.id)){seen.add(f.id);farms.push(f);}}
 return {version:2,farms,activeFarmId:farms.some(f=>f.id===value?.activeFarmId)?value.activeFarmId:farms[0]?.id||null};
}
export function upsertFarm(farms,value,sharedKeys=[]){
 const next=normalizeFarm(value);if(!next)return farms;
 const allowed=['name','lat','lon','district','city','country','locationKind','ph','organic'],share=sharedKeys.filter(k=>allowed.includes(k));
 const updated=farms.map(f=>{
  if(f.id===next.id)return next;
  if(f.landId!==next.landId||!share.length)return f;
  const sibling={...f};for(const key of share){if(Object.hasOwn(next,key))sibling[key]=next[key];else delete sibling[key];}return normalizeFarm(sibling);
 });
 if(!updated.some(f=>f.id===next.id)&&updated.length<100)updated.push(next);
 return updated;
}
export function weatherParams(lat,lon){return new URLSearchParams({latitude:String(lat),longitude:String(lon),current:'temperature_2m,apparent_temperature,weather_code,is_day,wind_speed_10m',daily:'weather_code,temperature_2m_min,temperature_2m_max,precipitation_sum,precipitation_probability_max,wind_speed_10m_max',temperature_unit:'celsius',wind_speed_unit:'kmh',precipitation_unit:'mm',timezone:'auto',forecast_days:'7'});}
export function weatherCondition(code,isDay=1){
 const clear=isDay===0?'☾':isDay===1?'☀':'◌';
 if(code===0)return {label:'Açık',icon:clear};
 if(code===1)return {label:'Az bulutlu',icon:isDay===0?'☾':'🌤'};
 if(code===2)return {label:'Parçalı bulutlu',icon:isDay===0?'☁':'⛅'};
 if(code===3)return {label:'Çok bulutlu',icon:'☁'};
 if([45,48].includes(code))return {label:code===48?'Kırağılı sis':'Sisli',icon:'🌫'};
 if([51,53,55].includes(code))return {label:code===51?'Hafif çisenti':'Çisentili',icon:'🌦'};
 if([56,57,66,67].includes(code))return {label:'Donan yağış',icon:'🌧'};
 if([61,63,65].includes(code))return {label:code===61?'Hafif yağmurlu':code===65?'Kuvvetli yağmurlu':'Yağmurlu',icon:'🌧'};
 if([71,73,75,77].includes(code))return {label:code===71?'Hafif kar yağışlı':code===75?'Yoğun kar yağışlı':'Kar yağışlı',icon:'❄'};
 if([80,81,82].includes(code))return {label:code===82?'Kuvvetli sağanak':'Sağanak yağışlı',icon:'🌦'};
 if([85,86].includes(code))return {label:'Kar sağanaklı',icon:'🌨'};
 if([95,96,97,99].includes(code))return {label:[96,99].includes(code)?'Gök gürültülü ve dolulu':'Gök gürültülü',icon:'⛈'};
 return {label:'Gökyüzü bilgisi yok',icon:'—'};
}
export function weatherSummary(raw,today=null,now=new Date()){
 try{today??=dayKey(now,raw?.timezone||'Europe/Istanbul');}catch{return {available:false,reason:'Hava saat dilimi doğrulanamadı.'};}
 const d=raw?.daily;if(!Array.isArray(d?.time)||!d.time.length)return {available:false,reason:'Hava bilgisi şu an alınamadı.'};
 const start=d.time.indexOf(today);if(start<0)return {available:false,reason:'Güncel hava bilgisi doğrulanamadı.'};
 if((raw.daily_units?.temperature_2m_min&&raw.daily_units.temperature_2m_min!=='°C')||(raw.daily_units?.precipitation_sum&&raw.daily_units.precipitation_sum!=='mm')||(raw.daily_units?.wind_speed_10m_max&&raw.daily_units.wind_speed_10m_max!=='km/h'))return {available:false,reason:'Hava birimleri doğrulanamadı.'};
 const rows=d.time.slice(start,start+7).map((date,i)=>{const k=start+i,probability=d.precipitation_probability_max?.[k];return {date,min:d.temperature_2m_min?.[k],max:d.temperature_2m_max?.[k],rain:d.precipitation_sum?.[k],rainProbability:Number.isFinite(probability)&&probability>=0&&probability<=100?probability:null,wind:d.wind_speed_10m_max?.[k],code:Number.isInteger(d.weather_code?.[k])?d.weather_code[k]:null};});
 if(!rows.length||rows.some(r=>![r.min,r.max,r.rain,r.wind].every(Number.isFinite)))return {available:false,reason:'Hava kaydında eksik değer var.'};
 const frost=rows.slice(0,3).find(r=>r.min<=0),rain=rows.slice(0,3).find(r=>r.rain>=5),wind=rows.slice(0,2).find(r=>r.wind>=25);
 const c=raw.current,stamp=typeof c?.time==='string'&&/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/.test(c.time)&&Number.isFinite(raw.utc_offset_seconds)?Date.parse(c.time+'Z')-raw.utc_offset_seconds*1000:NaN,age=now.getTime()-stamp;
 const current=Number.isFinite(stamp)&&age>=-900000&&age<=5400000&&c.time.slice(0,10)===today&&Number.isFinite(c.temperature_2m)&&raw.current_units?.temperature_2m==='°C'?{time:c.time,temperature:c.temperature_2m,apparent:Number.isFinite(c.apparent_temperature)&&raw.current_units?.apparent_temperature==='°C'?c.apparent_temperature:null,code:Number.isInteger(c.weather_code)?c.weather_code:null,isDay:[0,1].includes(c.is_day)?c.is_day:null,wind:Number.isFinite(c.wind_speed_10m)&&raw.current_units?.wind_speed_10m==='km/h'?c.wind_speed_10m:null}:null;
 return {available:true,rows,current,frost:!!frost,frostDay:frost?.date,rain:!!rain,wind:!!wind,today:rows[0],timezone:raw.timezone||'Europe/Istanbul',source:'Open-Meteo',fetchedAt:now.toISOString()};
}
export function buildWorklist(farm,weather,notes=[],state={},date=new Date(),seasonPlan=null){
 const today=dayKey(date),week=plusDay(today,-((new Date(today+'T12:00:00Z').getUTCDay()+6)%7)),tasks=[];
 const add=(id,title,why,priority,action='note',cadence='daily')=>tasks.push({id,title,why,priority,action,cadence,key:`${farm.id}|${cadence==='weekly'?week:cadence==='monthly'?today.slice(0,7):today}|${id}`});
 if(farm.locationKind!=='field')add('locate','Tarlanı haritada işaretle','Şimdilik ilçe merkezini kullanıyoruz. Bahçene yaklaştıkça hava kontrolü daha anlamlı olur.',100,'profile','weekly');
 if(weather.available&&weather.frost)add('frost','Soğuk geceye hazırlan','Önümüzdeki üç geceden biri sıfır derece veya altına inebilir. Yerel uyarıyı, ürün evresini ve kendi ölçümünü birlikte kontrol et.',110,'frost');
 if(!weather.available&&weather.error)add('weather','Bugünkü yerel hava uyarısını kontrol et','Canlı hava verisine ulaşamadık. MGM veya bölgenin resmî hava kaynağına bak.',85,'weather');
 if(farm.stage==='Emin değilim')add('stage','Ürünün hangi dönemde olduğunu birlikte bulalım','Yakından ve genel görünümden fotoğraf ekleyebilirsin. Böylece öneriler ürününün dönemine daha uygun olur.',88,'photo','weekly');
 if(farm.goal==='soil'&&farm.ph===undefined)add('soil','Toprak analizini hazırlamaya bir adım ayır','Besleme önerisi için yalnız toprak rengi yetmez. Mevcut analizini bul veya numune alma koşullarını laboratuvara sor.',84,'soil','weekly');
 if(farm.goal==='water'||farm.water!=='var')add('water','Sulamadan önce toprağı kontrol et','Kök bölgesindeki nemi ve son sulama kaydını karşılaştır. Yalnız havaya bakarak sulama miktarı belirleme.',82,'water');
 if(farm.goal==='planning')add('cropplan','Ekim kararında önce su ve toprağı konuşalım','Sulama imkânın, önceki ürün ve analiz bilgilerinle seçenekleri daraltabiliriz.',80,'planning','weekly');
 const lastPhoto=notes.filter(n=>n.farmId===farm.id&&n.type==='photo').at(-1),daysSince=lastPhoto?Math.floor((new Date(today+'T12:00:00Z')-new Date(lastPhoto.day+'T12:00:00Z'))/86400000):999;
 if(daysSince>=7||lastPhoto?.day===today)add('photo','Ürünün bu haftaki hâlini fotoğrafla','Aynı noktadan çekilen fotoğraflar değişimi fark etmeyi kolaylaştırır. Önceki kaydınla karşılaştırabilirsin.',farm.goal==='health'?83:65,'photo','weekly');
 add('scout',farm.crop==='Henüz seçmedim'?'Arsanın mevcut durumuna kısa bir göz at':farm.crop+' için kısa bir saha turu yap',farm.crop==='Henüz seçmedim'?'Suya erişimi, arazinin eğimini ve önceki kullanımı bir notla kaydet.':'Birkaç farklı noktada yaprağa, sürgüne ve toprağa bak. Yeni bir değişim görürsen fotoğrafla ve not düş.',68,'note');
 add('records','Son yaptığın işi bir cümleyle kaydet','Sulama, gübreleme veya bakımın tarihi sonraki önerileri daha anlamlı yapar.',60,'note');
 add('review','Bu haftanın kayıtlarına göz at','Tamamlanan işleri ve sürüp giden belirtileri birlikte gözden geçir.',35,'journal','weekly');
 if(seasonPlan?.available&&!seasonPlan.hypothetical)for(const a of seasonPlan.actions.slice(0,2))add('season_'+a.id,a.title,a.why+' '+a.next,Math.min(a.priority,95),'season','monthly');
 const custom=Array.isArray(state.custom)?state.custom.filter(t=>t.farmId===farm.id&&(!t.day||t.day<=today)).slice(0,20):[];
 for(const t of custom)tasks.push({id:t.id,title:t.title,why:'Kendi eklediğin iş.',priority:90,action:t.action||'note',cadence:'once',key:`${farm.id}|${t.day||today}|${t.id}`});
 return tasks.map(t=>({...t,done:!!state.done?.[t.key],snoozed:state.snoozed?.[t.key]>today})).sort((a,b)=>Number(a.done)-Number(b.done)||b.priority-a.priority);
}
export function regionalHint(f){const source='https://malatya.tarimorman.gov.tr/Haber/111/Hekimhan-Cevizi-Calismalari%E2%80%A6';const hints={'Doğanşehir':{crop:'Elma',text:'Doğanşehir, elma üretimiyle öne çıkan ilçelerden. Bahçenin yüksekliği, eğimi ve çeşidi kendi takibini belirler.'},'Yeşilyurt':{crop:'Kiraz',text:'Yeşilyurt, kirazıyla tanınır. Çiçeklenme dönemini ve bahçendeki gece sıcaklığını birlikte izleyelim.'},'Arapgir':{crop:'Üzüm',text:'Arapgir, üzüm üretimiyle tanınır. Bağının çeşidini ve gelişme dönemini kaydetmek takibi kolaylaştırır.'},'Hekimhan':{crop:'Ceviz',text:'Hekimhan, ceviz üretimiyle tanınır. Çeşit ve bahçenin konumu öneriler için önemlidir.'}};return hints[f.district]?{...hints[f.district],source}:null;}
