// Haftalık rapor (report-1.0): önce belirlenimci "olgular" çıkarılır; yapay zekâ yalnızca bu olguları sade Türkçeye çevirir.
// Denetçi: metinde olgularda geçmeyen bir sayı varsa metin reddedilir ve olgulardan kurulan yedek metin kullanılır.
import {evaluateWater,ACTION_TEXT} from './field-engine.mjs';
export const REPORT_VERSION='report-1.0';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const n=(v,d=0)=>Number(v).toFixed(d).replace('.',',');
export const weekKey=(d=new Date())=>{const t=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()));const day=(t.getUTCDay()+6)%7;t.setUTCDate(t.getUTCDate()-day);return t.toISOString().slice(0,10);};

/** Olgular: {id, text, source}. Her cümle hesaplanmış bir değerden gelir; kaynak yanında durur. */
export function buildReportFacts({farm,state,weather,season,notes=[],history=[],gaps=[],soil=null,today=new Date().toISOString().slice(0,10)}){
 const facts=[],weekStart=weekKey(new Date(today+'T12:00:00Z'));
 const w=evaluateWater(state);
 facts.push({id:'crop',text:`Ürün ${farm.crop}, dönem ${state.stage}.`,source:'Tarla profili'});
 facts.push({id:'water',text:`Su kararı: ${ACTION_TEXT[w.action].title}.${w.availablePct!=null?` Kök bölgesinde kullanılabilir suyun yaklaşık %${n(w.availablePct)} kadarı var.`:''}`,source:'FAO-56 su dengesi'});
 if(w.etc7!=null)facts.push({id:'demand',text:`Önümüzdeki 7 günde bitkinin su ihtiyacı yaklaşık ${n(w.etc7,1)} mm, beklenen etkili yağış ${n(w.rain7,1)} mm.`,source:'Open-Meteo tahmini + Hargreaves'});
 if(weather?.available){
  const rows=weather.rows,min=Math.min(...rows.map(r=>r.min)),max=Math.max(...rows.map(r=>r.max)),rain=rows.reduce((s,r)=>s+r.rain,0),frost=rows.filter(r=>r.min<=0).length;
  facts.push({id:'weather',text:`7 günlük tahmin: en düşük ${n(min)} °C, en yüksek ${n(max)} °C, toplam yağış ${n(rain,1)} mm.`,source:'Open-Meteo'});
  if(frost)facts.push({id:'frost',text:`${frost} gecede 0 °C ve altı bekleniyor.`,source:'Open-Meteo'});
 }else facts.push({id:'weather',text:'Bu hafta hava tahmini alınamadı.',source:'Open-Meteo'});
 const m=season?.available?season.months?.[0]:null;
 if(m){const t={warm:'normalden sıcak',cold:'normalden soğuk',mixed:'sıcaklıkta net eğilim yok'}[m.temperature.direction],r={dry:'kurak eğilim',wet:'yağışlı eğilim',mixed:'yağışta net eğilim yok'}[m.rain.direction];facts.push({id:'season',text:`Gelecek ay için mevsimlik öngörü: ${t}, ${r}.`,source:'ECMWF SEAS5 (model uyumu, kesin tahmin değil)'});}
 const week=notes.filter(x=>x.farmId===farm.id&&x.day>=weekStart),photos=week.filter(x=>x.type==='photo').length;
 facts.push({id:'records',text:week.length?`Bu hafta ${week.length} kayıt girdin${photos?`, ${photos} tanesi fotoğraf incelemesi`:''}.`:'Bu hafta tarla kaydı girilmedi.',source:'Kayıtlarım'});
 const changes=history.filter(h=>h.day>=weekStart),flips=changes.filter(h=>h.change?.decisionChanged);
 if(changes.length)facts.push({id:'changes',text:flips.length?`Eklediğin bilgi su kararını değiştirdi: ${flips.at(-1).change.before} → ${flips.at(-1).change.after}.`:`Bu hafta ${changes.length} yeni bilgi ekledin; su kararı aynı kaldı.`,source:'Tarla çalışma alanı'});
 if(soil?.text)facts.push(soil);
 if(gaps[0])facts.push({id:'gap',text:`En değerli eksik bilgi: ${gaps[0].title}`,source:'Gözlem ağı önceliği'});
 return {version:REPORT_VERSION,week:weekStart,facts};
}
const nums=s=>(String(s).match(/\d+(?:[.,]\d+)?/g)||[]).map(x=>x.replace(',','.'));
/** Metindeki her sayı olgularda geçmeli. Geçmeyen varsa döndürür. */
export function unsupportedNumbers(report,facts){
 const allowed=new Set(facts.flatMap(f=>nums(f.text)));
 const text=[report.headline,...(report.what_happened||[]),...(report.what_to_do||[]),...(report.watch_out||[])].join(' ');
 return nums(text).filter(x=>!allowed.has(x));
}
const DOSE=/(?<![\p{L}\d])\d+(?:[.,]\d+)?\s*(?:kg|gram|gr|g|litre|lt|ml|cc)(?![\p{L}])/iu;
/** Yapay zekâ çıktısını doğrular; geçmezse nedenini söyler. */
export function checkReport(report,facts){
 if(!report||typeof report.headline!=='string'||!Array.isArray(report.what_happened)||!Array.isArray(report.what_to_do))return 'format';
 if(report.what_to_do.length>3)return 'too_many_steps';
 const text=JSON.stringify(report);
 if(DOSE.test(text))return 'dose';
 if(unsupportedNumbers(report,facts).length)return 'number';
 return null;
}
/** Yedek metin: yalnızca olgulardan, yapay zekâsız. */
export function fallbackReport(facts){
 const by=Object.fromEntries(facts.map(f=>[f.id,f.text]));
 const todo=[];if(by.gap)todo.push(by.gap.replace('En değerli eksik bilgi: ','Şu bilgiyi topla: '));if(by.frost)todo.push('Don beklenen geceler için hazırlığını gözden geçir.');if(!todo.length)todo.push('Olağan kontrolünü sürdür ve gördüğünü kaydet.');
 const [head,...rest]=(by.water||'Haftalık tarla özeti.').split(/(?<=\.)\s+/);
 return {headline:head.replace(/\.$/,''),what_happened:[rest.join(' '),by.weather,by.demand,by.soil,by.records,by.changes].filter(Boolean),what_to_do:todo.slice(0,3),watch_out:[by.frost,by.season].filter(Boolean)};
}
export function reportHtml(r){
 if(!r)return `<section class="farm-card wr" id="weekly-report"><div><span class="farm-eyebrow">HAFTALIK RAPOR</span><h2>Bu haftanın özeti hazır değil.</h2><p>Hava, su hesabı, kayıtların ve mevsimlik öngörü tek sayfada, sade Türkçeyle.</p></div><button class="farm-primary" data-wr-make>Raporu hazırla →</button></section>`;
 const li=a=>(a||[]).map(x=>`<li>${esc(x)}</li>`).join('');
 return `<section class="farm-card wr wr-ready" id="weekly-report"><header class="fm-head"><div><span class="farm-eyebrow">HAFTALIK RAPOR · ${esc(r.week)} HAFTASI</span><h2>${esc(r.report.headline)}</h2></div><span class="fm-soon">${r.writer==='ai'?'Yapay zekâ yazdı · olgular hesaplandı':'Olgulardan kuruldu'}</span></header>
 <div class="wr-cols"><div><h3>Ne oldu?</h3><ul>${li(r.report.what_happened)}</ul></div><div><h3>Ne yapmalı?</h3><ul>${li(r.report.what_to_do)}</ul></div>${r.report.watch_out?.length?`<div><h3>Dikkat</h3><ul>${li(r.report.watch_out)}</ul></div>`:''}</div>
 <details class="fw-ranked"><summary>Kullanılan veriler (${r.facts.length})</summary><ul>${r.facts.map(f=>`<li>${esc(f.text)} <span class="fw-tag fw-tag-model">${esc(f.source)}</span></li>`).join('')}</ul><p class="fw-small">Metindeki her sayı bu listeden gelir; listede olmayan sayı içeren metin reddedilir. ${esc(REPORT_VERSION)}${r.model?' · '+esc(r.model):''}</p></details>
 <button class="farm-quiet-btn" data-wr-make>Yeniden hazırla</button></section>`;
}
const KEY='agrobas-report-v1';
export function mountReport(host,ctx){
 if(!host)return;
 const read=()=>{try{return (JSON.parse(ctx.storage.getItem(KEY)||'{}')||{})[ctx.farm.id]||null;}catch{return null;}};
 const write=v=>{try{const all=JSON.parse(ctx.storage.getItem(KEY)||'{}')||{};all[ctx.farm.id]=v;ctx.storage.setItem(KEY,JSON.stringify(all));}catch{}};
 const draw=()=>{const cur=read(),show=cur&&cur.week===weekKey()?cur:null;host.innerHTML=reportHtml(show);host.querySelector('[data-wr-make]')?.addEventListener('click',make);};
 const make=async e=>{
  const b=e.currentTarget;b.disabled=true;b.textContent='Hazırlanıyor…';
  const {week,facts}=await ctx.getFacts();let report=null,writer='facts',model=null;
  try{const r=await fetch('/api/report',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({facts,lang:window.BASRO_LANG||'tr'}),signal:AbortSignal.timeout(60000)}),d=await r.json();if(r.ok&&d.report&&!checkReport(d.report,facts)){report=d.report;writer='ai';model=d.model;}}catch{}
  if(!report)report=fallbackReport(facts);
  write({week,facts,report,writer,model,createdAt:new Date().toISOString()});if(host.isConnected)draw();
 };
 draw();
}
