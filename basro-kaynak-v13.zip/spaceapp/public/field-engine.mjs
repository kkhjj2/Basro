// Basro 2.0 tarla motoru: tek tarla durumu → su kararı → hangi bilginin kararı değiştireceği → ne değişti.
// Saf fonksiyonlar; tarayıcıda ve testte aynı çalışır. Yöntem: FAO-56 kök bölgesi su dengesi (Allen ve ark. 1998).
import {cropFamily} from './crop-catalog.mjs';

export const ENGINE_VERSION='field-engine-1';

// FAO-56 Tablo 19 aralık ortaları (m³/m³). Çiftçi dilinde adlar.
export const SOILS={
 kumlu:{label:'Kumlu (avuçta dağılır)',fc:0.15,wp:0.06},
 tinli:{label:'Tınlı (avuçta şekil alır, yapışmaz)',fc:0.27,wp:0.12},
 killi_tin:{label:'Killi tın (hafif yapışır)',fc:0.34,wp:0.20},
 killi:{label:'Killi (çok yapışır, parlar)',fc:0.40,wp:0.25}
};
const SOIL_PRIOR={kumlu:0.15,tinli:0.35,killi_tin:0.35,killi:0.15};

// Gelişme dönemine göre bitki katsayısı (FAO-56 Tablo 12 genellemesi) — dönem bilinmiyorsa aday olur.
export const STAGE_KC={'Henüz ekmedim':0.3,'Yeni ekim / dikim':0.5,'Yapraklanma / büyüme':0.8,'Çiçeklenme':1.05,'Meyve / dane gelişimi':1.1,'Hasat':0.8,'Hasat sonrası':0.3};
const STAGE_PRIOR={'Yeni ekim / dikim':0.2,'Yapraklanma / büyüme':0.3,'Çiçeklenme':0.15,'Meyve / dane gelişimi':0.25,'Hasat':0.1};
const ORCHARD_KC={'Henüz ekmedim':0.4,'Yeni ekim / dikim':0.5,'Yapraklanma / büyüme':0.75,'Çiçeklenme':0.9,'Meyve / dane gelişimi':0.95,'Hasat':0.85,'Hasat sonrası':0.6};

// Elle yoklama (20 cm): yarayışlı suyun yaklaşık oranı (USDA "feel and appearance" yöntemi).
export const FEEL={
 kuru:{label:'Kuru, toz gibi dağılıyor',fraction:0.15},
 az_nemli:{label:'Biraz nemli, top olmuyor',fraction:0.4},
 nemli:{label:'Nemli, top oluyor',fraction:0.7},
 islak:{label:'Islak, elde su bırakıyor',fraction:0.95}
};
const FEEL_PRIOR={kuru:0.25,az_nemli:0.3,nemli:0.3,islak:0.15};
export const IRRIGATION_ANSWERS=[{days:1,label:'Dün ya da bugün',p:0.25},{days:3,label:'2–4 gün önce',p:0.3},{days:6,label:'5–7 gün önce',p:0.25},{days:14,label:'Bir haftadan uzun',p:0.2}];

export function cropParams(crop){
 const fam=cropFamily(crop);
 if(fam==='orchard'||fam==='bush')return {family:fam,rootM:1.2,p:0.5,kcTable:ORCHARD_KC};
 if(fam==='grain')return {family:fam,rootM:1.0,p:0.55,kcTable:STAGE_KC};
 return {family:fam,rootM:0.6,p:0.4,kcTable:STAGE_KC};
}

const round=(v,d=0)=>Number.isFinite(v)?Number(v.toFixed(d)):null;

// FAO-56 Denklem 21 ve 52 (Hargreaves) — Open-Meteo günlük min/max'tan ET₀ (mm/gün).
export function et0Hargreaves(tmin,tmax,latDeg,dateStr){
 const d=new Date(dateStr+'T00:00:00Z'),start=Date.UTC(d.getUTCFullYear(),0,0),J=Math.floor((d-start)/86400000);
 const phi=latDeg*Math.PI/180,dr=1+0.033*Math.cos(2*Math.PI*J/365),delta=0.409*Math.sin(2*Math.PI*J/365-1.39);
 const ws=Math.acos(Math.max(-1,Math.min(1,-Math.tan(phi)*Math.tan(delta))));
 const Ra=24*60/Math.PI*0.082*dr*(ws*Math.sin(phi)*Math.sin(delta)+Math.cos(phi)*Math.cos(delta)*Math.sin(ws));
 const tmean=(tmin+tmax)/2;return Math.max(0,0.0023*(tmean+17.8)*Math.sqrt(Math.max(0,tmax-tmin))*0.408*Ra);
}

/**
 * Tarla durumu: her değer kaynağıyla. state = {
 *  crop, stage, water ('var'|'yok'|'kısıtlı'), lat,
 *  soil: {value, source:'farmer'|'unknown'},
 *  moisture: {kind:'feel', value} | {kind:'smap', theta, recordedDay} | null,
 *  weather: [{date,min,max,rain}] (7 gün) | null,
 *  lastIrrigationDays: number|null
 * }
 */
export function evaluateWater(state){
 const cp=cropParams(state.crop),notes=[];
 const soilKey=state.soil?.value&&SOILS[state.soil.value]?state.soil.value:'killi_tin',soil=SOILS[soilKey];
 const kc=cp.kcTable[state.stage]??null;
 const TAW=(soil.fc-soil.wp)*cp.rootM*1000,RAW=cp.p*TAW;
 // Ortalama günlük bitki su ihtiyacı (sulama tahmini için)
 const rows0=Array.isArray(state.weather)?state.weather.slice(0,7):[];
 const etcDay=kc!==null&&rows0.length?rows0.reduce((s,r)=>s+kc*et0Hargreaves(r.min,r.max,state.lat??38,r.date),0)/rows0.length:null;
 // Başlangıç tükenmesi (Dr0, mm). Öncelik: elle yoklama > son 7 gündeki sulama > SMAP model hücresi.
 let Dr0=null,moistureSource=null;
 if(state.moisture?.kind==='feel'&&FEEL[state.moisture.value]){Dr0=(1-FEEL[state.moisture.value].fraction)*TAW;moistureSource='feel';}
 else if(Number.isFinite(state.irrigationDays)&&state.irrigationDays<=7&&etcDay!==null){Dr0=Math.min(TAW,etcDay*state.irrigationDays);moistureSource='irrigation';}
 else if(state.moisture?.kind==='smap'&&Number.isFinite(state.moisture.theta)){
  // SMAP 9 km hücre ortalamasıdır: bölgesel referans toprağa (killi tın) göre yarayışlı oran alınır, tarlanın toprağına uygulanır.
  const ref=SOILS.killi_tin,frac=Math.max(0,Math.min(1,(state.moisture.theta-ref.wp)/(ref.fc-ref.wp)));
  Dr0=(1-frac)*TAW;moistureSource='smap';
 }
 // Günlük su dengesi: 7 gün boyunca açığın RAW eşiğine kaç günde ulaştığı
 let etc7=null,rain7=null,daysToRaw=null;const path=[];
 if(Array.isArray(state.weather)&&state.weather.length&&kc!==null){
  const rows=state.weather.slice(0,7);etc7=0;rain7=0;let Dr=Dr0;
  rows.forEach((r,i)=>{const etc=kc*et0Hargreaves(r.min,r.max,state.lat??38,r.date),pe=r.rain>=2?0.8*r.rain:0;etc7+=etc;rain7+=pe;
   if(Dr!==null){Dr=Math.max(0,Math.min(TAW,Dr+etc-pe));path.push(Dr);if(daysToRaw===null&&Dr>=RAW)daysToRaw=i+1;}});
 }
 const known={soil:state.soil?.source==='farmer',stage:kc!==null,moisture:Dr0!==null,weather:etc7!==null};
 let action='unknown',Dr7=null,amountMm=null;
 if(state.water==='yok'){action='conserve';}
 else if(Dr0!==null&&etc7!==null){
  Dr7=path.at(-1);
  if(Dr0>=RAW||(daysToRaw!==null&&daysToRaw<=2)){action='irrigate';amountMm=Math.max(Dr0,path[Math.min(1,path.length-1)]);}
  else if(daysToRaw!==null)action='soon';
  else action='wait';
 }
 if(state.water==='kısıtlı'&&action==='irrigate')notes.push('Su kısıtlı: önce en hassas dönemdeki parsele ver.');
 return {version:ENGINE_VERSION,action,soilKey,soilLabel:soil.label,kc,TAW:round(TAW),RAW:round(RAW),Dr0:round(Dr0),Dr7:round(Dr7),etc7:round(etc7,1),rain7:round(rain7,1),
  amountMm:round(amountMm),amountTonPerDecare:round(amountMm,0),daysToRaw,availablePct:Dr0===null?null:round(100*(1-Dr0/TAW)),moistureSource,known,rootM:cp.rootM,p:cp.p,notes};
}

export const ACTION_TEXT={
 irrigate:{title:'Bugün ya da yarın sula',tone:'act'},
 soon:{title:'Bu hafta sulama gerekecek',tone:'watch'},
 wait:{title:'Şimdilik sulama gerekmiyor',tone:'calm'},
 conserve:{title:'Sulama yok: toprağın nemini koru',tone:'watch'},
 unknown:{title:'Karar için bir bilgi eksik',tone:'watch'}
};

/** Aday sorular: her biri olası cevapları ve olasılıklarıyla. Kararı en çok değiştirebilecek olan seçilir. */
function candidates(state){
 const c=[];
 if(!(state.moisture?.kind==='feel'))c.push({id:'feel',title:'Toprağı 20 cm derinden avucuna al ve sık.',tool:'Bir küçük kürek veya bel',effort:1,minutes:3,
  answers:Object.entries(FEEL).map(([k,v])=>({value:k,label:v.label,p:FEEL_PRIOR[k],apply:s=>({...s,moisture:{kind:'feel',value:k}})}))});
 if(state.water!=='yok'&&!(state.moisture?.kind==='feel')&&!Number.isFinite(state.irrigationDays))c.push({id:'irrigation',title:'Bu tarlayı en son ne zaman suladın?',tool:'Hatırlaman yeterli',effort:0.8,minutes:1,
  answers:IRRIGATION_ANSWERS.map(a=>({value:String(a.days),label:a.label,p:a.p,apply:s=>({...s,irrigationDays:a.days})}))});
 if(state.soil?.source!=='farmer')c.push({id:'soil',title:'Toprağın avuçta nasıl davranıyor?',tool:'Bir avuç nemli toprak',effort:1,minutes:2,
  answers:Object.entries(SOILS).map(([k,v])=>({value:k,label:v.label,p:SOIL_PRIOR[k],apply:s=>({...s,soil:{value:k,source:'farmer'}})}))});
 if(STAGE_KC[state.stage]===undefined)c.push({id:'stage',title:'Bitkin şu an hangi dönemde?',tool:'Tarlaya bir bakış',effort:1,minutes:1,
  answers:Object.entries(STAGE_PRIOR).map(([k,p])=>({value:k,label:k,p,apply:s=>({...s,stage:k})}))});
 return c;
}

/**
 * Discovery: her aday için cevapların kararı değiştirme olasılığı (karar duyarlılığı).
 * Bilinmeyen karar için "kararı belirleyebilme" de değer sayılır. Rastgele değil, aynı durumda aynı soru.
 */
export function chooseQuestion(state){
 const base=evaluateWater(state),scored=[];
 for(const q of candidates(state)){
  let change=0,resolve=0;const outcomes=[];
  for(const a of q.answers){
   const r=evaluateWater(a.apply(state));
   if(r.action!==base.action)change+=a.p;
   if(base.action==='unknown'&&r.action!=='unknown')resolve+=a.p;
   outcomes.push({answer:a.label,value:a.value,action:r.action,p:a.p});
  }
  // Karar bilinmiyorsa, karar için zorunlu eksik girdiyi dolduran soru da değerlidir (tek adımda çözülmese bile).
  const fills=base.action==='unknown'&&((q.id==='feel'&&!base.known.moisture)||(q.id==='irrigation'&&!base.known.moisture&&base.known.stage)||(q.id==='stage'&&!base.known.stage))?0.3:0;
  const value=change+0.5*resolve+fills,score=value/q.effort;
  scored.push({id:q.id,title:q.title,tool:q.tool,minutes:q.minutes,changeProbability:round(change,2),score:round(score,3),outcomes,answers:q.answers.map(a=>({value:a.value,label:a.label}))});
 }
 scored.sort((a,b)=>b.score-a.score||a.minutes-b.minutes);
 const best=scored[0]||null;
 if(!best||best.score<=0.05)return {question:null,base,ranked:scored,reason:'Şu anki bilgiler kararı netleştirmeye yetiyor. Yeni bir soru kararı değiştirmez.'};
 const flips=best.outcomes.filter(o=>o.action!==base.action);
 const reason=base.action==='unknown'
  ?(()=>{const acts=[...new Set(best.outcomes.map(o=>o.action))].filter(a=>a!=='unknown');return acts.length?`Bu cevap olmadan su kararı verilemiyor. Cevaba göre karar ${acts.map(a=>'“'+ACTION_TEXT[a].title.toLowerCase()+'”').join(' ya da ')} olur.`:'Su kararı için önce bu bilgi gerekiyor; ardından bir adım daha kalacak.';})()
  :`Şu anki karar “${ACTION_TEXT[base.action].title.toLowerCase()}”. Cevabın ${flips.map(o=>'“'+o.answer.toLowerCase()+'”').join(' veya ')} olursa karar değişir (olasılık yaklaşık %${Math.round(best.changeProbability*100)}).`;
 return {question:best,base,ranked:scored,reason};
}

const FIELD_LABEL={action:'Karar',soilLabel:'Toprak',kc:'Bitki katsayısı (Kc)',TAW:'Toplam yarayışlı su (mm)',Dr0:'Bugünkü su açığı (mm)',Dr7:'7 gün sonraki su açığı (mm)',availablePct:'Yarayışlı nem (%)',etc7:'7 günlük bitki su ihtiyacı (mm)',moistureSource:'Nem kaynağı'};
const SOURCE_TEXT={feel:'senin yoklaman',irrigation:'son sulama tarihin',smap:'NASA SMAP (9 km model)',null:'yok'};

/** Ne değişti: iki değerlendirme arasındaki farkları çiftçi diliyle sırala. */
export function explainChange(before,after,changedInput){
 const diffs=[];
 for(const k of ['soilLabel','moistureSource','kc','TAW','Dr0','availablePct','etc7','Dr7']){
  if(before[k]!==after[k]){
   const fmt=v=>k==='moistureSource'?SOURCE_TEXT[v]??'yok':v===null||v===undefined?'bilinmiyor':String(v).replace('.',',');
   diffs.push({key:k,label:FIELD_LABEL[k],before:fmt(before[k]),after:fmt(after[k])});
  }
 }
 const decisionChanged=before.action!==after.action;
 return {changedInput,decisionChanged,before:ACTION_TEXT[before.action].title,after:ACTION_TEXT[after.action].title,diffs,
  summary:decisionChanged?`Yeni bilgi kararı değiştirdi: “${ACTION_TEXT[before.action].title}” → “${ACTION_TEXT[after.action].title}”.`:`Yeni bilgi hesabı güncelledi; karar aynı kaldı: “${ACTION_TEXT[after.action].title}”.`};
}
