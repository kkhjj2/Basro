// A product-name catalogue for records and navigation, not a crop-suitability or treatment database.
export const CROP_GROUPS=[
 {id:'bostan',label:'Bostan ve meyveli sebzeler',icon:'🥒',family:'vegetable',names:['Kabak','Sakız kabağı','Bal kabağı','Kestane kabağı','Su kabağı','Karpuz','Kavun','Salatalık','Acur','Domates','Çeri domates','Biber','Sivri biber','Dolmalık biber','Kapya biber','Acı biber','Patlıcan','Bamya','Taze fasulye','Taze bezelye','Taze bakla','Tatlı mısır','Pepino']},
 {id:'sebze',label:'Yapraklı ve köklü sebzeler',icon:'🥬',family:'vegetable',names:['Marul','Kıvırcık marul','Göbek marul','Ispanak','Pazı','Roka','Tere','Semizotu','Maydanoz','Dereotu','Kereviz','Lahana','Beyaz lahana','Kırmızı lahana','Kara lahana','Karnabahar','Brokoli','Brüksel lahanası','Pırasa','Soğan','Kuru soğan','Taze soğan','Arpacık soğan','Sarımsak','Taze sarımsak','Patates','Tatlı patates','Havuç','Turp','Kırmızı turp','Şalgam','Pancar','Kırmızı pancar','Enginar','Kuşkonmaz','Yer elması','Hindiba','Ravent']},
 {id:'meyve',label:'Meyveler',icon:'🍎',family:'orchard',names:['Elma','Armut','Ayva','Kayısı','Şeftali','Nektarin','Erik','Kiraz','Vişne','Nar','İncir','Dut','Beyaz dut','Karadut','Trabzon hurması','Yenidünya','Alıç','Hünnap','Kızılcık','Muşmula','İğde','Zeytin','Avokado','Mango','Muz','Hurma','Guava','Feijoa','Kivi','Ananas','Papaya','Çarkıfelek','Ejder meyvesi','Liçi','Longan','Harnup']},
 {id:'narenciye',label:'Narenciye',icon:'🍋',family:'orchard',names:['Limon','Portakal','Mandalina','Greyfurt','Turunç','Kan portakalı','Laym','Kumkat','Bergamot','Pomelo']},
 {id:'bag',label:'Bağ, üzümsü ve sert kabuklu meyveler',icon:'🍇',family:'bush',names:['Üzüm','Sofralık üzüm','Kurutmalık üzüm','Şaraplık üzüm','Çilek','Ahududu','Böğürtlen','Yaban mersini','Frenk üzümü','Bektaşi üzümü','Aronya','Kuşburnu','Turna yemişi','Kurt üzümü','Mürver','Ceviz','Badem','Fındık','Antep fıstığı','Kestane','Çam fıstığı','Pekan cevizi','Makadamya']},
 {id:'tahil',label:'Tahıllar',icon:'🌾',family:'grain',names:['Buğday','Arpa','Mısır','Çavdar','Yulaf','Çeltik','Karabuğday','Kinoa','Darı','Sorgum','Tritikale','Siyez buğdayı','Kavılca buğdayı','Makarnalık buğday','Ekmeklik buğday','Amarant']},
 {id:'baklagil',label:'Baklagiller',icon:'🫘',family:'vegetable',names:['Nohut','Mercimek','Kırmızı mercimek','Yeşil mercimek','Fasulye','Kuru fasulye','Bezelye','Bakla','Börülce','Maş fasulyesi','Barbunya','Acı bakla']},
 {id:'tarla',label:'Yağlık, endüstri ve yem bitkileri',icon:'🌻',family:'grain',names:['Ayçiçeği','Kanola','Soya','Susam','Yer fıstığı','Keten','Aspir','Pamuk','Şeker pancarı','Şeker kamışı','Tütün','Şerbetçiotu','Çay','Kahve','Kakao','Yonca','Fiğ','Korunga','Yem bezelyesi','Yem baklası','Yem mısırı','Silajlık mısır','İtalyan çimi','Sudan otu','Çim']},
 {id:'aromatik',label:'Aromatik bitkiler ve baharatlar',icon:'🌿',family:'herb',names:['Lavanta','Kekik','Biberiye','Adaçayı','Nane','Melisa','Fesleğen','Reyhan','Defne','Kimyon','Anason','Rezene','Kişniş','Çörek otu','Hardal','Safran','Zerdeçal','Zencefil','Papatya','Ekinezya','Kantaron','Isırgan otu','Şeker otu','Salep','Çemen','Sumak','Kapari','Kuş otu','Tarhun','Mercanköşk','Limon otu']},
 {id:'sus',label:'Çiçekler ve mantarlar',icon:'🌷',family:'herb',names:['Kültür mantarı','İstiridye mantarı','Şitake mantarı','Gül','Karanfil','Lale','Kasımpatı','Gerbera','Orkide','Menekşe','Petunya','Begonya','Ortanca','Yasemin','Nergis','Şakayık','Frezya','Zambak','Sümbül','Kadife çiçeği']}
];
const icons={Kabak:'🥒','Sakız kabağı':'🥒','Bal kabağı':'🎃','Kestane kabağı':'🎃',Karpuz:'🍉',Kavun:'🍈',Salatalık:'🥒',Domates:'🍅','Çeri domates':'🍅',Biber:'🌶️',Patlıcan:'🍆',Patates:'🥔',Havuç:'🥕',Soğan:'🧅',Sarımsak:'🧄',Brokoli:'🥦',Mısır:'🌽',Elma:'🍎',Armut:'🍐',Kayısı:'🍑',Şeftali:'🍑',Kiraz:'🍒',Vişne:'🍒',Üzüm:'🍇',Çilek:'🍓',Ceviz:'🌰',Kestane:'🌰',Zeytin:'🫒',Muz:'🍌',Ananas:'🍍',Avokado:'🥑',Kivi:'🥝',Mango:'🥭',Limon:'🍋',Portakal:'🍊',Mandalina:'🍊',Ayçiçeği:'🌻',Pamuk:'☁️',Kahve:'☕',Çay:'🍃',Gül:'🌹',Lavanta:'🪻'};
const ground=['Kabak','Sakız kabağı','Bal kabağı','Kestane kabağı','Su kabağı','Karpuz','Kavun','Salatalık','Acur'];
const nuts=['Ceviz','Badem','Fındık','Antep fıstığı','Kestane','Çam fıstığı','Pekan cevizi','Makadamya'];
const vines=['Üzüm','Sofralık üzüm','Kurutmalık üzüm','Şaraplık üzüm','Kivi','Çarkıfelek','Şerbetçiotu'];
export const CROP_CATALOG=CROP_GROUPS.flatMap(g=>g.names.map(name=>({name,group:g.id,groupLabel:g.label,icon:icons[name]||g.icon,family:ground.includes(name)?'ground':nuts.includes(name)?'orchard':vines.includes(name)?'vine':g.family})));
export const CROPS=[...CROP_CATALOG.map(c=>c.name),'Diğer','Henüz seçmedim'];
export const POPULAR_CROPS=['Kabak','Karpuz','Domates','Biber','Elma','Ceviz','Üzüm','Kayısı','Buğday','Salatalık','Kavun','Çilek'];
export const foldCrop=value=>String(value??'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ı/g,'i').replace(/[’']/g,'').replace(/[\s-]+/g,' ').trim();
const byName=new Map(CROP_CATALOG.map(c=>[foldCrop(c.name),c]));
const aliases={'balkabagi':'Bal kabağı','bal kabagi':'Bal kabağı','dolma biber':'Dolmalık biber','cherry domates':'Çeri domates','cherry tomato':'Çeri domates','tomato':'Domates','watermelon':'Karpuz','zucchini':'Kabak','pirinc':'Çeltik','malta erigi':'Yenidünya','keciboynuzu':'Harnup','antepfistigi':'Antep fıstığı','antep fistigi':'Antep fıstığı','yerfistigi':'Yer fıstığı','yer fistigi':'Yer fıstığı','yabanmersini':'Yaban mersini','corekotu':'Çörek otu','stevia':'Şeker otu','ejdermeyvesi':'Ejder meyvesi','goji berry':'Kurt üzümü'};
export function findCrop(value){const key=foldCrop(value),alias=Object.hasOwn(aliases,key)?aliases[key]:'';return byName.get(key)||byName.get(foldCrop(alias))||null;}
export function normalizeCropName(value){
 if(typeof value!=='string')return null;const name=value.normalize('NFC').trim().replace(/\s+/g,' ');
 if(!name||name.length>60||!/[\p{L}]/u.test(name)||!/^[\p{L}\p{M}\p{N}][\p{L}\p{M}\p{N} '\u2019()./\-]*$/u.test(name)||['constructor','prototype','proto'].includes(foldCrop(name)))return null;
 const known=findCrop(name);if(known)return known.name;
 if(foldCrop(name)==='diger')return 'Diğer';if(foldCrop(name)==='henuz secmedim')return 'Henüz seçmedim';
 return name.charAt(0).toLocaleUpperCase('tr-TR')+name.slice(1);
}
export const sameCrop=(a,b)=>foldCrop(a)===foldCrop(b)||!!(findCrop(a)&&findCrop(b)&&findCrop(a).name===findCrop(b).name);
export const cropIcon=name=>findCrop(name)?.icon||'🌱';
export const cropFamily=name=>findCrop(name)?.family||'herb';
const searchKey=value=>foldCrop(value).replace(/kabagi/g,'kabak').replace(/fistigi/g,'fistik');
export function searchCrops(query='',group='all'){
 const words=searchKey(query).split(' ').filter(Boolean),aliasName=Object.hasOwn(aliases,foldCrop(query))?aliases[foldCrop(query)]:'',matches=CROP_CATALOG.filter(c=>(group==='all'||c.group===group)&&(words.every(w=>searchKey(c.name).includes(w))||c.name===aliasName));
 return matches.sort((a,b)=>{if(words.length){const exactA=sameCrop(a.name,query)?0:1,exactB=sameCrop(b.name,query)?0:1;if(exactA!==exactB)return exactA-exactB;}else if(group==='all'){const pa=POPULAR_CROPS.indexOf(a.name),pb=POPULAR_CROPS.indexOf(b.name);if(pa>=0||pb>=0)return (pa<0?999:pa)-(pb<0?999:pb);}return a.name.localeCompare(b.name,'tr');});
}
