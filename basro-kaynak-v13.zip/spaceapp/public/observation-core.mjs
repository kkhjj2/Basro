// Local observation validation. Acceptance means this evidence can inform a screening
// decision; it does not certify scientific accuracy or authorize remote sharing.
export const OBSERVATION_METHOD = 'agro-observation-1.0';
const text = (tr, en) => ({tr, en});
const finite = value => typeof value === 'number' && Number.isFinite(value);
const sources = ['farmer_report', 'camera_assisted', 'test_kit', 'sensor', 'laboratory', 'external_dataset'];
const unknown = value => value === null || value === undefined || ['unknown', 'dont_know', "don't know", "i don't know", 'bilmiyorum', 'skipped', ''].includes(String(value).trim().toLowerCase());
const iso = value => {
  if (value instanceof Date) return Number.isFinite(value.getTime()) ? value.toISOString() : null;
  if (typeof value !== 'string') return null;
  const parts = /^(\d{4}-\d{2}-\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d{1,3})?)?(Z|[+-]\d{2}:\d{2}))?$/.exec(value);
  if (!parts || Number(parts[2] || 0) > 23 || Number(parts[3] || 0) > 59 || Number(parts[4] || 0) > 59) return null;
  const day = Date.parse(parts[1] + 'T00:00:00Z'), time = Date.parse(value);
  if (!Number.isFinite(day) || !Number.isFinite(time) || new Date(day).toISOString().slice(0, 10) !== parts[1]) return null;
  return new Date(time).toISOString();
};
const copy = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
const object = value => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
const boundedText = value => typeof value === 'string' ? value.trim().slice(0, 500) : '';
const newId = () => 'obs_' + (globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`);

function equivalent(a, b) {
  return a.fieldId === b.fieldId && a.userId === b.userId && a.observationType === b.observationType &&
    a.observedAt === b.observedAt && a.sourceType === b.sourceType && (a.method || a.measurementMethod) === b.method &&
    a.value === b.value && a.unit === b.unit && (a.depthCm ?? null) === b.depthCm;
}

function defaultUncertainty(record) {
  if (record.observationType === 'standing_water_duration' && finite(record.value)) {
    const error = Math.max(2, record.value * .25);
    return {lower: Math.max(0, record.value - error), upper: Math.min(8760, record.value + error), kind: 'heuristic_report_range', description: text('Hatırlamaya dayalı yaklaşık süre; aralık kalibre edilmiş güven aralığı değildir.', 'Approximate recalled duration; this range is not a calibrated confidence interval.')};
  }
  return {kind: 'qualitative', description: text('Yönteme ve kullanıcı beyanına bağlı belirsizlik sürüyor.', 'Method and farmer-report uncertainty remains.')};
}

/** Validate one private, owner-scoped record. Does not read storage or call a service. */
export function validateObservation(input, {fieldId, userId = 'device-owner', existing = [], now = new Date(), regionalReference = null} = {}) {
  input = object(input);
  const stamp = new Date(now);
  if (!Number.isFinite(stamp.getTime())) throw new TypeError('A valid validation time is required.');
  const submittedAt = stamp.toISOString(), metadata = copy(object(input.measurementMetadata || input.metadata));
  const type = boundedText(input.observationType || input.type), rawMethod = boundedText(input.method || input.measurementMethod);
  const method = rawMethod === 'manual_rain_gauge_reading' ? 'manual_gauge_read' : rawMethod;
  const rawUnit = boundedText(input.unit), unit = type === 'standing_water_duration' && ['h', 'hour', 'hours'].includes(rawUnit) ? 'hours' : rawUnit;
  const record = {
    id: boundedText(input.id) || newId(), fieldId: boundedText(fieldId), userId: boundedText(userId),
    observationType: type, value: unknown(input.value) ? null : typeof input.value === 'string' ? input.value.trim() : input.value,
    unit, observedAt: input.observedAt === undefined ? submittedAt : iso(input.observedAt), submittedAt,
    sourceType: boundedText(input.sourceType || 'farmer_report'), method,
    depthCm: input.depthCm === undefined || input.depthCm === null || input.depthCm === '' ? null : input.depthCm,
    measurementMetadata: metadata, qualityFlags: [], validationStatus: 'pending', uncertainty: null,
    sharingConsent: input.sharingConsent === true, validationMethod: OBSERVATION_METHOD,
    validationExplanation: text('Doğrulama bekliyor.', 'Awaiting validation.'),
    influence: {eligible: false, reason: text('Kabul edilmeyen kayıt kararı etkilemez.', 'An unaccepted record does not affect a decision.')}
  };
  const fail = (status, flag, explanation) => {
    record.validationStatus = status;
    if (!record.qualityFlags.includes(flag)) record.qualityFlags.push(flag);
    record.validationExplanation = explanation;
    record.influence = {eligible: false, reason: explanation};
    return record;
  };
  if (!record.fieldId || !record.userId || input.fieldId && input.fieldId !== record.fieldId || input.userId && input.userId !== record.userId)
    return fail('rejected', 'owner_or_field_mismatch', text('Kayıt bu tarla ve yerel kullanıcıya ait olmalıdır.', 'The record must belong to this field and local owner.'));
  if (!record.observedAt || Date.parse(record.observedAt) > stamp.getTime() + 300000)
    return fail('rejected', 'invalid_timestamp', text('Gözlem tarihi geçersiz veya gelecekte.', 'The observation time is invalid or in the future.'));
  if (!sources.includes(record.sourceType) || !type)
    return fail('rejected', 'invalid_source_or_type', text('Gözlem türü ve kaynak türü gerekli.', 'A valid observation type and source type are required.'));
  for (const [key, limit] of [['latitude', 90], ['longitude', 180]]) {
    if (input[key] !== undefined) {
      if (!finite(input[key]) || Math.abs(input[key]) > limit) return fail('rejected', 'invalid_coordinates', text('Koordinatlar geçerli değil.', 'Coordinates are invalid.'));
      record[key] = input[key];
    }
  }
  if (record.depthCm !== null && (!finite(record.depthCm) || record.depthCm < 0 || record.depthCm > 200))
    return fail('rejected', 'invalid_depth', text('Örnek derinliği 0–200 cm aralığında olmalıdır.', 'Sample depth must be within the supported 0–200 cm range.'));
  if (record.value !== null && !['number', 'string', 'boolean'].includes(typeof record.value))
    return fail('rejected', 'invalid_value_type', text('Gözlem değeri basit bir sayı, metin veya seçim olmalıdır.', 'The observation value must be a simple number, text or choice.'));
  if (Array.isArray(existing) && existing.some(row => row?.fieldId === record.fieldId && row?.userId === record.userId && (row.id === record.id || equivalent(row, record) || metadata.evidenceDigest && row.measurementMetadata?.evidenceDigest === metadata.evidenceDigest && row.observationType === type)))
    return fail('rejected', 'duplicate', text('Aynı gözlem zaten kayıtlı; tekrar kayıt ek ağırlık oluşturmaz.', 'This observation is already recorded; duplicates do not add weight.'));
  if (record.value === null) return fail('pending', 'skipped_unknown', text('Bilmiyorum yanıtı kaydedildi; ölçüm varsayılmadı ve karar değişmedi.', 'The unknown answer was recorded; no measurement was assumed and the decision is unchanged.'));

  const numericRules = {standing_water_duration: ['hours', 0, 8760], rainfall_measurement: ['mm', 0, 5000], soil_ph: ['pH', 0, 14]};
  if (numericRules[type]) {
    const [expectedUnit, low, high] = numericRules[type];
    if (!finite(record.value) || unit !== expectedUnit || record.value < low || record.value > high)
      return fail('rejected', 'invalid_value_or_unit', text('Değer veya birim desteklenen aralıkla uyuşmuyor.', 'The value or unit is outside the supported range.'));
  }
  const supplied = object(input.uncertainty);
  if (Object.hasOwn(supplied, 'lower') || Object.hasOwn(supplied, 'upper')) {
    if (!finite(record.value) || !finite(supplied.lower) || !finite(supplied.upper) || supplied.lower > record.value || supplied.upper < record.value)
      return fail('rejected', 'invalid_uncertainty', text('Belirsizlik aralığı geçerli olmalı ve bildirilen değeri içermelidir.', 'The uncertainty range must be valid and contain the reported value.'));
    if (numericRules[type] && (supplied.lower < numericRules[type][1] || supplied.upper > numericRules[type][2]))
      return fail('rejected', 'invalid_uncertainty', text('Belirsizlik aralığı desteklenen fiziksel aralığın dışında.', 'The uncertainty bounds exceed the supported physical range.'));
    record.uncertainty = {lower: supplied.lower, upper: supplied.upper, kind: 'user_reported_range', description: text('Kullanıcının bildirdiği aralık; kalibrasyonu doğrulanmadı.', 'User-reported range; calibration has not been verified.')};
  } else record.uncertainty = defaultUncertainty(record);

  const imageQuality = {...object(metadata.imageQuality), ...object(input.imageQuality), ...object(input.evidenceQuality)};
  if (metadata.blurry === true || metadata.sharpness === 'blurry' || imageQuality.blurry === true || input.qualityFlags?.includes?.('blurry'))
    return fail('needs_review', 'blurry_evidence', text('Görüntü bulanık; sayısal ölçüm çıkarılmadı. Daha net kanıt gerekir.', 'The image is blurry; no numerical measurement was extracted. Clearer evidence is needed.'));
  if (imageQuality.tooDark === true || imageQuality.tooBright === true || metadata.tooDark === true || metadata.tooBright === true)
    return fail('needs_review', 'poor_image_lighting', text('Görüntünün ışığı okumayı desteklemiyor; daha uygun ışıkta tekrar kontrol et.', 'Image lighting does not support the reading; check again under suitable lighting.'));
  // A photograph is only supporting evidence for an explicitly manual gauge
  // reading. This validator never extracts pH, moisture or a gauge number from it.
  if (record.sourceType === 'camera_assisted' && !(type === 'rainfall_measurement' && method === 'manual_gauge_read' && metadata.manualRead === true))
    return fail('needs_review', 'camera_not_a_measurement', text('Bu sürüm fotoğraftan ölçüm yapmaz. Araçla elle okunan veya laboratuvar sonucu gerekir.', 'This version does not measure from photographs. A manual instrument reading or laboratory result is required.'));

  if (type === 'standing_water_duration') {
    if (record.sourceType !== 'farmer_report' || method !== 'visual_after_rain')
      return fail('needs_review', 'unsupported_method', text('Yağmur sonrasındaki güvenli, geçmişe dayalı gözlemini kaydet; su basmış tarlaya girme.', 'Record a safe retrospective observation after rain; do not enter a flooded field.'));
    record.qualityFlags.push('farmer_report', 'approximate', 'not_drainage_measurement');
    record.validationExplanation = text('Yapısal olarak kontrol edilmiş yaklaşık çiftçi beyanı. Toprak drenajının bilimsel ölçümü veya güvenli ekim onayı değildir.', 'A structurally checked approximate farmer report. It is not a scientific drainage measurement or approval of planting safety.');
  } else if (type === 'soil_texture') {
    if (!['sandy', 'loam', 'clay'].includes(record.value) || !['', 'qualitative', 'class'].includes(unit))
      return fail('rejected', 'invalid_texture', text('Desteklenen yaklaşık bünye sınıfını seç.', 'Choose a supported approximate texture class.'));
    record.unit = 'qualitative';
    if (method !== 'feel' || record.sourceType !== 'farmer_report') return fail('needs_review', 'unsupported_method', text('Bu kayıt elle bünye tahmini olarak doğrulanmalı.', 'This record needs a texture-by-feel method check.'));
    record.qualityFlags.push('tentative_texture', 'approximate');
    record.validationExplanation = text('Elle bünye tahmini geçici, nitel kanıt olarak kabul edildi; laboratuvar tane dağılımı değildir.', 'The texture-by-feel estimate is accepted as tentative qualitative evidence; it is not a laboratory particle-size analysis.');
  } else if (type === 'previous_crop') {
    if (typeof record.value !== 'string' || !record.value || record.value.length > 100 || !['', 'crop', 'qualitative'].includes(unit))
      return fail('rejected', 'invalid_crop_history', text('Önceki ürün adı gerekli.', 'A previous crop name is required.'));
    if (record.sourceType !== 'farmer_report' || !['farmer_recall', 'farm_record'].includes(method)) return fail('needs_review', 'unsupported_method', text('Önceki ürünün kaydı veya çiftçi hatırlaması belirtilmeli.', 'Specify a farm record or farmer recall for the previous crop.'));
    record.unit = 'crop'; record.qualityFlags.push('farmer_report');
    record.validationExplanation = text('Çiftçinin önceki ürün kaydı kabul edildi; bağımsız doğrulama yapılmadı.', 'The farmer’s crop-history report is accepted; it has not been independently verified.');
  } else if (type === 'soil_ph') {
    if (record.sourceType !== 'laboratory' || !['laboratory_report', 'lab_report'].includes(method) || !boundedText(metadata.reportId) || !boundedText(metadata.labName) || record.depthCm === null)
      return fail('needs_review', 'laboratory_metadata_missing', text('pH için laboratuvar adı, rapor kimliği, yöntem ve örnek derinliği gerekir; toprak fotoğrafı pH ölçmez.', 'pH needs a laboratory name, report ID, method and sampling depth; a soil photograph does not measure pH.'));
    record.qualityFlags.push('report_not_independently_verified');
    record.validationExplanation = text('Rapor bilgileri yapısal olarak kontrol edildi; laboratuvar sonucu bağımsız doğrulanmadı.', 'Report metadata was structurally checked; the laboratory result has not been independently verified.');
  } else if (type === 'rainfall_measurement') {
    const periodStart = iso(metadata.periodStart), periodEnd = iso(metadata.periodEnd);
    if (method !== 'manual_gauge_read' || metadata.graduatedScale !== true || metadata.manualRead !== true || !boundedText(metadata.tool) || !periodStart || !periodEnd || periodStart >= periodEnd || periodEnd > record.observedAt)
      return fail('needs_review', 'rain_gauge_metadata_missing', text('Yağış için ölçekli yağışölçer, elle okuma ve geçerli başlangıç/bitiş zamanı gerekir.', 'Rainfall requires a graduated gauge, manual reading and a valid measurement start/end period.'));
    if (!['farmer_report', 'test_kit', 'sensor', 'camera_assisted'].includes(record.sourceType)) return fail('needs_review', 'unsupported_method', text('Yerel ölçümün aracı ve kaynağı doğrulanmalı.', 'The local measurement tool and source need checking.'));
    record.measurementMetadata.periodStart = periodStart; record.measurementMetadata.periodEnd = periodEnd;
    if (!Object.hasOwn(supplied, 'lower') && finite(metadata.scaleIncrementMm) && metadata.scaleIncrementMm > 0 && metadata.scaleIncrementMm <= 100) {
      record.uncertainty = {lower: Math.max(0, record.value - metadata.scaleIncrementMm / 2), upper: record.value + metadata.scaleIncrementMm / 2, kind: 'scale_reading_resolution', description: text('Ölçek aralığının yarısı; cihaz kalibrasyonu, rüzgâr ve yerleştirme hatalarını kapsamaz.', 'Half a scale increment; excludes calibration, wind and placement errors.')};
    }
    record.validationExplanation = text('Elle okunan yağışölçer kaydı yapısal olarak kabul edildi; cihaz kalibrasyonu doğrulanmadı.', 'The manual gauge report passes structural checks; instrument calibration has not been verified.');
    record.qualityFlags.push('instrument_calibration_unverified');
  } else return fail('pending', 'unsupported_observation_type', text('Bu gözlem türü için doğrulama yöntemi henüz yok; karara katılmadı.', 'No validation method exists for this observation type yet; it does not enter the decision.'));

  const reference = object(regionalReference), referenceType = reference.observationType || reference.type;
  if ((!referenceType || referenceType === type) && reference.value !== undefined && reference.unit === record.unit) {
    const tolerance = finite(reference.tolerance) && reference.tolerance >= 0 ? reference.tolerance : null;
    const refRange = object(reference.uncertainty);
    const disagreement = finite(record.value) && finite(reference.value)
      ? tolerance !== null ? Math.abs(record.value - reference.value) > tolerance : finite(refRange.lower) && finite(refRange.upper) && finite(record.uncertainty?.lower) && finite(record.uncertainty?.upper) && (record.uncertainty.upper < refRange.lower || record.uncertainty.lower > refRange.upper)
      : typeof reference.value === 'string' && reference.value !== record.value;
    if (disagreement) {
      record.regionalReference = copy(reference);
      return fail('needs_review', 'regional_discrepancy', text('Yerel beyan ile bölgesel veri farklı. Çözünürlük, zaman, derinlik veya sulama farkı olabilir; bu çiftçi hatasının kanıtı değildir.', 'The local report differs from regional data. Resolution, timing, depth or irrigation may explain it; this is not proof of farmer error.'));
    }
  }
  record.validationStatus = 'accepted';
  record.influence = {eligible: true, reason: text('Belirsizliği korunarak ilgili tarla karşılaştırmasına katılabilir; küresel modele aktarılmaz.', 'May inform this field’s relevant comparison with uncertainty retained; it is not sent to a global model.')};
  return record;
}

/** Latest accepted record per type for one owner/field; no averaging or vote count. */
export function acceptedEvidence(observations = [], {fieldId, userId = 'device-owner'} = {}) {
  if (!fieldId || !userId) return {};
  const rows = observations.filter(row => row?.fieldId === fieldId && row.userId === userId && row.validationStatus === 'accepted' && row.influence?.eligible === true)
    .sort((a, b) => String(b.observedAt).localeCompare(String(a.observedAt)) || String(b.submittedAt).localeCompare(String(a.submittedAt)) || String(a.id).localeCompare(String(b.id)));
  const result = {}, uncertainty = {}, provenance = {}, seen = new Set();
  const keys = {standing_water_duration: 'standingWaterHours', soil_texture: 'soilTexture', previous_crop: 'previousCrop', soil_ph: 'soilPh', rainfall_measurement: 'rainfallMm'};
  for (const row of rows) {
    const key = keys[row.observationType];
    if (!key || seen.has(key) || row.value === null || row.value === undefined) continue;
    if (['standingWaterHours', 'soilPh', 'rainfallMm'].includes(key) && !finite(row.value)) continue;
    seen.add(key); result[key] = row.value; uncertainty[key] = copy(row.uncertainty);
    provenance[key] = {observationId: row.id, observedAt: row.observedAt, sourceType: row.sourceType, method: row.method, qualityFlags: [...(row.qualityFlags || [])], validationMethod: row.validationMethod || OBSERVATION_METHOD};
  }
  if (seen.size) { result.uncertainty = uncertainty; result.provenance = provenance; }
  return result;
}
