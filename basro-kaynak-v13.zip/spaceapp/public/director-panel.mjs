// İlçe / il müdürü paneli (panel-1.0): topluluk gönderilerinden bölgenin haftalık toplu görünümü.
// Yalnızca toplu sayılar gösterilir; kişi adı, tam konum ya da tek çiftçiye ait ölçüm gösterilmez.
// Gerçek veri azsa örnek satırlar eklenir ve açıkça etiketlenir. Bu sürümde yetkili girişi yoktur.
export const PANEL_VERSION='panel-1.0';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const f=v=>String(v).replace('.',',');
export const SAMPLE={days:7,activeFarmers:38,posts:112,photos:41,measurements:57,comments:164,likes:420,
 signals:[{id:'don',label:'Don / kırağı',posts:19,farmers:14},{id:'su',label:'Su ve kuraklık',posts:12,farmers:9},{id:'hastalik',label:'Hastalık belirtisi',posts:7,farmers:6},{id:'hasat',label:'Hasat',posts:5,farmers:5}],
 cropGrowth:[{crop:'Domates',farmers:11,avgPerWeek:9.4,min:4,max:14.5},{crop:'Kayısı (fidan)',farmers:6,avgPerWeek:3.1,min:1.5,max:5},{crop:'Biber',farmers:4,avgPerWeek:6.8,min:5,max:9}],
 crops:[{crop:'Kayısı',posts:44},{crop:'Domates',posts:31},{crop:'Buğday',posts:14},{crop:'Biber',posts:9}],
 daily:[9,14,12,18,21,16,22]};
export function readFarm(storage){try{const v=JSON.parse(storage.getItem('agroatlas-farmer-v2')||'{}'),a=(v.farms||[]).find(x=>x.id===v.activeFarmId)||(v.farms||[])[0];return a?{district:a.district||'',city:a.city||''}:null;}catch{return null;}}
/** Gerçek özet yeterince doluysa onu, değilse örneği döndürür. */
export function pickData(summary){const real=!!summary&&summary.activeFarmers>=3&&summary.posts>=5;return real?{d:summary,sample:false}:{d:{...SAMPLE,daily:SAMPLE.daily.map((posts,i)=>({day:'',posts}))},sample:true,real:summary||null};}
export function panelHtml({farm,scope,summary,online}){
 const {d,sample,real}=pickData(summary),place=scope==='district'&&farm?.district?`${farm.district} İlçe Müdürlüğü`:farm?.city?`${farm.city} İl Müdürlüğü`:'Bölge Müdürlüğü',top=Math.max(1,...d.daily.map(x=>x.posts)),sig=Math.max(1,...d.signals.map(s=>s.posts)),cr=Math.max(1,...d.crops.map(c=>c.posts));
 const tile=(n,l)=>`<div class="dp-tile"><strong>${n}</strong><span>${l}</span></div>`;
 return `<div class="dp-head"><div><span class="dp-eyebrow">TARIM VE ORMAN · SAHA GÖRÜNÜMÜ</span><h1>${esc(place)}</h1><p>Çiftçilerin Basro topluluğunda paylaştıklarından son ${d.days} günün toplu görünümü.</p></div>
 <div class="dp-scope" role="tablist" aria-label="Kapsam">${farm?.district?`<button role="tab" aria-selected="${scope==='district'}" data-scope="district">${esc(farm.district)}</button>`:''}<button role="tab" aria-selected="${scope!=='district'}" data-scope="all">Tüm bölge</button></div></div>
 ${sample?`<p class="dp-note dp-sample">Bu kapsamda henüz yeterli gerçek paylaşım yok${real?` (${real.activeFarmers} çiftçi, ${real.posts} gönderi)`:''}. Panelin nasıl çalıştığını göstermek için aşağıdaki sayılar <b>örnek veridir</b>.</p>`:online===false?'<p class="dp-note">Sunucuya ulaşılamadı.</p>':''}
 <section class="dp-tiles" aria-label="Özet sayılar">${tile(d.activeFarmers,'aktif çiftçi')}${tile(d.posts,'gönderi')}${tile(d.photos,'fotoğraflı gönderi')}${tile(d.measurements,'boy ölçümü')}${tile(d.comments,'yorum')}${tile(d.likes,'beğeni')}</section>
 <div class="dp-grid">
 <section class="dp-card"><h2>Sahadan sinyaller</h2><p class="dp-muted">Gönderilerde geçen konular. Anahtar kelime sayımıdır; teşhis ya da resmî tespit değildir.</p>${d.signals.length?d.signals.map(s=>`<div class="dp-bar"><span>${esc(s.label)}</span><i><b style="width:${Math.round(100*s.posts/sig)}%"></b></i><em>${s.posts} gönderi · ${s.farmers} çiftçi</em></div>`).join(''):'<p class="dp-muted">Bu hafta öne çıkan bir konu yok.</p>'}</section>
 <section class="dp-card"><h2>Ürünlere göre haftalık gelişim</h2><p class="dp-muted">Çiftçilerin girdiği boy ölçümlerinden ortalama. En az 3 çiftçi ölçüm girdiyse gösterilir.</p>${d.cropGrowth.length?`<table class="dp-table"><thead><tr><th>Ürün</th><th>Çiftçi</th><th>Ortalama</th><th>Aralık</th></tr></thead><tbody>${d.cropGrowth.map(c=>`<tr><td>${esc(c.crop)}</td><td>${c.farmers}</td>${c.avgPerWeek==null?'<td colspan="2" class="dp-muted">yetersiz veri (gizlilik)</td>':`<td><strong>${c.avgPerWeek>0?'+':''}${f(c.avgPerWeek)} cm/hafta</strong></td><td>${f(c.min)} – ${f(c.max)}</td>`}</tr>`).join('')}</tbody></table>`:'<p class="dp-muted">Henüz iki ölçümü olan çiftçi yok.</p>'}</section>
 <section class="dp-card"><h2>Günlük paylaşım</h2><div class="dp-days" role="img" aria-label="Son ${d.days} günde günlük gönderi sayısı: ${d.daily.map(x=>x.posts).join(', ')}">${d.daily.map(x=>`<div><i style="height:${Math.max(4,Math.round(100*x.posts/top))}%"></i><span>${x.posts}</span><small>${esc(x.day?x.day.slice(8)+'.'+x.day.slice(5,7):'')}</small></div>`).join('')}</div></section>
 <section class="dp-card"><h2>En çok paylaşılan ürünler</h2>${d.crops.length?d.crops.slice(0,6).map(c=>`<div class="dp-bar"><span>${esc(c.crop)}</span><i><b style="width:${Math.round(100*c.posts/cr)}%"></b></i><em>${c.posts} gönderi</em></div>`).join(''):'<p class="dp-muted">Ürün bilgisi olan gönderi yok.</p>'}</section>
 </div>
 <p class="dp-foot">Bu panel yalnızca toplu sayıları gösterir: kişi adı, tarla konumu ve tek bir çiftçiye ait ölçüm burada yer almaz. Veriler çiftçilerin “Toplulukla paylaş” izniyle paylaştığı gönderilerden gelir. Gerçek kullanımda panel yalnızca yetkili müdürlük girişiyle açılır; bu sürümde giriş yoktur. ${esc(PANEL_VERSION)}</p>`;
}
export function mountPanel(root,storage){
 const farm=readFarm(storage);let scope=farm?.district?'district':'all',summary=null,online=null;
 const draw=()=>{root.innerHTML=panelHtml({farm,scope,summary,online});root.querySelectorAll('[data-scope]').forEach(b=>b.addEventListener('click',()=>{scope=b.dataset.scope;summary=null;draw();pull();}));};
 const pull=async()=>{try{const r=await fetch(`/api/social?summary=1&scope=${scope==='district'?'region':'all'}&region=${encodeURIComponent(farm?.district||'')}`,{signal:AbortSignal.timeout(12000)}),d=await r.json();online=!!d.configured;summary=d.summary||null;}catch{online=false;summary=null;}draw();};
 draw();pull();
}
if(typeof document!=='undefined'){const root=document.getElementById('dp-root');if(root)mountPanel(root,localStorage);}
