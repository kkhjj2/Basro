// A small, local 3D illustration. No field geometry, weather measurement or farm analysis is implied.
import {cropFamily} from './crop-catalog.mjs';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const motionQuery=matchMedia('(prefers-reduced-motion: reduce)');
const preferenceStorage=()=>new URLSearchParams(location.search).has('preview')?sessionStorage:localStorage;
let motionPreference;try{motionPreference=preferenceStorage().getItem('agrobas-motion-v1');}catch{}
let motion=motionPreference==='on'||(motionPreference!=='off'&&!motionQuery.matches);
const syncMotion=()=>document.documentElement.dataset.uiMotion=motion?'on':'off';syncMotion();
function setMotion(value){motion=value;motionPreference=value?'on':'off';try{preferenceStorage().setItem('agrobas-motion-v1',motionPreference);}catch{}syncMotion();window.dispatchEvent(new Event('agrobas-motion-change'));}
motionQuery.addEventListener('change',()=>{if(!motionPreference){motion=!motionQuery.matches;syncMotion();window.dispatchEvent(new Event('agrobas-motion-change'));}});

export const filizFace=`<svg viewBox="0 0 100 112" aria-hidden="true" class="filiz-art"><defs><linearGradient id="filiz-leaf" x2=".8" y2="1"><stop stop-color="#b7d66b"/><stop offset="1" stop-color="#679c4a"/></linearGradient><linearGradient id="filiz-pot" x2=".9" y2="1"><stop stop-color="#f2b981"/><stop offset="1" stop-color="#d48a55"/></linearGradient></defs><ellipse cx="51" cy="104" rx="30" ry="6" fill="#634b2920"/><path class="filiz-left-leaf" d="M49 48C23 52 12 32 17 15c24-2 35 12 32 33Z" fill="url(#filiz-leaf)"/><path class="filiz-right-leaf" d="M50 45C49 19 68 9 86 14c2 23-15 33-36 31Z" fill="#9dc35e"/><path d="M49 64V39M48 43 30 29M52 41l21-14" fill="none" stroke="#577e37" stroke-width="3.5" stroke-linecap="round"/><path d="M22 61h58l-8 34c-1 7-42 7-44 0Z" fill="url(#filiz-pot)"/><rect x="19" y="56" width="64" height="13" rx="6.5" fill="#efb17d"/><path d="M32 74v15" stroke="#f8cfac" stroke-width="4" stroke-linecap="round" opacity=".6"/><g class="filiz-eyes"><ellipse cx="42" cy="77" rx="2.8" ry="3.8" fill="#493c2b"/><ellipse cx="61" cy="77" rx="2.8" ry="3.8" fill="#493c2b"/></g><path d="M46 86q6 6 12-1" fill="none" stroke="#754d32" stroke-width="2.3" stroke-linecap="round"/><ellipse cx="35" cy="83" rx="4.5" ry="2.4" fill="#ec8f75" opacity=".65"/><ellipse cx="68" cy="83" rx="4.5" ry="2.4" fill="#ec8f75" opacity=".65"/></svg>`;

export function welcomeGarden({crop,district,date,completed=0}){
 return `<section class="garden-welcome" aria-label="Bugüne merhaba"><div class="garden-welcome-copy"><span class="garden-kicker"><i></i>${esc(date)} · ${esc(district)}</span><h1>Hoş geldin.<br><span>Birlikte büyütelim.</span></h1><p>${esc(["Diğer","Henüz seçmedim"].includes(crop)?"Tarlan":crop)} için bugün küçük bir adım atalım.<br>Gerisini birlikte, adım adım düşünürüz.</p><div class="garden-welcome-actions"><button class="farm-primary garden-today" id="garden-today">Bugünün işleri <span>↘</span></button><button class="garden-talk" id="garden-talk">Asistanına sor <span>↗</span></button></div><div class="garden-friend"><button class="filiz-button" id="filiz-hello" aria-label="Filiz'e merhaba de">${filizFace}</button><div><small>FİLİZ · KÜÇÜK TARLA REHBERİN</small><p id="filiz-message" aria-live="polite">${completed?'İlk adımı attın. Eline sağlık!':'Bir soru, bir fotoğraf… Birlikte başlayabiliriz.'}</p></div></div></div><div class="garden-visual"><div class="garden-orbit orbit-one"></div><div class="garden-orbit orbit-two"></div><span class="garden-floating-label"><i></i> Senin küçük bahçen</span><figure class="garden-stage"><canvas id="garden-canvas" tabindex="0" role="img" aria-label="Dekoratif üç boyutlu bahçe. Sürükleyerek veya sağ ve sol ok tuşlarıyla çevirebilirsin.">Üç boyutlu bahçe illüstrasyonu.</canvas><figcaption><span>✥ Sürükle, bahçeyi keşfet</span><small>İllüstrasyon</small></figcaption></figure><div class="garden-controls"><button id="garden-turn" aria-label="Bahçeyi biraz çevir">↻ <span>Çevir</span></button><button id="garden-reset" aria-label="Bahçeyi ilk görünümüne getir">⌂ <span>İlk görünüm</span></button><button id="garden-motion" aria-pressed="${motion}">${motion?'Ⅱ':'▷'} <span>${motion?'Hareketi durdur':'Hareketi aç'}</span></button></div></div></section>`;
}

const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function color(hex,amount=1){const n=parseInt(hex.slice(1),16);return `rgb(${[n>>16,(n>>8)&255,n&255].map(x=>Math.round(clamp(x*amount,0,255))).join(',')})`;}
function makeGarden(crop){
 const faces=[];
 function face(vertices,hex,sway=0){
  const a=vertices[0],b=vertices[1],c=vertices[2],u=b.map((v,i)=>v-a[i]),v=c.map((x,i)=>x-a[i]),n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],length=Math.hypot(...n)||1;
  const light=.82+.18*(n[0]*-.45+n[1]*.85+n[2]*.35)/length;
  faces.push({vertices,fill:color(hex,light),sway});
 }
 function box(x,y,z,w,h,d,hex,sway=0){
  const p=[[-1,-1,-1],[1,-1,-1],[1,-1,1],[-1,-1,1],[-1,1,-1],[1,1,-1],[1,1,1],[-1,1,1]].map(([a,b,c])=>[x+a*w/2,y+b*h/2,z+c*d/2]);
  for(const q of [[4,7,6,5],[0,1,2,3],[0,4,5,1],[1,5,6,2],[2,6,7,3],[3,7,4,0]])face(q.map(i=>p[i]),hex,sway);
 }
 function tile(w,d,y,height,hex){
  const cut=.22,p=[[-w/2+cut,-d/2],[w/2-cut,-d/2],[w/2,-d/2+cut],[w/2,d/2-cut],[w/2-cut,d/2],[-w/2+cut,d/2],[-w/2,d/2-cut],[-w/2,-d/2+cut]];
  face(p.map(([x,z])=>[x,y,z]).reverse(),hex);
  p.forEach(([x,z],i)=>{const [nx,nz]=p[(i+1)%p.length];face([[x,y-height,z],[nx,y-height,nz],[nx,y,nz],[x,y,z]],hex);});
 }
 function sphere(x,y,z,rx,ry,rz,hex,sway=0,segments=10,rings=6){
  const p=[];for(let i=0;i<=rings;i++){const row=[],a=i*Math.PI/rings;for(let j=0;j<segments;j++){const b=j*2*Math.PI/segments;row.push([x+Math.sin(a)*Math.cos(b)*rx,y+Math.cos(a)*ry,z+Math.sin(a)*Math.sin(b)*rz]);}p.push(row);}
  for(let i=0;i<rings;i++)for(let j=0;j<segments;j++)face([p[i][j],p[i][(j+1)%segments],p[i+1][(j+1)%segments],p[i+1][j]],hex,sway);
 }
 function stem(x,z,height=.7,hex='#886746',sway=.025){box(x,.35+height/2,z,.085,height,.085,hex,sway);}
 tile(4.4,3.3,.13,.35,'#b7875e');tile(4.35,3.24,.22,.11,'#d7aa79');tile(4.22,3.12,.29,.08,'#a8bd71');
 // Rounded stepping stones and soil beds.
 for(let i=0;i<5;i++)box(-.55,.335,-.8+i*.4,.28,.07,.25,'#f2dbb5');
 box(.87,.32,.05,1.86,.045,2.28,'#c49969');
 for(const z of [-.75,-.05,.65])box(.87,.35,z,1.72,.035,.36,'#9a7250');
 // A tiny farm shed, built from actual 3D faces.
 box(-1.25,.65,-.71,.88,.68,.75,'#f9e4bb');
 face([[-1.78,1.0,-1.16],[-.72,1,-1.16],[-1.25,1.4,-1.16]],'#e0a46c');
 face([[-1.78,1,-.27],[-1.25,1.4,-.27],[-.72,1,-.27]],'#f6d6a6');
 face([[-1.78,1,-1.16],[-1.78,1,-.27],[-1.25,1.4,-.27],[-1.25,1.4,-1.16]],'#c9744f');
 face([[-1.25,1.4,-1.16],[-1.25,1.4,-.27],[-.72,1,-.27],[-.72,1,-1.16]],'#e59865');
 box(-1.25,.57,-.32,.26,.48,.035,'#426a4d');box(-.96,.77,-.32,.16,.17,.04,'#92b9ad');
 box(-1.65,.34,-.24,.22,.13,.22,'#cd8a5b');sphere(-1.65,.49,-.24,.17,.15,.15,'#7b9d53',.025,8,4);
 // Fences behind the garden.
 for(const x of [-1.85,-.75,.35,1.45,2.02])box(x,.58,-1.4,.065,.58,.065,'#f6e5c6');
 for(const y of [.51,.73])box(.05,y,-1.4,3.98,.055,.04,'#e4cca6');
 for(const z of [-.9,0,.9])box(2.02,.56,z,.065,.53,.065,'#f3dfbc');
 for(const y of [.48,.69])box(2.02,y,.1,.04,.05,2.9,'#e8cca3');
 const family=cropFamily(crop),orchard=family==='orchard';
 if(orchard){
  [[.3,-.7],[1.42,-.55],[.35,.6],[1.44,.7]].forEach(([x,z],i)=>{stem(x,z,.64);sphere(x,.99,z,.36,.38,.34,i%2?'#88aa58':'#759b50',.025);sphere(x-.14,1.19,z-.06,.3,.32,.29,'#a0bd68',.025);sphere(x+.2,1.12,z+.04,.28,.31,.28,'#8eae58',.025);
   const fruit=crop==='Elma'?'#d98356':crop==='Kiraz'?'#c96a59':crop==='Kayısı'?'#efb15d':crop==='Ceviz'?'#b88a52':crop==='Zeytin'?'#607b44':null;
   if(fruit)for(const [dx,dy,dz]of [[-.18,.97,.25],[.26,1.12,.12],[.03,1.36,-.1]])sphere(x+dx,dy,z+dz,.055,.06,.055,fruit,.025,6,4);
  });
 }else if(family==='grain'){
  for(let i=0;i<5;i++)for(let j=0;j<4;j++){const x=.17+i*.33,z=-.8+j*.52,h=crop==='Mısır'?.67:.48;stem(x,z,h,'#c8ad58',.04);sphere(x,.36+h,z,.065,.13,.045,crop==='Mısır'?'#b6bc5f':'#e0bd65',.04,6,4);}
 }else if(family==='vine'){
  for(const z of [-.65,.5]){for(const x of [.15,.85,1.55]){stem(x,z,.65);sphere(x,1,z,.29,.23,.2,'#81a55b',.025);sphere(x+.06,.79,z+.1,.075,.12,.065,'#8b7197',.025,7,4);}box(.85,.99,z,1.6,.035,.035,'#a48b65');}
 }else if(family==='ground'){
  for(const [x,z]of [[.3,-.7],[1.35,-.65],[.35,.65],[1.4,.65]]){box(x,.38,z,.65,.03,.035,'#7e9a4f',.015);for(const [dx,dz]of [[-.2,0],[.16,-.14],[.05,.19]])sphere(x+dx,.42,z+dz,.17,.07,.15,'#83a653',.02,8,4);const melon=crop==='Karpuz'||crop==='Kavun',pumpkin=crop.includes('kabağı');sphere(x+.15,.48,z+.1,melon?.19:pumpkin?.18:.09,melon?.15:.12,melon?.17:pumpkin?.17:.25,crop==='Karpuz'?'#678a45':crop==='Kavun'?'#d9bd66':pumpkin?'#df9b53':'#83a559',.01,12,6);}
 }else{
  for(let i=0;i<4;i++)for(let j=0;j<3;j++){const x=.2+i*.42,z=-.72+j*.65;stem(x,z,.24,'#6d8d4c');sphere(x,.62,z,.19,.25,.17,'#82aa55',.035,8,5);sphere(x-.11,.51,z+.07,.16,.14,.13,'#a6bd63',.035,8,4);if(['Domates','Biber'].includes(crop))sphere(x+.1,.61,z+.14,.075,.075,.065,'#dc8561',.035,7,4);}
 }
 // A few flowers and a clay watering can keep the illustration welcoming.
 for(const [x,z]of [[-1.8,.45],[-1.5,.95],[-.9,1.15],[1.77,1.14]]){stem(x,z,.14,'#7c9d55',.045);sphere(x,.51,z,.06,.055,.06,'#edbd71',.045,6,4);}
 box(-1.3,.43,.62,.23,.26,.2,'#7da7a0');box(-1.11,.48,.62,.2,.07,.065,'#82aea5');
 return faces;
}

function mountScene(canvas,crop){
 const ctx=canvas.getContext('2d',{alpha:true});if(!ctx)return ()=>{};
 const faces=makeGarden(crop),events=[];let width=400,height=300,yaw=-.52,pitch=.63,targetYaw=yaw,targetPitch=pitch,drag=null,raf=0,lastFrame=0,visible=true,disposed=false;
 const on=(target,type,fn,options)=>{target.addEventListener(type,fn,options);events.push(()=>target.removeEventListener(type,fn,options));};
 function project(v){const [x,y,z]=v;
  const rx=x*Math.cos(yaw)-z*Math.sin(yaw),rz=x*Math.sin(yaw)+z*Math.cos(yaw),vy=y*Math.cos(pitch)-rz*Math.sin(pitch),depth=y*Math.sin(pitch)+rz*Math.cos(pitch),scale=Math.min(width/6.25,height/5)*8/(8-depth);
  return [width*.5+rx*scale,height*.52-vy*scale,depth];
 }
 function draw(ms=0){if(disposed)return;const t=motion?ms/1000:0;ctx.clearRect(0,0,width,height);
  // Soft sky details are decorative; the factual weather stays in the weather card.
  const orb=ctx.createRadialGradient(width*.77,height*.2,2,width*.77,height*.2,44);orb.addColorStop(0,'#f2cf8dc0');orb.addColorStop(1,'#f2cf8d00');ctx.fillStyle=orb;ctx.beginPath();ctx.arc(width*.77,height*.2,44,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#edc27b';ctx.beginPath();ctx.arc(width*.77,height*.2,17,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#fffdf2dc';for(const [x,y,r]of [[.23,.18,18],[.27,.15,22],[.31,.19,17],[.7,.31,12],[.73,.29,16],[.76,.31,12]]){ctx.beginPath();ctx.ellipse(width*x+Math.sin(t*.25)*5,height*y,r,r*.55,0,0,Math.PI*2);ctx.fill();}
  ctx.save();ctx.translate(width*.5,height*.8);ctx.scale(1,.3);const shadow=ctx.createRadialGradient(0,0,10,0,0,width*.35);shadow.addColorStop(0,'#65764b30');shadow.addColorStop(1,'#65764b00');ctx.fillStyle=shadow;ctx.beginPath();ctx.arc(0,0,width*.35,0,Math.PI*2);ctx.fill();ctx.restore();
  const polys=faces.map(f=>{const points=f.vertices.map(v=>{const p=[...v];p[0]+=Math.sin(t*.8+p[2]*2)*Math.max(0,p[1]-.35)*f.sway;return project(p,t);});return {points,fill:f.fill,z:points.reduce((n,p)=>n+p[2],0)/points.length};}).sort((a,b)=>a.z-b.z);
  ctx.lineJoin='round';for(const f of polys){ctx.beginPath();f.points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.fillStyle=f.fill;ctx.fill();ctx.strokeStyle=f.fill;ctx.lineWidth=.55;ctx.stroke();}
  canvas.dataset.sceneReady='true';
 }
 function tick(now){raf=0;if(disposed||!motion||!visible||document.visibilityState!=='visible')return;if(now-lastFrame>40){yaw+=(targetYaw-yaw)*.22;pitch+=(targetPitch-pitch)*.22;draw(now);lastFrame=now;}raf=requestAnimationFrame(tick);}
 function start(){if(!raf&&motion&&visible&&document.visibilityState==='visible')raf=requestAnimationFrame(tick);else if(!motion)draw();}
 function stop(){if(raf)cancelAnimationFrame(raf);raf=0;}
 const resize=new ResizeObserver(()=>{const rect=canvas.getBoundingClientRect();width=Math.max(1,rect.width);height=Math.max(1,rect.height);const ratio=Math.min(window.devicePixelRatio||1,1.5);canvas.width=Math.round(width*ratio);canvas.height=Math.round(height*ratio);ctx.setTransform(ratio,0,0,ratio,0,0);draw(performance.now());});resize.observe(canvas);
 const observer='IntersectionObserver'in window?new IntersectionObserver(entries=>{visible=entries[0]?.isIntersecting??true;if(visible)start();else stop();}):null;observer?.observe(canvas);
 on(document,'visibilitychange',()=>{if(document.visibilityState==='visible')start();else stop();});
 on(window,'agrobas-motion-change',()=>{stop();targetYaw=yaw;targetPitch=pitch;draw();start();});
 on(canvas,'pointerdown',e=>{if(e.button!==0)return;drag={x:e.clientX,y:e.clientY,yaw,pitch};canvas.setPointerCapture(e.pointerId);canvas.classList.add('is-dragging');});
 on(canvas,'pointermove',e=>{if(!drag)return;targetYaw=yaw=clamp(drag.yaw+(e.clientX-drag.x)*.008,-1.45,1.45);targetPitch=pitch=clamp(drag.pitch+(e.clientY-drag.y)*.004,.4,.9);draw(performance.now());});
 const end=()=>{drag=null;canvas.classList.remove('is-dragging');};on(canvas,'pointerup',end);on(canvas,'pointercancel',end);on(canvas,'lostpointercapture',end);
 function changeView(nextYaw,nextPitch){targetYaw=nextYaw;targetPitch=nextPitch;if(!motion){yaw=targetYaw;pitch=targetPitch;}draw(performance.now());}
 on(canvas,'keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home'].includes(e.key)){e.preventDefault();if(e.key==='Home')changeView(-.52,.63);else if(e.key==='ArrowLeft')changeView(clamp(targetYaw-.15,-1.45,1.45),targetPitch);else if(e.key==='ArrowRight')changeView(clamp(targetYaw+.15,-1.45,1.45),targetPitch);else changeView(targetYaw,clamp(targetPitch+(e.key==='ArrowUp'?-.08:.08),.4,.9));}});
 const turn=document.querySelector('#garden-turn'),reset=document.querySelector('#garden-reset');
 on(turn,'click',()=>changeView(targetYaw>1.1?-1.1:targetYaw+.3,targetPitch));on(reset,'click',()=>changeView(-.52,.63));start();
 return ()=>{disposed=true;stop();resize.disconnect();observer?.disconnect();events.forEach(fn=>fn());};
}

export function bindGarden(root,{crop,ask,showTasks}){
 const cleanups=[],on=(selector,fn)=>{const element=root.querySelector(selector);if(element){element.addEventListener('click',fn);cleanups.push(()=>element.removeEventListener('click',fn));}};
 on('#garden-today',showTasks);on('#garden-talk',()=>ask('Ürünüm ve son kayıtlarıma göre bugün nereden başlamalıyım? İki kısa adım söyle.'));
 let hello=0;const greetings=['Bir soru, bir fotoğraf… Birlikte başlayabiliriz.','Merhaba! Bugün bir küçük adım yeter.','Bir değişim gördüysen fotoğrafla birlikte bakalım.','Dün ne yaptığını not etmek, bugün işini kolaylaştırır.'];
 on('#filiz-hello',()=>{const friend=root.querySelector('.garden-friend');root.querySelector('#filiz-message').textContent=greetings[++hello%greetings.length];friend.classList.remove('filiz-wave');void friend.offsetWidth;friend.classList.add('filiz-wave');});
 const updateButton=()=>{const b=root.querySelector('#garden-motion');if(b){b.setAttribute('aria-pressed',String(motion));b.innerHTML=`${motion?'Ⅱ':'▷'} <span>${motion?'Hareketi durdur':'Hareketi aç'}</span>`;}};
 on('#garden-motion',()=>setMotion(!motion));window.addEventListener('agrobas-motion-change',updateButton);cleanups.push(()=>window.removeEventListener('agrobas-motion-change',updateButton));
 const canvas=root.querySelector('#garden-canvas');if(canvas)cleanups.push(mountScene(canvas,crop));
 return ()=>cleanups.forEach(fn=>fn());
}

export function celebrateTask(rect){
 if(!motion||!rect)return;const burst=document.createElement('div');burst.className='garden-leaf-burst';burst.setAttribute('aria-hidden','true');burst.style.left=(rect.left+rect.width/2)+'px';burst.style.top=(rect.top+rect.height/2)+'px';burst.innerHTML=Array.from({length:7},(_,i)=>`<i style="--leaf-x:${Math.cos(i*.9)*52}px;--leaf-y:${-35-Math.sin(i*.7)*35}px;--leaf-r:${i*63}deg;--leaf-delay:${i*15}ms"></i>`).join('');document.body.appendChild(burst);setTimeout(()=>burst.remove(),950);
}
