/* Real model chat. No simulated or rule-based answer fallback. */
(()=>{
  'use strict';
  const icon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v3m0 12v3M3 12h3m12 0h3M6 6l2 2m8 8 2 2M6 18l2-2m8-8 2-2"/><path d="m12 7 2 3 3 2-3 2-2 3-2-3-3-2 3-2Z"/></svg>';
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const $=s=>document.querySelector(s), sessions=new Map();
  let status=null, busy=false, controller=null, requestId=0, currentKey='', lastFocus=null, currentContext=null;
  const button=document.createElement('button');button.className='assistant-launch';button.id='assistant-launch';button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-expanded','false');button.innerHTML=icon+'<span>Tarım Asistanı<small>Birlikte bakalım</small></span>';document.body.appendChild(button);
  const nav=document.createElement('button');nav.className='assistant-nav';nav.innerHTML=icon+'<span>Asistan</span>';nav.setAttribute('aria-haspopup','dialog');$('.topnav').appendChild(nav);
  const dialog=document.createElement('dialog');dialog.id='assistant-dialog';dialog.className='assistant-drawer';dialog.setAttribute('aria-labelledby','assistant-title');
  dialog.innerHTML=`<div class="assistant-shell"><header class="assistant-head"><div class="assistant-identity"><div class="assistant-mark">${icon}</div><div><h2 id="assistant-title">Tarım Asistanı</h2><div class="assistant-state" id="assistant-state"><i></i><span>Bağlantı kontrol ediliyor</span></div></div></div><button class="assistant-close" id="assistant-close" aria-label="Asistanı kapat"><svg><use href="#i-close"/></svg></button></header><div class="assistant-context" id="assistant-context"></div><div class="assistant-messages" id="assistant-messages" role="log" aria-label="Tarım asistanı sohbeti" aria-live="polite" aria-relevant="additions"></div><form class="assistant-compose" id="assistant-compose"><label class="assistant-input-label" for="assistant-input">Arazin hakkında bir soru yaz</label><div class="assistant-input-wrap"><textarea id="assistant-input" maxlength="2000" placeholder="Toprağım ve ürünüm için ne yapabilirim?" rows="2"></textarea><button id="assistant-send" aria-label="Mesajı gönder" type="submit"><svg><path d="m4 12 16-8-5 16-3-7-8-1Zm8 1 8-9"/></svg></button></div><p class="assistant-disclosure">Yanıt ücretsiz yapay zekâ katmanıyla hazırlanır. Arazi ve ürün bilgilerin dikkate alınır. Uygulamadan önce öneriyi kontrol et.</p></form></div>`;
  document.body.appendChild(dialog);
  const isFarmer=()=>document.documentElement.dataset.product==='farmer';
  const keyOf=c=>c?`${c.fieldId||c.name},${c.lat.toFixed(4)},${c.lon.toFixed(4)},${c.year},${JSON.stringify(c.profile)}`:'demo';
  const getContext=()=>document.documentElement.dataset.product==='farmer'?(window.AgroFarmer?.getAssistantContext?.()||null):(window.AgroGlobal?.assistantContext?.()||null);
  function session(){if(!sessions.has(currentKey))sessions.set(currentKey,{messages:[],error:'',failed:null});return sessions.get(currentKey);}
  function updateContext(){
    const c=getContext(),key=keyOf(c),changed=key!==currentKey;currentContext=c;
    if(changed){controller?.abort();requestId++;busy=false;currentKey=key;$('#assistant-input').value='';}
    $('#assistant-context').innerHTML=c&&isFarmer()?`<div class="assistant-context-line"><strong>${esc(c.profile.crop||'Tarlan')} için konuşalım</strong><span>Senin tarlana göre</span></div><p class="assistant-context-detail">${esc(c.name)} · ${esc(c.profile.stage||'Dönem eklenmedi')}</p><button id="assistant-profile">Bilgilerimi düzenle ↗</button>`:c?`<div class="assistant-context-line"><strong>${esc(c.name)}</strong><span>${c.year} · Geçmiş NASA verisi</span></div><p class="assistant-context-detail">${c.lat.toFixed(4)}°, ${c.lon.toFixed(4)}° · ${esc(c.profile.crop||'Ürün eklenmedi')} · ${esc(c.profile.stage||'Dönem eklenmedi')}</p><button id="assistant-profile">Ürün ve toprak bilgilerimi düzenle ↗</button>`:'<div class="assistant-context-line"><strong>Temsili demo açık</strong></div><p class="assistant-context-detail">Gerçek veriye dayalı sohbet için dünya atlasını aç.</p><button id="assistant-back-world">Dünya atlasına dön ↗</button>';
    $('#assistant-profile')?.addEventListener('click',()=>{dialog.close();if(document.documentElement.dataset.product==='farmer')window.AgroFarmer?.edit();else window.AgroGlobal.openDialog('nutrition');});
    $('#assistant-back-world')?.addEventListener('click',()=>{dialog.close();$('#return-world')?.click();});
    $('#assistant-input').disabled=!c||!status?.configured;
    $('#assistant-send').disabled=!c||!status?.configured||busy;
    if(changed)render();
  }
  function format(text){return esc(text).replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>');}
  function render(){
    const s=session(),box=$('#assistant-messages');
    const welcome=`<div class="assistant-welcome"><p class="assistant-kicker">TOPRAĞINI BİRLİKTE ANLAYALIM</p><h3>Merhaba,<br>birlikte bakalım.</h3><p>Bölgeni, ürününü ve son gözlemlerini dikkate alıyorum. Kısa ve uygulanabilir adımlarla ilerleyelim.</p><div class="assistant-suggestions"><button data-prompt="Tarlam ve ürünüm için bugün en önemli üç kontrol ne? Basitçe anlat. İstatistik dökme.">Bugün ilk neye bakmalıyım?<span>↗</span></button><button data-prompt="Ürün ve toprak bilgilerime göre gübreleme kararından önce hangi ölçüm ve bilgilere ihtiyacım var?">Gübreleme için hangi bilgiler eksik?<span>↗</span></button><button data-prompt="Seçili ürünüm için bu hafta yapabileceğim 3 güvenli gözlem ve hazırlık görevi öner. Güncel hava tahmini olmadığını dikkate al.">Bu hafta neyi kontrol etmeliyim?<span>↗</span></button><button data-prompt="Don riskine hazırlanmak için hangi bilgileri toplayıp hangi sırayla kontrol yapmalıyım? Geleceğe yönelik don tahmini yapma.">Don hazırlığına nereden başlayayım?<span>↗</span></button></div></div>`;
    box.innerHTML=(s.messages.length?'<button class="assistant-new" id="assistant-new">Yeni sohbet başlat</button>':welcome)+s.messages.map((m,i)=>`<article class="assistant-message ${m.role}"><div class="assistant-message-label">${m.role==='user'?'SEN':'TARIM ASİSTANI'}</div><div class="assistant-message-body">${format(m.content)}</div>${m.role==='assistant'?`<div class="assistant-response-meta">${isFarmer()?'Tarım asistanı':esc(m.model||'Asistan')+' · '+esc(m.year)} · ${m.evidence?.available?`<a href="${esc(m.evidence.url)}" target="_blank" rel="noopener noreferrer">NASA POWER kaydını gör ↗</a><br>${esc(m.evidence.mode)} · Kayıt: ${esc(m.evidence.retrieved?.slice(0,10))}`:'Ürün profilin ve paylaştığın gözlemler dikkate alındı.'}${m.partial?'<br>Yanıt uzunluk sınırında kesildi. Devam etmesini isteyebilirsin.':''}</div><button class="assistant-task-btn" data-assistant-task="${i}">+ Bir göreve dönüştür</button>`:''}</article>`).join('')+(busy?'<div class="assistant-wait" role="status"><i></i> Tarlanın bilgileriyle yanıt hazırlanıyor…</div>':'')+(s.error?`<div class="assistant-error" role="alert">${esc(s.error)}${s.failed?'<button id="assistant-retry">Tekrar dene</button>':''}</div>`:'');
    box.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>{if(status?.configured){$('#assistant-input').value=b.dataset.prompt;send();}else{$('#assistant-input').value=b.dataset.prompt;checkStatus();}}));
    $('#assistant-new')?.addEventListener('click',()=>{controller?.abort();requestId++;busy=false;s.messages=[];s.error='';s.failed=null;render();updateContext();});
    $('#assistant-retry')?.addEventListener('click',()=>{const t=s.failed;s.failed=null;$('#assistant-input').value=t;send();});
    box.querySelectorAll('[data-assistant-task]').forEach(b=>b.addEventListener('click',()=>taskDialog(s.messages[Number(b.dataset.assistantTask)].content)));
    $('#assistant-send').disabled=busy||!status?.configured||!currentContext;
    if(s.messages.length||s.error||busy)box.scrollTop=box.scrollHeight;
  }
  async function checkStatus(){
    try{const res=await fetch('/api/assistant',{headers:{Accept:'application/json'}});if(!res.ok)throw new Error();const data=await res.json();if(typeof data.configured!=='boolean')throw new Error();status=data;$('#assistant-state span').textContent=data.configured?'Ücretsiz · Hazır':'Asistan şu an kapalı';if(!data.configured){session().code='NOT_CONFIGURED';session().error='Asistan şu an kapalı. Yapay zekâ anahtarı ayarlanınca açılır.';render();}else if(!session().failed){session().error='';render();}}
    catch{status={configured:false};$('#assistant-state span').textContent='Bağlantı kurulamadı';session().code='OFFLINE';session().error='Asistana şu an ulaşılamıyor. İnternet bağlantını kontrol edip tekrar dene.';render();}
    updateContext();
  }
  async function send(){
    const input=$('#assistant-input'),text=input.value.trim();if(!text||busy||!currentContext||!status?.configured)return;
    const c=structuredClone(currentContext),key=currentKey,s=session(),id=++requestId;
    s.error='';s.code='';s.failed=null;s.messages.push({role:'user',content:text});input.value='';busy=true;controller=new AbortController();render();
    const timer=setTimeout(()=>controller?.abort(),200000);
    try{
      const history=s.messages.slice(-11).map(m=>({role:m.role,content:m.content.slice(0,2400)}));
      while(history.reduce((n,m)=>n+m.content.length,0)>13000)history.shift();
      const res=await fetch('/api/assistant',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({context:c,messages:history,lang:window.BASRO_LANG||'tr'}),signal:controller.signal});const data=await res.json();
      if(id!==requestId||key!==currentKey)return;
      if(!res.ok)throw Object.assign(new Error(data.error||'Yanıt alınamadı.'),{code:data.code});
      s.messages.push({role:'assistant',content:data.text,model:data.model,year:c.year,evidence:data.evidence,partial:data.partial});
    }catch(e){if(id!==requestId||key!==currentKey)return;s.messages.pop();s.error=e.name==='AbortError'?'İstek zaman aşımına uğradı. Yeniden deneyebilirsin.':e.message;s.failed=text;s.code=e.code;}
    finally{clearTimeout(timer);if(id===requestId){busy=false;render();}}
  }
  function taskDialog(answer){if(document.documentElement.dataset.product==='farmer'&&window.AgroFarmer){dialog.close();window.AgroFarmer.captureTask(answer);return;}
    const fieldId=currentContext?.fieldId;if(!fieldId)return;
    dialog.close();openDialog('tasks');
    $('#modal-content').innerHTML=`<h2 id="modal-title">Öneriden bir görev oluştur.</h2><p>Görevi gözden geçir ve kendi cümlenle yaz. ${esc(currentContext.name)} bölgesine kaydedilecek.</p><form class="assistant-task-form" id="assistant-task-form"><label for="assistant-task-text">Görev <span>(en fazla 160 karakter)</span></label><textarea id="assistant-task-text" maxlength="160" required placeholder="Örn. Toprak analizindeki eksik ölçümleri laboratuvara sor"></textarea><label for="assistant-task-cadence">Görev sıklığı</label><select id="assistant-task-cadence"><option value="daily">Günlük</option><option value="weekly">Haftalık</option><option value="monthly">Aylık</option></select><p>Görev oluşturmak, gübre veya ilaç uygulamasını doğrulamaz. Kayıt bu cihazda tutulur.</p><button type="submit">Görevlerime ekle</button></form><details style="margin-top:16px;font-size:11px;line-height:1.7"><summary>Asistanın önerisini yeniden oku</summary><p style="white-space:pre-wrap">${esc(answer)}</p></details>`;
    $('#assistant-task-form').addEventListener('submit',e=>{e.preventDefault();const text=$('#assistant-task-text').value.trim(),cadence=$('#assistant-task-cadence').value;if(!text)return;if(taskData.custom.length>=300){toast('En fazla 300 özel görev saklanabilir.');return;}taskData.custom.push({id:`u${Date.now().toString(36)}-${Math.random().toString(36).slice(2,6)}`,field:fieldId,cadence,text});saveTasks();renderDailyTasks();modal.close();toast('Görev seçili araziye eklendi.');});
    $('#assistant-task-text').focus();
  }
  async function open(prompt=''){if(typeof prompt!=='string')prompt='';lastFocus=document.activeElement;updateContext();render();dialog.showModal();button.setAttribute('aria-expanded','true');await checkStatus();if(status?.configured&&currentContext){if(prompt)$('#assistant-input').value=prompt;$('#assistant-input').focus();}}
  window.AgroAssistant={open};
  button.addEventListener('click',open);nav.addEventListener('click',open);$('#assistant-close').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('close',()=>{button.setAttribute('aria-expanded','false');lastFocus?.focus?.();});
  dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
  $('#assistant-compose').addEventListener('submit',e=>{e.preventDefault();send();});$('#assistant-input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send();}});
  window.addEventListener('agro-context-change',updateContext);
  updateContext();
})();
