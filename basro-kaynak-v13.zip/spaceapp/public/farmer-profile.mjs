// Çiftçiyi tanıma (me-1.0): ad ve deneyim. Yalnızca bu cihazda saklanır; ad, toplulukta paylaşım yaparsan görünür.
const KEY='agrobas-me-v1',SOCIAL='agrobas-social-v1';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const EXPERIENCE={new:'Yeni başlıyorum',some:'1–5 yıldır',long:'5 yıldan uzun',family:'Aile işi, çocukluktan beri'};
const cleanName=s=>String(s??'').replace(/[\u0000-\u001f\u007f<>§]/g,'').replace(/\s+/g,' ').trim().slice(0,30);
export function readMe(storage){try{const v=JSON.parse(storage.getItem(KEY)||'{}')||{};return {name:cleanName(v.name),experience:EXPERIENCE[v.experience]?v.experience:''};}catch{return {name:'',experience:''};}}
export function saveMe(storage,patch){
 const me={...readMe(storage)};if('name' in patch)me.name=cleanName(patch.name);if('experience' in patch)me.experience=EXPERIENCE[patch.experience]?patch.experience:'';
 try{storage.setItem(KEY,JSON.stringify(me));
  // Topluluk adı boşsa aynı adı kullan; kullanıcı orada değiştirdiyse dokunma.
  if(me.name){const s=JSON.parse(storage.getItem(SOCIAL)||'{}')||{};if(!s.name){s.name=me.name;storage.setItem(SOCIAL,JSON.stringify(s));}}
 }catch{}
 return me;
}
export function meStepHtml(me){
 return `<section class="me-step" aria-label="Seni tanıyalım"><div class="farm-form-row"><label><span class="farm-label">Sana nasıl seslenelim? (isteğe bağlı)</span><input class="farm-input" id="me-name" maxlength="30" autocomplete="given-name" placeholder="Örn. Bilal" value="${esc(me.name)}"></label><label><span class="farm-label">Ne zamandır çiftçilik yapıyorsun?</span><select class="farm-input" id="me-exp"><option value="">Söylemek istemiyorum</option>${Object.entries(EXPERIENCE).map(([k,v])=>`<option value="${k}"${me.experience===k?' selected':''}>${esc(v)}</option>`).join('')}</select></label></div><p class="farm-hint">Adın bu cihazda kalır; yalnızca toplulukta paylaşım yaparsan görünür.</p></section><h2 class="me-step-next">Şu an en çok neye ihtiyacın var?</h2>`;
}
export function bindMeStep(root,storage){
 root.querySelector('#me-name')?.addEventListener('input',e=>saveMe(storage,{name:e.target.value}));
 root.querySelector('#me-exp')?.addEventListener('change',e=>saveMe(storage,{experience:e.target.value}));
}
/** Ana ekran selamına adı ekler: "Hoş geldin, Bilal." */
export function greetMe(h1,storage){
 const name=readMe(storage).name;if(!h1||!name)return false;
 const node=[...h1.childNodes].find(n=>n.nodeType===3&&n.textContent.includes('Hoş geldin'));if(!node)return false;
 node.textContent=`Hoş geldin, ${name}.`;return true;
}
