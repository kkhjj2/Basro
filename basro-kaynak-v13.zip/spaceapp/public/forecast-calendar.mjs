// Tahmin takvimi: önümüzdeki 7 gün (Open-Meteo) + 3 ay (ECMWF SEAS5) → somut tarla işleri.
// Kurallar açık ve sınanabilir; doz, ürün adı veya kesin hasar tahmini üretmez.
import {weatherCondition} from './farmer-core.mjs';

export const CALENDAR_VERSION='forecast-calendar-1';
const DAYS=['Paz','Pzt','Sal','Çar','Per','Cum','Cmt'];
const MONTHS=['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=(v,d=0)=>Number(v).toFixed(d).replace('.',',');
const ACTIVE=s=>!['Henüz ekmedim','Hasat sonrası'].includes(s);
const SENSITIVE=s=>['Yeni ekim / dikim','Çiçeklenme','Meyve / dane gelişimi'].includes(s);

/**
 * rows: [{date,min,max,rain,rainProbability,wind,code}] (Open-Meteo, bugünden başlar)
 * ctx: {stage, water, irrigation:{action,daysToRaw,amountTonPerDecare}|null}
 * → [{date, dayName, icon, min, max, rain, chips:[{kind,label,why,task}]}]
 */
export function buildDays(rows,ctx={}){
 if(!Array.isArray(rows)||!rows.length)return [];
 const out=rows.slice(0,7).map((r,i)=>{
  const d=new Date(r.date+'T12:00:00Z'),cond=weatherCondition(r.code,1);
  return {date:r.date,dayName:i===0?'Bugün':i===1?'Yarın':DAYS[d.getUTCDay()],dayNum:d.getUTCDate(),icon:cond.icon,condition:cond.label,min:r.min,max:r.max,rain:r.rain,wind:r.wind,rainProbability:r.rainProbability,chips:[]};
 });
 const add=(i,chip)=>{if(out[i]&&out[i].chips.length<3)out[i].chips.push(chip);};
 // 1) Don
 out.forEach((d,i)=>{
  if(d.min<=0)add(i,{kind:'frost',label:'Don gecesi',why:`En düşük ${num(d.min)} °C bekleniyor.${SENSITIVE(ctx.stage)?' Ürünün hassas dönemde; gece örtüsü ve sabah erken kontrol planla.':' Sabah erken bitkiyi kontrol et.'}`,task:'Don gecesi için hazırlık ve sabah kontrolü'});
  else if(d.min<=2)add(i,{kind:'frost-watch',label:'Don riski',why:`En düşük ${num(d.min)} °C; çukur yerlerde don olabilir.`,task:'Çukur yerlerde sabah don kontrolü'});
 });
 // 2) Sağanak / sıcak / rüzgâr uyarıları
 out.forEach((d,i)=>{
  if(d.rain>=15)add(i,{kind:'storm',label:'Sağanak',why:`${num(d.rain)} mm yağış: bu gün ilaç ve gübre yıkanır. Drenaj kanallarını kontrol et.`,task:'Sağanak öncesi drenaj kontrolü'});
  if(d.max>=35)add(i,{kind:'heat',label:'Sıcak stres',why:`En yüksek ${num(d.max)} °C. Sulama gerekiyorsa sabah erken ya da akşam yap.`,task:'Sıcakta sabah erken sulama'});
 });
 // 3) Sulama günü (tarla motorundan)
 if(ctx.water!=='yok'&&ctx.irrigation){
  const ir=ctx.irrigation;
  const idx=ir.action==='irrigate'?0:ir.action==='soon'&&ir.daysToRaw?Math.min(out.length-1,Math.max(0,ir.daysToRaw-1)):-1;
  if(idx>=0){
   const rainy=out.findIndex((d,i)=>i>=idx&&i<=idx+1&&d.rain>=8);
   if(rainy>=0)add(idx,{kind:'water-skip',label:'Sulamayı ertele',why:`Kök bölgesi kuruyor ama ${out[rainy].dayName.toLowerCase()} ${num(out[rainy].rain)} mm yağış bekleniyor. Yağıştan sonra yeniden yokla.`,task:'Yağıştan sonra toprağı yokla'});
   else add(idx,{kind:'water',label:'Sulama günü',why:`Su dengesi hesabına göre kök bölgesindeki kolay alınabilir su bu gün tükeniyor${ir.amountTonPerDecare?`; yaklaşık ${ir.amountTonPerDecare} ton/dekar`:''}. Tarla çalışma alanında ayrıntısı var.`,task:'Sulama'+(ir.amountTonPerDecare?` (~${ir.amountTonPerDecare} ton/dekar)`:'')});
  }
 }
 // 4) Gübre: yağıştan bir gün önce, kuru ve sakin gün (yağış 3–15 mm toprağa işler; daha fazlası yıkar)
 if(ACTIVE(ctx.stage)){
  for(let i=0;i<out.length-1;i++){
   const d=out[i],n=out[i+1];
   if(d.rain<1&&n.rain>=3&&n.rain<15&&d.wind<25&&d.min>0){add(i,{kind:'fert',label:'Gübre penceresi',why:`Yarın ${num(n.rain)} mm yağış bekleniyor: bugün verilen gübre yağışla toprağa işler. Miktarı toprak analizine göre belirle.`,task:'Planlı gübreyi yağıştan önce ver (analize göre)'});break;}
  }
 }
 // 5) İlaçlama penceresi: rüzgâr <15 km/s, yağış yok ve ertesi gün kuru, 8–28 °C. En iyi iki gün.
 if(ACTIVE(ctx.stage)){
  const ok=out.map((d,i)=>({d,i})).filter(({d,i})=>d.wind<15&&d.rain<0.5&&(d.rainProbability??0)<30&&(out[i+1]?.rain??0)<2&&d.max<=28&&d.max>=8&&d.min>0);
  ok.sort((a,b)=>a.d.wind-b.d.wind).slice(0,2).forEach(({d,i})=>add(i,{kind:'spray',label:'İlaçlama penceresi',why:`Rüzgâr en çok ${num(d.wind)} km/s, yağış yok, ertesi gün de kuru. Gerekirse uygulamak için uygun hava; ilaç kararı zararlının teşhisi ve sayımıyla verilir.`,task:'Gerekirse ilaçlama için uygun gün (teşhis ve sayımdan sonra)'}));
 }
 return out;
}

/** SEAS5 aylık sinyallerinden çiftçi diliyle 3 aylık görünüm. */
export function buildMonths(season,ctx={}){
 if(!season?.available||!Array.isArray(season.months))return [];
 return season.months.slice(0,3).map(m=>{
  const t=m.temperature,r=m.rain,mo=MONTHS[Number(m.month.slice(5))-1];
  const temp=t.direction==='warm'?{k:'warm',text:`Normalden sıcak (${t.anomaly>0?'+':''}${num(t.anomaly,1)} °C)`}:t.direction==='cold'?{k:'cold',text:`Normalden soğuk (${num(t.anomaly,1)} °C)`}:{k:'mixed',text:'Sıcaklıkta net sinyal yok'};
  const rain=r.direction==='dry'?{k:'dry',text:`Kurak eğilim${r.change!=null?` (%${num(r.change)})`:''}`}:r.direction==='wet'?{k:'wet',text:`Yağışlı eğilim${r.change!=null?` (+%${num(r.change)})`:''}`}:{k:'mixed',text:'Yağışta net sinyal yok'};
  const tasks=[];
  if(rain.k==='dry')tasks.push(ctx.water==='yok'?'Toprağı örtüyle koru, nemi tut':'Su bütçeni şimdiden planla');
  if(rain.k==='wet')tasks.push('Gübreyi yağışlar arasına böl, drenajı aç');
  if(temp.k==='warm')tasks.push('Zararlı takibine erken başla');
  if(temp.k==='cold')tasks.push('Geç don hazırlığını gözden geçir');
  if(!tasks.length)tasks.push('Olağan bakım takvimini sürdür');
  return {month:m.month,name:mo,temp,rain,members:m.members,tasks};
 });
}

export function calendarHtml(days,months,{weatherAvailable=true,seasonStatus='idle'}={}){
 const chip=(c,i,j)=>`<button class="fc-chip fc-${c.kind}" data-fc-chip="${i}-${j}" aria-expanded="false">${esc(c.label)}</button>`;
 const dayHtml=days.length?days.map((d,i)=>`<li class="fc-day${d.chips.some(c=>c.kind==='frost')?' fc-day-frost':''}"><div class="fc-dayname">${esc(d.dayName)}<span>${d.dayNum}</span></div><div class="fc-icon" aria-hidden="true">${d.icon}</div><div class="fc-temps"><strong>${num(d.max)}°</strong><span>${num(d.min)}°</span></div><div class="fc-meta">${d.rain>=0.5?`💧 ${num(d.rain,d.rain<10?1:0)} mm`:'—'} · ${num(d.wind)} km/s</div><div class="fc-chips">${d.chips.map((c,j)=>chip(c,i,j)).join('')}</div></li>`).join(''):`<li class="fc-empty">${weatherAvailable?'Hava bilgisi bekleniyor…':'Hava bilgisi şu an alınamadı; takvim hava gelince dolar.'}</li>`;
 const monthHtml=months.length?months.map(m=>`<li class="fc-month"><span class="fc-month-name">${esc(m.name)}</span><span class="fc-sig fc-${m.temp.k}">${esc(m.temp.text)}</span><span class="fc-sig fc-${m.rain.k}">${esc(m.rain.text)}</span><ul>${m.tasks.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></li>`).join(''):`<li class="fc-empty">${seasonStatus==='loading'?'Mevsimlik öngörü alınıyor…':'Mevsimlik öngörü şu an yok; Sezon ekranından yeniden deneyebilirsin.'}</li>`;
 return `<section class="farm-card fc" id="fc-calendar" aria-label="Tahmin takvimi"><header class="fc-head"><div><span class="farm-eyebrow">TAHMİN TAKVİMİN</span><h2>Önümüzdeki günler ve aylar için işler</h2></div><span class="fc-legend"><i class="fc-dot fc-spray"></i>İlaçlama <i class="fc-dot fc-fert"></i>Gübre <i class="fc-dot fc-water"></i>Sulama <i class="fc-dot fc-frost"></i>Don</span></header>
 <ol class="fc-days">${dayHtml}</ol><div class="fc-detail" id="fc-detail" hidden></div>
 <h3 class="fc-sub">Önümüzdeki 3 ay <small>ECMWF SEAS5 · 51 senaryo · model iklimine göre</small></h3><ol class="fc-months">${monthHtml}</ol>
 <p class="fc-source">Günler: Open-Meteo bölgesel tahmin. Aylar: ECMWF SEAS5 mevsimlik öngörü (Open-Meteo). Sulama: FAO-56 su dengesi. Tahmin parsel ölçümü değildir.</p></section>`;
}

export function bindCalendar(host,days,{onAddTask}={}){
 if(!host)return;
 const detail=host.querySelector('#fc-detail');
 host.querySelectorAll('[data-fc-chip]').forEach(b=>b.addEventListener('click',()=>{
  const [i,j]=b.dataset.fcChip.split('-').map(Number),d=days[i],c=d?.chips[j];if(!c)return;
  const open=b.getAttribute('aria-expanded')==='true';
  host.querySelectorAll('[data-fc-chip]').forEach(x=>x.setAttribute('aria-expanded','false'));
  if(open){detail.hidden=true;return;}
  b.setAttribute('aria-expanded','true');
  detail.innerHTML=`<strong>${esc(d.dayName)} · ${esc(c.label)}</strong><p>${esc(c.why)}</p><button class="farm-quiet-btn" data-fc-add>+ ${esc(d.dayName)} işlerime ekle</button>`;
  detail.hidden=false;
  detail.querySelector('[data-fc-add]').addEventListener('click',e=>{const ok=onAddTask?.(c.task,d.date);e.target.textContent=ok===false?'Bu iş zaten listende':'✓ İşlerine eklendi';e.target.disabled=true;});
 }));
}
