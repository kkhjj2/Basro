// Ana ekran düzeni (home-2): önce tarlanın kararı ve günün işleri, yan sütunda küçük "Günün bilgisi", tek hava bloğu (takvim), en sonda rapor.
// Öğeler yalnızca taşınır; kimlikler ve olay dinleyicileri aynı kalır. İkinci hava kartı gizlenir (takvim aynı veriyi gösterir).
let bookTab='today';
export function arrangeToday(main){
 if(!main)return false;const q=s=>main.querySelector(s);
 const hero=q('.garden-welcome'),pulse=q('.ab-pulse'),layout=q('.farm-layout'),cal=q('#fc-host'),di=q('#daily-info'),wr=q('#wr-host');
 if(!hero||!layout)return false;
 if(pulse)hero.after(pulse);
 (pulse||hero).after(layout);
 // İki sütun: solda sekmeli tarla defteri (Bugün: işler · Bu hafta: hava takvimi · Geçmiş: tarla hafızası ve haftalık rapor), sağda fotoğraf ve küçük günün bilgisi.
 const tasks=layout.querySelector('.farm-tasks'),photo=layout.querySelector('.farm-photo-card');
 const mem=[...main.querySelectorAll('.farm-section')].find(x=>x.querySelector('.farm-small-grid'));
 if(tasks&&photo&&!layout.querySelector('.ab-col')){
  const L=document.createElement('div'),R=document.createElement('div');L.className='ab-col';R.className='ab-col ab-col-side';
  layout.prepend(L,R);R.append(photo);if(di)R.append(di);
  const book=document.createElement('section');book.className='ab-book';
  const tabs=[['today','Bugün',[tasks]],['week','Bu hafta',[cal]],['past','Geçmiş',[mem,wr]]].map(([id,label,els])=>[id,label,els.filter(Boolean)]).filter(t=>t[2].length);
  const bar=document.createElement('div');bar.className='ab-book-tabs';bar.setAttribute('role','tablist');bar.setAttribute('aria-label','Tarla defteri');
  const show=id=>{bookTab=id;bar.querySelectorAll('button').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.book===id)));book.querySelectorAll('.ab-book-page').forEach(pg=>{pg.hidden=pg.dataset.book!==id;});};
  book.append(bar);
  for(const [id,label,els] of tabs){const b=document.createElement('button');b.type='button';b.setAttribute('role','tab');b.dataset.book=id;b.textContent=label;b.addEventListener('click',()=>show(id));bar.append(b);
   const pg=document.createElement('div');pg.className='ab-book-page';pg.dataset.book=id;pg.append(...els);book.append(pg);}
  L.append(book);show(tabs.some(t=>t[0]===bookTab)?bookTab:'today');
 }else if(di)layout.append(di);
 layout.querySelectorAll('.farm-weather').forEach(w=>{w.hidden=true;});
 main.dataset.home='2';return true;
}
