// Fotoğraf kanıtı (vision-lite-1): yapay zekâ çıktısını süzer ve "karar düzeyi" olup olmadığını belirler.
// Kural: kanıt ancak fotoğraf kullanılabilir, model çekimser değil, kayıtlı ürün görünüyor ve evre güveni ≥ 0,6 ise hesaba girer.
// Fotoğraftan ASLA çıkarılmayanlar: toprak pH, besin düzeyi, kesin toprak nemi, sulama miktarı, verim, kesin hastalık teşhisi.
export const VISION_SCHEMA='vision-lite-1';
export const MIN_CONFIDENCE=0.6;
export const PHOTO_STAGES=['Yeni ekim / dikim','Yapraklanma / büyüme','Çiçeklenme','Meyve / dane gelişimi','Hasat','Hasat sonrası'];
export const NEVER_FROM_IMAGE=['soil_ph','nutrient_levels','exact_soil_moisture','irrigation_amount','yield','disease_diagnosis'];
const norm=s=>String(s??'').toLocaleLowerCase('tr-TR').normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/ı/g,'i').replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();

/** raw: modelin {usable, plant, stage, stageConfidence} alanları. registeredCrop: çiftçinin kayıtlı ürünü. */
export function gradeVision(raw,registeredCrop){
 const usable=raw?.usable!==false&&raw?.usable!=='false';
 const plant=typeof raw?.plant==='string'?raw.plant.trim().slice(0,80):'';
 const unknownPlant=!plant||/^belirsiz/i.test(plant);
 const stage=PHOTO_STAGES.find(s=>norm(s)===norm(raw?.stage))||null;
 let confidence=Number(raw?.stageConfidence);confidence=Number.isFinite(confidence)?Math.min(1,Math.max(0,confidence)):0;
 const a=norm(registeredCrop),b=norm(plant);
 const cropMatch=!unknownPlant&&!!a&&(b.includes(a)||a.includes(b)||a.split(' ').some(w=>w.length>3&&b.includes(w)));
 const abstain=!usable||unknownPlant||!stage;
 const decisionGrade=!abstain&&cropMatch&&confidence>=MIN_CONFIDENCE;
 const reason=!usable?'Fotoğraf net değil ya da bitki görünmüyor.':unknownPlant?'Bitki tanınamadı.':!stage?'Gelişme dönemi fotoğraftan anlaşılamadı.':!cropMatch?`Fotoğrafta kayıtlı ürünün (${registeredCrop}) yerine “${plant}” görünüyor.`:confidence<MIN_CONFIDENCE?`Dönem tahmini yeterince güvenli değil (%${Math.round(confidence*100)}).`:null;
 const tip=!usable?'Gün ışığında, bitkiye 30–50 cm yaklaşıp telefonu sabit tutarak yeniden çek.':unknownPlant||!cropMatch?'Kayıtlı ürününün bir yaprağını ya da meyvesini kadraja tek başına al.':!stage||confidence<MIN_CONFIDENCE?'Bitkinin tamamını, çiçek ya da meyve görünecek şekilde bir de uzaktan çek.':null;
 return {schema:VISION_SCHEMA,usable,abstain,plant:unknownPlant?null:plant,cropMatch,stage,confidence,decisionGrade,reason,tip,cannotInfer:NEVER_FROM_IMAGE};
}
