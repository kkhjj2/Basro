// Günlük bilgi kartı: güneş/ay bilgisi (konumdan hesaplanır), ayın tarla notu ve her gün değişen kısa bilgiler.
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const REGION = {
  Malatya: [
    'Malatya, Türkiye\'nin kuru kayısı üretiminde ilk sıradadır; dünyada satılan kuru kayısının büyük bölümü buradan çıkar.',
    'Turuncu kuru kayısının rengi kükürtleme ile korunur. Kükürtsüz, güneşte kurutulan "gün kurusu" kayısı koyu kahverengi olur.',
    'Kayısının en büyük düşmanı ilkbahar geç donlarıdır. Çiçek ve küçük meyve döneminde birkaç saatlik don, bütün yılın ürününü etkileyebilir.',
    'Battalgazi\'deki Arslantepe Höyüğü 2021\'de UNESCO Dünya Mirası Listesi\'ne girdi. Höyük, binlerce yıllık yerleşim katmanları barındırıyor.',
    'Fırat Nehri üzerindeki Karakaya Baraj Gölü, Malatya\'nın kuzey ve doğusunda uzanır; bölge iklimini ve sulamayı etkiler.',
    'Darende\'deki Tohma Kanyonu ve Günpınar Şelalesi, Tohma Çayı\'nın yüzyıllar içinde kayaları oymasıyla oluşmuştur.',
    'Malatya karasal iklime sahiptir: yazlar sıcak ve kurak, kışlar soğuktur. Bu yüzden yaz aylarında sulama planı kritik önemdedir.',
    'Battalgazi\'deki (Eski Malatya) Ulu Camii, Anadolu Selçuklu döneminden kalma önemli bir yapıdır.',
  ],
};
Object.assign(REGION, {
  Konya: ['Konya Ovası, Türkiye\'nin en büyük hububat alanlarındandır ve "tahıl ambarı" diye anılır.', 'Konya Kapalı Havzası\'nda yeraltı suyu düşüyor; damla sulama burada her damlanın değerini artırır.'],
  Şanlıurfa: ['Harran Ovası, GAP sulamasıyla Türkiye\'nin en önemli pamuk alanlarından biri oldu.'],
  Adana: ['Çukurova, ılıman iklimi sayesinde pamuk, narenciye ve mısırla bilinir; yılda iki ürün alınabilen alanları vardır.'],
  Rize: ['Rize, Türkiye çay üretiminin merkezidir; çay yaprağı yılda birkaç sürgün döneminde toplanır.'],
  Ordu: ['Ordu, dünyanın en büyük fındık üretim bölgelerinden biridir.'],
  Giresun: ['Giresun fındığı, ince kabuğu ve yüksek iç oranıyla bilinir.'],
  Manisa: ['Manisa, sultani çekirdeksiz kuru üzüm üretiminin merkezidir.'],
  Isparta: ['Isparta yağlık gül tarımıyla bilinir; gül çiçekleri mayıs–haziranda sabah erken toplanır.'],
  Antalya: ['Antalya, örtü altı sebze yetiştiriciliğinin Türkiye\'deki en büyük merkezidir.'],
  Aydın: ['Aydın, incir ve zeytin bahçeleriyle bilinir; kuru incir ihracatında öne çıkar.'],
});
// Halk takvimi (yaklaşık; yöreye göre birkaç gün oynar)
const FOLK = [
  ['01-01', '01-30', 'Zemheri günlerindeyiz: halk takviminde yılın en soğuk dönemi.'],
  ['02-19', '02-21', 'Halk takviminde birinci cemre havaya düşer. Erken uyanan tomurcuklarda don riski sürer.'],
  ['02-26', '02-28', 'İkinci cemre suya düşer, der halk takvimi. Kanalları ve hendekleri temizlemeyi planla.'],
  ['03-05', '03-07', 'Üçüncü cemre toprağa düşer. Toprak tavına gelmeden, çamurken sürmek yapısını bozar.'],
  ['03-09', '03-16', 'Halk arasında "kocakarı soğuğu" denen dönem: ılık günlerden sonra kısa bir soğuk dalga gelebilir.'],
  ['05-05', '05-07', 'Hıdrellez: halk takviminde yazın başlangıcı. Birçok yörede yazlık fideler tarlaya çıkar.'],
  ['06-20', '06-22', 'Yılın en uzun günleri. Sulamayı sabah erken ya da akşam serinliğine kaydır.'],
  ['11-07', '11-10', 'Halk takviminde "Kasım günü" (8 Kasım) kışın başladığı gün sayılır. Kışlık hububat ekiminde son düzlükteyiz.'],
  ['12-20', '12-23', 'Yılın en uzun gecesi (21–22 Aralık). Bundan sonra günler yeniden uzar.'],
];
export function folkNote(date = new Date()) {
  const md = String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0');
  return FOLK.find(([a, b]) => md >= a && md <= b)?.[2] || null;
}
const DISTRICT = {
  'Doğanşehir': 'Doğanşehir, Malatya\'nın yüksek rakımlı ilçelerindendir; serin geceler elma gibi meyvelerin renk tutmasına yardım eder.',
  'Darende': 'Darende, Tohma Çayı vadisinde kurulmuştur; vadi tabanındaki bahçeler çayın suyuyla sulanır.',
  'Battalgazi': 'Battalgazi, kayısı bahçelerinin en yoğun olduğu ilçelerdendir ve Eski Malatya\'nın tarihi yapılarına ev sahipliği yapar.',
  'Yeşilyurt': 'Yeşilyurt, kent merkezine bitişik bahçeleri ve kiraz-kayısı yetiştiriciliğiyle bilinir.',
};
const FARMING = [
  'Baklagiller (nohut, mercimek, fasulye) köklerindeki bakterilerle havadaki azotu toprağa bağlar. Ekim nöbetine baklagil eklemek gübre ihtiyacını azaltır.',
  'Sabah erken saatlerde sulamak, öğle sıcağına göre buharlaşma kaybını belirgin şekilde azaltır.',
  'Malç (saman, kompost, örtü) toprağın nemini korur, sıcaklığını dengeler ve yabani otu bastırır.',
  'Damla sulama, suyu doğrudan kök bölgesine verdiği için salma sulamaya göre çok daha az su harcar.',
  'Çoğu sebze, pH değeri 6 ile 7 arasındaki hafif asidik ya da nötr topraklarda en iyi gelişir.',
  'Aynı tarlaya her yıl aynı ürünü ekmek, o ürüne özgü hastalık ve zararlıların birikmesine yol açar. Ekim nöbeti bu döngüyü kırar.',
  'Birkaç santimetrelik verimli üst toprağın oluşması yüzlerce yıl sürebilir. Erozyonla kaybedilen toprak kolay geri gelmez.',
  'Arılar meyve ağaçlarında tozlaşmayı artırır. Çiçeklenme döneminde ilaçlamayı arıların uçmadığı akşam saatlerine kaydırmak onları korur.',
  'Toprak organik maddesi arttıkça toprak süngerleşir ve daha fazla su tutar; kompost bunun en kolay yoludur.',
  'Domates aslen Güney Amerika\'nın And bölgesinden gelir; Avrupa\'ya 16. yüzyılda ulaşmıştır.',
  'Güneydoğu Anadolu\'daki Karacadağ çevresi, ilk evcilleştirilen buğday türlerinden siyez (einkorn) buğdayının anavatanı olarak gösterilir.',
  '1 mm yağış, 1 dekar tarlaya 1 ton su demektir. 10 mm yağış dekara 10 ton su bırakır.',
  'Don gecesinde soğuk hava yere yakın ve çukurlarda toplanır; yamaçtaki bahçeler çukur yerlere göre daha az etkilenir.',
  'Yaprak üstü ilaçlamada rüzgâr saatte 15 km\'yi geçerse damlacıklar sürüklenir ve komşu tarlaya gider.',
  'Toprak 10 °C\'nin altındayken mısır ve fasulye tohumu çimlenmekte zorlanır; ekimde toprak sıcaklığı havadan önemlidir.',
  'Toprak analizi 3–4 yılda bir yapıldığında gübre gereğinden fazla ya da eksik verilmez, hem para hem toprak korunur.',
  'Yapraklarda sabah çiğinin uzun süre kalması mantar hastalıklarını kolaylaştırır. Sık dikimden kaçınmak hava akışını artırır.',
];
const SPACE = [
  'NASA\'nın SMAP uydusu 2015\'ten beri toprağın üst katmanındaki nemi mikrodalga ile ölçüyor. Bu uygulamadaki toprak nemi verisi oradan geliyor.',
  'Sağlıklı yapraklar yakın kızılötesi ışığı güçlü biçimde yansıtır. Uydular bitki sağlığını (NDVI) bu farktan hesaplar.',
  'Landsat uyduları 1972\'den beri Dünya yüzeyini fotoğraflıyor; yarım asırlık arazi kullanımı değişimi bu arşivden izlenebiliyor.',
  'ECMWF mevsimlik tahmini 51 farklı senaryo çalıştırır. Basro bu yüzden kesin gün değil "eğilim" söyler.',
  'NASA POWER, güneş ışınımı, sıcaklık ve yağış gibi tarımsal iklim verilerini dünyanın her noktası için ücretsiz sunar.',
];
const MONTH = [
  'Ocak: Aletlerin bakımını yap, budama planını çıkar. Toprak donmuyorsa analiz için örnek alabilirsin.',
  'Şubat: Kış budaması için uygun dönem; kayısıda büyük kesimleri kuru ve donsuz günlere bırak.',
  'Mart: Tomurcuk patlıyor. Gece sıcaklıklarını izle; don tahmini varsa önlem planın hazır olsun.',
  'Nisan: Geç don riski sürüyor. Çiçeklenmede arıları korumak için ilaçlamayı akşama kaydır.',
  'Mayıs: Sulama sezonu başlıyor. Meyve tutumu fazlaysa seyreltme iri ve kaliteli meyve sağlar.',
  'Haziran: Kiraz hasadı sürerken kayısıda hasat yaklaşıyor. Sıcak günlerde sulama aralığını kısalt.',
  'Temmuz: Sıcaklık ve su ihtiyacı zirvede. Sabah erken sulama ve malç su kaybını azaltır.',
  'Ağustos: Kurutma ve hasat sonrası dönem. Kurutma alanını toz ve nemden koru.',
  'Eylül: Hasat sonrası ağaçlar gelecek yılın tomurcuklarını oluşturur; su ve besini kesme.',
  'Ekim: Buğday ve arpa ekim zamanı. Ekimden önce toprak nemini ve tohum yatağını kontrol et.',
  'Kasım: Dökülen yaprakları ve hastalıklı dalları temizle; kışı geçiren zararlıların sayısı azalır.',
  'Aralık: Yılın kayıtlarını gözden geçir: hangi tarla ne verdi, ne kadar su ve gübre harcandı?',
];

const rad = Math.PI / 180;
function dayOfYear(d) { return Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(d.getFullYear(), 0, 0)) / 864e5); }
// NOAA yaklaşık güneş hesabı: doğuş/batış (yerel saat) ve gün uzunluğu.
export function sunInfo(lat, lon, date = new Date(), tz = 'Europe/Istanbul') {
  const n = dayOfYear(date), g = (2 * Math.PI / 365) * (n - 1);
  const eqt = 229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
  const decl = 0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 0.006758 * Math.cos(2 * g) + 0.000907 * Math.sin(2 * g) - 0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
  const cosH = (Math.cos(90.833 * rad) - Math.sin(lat * rad) * Math.sin(decl)) / (Math.cos(lat * rad) * Math.cos(decl));
  if (cosH > 1 || cosH < -1) return null;
  const ha = Math.acos(cosH) / rad;
  const noonUtc = 720 - 4 * lon - eqt; // dakika
  // Saat, tarlanın saat diliminde (varsayılan Türkiye) gösterilir; tarayıcının saat dilimi değil.
  const day0 = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
  const fmt = (m) => new Intl.DateTimeFormat('tr-TR', { hour: '2-digit', minute: '2-digit', timeZone: tz }).format(new Date(day0 + Math.round(m) * 6e4));
  const len = (8 * ha);
  return { rise: fmt(noonUtc - 4 * ha), set: fmt(noonUtc + 4 * ha), hours: Math.floor(len / 60), minutes: Math.round(len % 60) };
}
export function moonInfo(date = new Date()) {
  const syn = 29.530588853, ref = Date.UTC(2000, 0, 6, 18, 14);
  const age = (((date.getTime() - ref) / 864e5) % syn + syn) % syn;
  const names = ['Yeni ay', 'Hilal (büyüyen)', 'İlk dördün', 'Şişkin ay (büyüyen)', 'Dolunay', 'Şişkin ay (küçülen)', 'Son dördün', 'Hilal (küçülen)'];
  const icons = ['🌑', '🌒', '🌓', '🌔', '🌕', '🌖', '🌗', '🌘'];
  const i = Math.floor(((age / syn) * 8 + 0.5)) % 8;
  return { name: names[i], icon: icons[i], illum: Math.round((1 - Math.cos((2 * Math.PI * age) / syn)) / 2 * 100) };
}

export function factsFor(farm) {
  const list = [];
  if (farm?.district && DISTRICT[farm.district]) list.push({ tag: farm.district, text: DISTRICT[farm.district] });
  for (const t of REGION[farm?.city] || []) list.push({ tag: farm.city, text: t });
  for (const t of FARMING) list.push({ tag: 'Tarım', text: t });
  for (const t of SPACE) list.push({ tag: 'Uzaydan tarım', text: t });
  return list;
}
function dayIndex(d = new Date()) { return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5); }

export function dailyInfoHtml(farm, date = new Date()) {
  const facts = factsFor(farm), i = dayIndex(date) % facts.length, f = facts[i];
  const sun = Number.isFinite(farm?.lat) && Number.isFinite(farm?.lon) ? sunInfo(farm.lat, farm.lon, date) : null;
  const moon = moonInfo(date);
  return `<section class="farm-card di-card" id="daily-info" data-index="${i}" aria-labelledby="di-title">
  <header class="farm-card-title"><h2 id="di-title">Günün bilgisi</h2><span>${esc(date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', weekday: 'long' }))}</span></header>
  <div class="di-sky">
    ${sun ? `<div class="di-pill"><span aria-hidden="true">🌅</span><b>${sun.rise}</b><small>Gün doğumu</small></div><div class="di-pill"><span aria-hidden="true">🌇</span><b>${sun.set}</b><small>Gün batımı</small></div><div class="di-pill"><span aria-hidden="true">☀️</span><b>${sun.hours} sa ${sun.minutes} dk</b><small>Gün uzunluğu</small></div>` : ''}
    <div class="di-pill"><span aria-hidden="true">${moon.icon}</span><b>${moon.name}</b><small>Ay · %${moon.illum} aydınlık</small></div>
  </div>
  <figure class="di-fact"><figcaption class="di-tag">${esc(f.tag)}</figcaption><blockquote id="di-text">${esc(f.text)}</blockquote></figure>
  ${folkNote(date) ? `<div class="di-month di-folk"><b>Takvimde bugün</b><p>${esc(folkNote(date))}</p></div>` : ''}
  <div class="di-month"><b>Bu ayın tarla notu</b><p>${esc(MONTH[date.getMonth()])}</p></div>
  <button type="button" class="di-next" id="di-next">Başka bir bilgi göster →</button>
</section>`;
}

export function mountDailyInfo(host, farm) {
  if (!host) return;
  const facts = factsFor(farm);
  let i = Number(host.dataset.index) || 0;
  host.querySelector('#di-next')?.addEventListener('click', () => {
    i = (i + 1) % facts.length;
    host.querySelector('.di-tag').textContent = facts[i].tag;
    host.querySelector('#di-text').textContent = facts[i].text;
  });
}
