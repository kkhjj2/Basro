// Basro 2.0 tarla çalışma alanı: dört soru tek ekranda, tek tarla durumu üzerinden.
// 1) Tarlamın durumu  2) Şimdi hangi bilgiyi toplamalıyım?  3) Planımın geleceği  4) Ne değişti?
import {evaluateWater,chooseQuestion,explainChange,ACTION_TEXT,SOILS,FEEL,STAGE_KC,ENGINE_VERSION} from './field-engine.mjs';

const KEY='agrobas-field-v1';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today=()=>new Date().toISOString().slice(0,10);
const evidenceCache=new Map();

function load(storage){try{return JSON.parse(storage.getItem(KEY)||'{}')||{};}catch{return {};}}
function save(storage,all){try{storage.setItem(KEY,JSON.stringify(all));}catch{}}

import {mountSoilBlock} from './soil-block.mjs';
export async function fetchEvidence(farm){
 const k=farm.lat.toFixed(4)+','+farm.lon.toFixed(4);
 if(evidenceCache.has(k))return evidenceCache.get(k);
 const p=fetch(`/api/field-evidence?lat=${farm.lat}&lon=${farm.lon}`,{signal:AbortSignal.timeout(15000)}).then(r=>r.ok?r.json():{smap:{available:false}}).catch(()=>({smap:{available:false,reason:'Uydu kanıtına ulaşılamadı.'}}));
 evidenceCache.set(k,p);return p;
}

/** Profil + kayıtlı gözlemler + uydu kanıtı → motorun tek tarla durumu. */
export function buildState(farm,record,weather,evidence){
 const feel=record.feel&&record.feel.day>=new Date(Date.now()-3*86400000).toISOString().slice(0,10)?record.feel:null; // yoklama 3 gün geçerli
 const smap=evidence?.smap?.available?evidence.smap:null;
 return {crop:farm.crop,stage:record.stage||farm.stage,water:farm.water,lat:farm.lat,
  soil:record.soil?{value:record.soil,source:'farmer'}:{value:null,source:'unknown'},
  moisture:feel?{kind:'feel',value:feel.value}:smap?{kind:'smap',theta:smap.theta,recordedDay:smap.window.end}:null,
  irrigationDays:record.irrigation?record.irrigation.days+Math.round((Date.parse(today())-Date.parse(record.irrigation.day))/86400000):null,
  weather:weather?.available?weather.rows.map(r=>({date:r.date,min:r.min,max:r.max,rain:r.rain})):null};
}

const tag=(text,kind)=>`<span class="fw-tag fw-tag-${kind}">${esc(text)}</span>`;

function stateCard(farm,state,r,record,evidence){
 const a=ACTION_TEXT[r.action];
 const moisture=r.moistureSource==='irrigation'?`Son sulamadan bu yana tahmini ${r.Dr0} mm su kullanıldı ${tag('senin sulama kaydın · '+record.irrigation.day,'farmer')}${state.moisture?.kind==='smap'?' '+tag('SMAP 9 km model de var','model'):''}`
  :state.moisture?.kind==='feel'?`${esc(FEEL[state.moisture.value].label)} ${tag('senin yoklaman · '+record.feel.day,'farmer')}`
  :state.moisture?.kind==='smap'?`Kök bölgesi nemi ${(state.moisture.theta).toFixed(2).replace('.',',')} m³/m³ (±0,04) ${tag('NASA SMAP L4 · 9 km model · '+evidence.smap.window.end,'model')}`
  :`Bilinmiyor ${tag(evidence?.smap?.distanceKm!=null?'bu nokta için uydu kaydı yok':'uydu kanıtı bekleniyor','unknown')}`;
 const rows=[
  ['Ürün ve dönem',`${esc(farm.crop)} · ${esc(state.stage)} ${tag(STAGE_KC[state.stage]===undefined?'dönem belirsiz':record.stageSource==='photo'?'fotoğraf kanıtı · '+record.stageDay:'senin beyanın',record.stageSource==='photo'?'model':'farmer')}`],
  ['Toprak',state.soil.source==='farmer'?`${esc(SOILS[state.soil.value].label)} ${tag('senin beyanın','farmer')}`:`Bilinmiyor; şimdilik killi tın varsayıldı ${tag('varsayım','unknown')}`],
  ['Toprak nemi',moisture],
  ['Önümüzdeki 7 gün',r.etc7!=null?`Bitkinin su ihtiyacı ~${r.etc7.toString().replace('.',',')} mm, etkili yağış ~${r.rain7.toString().replace('.',',')} mm ${tag('Open-Meteo bölgesel tahmin','model')}`:`Hava alınamadı ${tag('eksik','unknown')}`],
  ['Sulama imkânı',`${{var:'Var',yok:'Yok',kısıtlı:'Kısıtlı'}[farm.water]||'—'} ${tag('senin beyanın','farmer')}`]
 ];
 const amount=r.action==='irrigate'&&r.amountMm?`<p class="fw-amount">Yaklaşık <strong>${r.amountTonPerDecare} ton/dekar</strong> (${r.amountMm} mm) su, kök bölgesini doldurur.</p>`:r.action==='soon'&&r.daysToRaw?`<p class="fw-amount">Bu gidişle yaklaşık <strong>${r.daysToRaw} gün</strong> sonra bitki strese girmeye başlar.</p>`:'';
 return `<section class="farm-card fw-card fw-state"><span class="fw-step">1</span><span class="farm-eyebrow">TARLAMIN DURUMU</span>
  <div class="fw-decision fw-${a.tone}"><span>Su kararı</span><strong>${esc(a.title)}</strong>${r.availablePct!=null?`<em>Kökte bitkinin kullanabileceği suyun yaklaşık %${r.availablePct}'i var.</em>`:''}</div>${amount}
  <dl class="fw-facts">${rows.map(([k,v])=>`<div><dt>${k}</dt><dd>${v}</dd></div>`).join('')}</dl>
  ${r.notes.map(n=>`<p class="fw-note">${esc(n)}</p>`).join('')}</section>`;
}

function questionCard(q){
 if(!q.question)return `<section class="farm-card fw-card fw-question"><span class="fw-step">2</span><span class="farm-eyebrow">ŞİMDİ HANGİ BİLGİYİ TOPLAMALIYIM?</span><h2>Şu an yeni bir ölçüme gerek yok.</h2><p>${esc(q.reason)}</p><p class="fw-small">Toprak yoklaman 3 gün geçerli sayılır; sonra yeniden sorarım.</p></section>`;
 const b=q.question;
 return `<section class="farm-card fw-card fw-question"><span class="fw-step">2</span><span class="farm-eyebrow">ŞİMDİ HANGİ BİLGİYİ TOPLAMALIYIM?</span><h2>${esc(b.title)}</h2>
  <p class="fw-why"><strong>Bu soruyu sordum çünkü</strong> ${esc(q.reason)}</p>
  <p class="fw-small">Gereken: ${esc(b.tool)} · yaklaşık ${b.minutes} dakika</p>
  <div class="fw-answers">${b.answers.map(a=>`<button class="fw-answer" data-fw-answer="${esc(b.id)}" data-fw-value="${esc(a.value)}">${esc(a.label)}</button>`).join('')}</div>
  ${q.ranked.length>1?`<details class="fw-ranked"><summary>Diğer adaylar ve neden geride kaldılar</summary><ul>${q.ranked.slice(1).map(c=>`<li>${esc(c.title)} — kararı değiştirme olasılığı %${Math.round(c.changeProbability*100)}</li>`).join('')}</ul><p class="fw-small">Sıralama: cevabın kararı değiştirme olasılığı ÷ zahmet. Aynı durumda hep aynı soru gelir.</p></details>`:''}
 </section>`;
}

function futureCard(ctx){
 const s=ctx.seasonSummary;
 return `<section class="farm-card fw-card fw-future"><span class="fw-step">3</span><span class="farm-eyebrow">PLANIMIN GELECEĞİ</span><h2>${esc(s?.title||'Önümüzdeki aylar ve sonraki ürün')}</h2>
  <p>${esc(s?.text||'ECMWF SEAS5 mevsimlik öngörüsü ve NASA POWER iklim geçmişiyle önümüzdeki 3–12 ayı planla; sonraki ürünleri su ve toprak açısından yan yana koy.')}</p>
  ${s?.actions?.length?`<ul class="fw-list">${s.actions.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
  <div class="fw-buttons"><button class="farm-primary" data-fw-open="season">Sezon planım</button><button class="farm-quiet-btn" data-fw-open="lab">Rotasyon laboratuvarı</button></div></section>`;
}

function changeCard(record){
 const last=record.history?.at(-1);
 if(!last)return `<section class="farm-card fw-card fw-change"><span class="fw-step">4</span><span class="farm-eyebrow">NE DEĞİŞTİ?</span><h2>Henüz yeni bir bilgi eklenmedi.</h2><p>Soruyu cevapladığında hangi hesabın değiştiğini ve kararın değişip değişmediğini burada önce/sonra olarak göreceksin.</p></section>`;
 const c=last.change;
 return `<section class="farm-card fw-card fw-change"><span class="fw-step">4</span><span class="farm-eyebrow">NE DEĞİŞTİ? · ${esc(last.day)}</span><h2>${esc(c.summary)}</h2>
  <p class="fw-small">Eklenen bilgi: ${esc(c.changedInput)}</p>
  <div class="fw-before-after"><div><span>Önce</span><strong>${esc(c.before)}</strong></div><span aria-hidden="true">→</span><div class="${c.decisionChanged?'fw-changed':''}"><span>Sonra</span><strong>${esc(c.after)}</strong></div></div>
  ${c.diffs.length?`<table class="fw-diff"><thead><tr><th>Hesap</th><th>Önce</th><th>Sonra</th></tr></thead><tbody>${c.diffs.map(d=>`<tr><td>${esc(d.label)}</td><td>${esc(d.before)}</td><td>${esc(d.after)}</td></tr>`).join('')}</tbody></table>`:''}
  ${record.history.length>1?`<details class="fw-ranked"><summary>Önceki değişiklikler (${record.history.length-1})</summary><ul>${record.history.slice(0,-1).reverse().slice(0,6).map(h=>`<li>${esc(h.day)} · ${esc(h.change.changedInput)} → ${esc(h.change.after)}</li>`).join('')}</ul></details>`:''}
 </section>`;
}

export function workspaceHtml(){return `<div class="fw" id="field-workspace" aria-live="polite"><div class="fw-head"><div><span class="farm-eyebrow">TARLA ÇALIŞMA ALANI</span><h1>Tarlan, kararın <em>ve nedeni.</em></h1><p>Her değer nereden geldiğiyle birlikte. Bir bilgi eklediğinde neyin değiştiğini görürsün.</p></div></div><div class="fw-grid"><div class="fw-loading">Tarla durumu hazırlanıyor…</div></div><p class="fw-method">Yöntem: FAO-56 kök bölgesi su dengesi (Hargreaves ET₀, bitki katsayısı Kc, toprak su tutma Tablo 19) · ${ENGINE_VERSION}. Model tahminleri parsel ölçümü değildir.</p></div>`;}

/** ctx = {farm, weather, storage, seasonSummary, onOpen(view), onStage(stage)} */
export function mountWorkspace(host,ctx){
 if(!host)return ()=>{};
 let alive=true,evidence=null;
 const all=()=>load(ctx.storage),record=()=>all()[ctx.farm.id]||{history:[]};
 const paint=()=>{
  if(!alive)return;
  const rec=record(),state=buildState(ctx.farm,rec,ctx.weather,evidence),r=evaluateWater(state),q=chooseQuestion(state);
  host.querySelector('.fw-grid').innerHTML=stateCard(ctx.farm,state,r,rec,evidence)+questionCard(q)+futureCard(ctx)+changeCard(rec);
  {const dec=host.querySelector('.fw-decision');if(dec){const slot=document.createElement('div');slot.className='sb-slot';dec.after(slot);if(!mountSoilBlock(slot,r))slot.remove();}}
  host.querySelectorAll('[data-fw-answer]').forEach(b=>b.addEventListener('click',()=>answer(b.dataset.fwAnswer,b.dataset.fwValue,b.textContent)));
  host.querySelectorAll('[data-fw-open]').forEach(b=>b.addEventListener('click',()=>ctx.onOpen?.(b.dataset.fwOpen)));
 };
 const answer=(id,value,label)=>{
  const store=all(),rec=store[ctx.farm.id]||{history:[]};
  const before=evaluateWater(buildState(ctx.farm,rec,ctx.weather,evidence));
  const next={...rec,history:[...(rec.history||[])]};
  let input='';
  if(id==='feel'){next.feel={value,day:today()};input='Toprak yoklaması: '+label;}
  else if(id==='soil'){next.soil=value;input='Toprak bünyesi: '+label;}
  else if(id==='irrigation'){next.irrigation={days:Number(value),day:today()};input='Son sulama: '+label;}
  else if(id==='stage'){next.stage=value;next.stageSource='farmer';next.stageDay=today();input='Gelişme dönemi: '+label;ctx.onStage?.(value);}
  const after=evaluateWater(buildState(ctx.farm,next,ctx.weather,evidence));
  next.history.push({day:today(),input:{id,value},change:explainChange(before,after,input),version:ENGINE_VERSION});
  next.history=next.history.slice(-30);
  store[ctx.farm.id]=next;save(ctx.storage,store);
  paint();ctx.onChange?.();host.querySelector('.fw-change')?.scrollIntoView({behavior:'smooth',block:'nearest'});
 };
 paint();
 fetchEvidence(ctx.farm).then(e=>{evidence=e;paint();});
 return ()=>{alive=false;};
}

/** Bugün ekranı için kısa özet: su kararı + sıradaki soru. Ayrıntı Tarlam'da. */
/** Gözlem ağı ve benzeri modüller için güncel tarla durumu (aynı kayıt, aynı kanıt). */
export async function currentState(farm,storage,weather){const rec=load(storage)[farm.id]||{history:[]};return buildState(farm,rec,weather,await fetchEvidence(farm));}
export function teaserHtml(){return `<section class="farm-card fw-teaser" id="fw-teaser"><div><span class="farm-eyebrow">TARLA ÇALIŞMA ALANI</span><h2>Tarlanın su kararı hazırlanıyor…</h2><p>Uydu, hava ve senin bilgilerinle.</p></div><button class="farm-primary" data-fw-teaser>Tarlama bak →</button></section>`;}
export function mountTeaser(host,ctx){
 if(!host)return;
 host.querySelector('[data-fw-teaser]')?.addEventListener('click',()=>ctx.onOpen?.());
 const rec=load(ctx.storage)[ctx.farm.id]||{history:[]};
 fetchEvidence(ctx.farm).then(ev=>{
  if(!host.isConnected)return;
  const st=buildState(ctx.farm,rec,ctx.weather,ev),q=chooseQuestion(st),a=ACTION_TEXT[q.base.action];
  host.querySelector('h2').textContent='Su kararı: '+a.title;ctx.onDecision?.(q.base);
  host.querySelector('p').textContent=q.question?'Kararı netleştirecek bilgi: '+q.question.title:'Şu an yeni bir ölçüme gerek yok.';
  let slot=host.querySelector('.sb-slot');if(!slot){slot=document.createElement('div');slot.className='sb-slot';host.append(slot);}
  if(mountSoilBlock(slot,q.base))host.classList.add('fw-teaser-soil');else slot.remove();
 });
}

/**
 * Fotoğraf kanıtını tarla durumuna işler (çekirdek zincir): kanıt → durum → yeniden hesap → "Ne değişti?" → sıradaki soru.
 * vision: gradeVision çıktısı. hash: görselin SHA-256'sı (aynı fotoğraf iki kez sayılmaz).
 * Döner: {status:'accepted'|'note'|'duplicate', change?, stageChanged?, nextQuestion?}
 */
export async function applyPhotoEvidence({storage,farm,weather,vision,hash}){
 const store=load(storage),rec=store[farm.id]||{history:[]};
 if(hash&&(rec.photoHashes||[]).includes(hash))return {status:'duplicate'};
 const evidence=await fetchEvidence(farm);
 const next={...rec,history:[...(rec.history||[])],photoHashes:[...(rec.photoHashes||[]),hash].filter(Boolean).slice(-40)};
 if(!vision?.decisionGrade){store[farm.id]=next;save(storage,store);return {status:'note',reason:vision?.reason||'Fotoğraf karar için yeterli değil.',tip:vision?.tip||null};}
 const beforeState=buildState(farm,rec,weather,evidence),before=evaluateWater(beforeState);
 const stageChanged=beforeState.stage!==vision.stage;
 next.stage=vision.stage;next.stageSource='photo';next.stageDay=today();
 const afterState=buildState(farm,next,weather,evidence),after=evaluateWater(afterState);
 const input=`Fotoğraf kanıtı: ${vision.stage} (güven %${Math.round(vision.confidence*100)})`;
 const change=explainChange(before,after,input);
 if(!stageChanged)change.summary=`Fotoğraf, kayıtlı dönemi doğruladı (${vision.stage}); hesap ve karar aynı kaldı: “${change.after}”.`;
 next.history.push({day:today(),input:{id:'photo',value:vision.stage},change,version:ENGINE_VERSION});next.history=next.history.slice(-30);
 store[farm.id]=next;save(storage,store);
 const q=chooseQuestion(afterState);
 return {status:'accepted',change,stageChanged,stage:vision.stage,nextQuestion:q.question?{title:q.question.title,reason:q.reason}:null};
}
