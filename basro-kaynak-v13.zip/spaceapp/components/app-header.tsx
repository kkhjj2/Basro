import Link from "next/link";

const links = [
  { href: "/panel", label: "Bugün" },
  { href: "/atlas", label: "Atlas" },
  { href: "/tarla/FIELD_102", label: "Tarlam" },
  { href: "/konum", label: "Tarla ekle" },
  { href: "/gorevler", label: "Görevler" },
  { href: "/rotasyon", label: "Rotasyon" },
  { href: "/topluluk", label: "Topluluk" },
];

export function AppHeader() {
  return (
    <header className="navbar sticky top-0 z-20 border-b border-base-300 bg-base-100/90 px-4 backdrop-blur md:px-8">
      <div className="flex-1">
        <Link href="/" className="text-xl font-bold tracking-tight">
          <span className="text-primary">Agro</span>Bas
        </Link>
      </div>
      <nav className="flex-none overflow-x-auto">
        <ul className="menu menu-horizontal menu-sm flex-nowrap gap-1 px-1">
          {links.map((l) => (
            <li key={l.href}>
              <Link href={l.href}>{l.label}</Link>
            </li>
          ))}
          <li>
            <Link href="/upload" className="btn btn-primary btn-sm">
              Fotoğraf ekle
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export function PageShell({ title, lead, children }: { title: string; lead?: string; children: React.ReactNode }) {
  return (
    <>
      <AppHeader />
      <main className="flex-1 bg-base-200 px-4 py-8 md:px-8">
        <div className="mx-auto max-w-5xl">
          <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
          {lead && <p className="mt-2 text-base-content/70">{lead}</p>}
          <div className="mt-6 space-y-6">{children}</div>
        </div>
      </main>
    </>
  );
}
