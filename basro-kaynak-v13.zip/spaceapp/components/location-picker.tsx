"use client";

import "leaflet/dist/leaflet.css";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import type { CircleMarker, Map as LeafletMap } from "leaflet";
import type { LocationAnalysis } from "@/lib/location-analysis";

type Crop = { id: string; name: string };
type Point = { lat: number; lon: number };

const MONTHS = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"];
const IRRIGATION = [
  { value: "drip", label: "Damla sulama" },
  { value: "sprinkler", label: "Yağmurlama" },
  { value: "furrow", label: "Karık / salma" },
  { value: "rainfed", label: "Kuru tarım (sulamasız)" },
  { value: "other", label: "Diğer" },
];
const DEFAULT_CENTER: Point = { lat: 38.9, lon: 35.2 };
const fmt = (n: number | null | undefined, d = 0) => (n == null ? "—" : n.toLocaleString("tr-TR", { maximumFractionDigits: d, minimumFractionDigits: d }));

export function LocationPicker({ crops }: { crops: Crop[] }) {
  const mapEl = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const markerRef = useRef<CircleMarker | null>(null);
  const [point, setPoint] = useState<Point | null>(null);
  const [crop, setCrop] = useState(crops.find((c) => c.id === "tomato")?.id ?? crops[0].id);
  const [sowingDate, setSowingDate] = useState("2026-05-10");
  const [geoMsg, setGeoMsg] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<LocationAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Harita yalnızca tarayıcıda yüklenir (Leaflet window ister).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      if (cancelled || !mapEl.current || mapRef.current) return;
      const map = L.map(mapEl.current).setView([DEFAULT_CENTER.lat, DEFAULT_CENTER.lon], 6);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      }).addTo(map);
      map.on("click", (e) => setPoint({ lat: e.latlng.lat, lon: e.latlng.lng }));
      mapRef.current = map;
    })();
    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
      markerRef.current = null;
    };
  }, []);

  // Seçilen noktayı haritada göster.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !point) return;
    (async () => {
      const L = (await import("leaflet")).default;
      if (markerRef.current) markerRef.current.setLatLng([point.lat, point.lon]);
      else
        markerRef.current = L.circleMarker([point.lat, point.lon], { radius: 9, color: "#15803d", weight: 3, fillOpacity: 0.5 }).addTo(map);
    })();
    setAnalysis(null);
  }, [point]);

  function locateMe() {
    if (!("geolocation" in navigator)) return setGeoMsg("Bu tarayıcı konum paylaşmayı desteklemiyor. Haritadan seçebilirsin.");
    setGeoMsg("Konum alınıyor…");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const p = { lat: pos.coords.latitude, lon: pos.coords.longitude };
        setPoint(p);
        mapRef.current?.setView([p.lat, p.lon], 14);
        setGeoMsg(`Konum alındı (±${Math.round(pos.coords.accuracy)} m). Tarlanın tam üstünde değilsen haritadan düzeltebilirsin.`);
      },
      () => setGeoMsg("Konum alınamadı. İzin vermediysen ya da sayfa güvenli bağlantıda değilse haritadan seçebilirsin."),
      { enableHighAccuracy: true, timeout: 10_000 },
    );
  }

  async function analyze() {
    if (!point) return;
    setLoading(true);
    setError(null);
    try {
      const q = new URLSearchParams({ lat: String(point.lat), lon: String(point.lon), crop, sowingDate });
      const res = await fetch(`/api/konum?${q}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Analiz yapılamadı.");
      setAnalysis(data as LocationAnalysis);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Analiz yapılamadı.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="card bg-base-100 shadow-sm">
        <div className="card-body gap-4">
          <div ref={mapEl} className="z-0 h-80 w-full overflow-hidden rounded-box border border-base-300 md:h-96" aria-label="Tarla konumu haritası" />
          <div className="flex flex-wrap items-center gap-3">
            <button type="button" className="btn btn-outline btn-sm" onClick={locateMe}>
              Konumumu kullan
            </button>
            <span className="text-sm text-base-content/70">
              {point ? `Seçilen nokta: ${fmt(point.lat, 4)}, ${fmt(point.lon, 4)}` : "Haritada tarlanın üstüne dokun."}
            </span>
          </div>
          {geoMsg && <p className="text-sm text-base-content/70">{geoMsg}</p>}
          <ManualPoint onSet={(p) => { setPoint(p); mapRef.current?.setView([p.lat, p.lon], 12); }} />

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="form-control">
              <span className="label-text mb-1">Ne ekili?</span>
              <select className="select select-bordered w-full" value={crop} onChange={(e) => { setCrop(e.target.value); setAnalysis(null); }}>
                {crops.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </label>
            <label className="form-control">
              <span className="label-text mb-1">Ekim / dikim tarihi</span>
              <input type="date" className="input input-bordered w-full" value={sowingDate} onChange={(e) => { setSowingDate(e.target.value); setAnalysis(null); }} />
            </label>
          </div>

          <button type="button" className="btn btn-primary" disabled={!point || loading} onClick={analyze}>
            {loading ? <span className="loading loading-spinner loading-sm" /> : null}
            {loading ? "NASA kayıtlarına bakılıyor…" : "Bu tarlaya birlikte bakalım"}
          </button>
          {error && <div role="alert" className="alert alert-error alert-soft text-sm">{error}</div>}
        </div>
      </div>

      {analysis && <Results a={analysis} cropName={crops.find((c) => c.id === analysis.input.crop)?.name ?? ""} />}
      {analysis && <SaveField a={analysis} />}
    </div>
  );
}

function ManualPoint({ onSet }: { onSet: (p: Point) => void }) {
  const [lat, setLat] = useState("");
  const [lon, setLon] = useState("");
  const la = Number(lat.replace(",", "."));
  const lo = Number(lon.replace(",", "."));
  const ok = lat !== "" && lon !== "" && Number.isFinite(la) && Number.isFinite(lo) && Math.abs(la) <= 90 && Math.abs(lo) <= 180;
  return (
    <details className="text-sm">
      <summary className="cursor-pointer text-base-content/70">Koordinatı elle gir</summary>
      <div className="mt-2 flex flex-wrap items-end gap-2">
        <input className="input input-bordered input-sm w-32" placeholder="Enlem (38,05)" inputMode="decimal" value={lat} onChange={(e) => setLat(e.target.value)} />
        <input className="input input-bordered input-sm w-32" placeholder="Boylam (37,88)" inputMode="decimal" value={lon} onChange={(e) => setLon(e.target.value)} />
        <button type="button" className="btn btn-sm" disabled={!ok} onClick={() => onSet({ lat: la, lon: lo })}>Bu noktayı seç</button>
      </div>
    </details>
  );
}

function Results({ a, cropName }: { a: LocationAnalysis; cropName: string }) {
  const p = a.power.provenance;
  const live = p.mode !== "unavailable";
  const climLive = a.climatology.provenance.mode !== "unavailable";
  const deficit = a.power.etcMm != null && a.power.precipMm != null ? a.power.etcMm - a.power.precipMm : null;
  const good = a.climatology.goodMonths.filter((m) => m.ok).map((m) => MONTHS[m.month]);

  return (
    <div className="card bg-base-100 shadow-sm">
      <div className="card-body gap-5">
        <div className="flex flex-wrap items-center gap-2">
          <h2 className="card-title">Bu nokta için gördüklerimiz</h2>
          <span className={`badge badge-soft badge-xs ${p.mode === "live" ? "badge-success" : p.mode === "snapshot" ? "badge-warning" : "badge-error"}`}>
            {p.mode === "live" ? "NASA POWER · canlı" : p.mode === "snapshot" ? `NASA POWER · kayıtlı veri · ${p.recordedAt}` : "NASA POWER · veri alınamadı"}
          </span>
          <span className="badge badge-soft badge-xs badge-info">model tahmini · tarla ölçümü değil</span>
        </div>

        {a.sowingInFuture ? (
          <p className="text-sm">Ekim tarihi henüz gelmemiş. Sezon başlayınca sıcaklık birikimini burada izleyeceğiz.</p>
        ) : live ? (
          <div className="stats stats-vertical bg-base-200 sm:stats-horizontal">
            <div className="stat">
              <div className="stat-title">Biriken sıcaklık (GDD)</div>
              <div className="stat-value text-2xl">{fmt(a.power.gddTotal)} °C·gün</div>
              <div className="stat-desc">{cropName}, {a.window.start} → {a.window.end}</div>
            </div>
            <div className="stat">
              <div className="stat-title">Bitkinin su ihtiyacı (ETc)</div>
              <div className="stat-value text-2xl">{fmt(a.power.etcMm)} mm</div>
              <div className="stat-desc">Aynı dönemde yağış: {fmt(a.power.precipMm)} mm</div>
            </div>
            <div className="stat">
              <div className="stat-title">Yağışın karşılamadığı kısım</div>
              <div className="stat-value text-2xl">{deficit == null ? "—" : `${fmt(Math.max(0, deficit))} mm`}</div>
              <div className="stat-desc">Sulamayla karşılanması gereken yaklaşık miktar</div>
            </div>
          </div>
        ) : (
          <div className="alert alert-warning alert-soft text-sm">
            NASA POWER bu nokta için şu an yanıt vermedi. Başka bir noktanın kaydını göstermiyoruz; birazdan tekrar deneyebilirsin.
          </div>
        )}
        {a.window.finished && !a.sowingInFuture && (
          <p className="text-xs text-base-content/60">Bu ekim tarihine göre sezon {a.window.end} civarında tamamlanmış; hesap sezon sonuna kadar.</p>
        )}

        <div>
          <h3 className="font-semibold">Uzun yıllar iklimi</h3>
          {climLive ? (
            <>
              <p className="text-sm">
                Yıllık ortalama sıcaklık {fmt(a.climatology.annualMeanTemp, 1)} °C, yıllık yağış yaklaşık {fmt(a.climatology.annualPrecipMm)} mm.
              </p>
              <p className="mt-1 text-sm">
                {cropName} için uygun aylık ortalama sıcaklık ({a.climatology.cropTRange[0]}–{a.climatology.cropTRange[1]} °C) olan aylar:{" "}
                <strong>{good.length ? good.join(", ") : "yok"}</strong>
              </p>
            </>
          ) : (
            <p className="text-sm text-base-content/70">Uzun yıllar ortalaması şu an alınamadı.</p>
          )}
        </div>

        <div>
          <h3 className="flex items-center gap-2 font-semibold">
            Kök bölgesi nemi (SMAP L4, 9 km)
            <span className="badge badge-soft badge-xs badge-info">model tahmini</span>
          </h3>
          {a.smap.status === "recorded" ? (
            <p className="text-sm">
              {a.smap.window!.start} → {a.smap.window!.end} ortalaması {fmt(a.smap.mean, 3)} m³/m³ (aralık {fmt(a.smap.low, 2)}–{fmt(a.smap.high, 2)}), bitkiye yarayışlı suyun yaklaşık %{a.smap.availablePct}&apos;i.{" "}
              <span className="badge badge-soft badge-xs badge-warning">kayıtlı veri · {a.smap.recordedAt}</span>
            </p>
          ) : (
            <p className="text-sm text-base-content/70">
              Bu konum için henüz SMAP kaydı yok{a.smap.distanceKm != null ? ` (kayıtlı hücreye ${fmt(a.smap.distanceKm, 1)} km)` : ""}. NASA&apos;dan bir nokta için kayıt hazırlamak yaklaşık 45 dakika sürüyor; başka bir noktanın nemini bu tarlaya ait gibi göstermiyoruz.
            </p>
          )}
        </div>

        <div className="rounded-box border border-base-300 bg-base-200/60 p-3 font-mono text-xs leading-relaxed text-base-content/70">
          <div>Source: NASA POWER {p.endpoint} · {p.resolution}</div>
          <div>Lat/Lon: {a.input.lat}, {a.input.lon} · Parameters: {p.parameters.join(", ")}</div>
          <div>GDD = Σ max(0, (Tmax+Tmin)/2 − Tbase) · ETc = Kc × ET₀ (Hargreaves, FAO-56)</div>
        </div>
      </div>
    </div>
  );
}

function SaveField({ a }: { a: LocationAnalysis }) {
  const [farmName, setFarmName] = useState("");
  const [fieldName, setFieldName] = useState("");
  const [areaHa, setAreaHa] = useState("");
  const [irrigation, setIrrigation] = useState("drip");
  const [state, setState] = useState<{ kind: "idle" | "saving" } | { kind: "saved"; fieldId: string } | { kind: "error"; message: string }>({ kind: "idle" });

  async function save() {
    setState({ kind: "saving" });
    try {
      const res = await fetch("/api/konum", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...a.input, farmName, fieldName, areaHa: Number(areaHa.replace(",", ".")), irrigation }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Kaydedilemedi.");
      setState({ kind: "saved", fieldId: data.fieldId });
    } catch (e) {
      setState({ kind: "error", message: e instanceof Error ? e.message : "Kaydedilemedi." });
    }
  }

  if (state.kind === "saved")
    return (
      <div role="status" className="alert alert-success alert-soft">
        <span>
          Tarlan kaydedildi. Haftalık fotoğraflarınla bu tarlayı birlikte izleyeceğiz.{" "}
          <Link href="/upload" className="link">Fotoğraf ekle</Link>
        </span>
      </div>
    );

  return (
    <div className="card bg-base-100 shadow-sm">
      <div className="card-body gap-4">
        <h2 className="card-title">Tarlanı kaydedelim mi?</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <input className="input input-bordered w-full" placeholder="Çiftlik adı (ör. Kuzey Bahçe)" value={farmName} onChange={(e) => setFarmName(e.target.value)} maxLength={80} />
          <input className="input input-bordered w-full" placeholder="Tarla adı (ör. Dere kenarı)" value={fieldName} onChange={(e) => setFieldName(e.target.value)} maxLength={80} />
          <input className="input input-bordered w-full" placeholder="Alan (hektar, isteğe bağlı)" inputMode="decimal" value={areaHa} onChange={(e) => setAreaHa(e.target.value)} />
          <select className="select select-bordered w-full" value={irrigation} onChange={(e) => setIrrigation(e.target.value)}>
            {IRRIGATION.map((i) => (
              <option key={i.value} value={i.value}>{i.label}</option>
            ))}
          </select>
        </div>
        <button type="button" className="btn btn-primary" disabled={state.kind === "saving"} onClick={save}>
          {state.kind === "saving" ? "Kaydediliyor…" : "Tarlamı kaydet"}
        </button>
        {state.kind === "error" && <div role="alert" className="alert alert-error alert-soft text-sm">{state.message}</div>}
      </div>
    </div>
  );
}
