import type { SmapSeries } from "@/lib/smap";

export function SmapSourceNote({ s }: { s: SmapSeries }) {
  const p = s.provenance;
  return (
    <div className="rounded-box border border-base-300 bg-base-200/60 p-3 font-mono text-xs leading-relaxed text-base-content/70">
      <div className="mb-1 flex flex-wrap items-center gap-2 font-sans">
        {s.available ? (
          <span className="badge badge-soft badge-xs badge-warning">kayıtlı veri · {p.recordedAt}</span>
        ) : (
          <span className="badge badge-soft badge-xs badge-error">SMAP verisi henüz kaydedilmedi</span>
        )}
        <span className="badge badge-soft badge-xs badge-info">model tahmini · tarla ölçümü değil</span>
      </div>
      <div>Source: NASA SMAP L4 {p.product} · {p.layer}</div>
      <div>Via: {p.via}{p.lat != null && ` · Lat/Lon: ${p.lat}, ${p.lon}`}</div>
      <div>{p.resolution} · belirsizlik ±0,04 m³/m³</div>
    </div>
  );
}
