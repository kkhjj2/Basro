"use client";

import { useId, useState } from "react";

type Point = { date: string; value: number | null };

/**
 * Tek seri, tek eksen çizgi/sütun grafik. Hover'da çizgi + değer gösterir.
 * Renk tek seri için tema rengidir; metinler mürekkep renginde kalır.
 */
export function MiniChart({
  data,
  unit,
  kind = "line",
  color = "var(--color-primary)",
  baseline,
  label,
}: {
  data: Point[];
  unit: string;
  kind?: "line" | "bar";
  color?: string;
  /** Karşılaştırma için yatay referans (ör. uzun dönem ortalaması) */
  baseline?: { value: number; label: string };
  label: string;
}) {
  const id = useId();
  const [hover, setHover] = useState<number | null>(null);
  const W = 640;
  const H = 200;
  const pad = { l: 36, r: 8, t: 12, b: 24 };
  const vals = data.map((d) => d.value).filter((v): v is number => v != null);
  if (vals.length === 0) return <p className="text-sm text-base-content/60">Gösterilecek veri yok.</p>;

  const extra = baseline ? [baseline.value] : [];
  let min = Math.min(...vals, ...extra);
  let max = Math.max(...vals, ...extra);
  if (kind === "bar") min = 0;
  if (max === min) max = min + 1;
  const span = max - min;
  // Küçük değer aralıkları (ör. m³/m³) için ondalık hassasiyet korunur.
  const step = 10 ** Math.floor(Math.log10(span || 1));
  min = kind === "bar" ? 0 : Math.floor((min - span * 0.1) / step) * step;
  max = Math.ceil((max + span * 0.1) / step) * step;
  if (min < 0 && Math.min(...vals) >= 0) min = 0;
  const decimals = Math.max(0, -Math.floor(Math.log10(step)));

  const x = (i: number) => pad.l + (i / Math.max(1, data.length - 1)) * (W - pad.l - pad.r);
  const y = (v: number) => pad.t + (1 - (v - min) / (max - min)) * (H - pad.t - pad.b);
  const ticks = [min, (min + max) / 2, max];

  const path = data
    .map((d, i) => (d.value == null ? null : `${x(i)},${y(d.value)}`))
    .filter(Boolean)
    .join(" L");
  const barW = Math.max(2, (W - pad.l - pad.r) / data.length - 2);
  const h = hover != null ? data[hover] : null;

  return (
    <div className="w-full max-w-2xl" role="group">
      <span className="sr-only">{label}</span>
      <div className="relative">
        <svg
          viewBox={`0 0 ${W} ${H}`}
          className="h-auto w-full"
          role="img"
          aria-labelledby={id}
          onMouseLeave={() => setHover(null)}
          onMouseMove={(e) => {
            const r = (e.currentTarget as SVGSVGElement).getBoundingClientRect();
            const px = ((e.clientX - r.left) / r.width) * W;
            const i = Math.round(((px - pad.l) / (W - pad.l - pad.r)) * (data.length - 1));
            setHover(Math.max(0, Math.min(data.length - 1, i)));
          }}
        >
          <title id={id}>{label}</title>
          {ticks.map((t) => (
            <g key={t}>
              <line x1={pad.l} x2={W - pad.r} y1={y(t)} y2={y(t)} stroke="currentColor" strokeOpacity={0.1} />
              <text x={pad.l - 6} y={y(t) + 4} textAnchor="end" fontSize={11} fill="currentColor" fillOpacity={0.6}>
                {t.toFixed(decimals)}
              </text>
            </g>
          ))}
          {baseline && (
            <g>
              <line x1={pad.l} x2={W - pad.r} y1={y(baseline.value)} y2={y(baseline.value)} stroke="currentColor" strokeOpacity={0.5} strokeDasharray="4 4" />
              <text x={W - pad.r} y={y(baseline.value) - 4} textAnchor="end" fontSize={11} fill="currentColor" fillOpacity={0.7}>
                {baseline.label}
              </text>
            </g>
          )}
          {kind === "line" ? (
            <path d={`M${path}`} fill="none" stroke={color} strokeWidth={2} strokeLinejoin="round" />
          ) : (
            data.map((d, i) =>
              d.value == null || d.value <= 0 ? null : (
                <rect key={d.date} x={x(i) - barW / 2} y={y(d.value)} width={barW} height={y(0) - y(d.value)} rx={2} fill={color} />
              ),
            )
          )}
          <text x={pad.l} y={H - 6} fontSize={11} fill="currentColor" fillOpacity={0.6}>
            {data[0].date}
          </text>
          <text x={W - pad.r} y={H - 6} textAnchor="end" fontSize={11} fill="currentColor" fillOpacity={0.6}>
            {data[data.length - 1].date}
          </text>
          {hover != null && h && (
            <g>
              <line x1={x(hover)} x2={x(hover)} y1={pad.t} y2={H - pad.b} stroke="currentColor" strokeOpacity={0.3} />
              {h.value != null && <circle cx={x(hover)} cy={y(h.value)} r={4} fill={color} stroke="var(--color-base-100)" strokeWidth={2} />}
            </g>
          )}
        </svg>
        {h && (
          <div className="pointer-events-none absolute top-0 right-0 rounded-box border border-base-300 bg-base-100 px-2 py-1 text-xs shadow-sm">
            <span className="text-base-content/60">{h.date}</span>{" "}
            <strong>{h.value == null ? "—" : `${h.value.toFixed(Math.max(1, decimals))} ${unit}`}</strong>
          </div>
        )}
      </div>
    </div>
  );
}
