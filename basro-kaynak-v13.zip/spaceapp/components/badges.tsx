import type { FeatureStatus } from "@/lib/demo-data";
import type { PowerProvenance } from "@/lib/nasa-power";

const STATUS: Record<FeatureStatus, { label: string; cls: string }> = {
  implemented: { label: "çalışıyor", cls: "badge-success" },
  demo_static: { label: "örnek veri", cls: "badge-warning" },
  future_vision: { label: "gelecek vizyon", cls: "badge-ghost" },
};

export function StatusTag({ status }: { status: FeatureStatus }) {
  const s = STATUS[status];
  return <span className={`badge badge-soft badge-xs ${s.cls}`}>{s.label}</span>;
}

/** Her NASA verisinin yanında kaynak, çözünürlük ve canlı/kayıtlı bilgisi zorunlu (brief §0.6, §10). */
export function SourceNote({ p }: { p: PowerProvenance }) {
  const mode =
    p.mode === "live"
      ? { text: "canlı API", cls: "badge-success" }
      : p.mode === "snapshot"
        ? { text: `kayıtlı veri · ${p.recordedAt}`, cls: "badge-warning" }
        : { text: "veri alınamadı", cls: "badge-error" };
  return (
    <div className="rounded-box border border-base-300 bg-base-200/60 p-3 font-mono text-xs leading-relaxed text-base-content/70">
      <div className="mb-1 flex flex-wrap items-center gap-2 font-sans">
        <span className={`badge badge-soft badge-xs ${mode.cls}`}>{mode.text}</span>
        <span className="badge badge-soft badge-xs badge-info">model tahmini · tarla ölçümü değil</span>
      </div>
      <div>Source: NASA POWER {p.endpoint}</div>
      <div>
        Lat/Lon: {p.lat}, {p.lon} · {p.resolution}
      </div>
      <div>Parameters: {p.parameters.join(", ")}</div>
    </div>
  );
}
