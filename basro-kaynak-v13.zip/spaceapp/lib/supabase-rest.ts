/**
 * Supabase'e bağımlılıksız, yalnızca sunucuda çalışan küçük REST istemcisi (service role).
 * Service role anahtarı asla istemciye gönderilmez. MVP'de tek demo kullanıcı adına yazar;
 * RLS politikaları gerçek kullanıcı oturumları için hazırdır (supabase/tests/rls_test.sql).
 */

const URL_ = process.env.NEXT_PUBLIC_SUPABASE_URL;
const KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

export const demoIds = {
  userId: process.env.AGROBAS_DEMO_USER_ID ?? "",
  fieldId: process.env.AGROBAS_DEMO_FIELD_ID ?? "",
  seasonId: process.env.AGROBAS_DEMO_SEASON_ID ?? "",
};

export function supabaseConfigured() {
  return Boolean(URL_ && KEY && demoIds.userId && demoIds.fieldId);
}

/** Yeni sb_secret_ anahtarları JWT değildir; yalnızca apikey başlığıyla gönderilir. Eski service_role JWT'si için Bearer de eklenir. */
function headers(extra: Record<string, string> = {}): Record<string, string> {
  const auth: Record<string, string> = KEY!.startsWith("sb_") ? {} : { Authorization: `Bearer ${KEY}` };
  return { apikey: KEY!, ...auth, ...extra };
}

export async function insert<T = Record<string, unknown>>(table: string, rows: object | object[]): Promise<T[]> {
  const res = await fetch(`${URL_}/rest/v1/${table}`, {
    method: "POST",
    headers: headers({ "Content-Type": "application/json", Prefer: "return=representation" }),
    body: JSON.stringify(rows),
  });
  if (!res.ok) throw new SupabaseError(table, res.status, await res.text());
  return (await res.json()) as T[];
}

export async function select<T = Record<string, unknown>>(table: string, query: string): Promise<T[]> {
  const res = await fetch(`${URL_}/rest/v1/${table}?${query}`, { headers: headers(), cache: "no-store" });
  if (!res.ok) throw new SupabaseError(table, res.status, await res.text());
  return (await res.json()) as T[];
}

/** Çakışan birincil anahtarı sessizce atlayan ekleme (referans verisi için). */
export async function insertIgnore(table: string, rows: object | object[]): Promise<void> {
  const res = await fetch(`${URL_}/rest/v1/${table}`, {
    method: "POST",
    headers: headers({ "Content-Type": "application/json", Prefer: "resolution=ignore-duplicates,return=minimal" }),
    body: JSON.stringify(rows),
  });
  if (!res.ok) throw new SupabaseError(table, res.status, await res.text());
}

/** query bir PostgREST filtresi olmalı (ör. "id=eq.<uuid>&author_id=eq.<uuid>"); silinen satır sayısını döner. */
export async function remove(table: string, query: string): Promise<number> {
  if (!query.includes("=eq.")) throw new Error("remove: filtre zorunlu");
  const res = await fetch(`${URL_}/rest/v1/${table}?${query}`, {
    method: "DELETE",
    headers: headers({ Prefer: "return=representation" }),
  });
  if (!res.ok) throw new SupabaseError(table, res.status, await res.text());
  return ((await res.json()) as unknown[]).length;
}

export async function uploadObject(bucket: string, key: string, body: ArrayBuffer, mime: string) {
  const res = await fetch(`${URL_}/storage/v1/object/${bucket}/${key}`, {
    method: "POST",
    headers: headers({ "Content-Type": mime, "x-upsert": "false" }),
    body,
  });
  if (!res.ok) throw new SupabaseError(`storage:${bucket}`, res.status, await res.text());
}

/** Özel kovadaki nesneyi service role ile indirir (ör. topluluk fotoğrafını sunucu üzerinden göstermek için). */
export async function downloadObject(storageKey: string): Promise<{ bytes: ArrayBuffer; mime: string }> {
  const res = await fetch(`${URL_}/storage/v1/object/${storageKey}`, { headers: headers(), cache: "no-store" });
  if (!res.ok) throw new SupabaseError("storage", res.status, await res.text());
  return { bytes: await res.arrayBuffer(), mime: res.headers.get("content-type") ?? "application/octet-stream" };
}

export class SupabaseError extends Error {
  constructor(
    public table: string,
    public status: number,
    public body: string,
  ) {
    super(`Supabase ${table} ${status}: ${body.slice(0, 200)}`);
  }
  /** Postgres unique_violation (23505) → 409 */
  get isConflict() {
    return this.status === 409 || this.body.includes("23505");
  }
}
