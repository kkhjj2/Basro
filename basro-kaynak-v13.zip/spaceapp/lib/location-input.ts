import { KC } from "./agro.ts";

/** Konum girdisi: saf fonksiyonlar (sunucu/istemci/test ortak). */

const iso = (d: Date) => d.toISOString().slice(0, 10);

/** Ürün taban sıcaklıkları (°C) — supabase crops tablosundaki tbase_c ile aynı. */
export const TBASE: Record<string, number> = { tomato: 10, wheat: 0, chickpea: 5, sugar_beet: 3 };

/** SMAP L4 hücresi 9 km; kayıtlı noktadan bu mesafe içi aynı hücre sayılır (yaklaşık, hücre yarı köşegeni ≈ 6,4 km). */
export const SMAP_SAME_CELL_KM = 6;

export function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const r = (d: number) => (d * Math.PI) / 180;
  const a = Math.sin(r(lat2 - lat1) / 2) ** 2 + Math.cos(r(lat1)) * Math.cos(r(lat2)) * Math.sin(r(lon2 - lon1) / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.sqrt(a));
}

export type LocationInput = { lat: number; lon: number; crop: string; sowingDate: string };

export function parseLocationInput(q: { lat: unknown; lon: unknown; crop: unknown; sowingDate: unknown }): LocationInput | string {
  const lat = Number(q.lat);
  const lon = Number(q.lon);
  if (!Number.isFinite(lat) || lat < -60 || lat > 70) return "Enlem geçersiz.";
  if (!Number.isFinite(lon) || lon < -180 || lon > 180) return "Boylam geçersiz.";
  const crop = String(q.crop ?? "");
  if (!(crop in KC) || !(crop in TBASE)) return "Ürün seçimi geçersiz.";
  const sowingDate = String(q.sowingDate ?? "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(sowingDate) || Number.isNaN(Date.parse(sowingDate))) return "Ekim tarihi geçersiz.";
  // POWER grid ~55 km; 4 ondalık (~11 m) fazlasıyla yeterli ve önbellek anahtarını sabitler.
  return { lat: Math.round(lat * 1e4) / 1e4, lon: Math.round(lon * 1e4) / 1e4, crop, sowingDate };
}

/** Sezon penceresi: ekimden, (ürün sezon uzunluğu) ile (bugün − 4 gün, POWER gecikmesi) arasındaki erken tarihe. */
export function seasonWindow(crop: string, sowingDate: string, now = new Date()) {
  const len = KC[crop].stages.reduce((a, b) => a + b, 0);
  const seasonEnd = new Date(Date.parse(sowingDate) + (len - 1) * 86_400_000);
  // NASA POWER günlük verisi birkaç gün gecikmeli: en son bugün − 4 gün
  const latest = new Date(Date.parse(iso(now)) - 4 * 86_400_000);
  const end = seasonEnd < latest ? seasonEnd : latest;
  return { start: sowingDate, end: iso(end), seasonLengthDays: len, finished: seasonEnd < latest };
}

