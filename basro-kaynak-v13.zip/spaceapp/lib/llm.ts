/**
 * Ücretsiz katmanlı LLM istemcisi: önce Groq (OpenAI uyumlu), olmazsa Gemini model listesi.
 * Yalnız sunucuda çalışır; anahtarlar istemciye gitmez. Her zaman JSON nesnesi döndürür ya da hata atar.
 */

export type ChatTurn = { role: "user" | "assistant"; content: string };
export type LlmRequest = {
  system: string;
  turns: ChatTurn[];
  /** Son kullanıcı mesajına eklenecek JPEG (data URL değil, saf base64). */
  imageB64?: string;
  imageMime?: string;
  schema?: object; // Gemini responseSchema (OpenAPI alt kümesi)
  maxTokens?: number;
  temperature?: number;
};
export type LlmResult = { json: unknown; provider: "groq" | "gemini"; model: string; latencyMs: number };

const GROQ_CHAT_MODEL = () => process.env.GROQ_CHAT_MODEL ?? process.env.GROQ_VISION_MODEL ?? "qwen/qwen3.8-27b";
const GROQ_VISION_MODEL = () => process.env.GROQ_VISION_MODEL ?? "qwen/qwen3.8-27b";
const GEMINI_MODELS = () =>
  (process.env.GEMINI_VISION_MODEL ?? "gemini-3.8-flash,gemini-3.6-flash,gemini-flash-latest,gemini-3.1-flash-lite")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

export const llmConfigured = () => Boolean(process.env.GROQ_API_KEY || process.env.GEMINI_API_KEY);

export function parseJsonLoose(text: string): unknown {
  const t = text.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
  try {
    return JSON.parse(t);
  } catch {
    const a = t.indexOf("{");
    const b = t.lastIndexOf("}");
    if (a >= 0 && b > a) return JSON.parse(t.slice(a, b + 1));
    throw new Error("MODEL_FORMAT");
  }
}

async function callGroq(req: LlmRequest): Promise<LlmResult> {
  const model = req.imageB64 ? GROQ_VISION_MODEL() : GROQ_CHAT_MODEL();
  const turns = req.turns.map((t, i) => {
    if (i === req.turns.length - 1 && t.role === "user" && req.imageB64)
      return {
        role: "user",
        content: [
          { type: "text", text: t.content },
          { type: "image_url", image_url: { url: `data:${req.imageMime ?? "image/jpeg"};base64,${req.imageB64}` } },
        ],
      };
    return t;
  });
  const start = Date.now();
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.GROQ_API_KEY}` },
    body: JSON.stringify({
      model,
      messages: [{ role: "system", content: req.system + "\nYalnızca geçerli bir JSON nesnesi döndür." }, ...turns],
      response_format: { type: "json_object" },
      temperature: req.temperature ?? 0.15,
      max_tokens: req.maxTokens ?? 900,
    }),
    signal: AbortSignal.timeout(40_000),
  });
  if (!res.ok) throw new Error(`GROQ_${res.status}`);
  const data = await res.json();
  const text = data.choices?.[0]?.message?.content;
  if (typeof text !== "string") throw new Error("GROQ_EMPTY");
  return { json: parseJsonLoose(text), provider: "groq", model, latencyMs: Date.now() - start };
}

async function callGeminiModel(model: string, req: LlmRequest): Promise<LlmResult> {
  const contents = req.turns.map((t, i) => {
    const parts: object[] = [{ text: t.content }];
    if (i === req.turns.length - 1 && t.role === "user" && req.imageB64)
      parts.push({ inline_data: { mime_type: req.imageMime ?? "image/jpeg", data: req.imageB64 } });
    return { role: t.role === "assistant" ? "model" : "user", parts };
  });
  const start = Date.now();
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY ?? "" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: req.system }] },
      contents,
      generationConfig: {
        responseMimeType: "application/json",
        ...(req.schema ? { responseSchema: req.schema } : {}),
        temperature: req.temperature ?? 0.15,
        maxOutputTokens: req.maxTokens ?? 900,
      },
    }),
    signal: AbortSignal.timeout(45_000),
  });
  if (!res.ok) throw new Error(`GEMINI_${model}_${res.status}`);
  const data = await res.json();
  const text = data.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("");
  if (!text) throw new Error(`GEMINI_${model}_EMPTY`);
  return { json: parseJsonLoose(text), provider: "gemini", model, latencyMs: Date.now() - start };
}

/** Groq → Gemini modelleri sırayla; ilk geçerli JSON döner. `validate` false dönerse sıradakine geçilir. */
export async function chatJson(req: LlmRequest, validate: (v: unknown) => boolean = () => true): Promise<LlmResult & { errors: string[] }> {
  const errors: string[] = [];
  const tries: (() => Promise<LlmResult>)[] = [];
  if (process.env.GROQ_API_KEY) tries.push(() => callGroq(req));
  if (process.env.GEMINI_API_KEY) for (const m of GEMINI_MODELS()) tries.push(() => callGeminiModel(m, req));
  for (const t of tries) {
    try {
      const r = await t();
      if (validate(r.json)) return { ...r, errors };
      errors.push(`${r.provider}:${r.model}:INVALID`);
    } catch (e) {
      errors.push(e instanceof Error ? e.message : String(e));
    }
  }
  const err = new Error("LLM_UNAVAILABLE");
  (err as Error & { attempts?: string[] }).attempts = errors;
  throw err;
}
