/**
 * Bilimsel hesaplama çekirdeği (MVP, TypeScript).
 * Formüller FAO-56'ya dayanır. LLM burada hiçbir sayı üretmez.
 * Not: Brief'teki ayrı Python motoru için bu dosya referans uygulamadır;
 * aynı formüller engine/ altında Python'a taşınabilir.
 */

export type DailyClimate = {
  date: string; // YYYY-MM-DD
  t2m: number | null; // °C, günlük ortalama
  tmax: number | null; // °C
  tmin: number | null; // °C
  precip: number | null; // mm/gün (PRECTOTCORR)
};

/** GDD_d = max(0, (Tmax + Tmin)/2 − Tbase). Tbase ürün/çeşit parametresidir. */
export function dailyGdd(tmax: number, tmin: number, tbase: number) {
  return Math.max(0, (tmax + tmin) / 2 - tbase);
}

export function cumulativeGdd(days: DailyClimate[], tbase: number) {
  let total = 0;
  const series: { date: string; value: number }[] = [];
  for (const d of days) {
    if (d.tmax != null && d.tmin != null) total += dailyGdd(d.tmax, d.tmin, tbase);
    series.push({ date: d.date, value: Math.round(total) });
  }
  return { total: Math.round(total), series };
}

function dayOfYear(date: string) {
  const d = new Date(date + "T00:00:00Z");
  const start = Date.UTC(d.getUTCFullYear(), 0, 0);
  return Math.floor((d.getTime() - start) / 86_400_000);
}

/** FAO-56 Eq. 21: dünya dışı radyasyon Ra (MJ m⁻² gün⁻¹). */
export function extraterrestrialRadiation(latDeg: number, date: string) {
  const J = dayOfYear(date);
  const phi = (Math.PI / 180) * latDeg;
  const dr = 1 + 0.033 * Math.cos(((2 * Math.PI) / 365) * J);
  const delta = 0.409 * Math.sin(((2 * Math.PI) / 365) * J - 1.39);
  const ws = Math.acos(Math.max(-1, Math.min(1, -Math.tan(phi) * Math.tan(delta))));
  return (
    ((24 * 60) / Math.PI) *
    0.082 *
    dr *
    (ws * Math.sin(phi) * Math.sin(delta) + Math.cos(phi) * Math.cos(delta) * Math.sin(ws))
  );
}

/**
 * FAO-56 Eq. 52 (Hargreaves) ile ET₀ (mm/gün).
 * Penman-Monteith için rüzgâr/nem/radyasyon gerekir; MVP'de Hargreaves kullanılır
 * ve UI'da "Hargreaves yaklaşımı" olarak etiketlenir.
 */
export function et0Hargreaves(tmax: number, tmin: number, latDeg: number, date: string) {
  const ra = extraterrestrialRadiation(latDeg, date);
  const tmean = (tmax + tmin) / 2;
  return Math.max(0, 0.0023 * (tmean + 17.8) * Math.sqrt(Math.max(0, tmax - tmin)) * 0.408 * ra);
}

export type KcCurve = {
  ini: number;
  mid: number;
  end: number;
  /** Gün olarak evre uzunlukları: başlangıç, gelişme, orta, son */
  stages: [number, number, number, number];
};

/** FAO-56 Tablo 11/12 değerleri (Akdeniz koşulları, yaklaşık). */
export const KC: Record<string, KcCurve> = {
  tomato: { ini: 0.6, mid: 1.15, end: 0.8, stages: [30, 40, 45, 30] },
  wheat: { ini: 0.4, mid: 1.15, end: 0.3, stages: [30, 140, 40, 30] },
  chickpea: { ini: 0.4, mid: 1.0, end: 0.35, stages: [20, 30, 40, 20] },
  sugar_beet: { ini: 0.35, mid: 1.2, end: 0.7, stages: [25, 35, 50, 50] },
};

/** Ekimden bu yana geçen güne göre Kc (doğrusal interpolasyon, FAO-56 Şekil 25). */
export function kcForDay(curve: KcCurve, dayAfterSowing: number) {
  const [a, b, c, d] = curve.stages;
  if (dayAfterSowing <= a) return curve.ini;
  if (dayAfterSowing <= a + b) return curve.ini + ((dayAfterSowing - a) / b) * (curve.mid - curve.ini);
  if (dayAfterSowing <= a + b + c) return curve.mid;
  if (dayAfterSowing <= a + b + c + d)
    return curve.mid + ((dayAfterSowing - a - b - c) / d) * (curve.end - curve.mid);
  return curve.end;
}

/** ETc = Kc × ET₀ toplamı (mm). Gerçek kullanılan su değil, ihtiyaç tahminidir. */
export function seasonalWaterNeed(days: DailyClimate[], latDeg: number, curve: KcCurve) {
  let etc = 0;
  let precip = 0;
  days.forEach((d, i) => {
    if (d.tmax != null && d.tmin != null) {
      etc += kcForDay(curve, i) * et0Hargreaves(d.tmax, d.tmin, latDeg, d.date);
    }
    if (d.precip != null) precip += d.precip;
  });
  return { etc: Math.round(etc), precip: Math.round(precip) };
}

export function mean(values: (number | null)[]) {
  const v = values.filter((x): x is number => x != null);
  return v.length ? v.reduce((s, x) => s + x, 0) / v.length : null;
}

/**
 * Numerik model tahminleri için aralık birleştirme (brief §5.3):
 * ağırlıklı ortalama değil, [min(low_i), max(high_i)].
 */
export function unionIntervals(intervals: { low: number; high: number }[]) {
  return {
    low: Math.min(...intervals.map((i) => i.low)),
    high: Math.max(...intervals.map((i) => i.high)),
  };
}
