import { gate, latestVision, phenologyLabels, previousVision } from "./demo-data";
import { availableFraction } from "./smap";

/**
 * Karar kapısı (brief §7.1), MVP sürümü.
 * Değişim ancak kalite, güven ve çelişki kontrolleri geçerse olur;
 * değişmediğinde de nedeni kaydedilir (recommendation_changes).
 */

const RECOMMENDATION_BY_STAGE: Record<string, string> = {
  fruit_development: "Meyve oluşumu sürüyor; sulamayı düzenli tut, olgunlaşma bekleniyor.",
  fruit_ripening: "Olgunlaşma başladı; hasat hazırlığını planla, sulamayı kademeli azaltmayı değerlendir.",
  fruit_ripening_unknown: "Olgunlaşma başladı; hasat hazırlığını planla. Sulamayı azaltmadan önce toprağı elle kontrol et.",
  fruit_ripening_dry: "Olgunlaşma başladı; hasat hazırlığını planla. Bölgede kök bölgesi kuru görünüyor; sulamayı azaltmadan önce toprağı elle kontrol et.",
};

/** Kök bölgesi nemi (SMAP L4), m³/m³, aralığıyla. */
export type RootzoneEvidence = { mean: number; low: number; high: number } | null;

/** Ürün/çeşit için olgunlaşma GDD bandı — uzman varsayımı, pilot verisiyle kalibre edilecek. */
export const RIPENING_GDD_BAND = { low: 470, high: 560 };

export type GateCheck = { label: string; pass: boolean; detail: string };

export function evaluateRecommendation(gddPrev: number | null, gddNow: number | null, rootzone: RootzoneEvidence = null) {
  const v = latestVision;
  const quality = v.image_quality.usable && !v.abstain ? v.image_quality.crop_visibility : 0;
  const stageChanged = v.phenology.stage !== previousVision.phenology.stage;
  // Olgunlaşma iddiası ancak sıcaklık birikimi yetersizse çelişir (bandın altında kalmak).
  // Bandın üstünde olmak olgunlaşmayla uyumludur.
  const gddSupports = gddNow == null ? null : gddNow >= RIPENING_GDD_BAND.low * 0.9;

  const checks: GateCheck[] = [
    { label: "Fotoğraf kullanılabilir", pass: quality >= gate.Q_MIN, detail: `kadrajda bitki ${Math.round(v.image_quality.crop_visibility * 100)}%` },
    { label: "Model emin (abstain değil)", pass: !v.abstain, detail: v.abstain ? (v.abstain_reason ?? "") : "karar verebildi" },
    { label: `Güven ≥ ${gate.C_MIN}`, pass: v.phenology.confidence >= gate.C_MIN, detail: `fenoloji güveni ${v.phenology.confidence}` },
    {
      label: "İklim kanıtıyla çelişmiyor",
      pass: gddSupports !== false,
      detail: gddNow == null ? "GDD hesaplanamadı (NASA POWER yok) — kontrol atlandı" : `kümülatif GDD ${gddNow}; olgunlaşma için tipik bant ${RIPENING_GDD_BAND.low}–${RIPENING_GDD_BAND.high} (uzman varsayımı)`,
    },
  ];
  // Güvenlik kısıtı: kök bölgesi kuruysa "sulamayı azalt" önerilmez, güvenli varyant seçilir.
  const awFrac = rootzone ? availableFraction(rootzone.mean) : null;
  const dry = awFrac != null && awFrac < 0.3;
  checks.push({
    label: "Su güvenliği (SMAP)",
    pass: true,
    detail:
      rootzone == null
        ? "SMAP verisi yok — güvenli metin varsayılan"
        : `kök bölgesi ${rootzone.mean.toFixed(2)} m³/m³ (${rootzone.low.toFixed(2)}–${rootzone.high.toFixed(2)}), yarayışlı suyun ~%${Math.round((awFrac ?? 0) * 100)}'i${dry ? " → sulamayı azaltma önerilmedi" : ""}`,
  });
  const allPass = checks.every((c) => c.pass);
  const changed = stageChanged && allPass;

  const oldText = RECOMMENDATION_BY_STAGE[previousVision.phenology.stage];
  const ripeKey =
    v.phenology.stage !== "fruit_ripening" ? v.phenology.stage : rootzone == null ? "fruit_ripening_unknown" : dry ? "fruit_ripening_dry" : "fruit_ripening";
  const newText = changed ? RECOMMENDATION_BY_STAGE[ripeKey] : oldText;

  const reason = changed
    ? `Kümülatif GDD ${gddPrev ?? "?"} → ${gddNow ?? "?"} (NASA POWER); fotoğrafta görsel evre "${phenologyLabels[v.phenology.stage]}" (güven ${v.phenology.confidence})` +
      (rootzone ? `; SMAP kök bölgesi nemi ${rootzone.mean.toFixed(2)} m³/m³ ayrı kanıt olarak sulama metnini belirledi.` : ".")
    : `Bu hafta tavsiye değişmedi çünkü yeni kanıt eşiği geçmedi: ${checks.filter((c) => !c.pass).map((c) => c.label).join(", ") || "evre değişmedi"}.`;

  return {
    changed,
    old: { stage: phenologyLabels[previousVision.phenology.stage], text: oldText, date: previousVision.observed_at },
    current: { stage: phenologyLabels[changed ? v.phenology.stage : previousVision.phenology.stage], text: newText, date: v.observed_at },
    reason,
    checks,
  };
}
