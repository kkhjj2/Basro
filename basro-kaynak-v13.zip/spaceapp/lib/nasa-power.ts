import { readFile } from "node:fs/promises";
import path from "node:path";
import { cacheLife } from "next/cache";
import type { DailyClimate } from "./agro";

/**
 * NASA POWER adaptörü (Agroclimatology / AG topluluğu).
 * Kaynak türü: model_estimate — ~0.5° x 0.625° (~55 km) grid ortalaması, tarla sensörü değil.
 * Canlı API erişilemezse kaydedilmiş snapshot (data/power-snapshot.json) kullanılır
 * ve UI bunu açıkça "kayıtlı veri" olarak gösterir; "canlı" gibi sunulmaz.
 */

export const POWER_BASE = "https://power.larc.nasa.gov/api/temporal";
export const DAILY_PARAMS = ["T2M", "T2M_MAX", "T2M_MIN", "PRECTOTCORR"] as const;

export type PowerProvenance = {
  mode: "live" | "snapshot" | "unavailable";
  endpoint: string;
  lat: number;
  lon: number;
  parameters: string[];
  resolution: string;
  sourceType: "model_estimate";
  recordedAt: string | null; // snapshot ise kayıt zamanı
};

export type DailySeries = { days: DailyClimate[]; provenance: PowerProvenance };

export type Climatology = {
  /** Aylık uzun dönem ortalamaları: index 0 = Ocak */
  t2m: number[];
  tmax: number[];
  tmin: number[];
  precip: number[]; // mm/gün
  provenance: PowerProvenance;
};

const RESOLUTION = "~0.5° grid (~55 km), grid ortalaması";
const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

const ymd = (s: string) => s.replaceAll("-", "");
const clean = (v: unknown) => (typeof v === "number" && v > -990 ? v : null);

function dailyUrl(lat: number, lon: number, start: string, end: string) {
  return `${POWER_BASE}/daily/point?parameters=${DAILY_PARAMS.join(",")}&community=AG&latitude=${lat}&longitude=${lon}&start=${ymd(start)}&end=${ymd(end)}&format=JSON`;
}

function climatologyUrl(lat: number, lon: number) {
  return `${POWER_BASE}/climatology/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR&community=AG&latitude=${lat}&longitude=${lon}&format=JSON`;
}

type PowerJson = { properties: { parameter: Record<string, Record<string, number>> } };

export function parseDaily(json: PowerJson): DailyClimate[] {
  const p = json.properties.parameter;
  return Object.keys(p.T2M ?? {})
    .sort()
    .map((k) => ({
      date: `${k.slice(0, 4)}-${k.slice(4, 6)}-${k.slice(6, 8)}`,
      t2m: clean(p.T2M?.[k]),
      tmax: clean(p.T2M_MAX?.[k]),
      tmin: clean(p.T2M_MIN?.[k]),
      precip: clean(p.PRECTOTCORR?.[k]),
    }));
}

type Snapshot = {
  recordedAt: string;
  lat: number;
  lon: number;
  /** anahtar: kullanım türü ("season" | "recent") */
  daily: Record<string, { start: string; end: string; json: PowerJson }>;
  climatology?: PowerJson;
};

async function readSnapshot(): Promise<Snapshot | null> {
  try {
    const raw = await readFile(path.join(process.cwd(), "data", "power-snapshot.json"), "utf8");
    return JSON.parse(raw) as Snapshot;
  } catch {
    return null;
  }
}

/** Kayıtlı veri yalnızca kaydedildiği nokta için kullanılır; başka bir konuma asla "ödünç" verilmez. */
function samePoint(snap: { lat: number; lon: number }, lat: number, lon: number) {
  return Math.abs(snap.lat - lat) < 0.01 && Math.abs(snap.lon - lon) < 0.01;
}

async function fetchJson(url: string): Promise<PowerJson> {
  const res = await fetch(url, { signal: AbortSignal.timeout(15_000) });
  if (!res.ok) throw new Error(`NASA POWER ${res.status}`);
  return (await res.json()) as PowerJson;
}

export type SeriesKind = "season" | "recent";

async function loadDaily(kind: SeriesKind, lat: number, lon: number, start: string, end: string): Promise<DailySeries> {
  const endpoint = "/api/temporal/daily/point";
  const base = { endpoint, lat, lon, parameters: [...DAILY_PARAMS], resolution: RESOLUTION, sourceType: "model_estimate" as const };
  try {
    const json = await fetchJson(dailyUrl(lat, lon, start, end));
    return { days: parseDaily(json), provenance: { ...base, mode: "live", recordedAt: null } };
  } catch {
    const snap = await readSnapshot();
    const stored = snap && samePoint(snap, lat, lon) ? snap.daily[kind] : undefined;
    // Sezon kaydı yalnızca aynı tarih aralığı istendiğinde kullanılır (farklı aralık = farklı sonuç).
    const hit = stored && (kind === "recent" || (stored.start === start && stored.end === end)) ? stored : undefined;
    if (snap && hit) {
      return { days: parseDaily(hit.json), provenance: { ...base, mode: "snapshot", recordedAt: snap.recordedAt } };
    }
    return { days: [], provenance: { ...base, mode: "unavailable", recordedAt: null } };
  }
}

/** Sabit tarih aralığı (ör. sezon: ekimden demo tarihine). */
export async function getDailyClimate(lat: number, lon: number, start: string, end: string): Promise<DailySeries> {
  "use cache";
  const r = await loadDaily("season", lat, lon, start, end);
  if (r.provenance.mode === "live") cacheLife("days");
  else cacheLife("minutes");
  return r;
}

/** POWER günlük verisi birkaç gün gecikmeyle gelir; son 30 günü (bugün − 4 gün'e kadar) çeker. */
export function recentWindow(now = new Date()) {
  const end = new Date(now.getTime() - 4 * 86_400_000);
  const start = new Date(end.getTime() - 29 * 86_400_000);
  const iso = (d: Date) => d.toISOString().slice(0, 10);
  return { start: iso(start), end: iso(end) };
}

export async function getRecentClimate(lat: number, lon: number): Promise<DailySeries> {
  "use cache";
  const { start, end } = recentWindow();
  const r = await loadDaily("recent", lat, lon, start, end);
  if (r.provenance.mode === "live") cacheLife("hours");
  else cacheLife("minutes");
  return r;
}

export async function getClimatology(lat: number, lon: number): Promise<Climatology> {
  "use cache";

  const base = {
    endpoint: "/api/temporal/climatology/point",
    lat,
    lon,
    parameters: ["T2M", "T2M_MAX", "T2M_MIN", "PRECTOTCORR"],
    resolution: RESOLUTION,
    sourceType: "model_estimate" as const,
  };
  const toClim = (json: PowerJson) => ({
    t2m: MONTHS.map((m) => json.properties.parameter.T2M[m]),
    tmax: MONTHS.map((m) => json.properties.parameter.T2M_MAX[m]),
    tmin: MONTHS.map((m) => json.properties.parameter.T2M_MIN[m]),
    precip: MONTHS.map((m) => json.properties.parameter.PRECTOTCORR[m]),
  });
  try {
    const live = toClim(await fetchJson(climatologyUrl(lat, lon)));
    cacheLife("max");
    return { ...live, provenance: { ...base, mode: "live", recordedAt: null } };
  } catch {
    cacheLife("minutes");
    const snap = await readSnapshot();
    if (snap?.climatology && samePoint(snap, lat, lon)) {
      return { ...toClim(snap.climatology), provenance: { ...base, mode: "snapshot", recordedAt: snap.recordedAt } };
    }
    return { t2m: [], tmax: [], tmin: [], precip: [], provenance: { ...base, mode: "unavailable", recordedAt: null } };
  }
}

/** URL'leri snapshot betiği de kullanır. */
export const powerUrls = { dailyUrl, climatologyUrl };
