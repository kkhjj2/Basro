import { et0Hargreaves, KC, type KcCurve } from "./agro";
import type { Climatology } from "./nasa-power";
import { field } from "./demo-data";
import { availableWaterMm, SMAP_UNCERTAINTY } from "./smap";

/**
 * Rotation Lab — 2 rotasyonun 5 metrikle karşılaştırması (brief §2, §10).
 * Metrikler kural tabanlıdır ve ağırlıklar uzman sezgisidir; "AI buldu" değildir.
 */

type Crop = {
  id: keyof typeof KC;
  name: string;
  family: string;
  legume: boolean;
  /** Yetiştirme ayları (0 = Ocak) */
  months: number[];
  /** Uygun aylık ortalama sıcaklık aralığı °C */
  tRange: [number, number];
  /** Uygun pH aralığı */
  ph: [number, number];
  /** Etkili kök derinliği m (FAO-56 Tablo 22) */
  rootDepth: number;
  /** Pazar sinyali (opsiyonel, demo_static) 0–100 */
  market: number;
};

export const CROPS: Record<string, Crop> = {
  wheat: { id: "wheat", rootDepth: 1.5, name: "Buğday", family: "Poaceae", legume: false, months: [9, 10, 11, 0, 1, 2, 3, 4, 5], tRange: [0, 24], ph: [6.0, 8.0], market: 55 },
  chickpea: { id: "chickpea", rootDepth: 0.8, name: "Nohut", family: "Fabaceae", legume: true, months: [2, 3, 4, 5, 6], tRange: [8, 27], ph: [6.0, 8.5], market: 65 },
  tomato: { id: "tomato", rootDepth: 1.0, name: "Domates", family: "Solanaceae", legume: false, months: [4, 5, 6, 7, 8], tRange: [16, 28], ph: [5.5, 7.5], market: 70 },
  sugar_beet: { id: "sugar_beet", rootDepth: 1.0, name: "Şeker pancarı", family: "Amaranthaceae", legume: false, months: [3, 4, 5, 6, 7, 8], tRange: [10, 26], ph: [6.5, 8.0], market: 60 },
};

export const ROTATIONS = [
  { id: "A", name: "Rotasyon A", crops: ["wheat", "chickpea", "tomato"] },
  { id: "B", name: "Rotasyon B", crops: ["tomato", "tomato", "sugar_beet"] },
] as const;

export type MetricResult = {
  key: string;
  label: string;
  score: number | null; // 0–100
  /** Belirsizlik aralığı (puan) — tek sayı yerine gösterilir */
  interval?: [number, number];
  detail: string;
  source: string;
  status: "implemented" | "demo_static";
  inTotal: boolean;
};

const clamp = (x: number) => Math.max(0, Math.min(100, Math.round(x)));
const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function climateFit(crop: Crop, clim: Climatology) {
  const ok = crop.months.filter((m) => clim.t2m[m] >= crop.tRange[0] && clim.t2m[m] <= crop.tRange[1]);
  return ok.length / crop.months.length;
}

/**
 * Su dengesi: arz = yetiştirme aylarının yağışı (POWER klimatoloji) + ekim ayındaki kök bölgesi
 * yarayışlı suyu (SMAP L4); talep = ETc (FAO-56 Kc × Hargreaves ET₀).
 * SMAP ±0,04 m³/m³ belirsizliği arz aralığına taşınır.
 */
function waterBalance(crop: Crop, clim: Climatology, lat: number, smapMonthly: (number | null)[] | null) {
  const curve: KcCurve = KC[crop.id];
  let p = 0;
  let etc = 0;
  for (const m of crop.months) {
    const mid = `2026-${String(m + 1).padStart(2, "0")}-15`;
    const et0 = et0Hargreaves(clim.tmax[m], clim.tmin[m], lat, mid);
    const kc = (curve.ini + curve.mid + curve.end) / 3;
    etc += kc * et0 * DAYS_IN_MONTH[m];
    p += clim.precip[m] * DAYS_IN_MONTH[m];
  }
  const theta = smapMonthly?.[crop.months[0]] ?? null;
  const aw = theta == null ? null : {
    mid: availableWaterMm(theta, crop.rootDepth),
    low: availableWaterMm(theta - SMAP_UNCERTAINTY, crop.rootDepth),
    high: availableWaterMm(theta + SMAP_UNCERTAINTY, crop.rootDepth),
  };
  return { p: Math.round(p), etc: Math.round(etc), aw, theta };
}

/** pH tahmin aralığının (Q05–Q95) ürünün uygun aralığıyla örtüşme oranı. */
function soilFit(crop: Crop) {
  const { low, high } = field.soil.ph;
  const overlap = Math.max(0, Math.min(high, crop.ph[1]) - Math.max(low, crop.ph[0]));
  return overlap / (high - low);
}

function continuity(ids: string[]) {
  let score = 70;
  const notes: string[] = [];
  for (let i = 1; i < ids.length; i++) {
    if (CROPS[ids[i]].family === CROPS[ids[i - 1]].family) {
      score -= 40;
      notes.push(`${CROPS[ids[i]].name} art arda (aynı familya)`);
    }
  }
  if (ids.some((id) => CROPS[id].legume)) {
    score += 25;
    notes.push("baklagil azot bağlar");
  }
  return { score: clamp(score), note: notes.join("; ") || "familya tekrarı yok" };
}

export function scoreRotation(
  ids: readonly string[],
  clim: Climatology,
  lat: number,
  smapMonthly: (number | null)[] | null,
): MetricResult[] {
  const crops = ids.map((id) => CROPS[id]);
  const hasClim = clim.t2m.length === 12;
  const avg = (xs: number[]) => xs.reduce((s, x) => s + x, 0) / xs.length;

  const climScore = hasClim ? clamp(avg(crops.map((c) => climateFit(c, clim))) * 100) : null;
  const water = hasClim ? crops.map((c) => waterBalance(c, clim, lat, smapMonthly)) : [];
  const smapUsed = water.length > 0 && water.every((w) => w.aw != null);
  const ratio = (w: (typeof water)[number], k: "low" | "mid" | "high") =>
    Math.min(1, (w.p + (smapUsed ? w.aw![k] : 0)) / w.etc);
  const waterScore = hasClim ? clamp(avg(water.map((w) => ratio(w, "mid"))) * 100) : null;
  const waterInterval: [number, number] | undefined =
    hasClim && smapUsed ? [clamp(avg(water.map((w) => ratio(w, "low"))) * 100), clamp(avg(water.map((w) => ratio(w, "high"))) * 100)] : undefined;
  const deficit = Math.round(water.reduce((s, w) => s + Math.max(0, w.etc - w.p - (smapUsed ? w.aw!.mid : 0)), 0));
  const soilStore = smapUsed ? Math.round(water.reduce((s, w) => s + w.aw!.mid, 0)) : null;
  const soil = clamp(avg(crops.map(soilFit)) * 100);
  const cont = continuity([...ids]);
  const market = clamp(avg(crops.map((c) => c.market)));

  return [
    {
      key: "climate",
      label: "İklim uyumu",
      score: climScore,
      detail: hasClim ? "Yetiştirme aylarının uzun dönem sıcaklığı ürün aralığında" : "İklim verisi alınamadı",
      source: "NASA POWER klimatoloji (T2M) · model_estimate",
      status: "implemented",
      inTotal: true,
    },
    {
      key: "water",
      label: "Su dengesi",
      score: waterScore,
      interval: waterInterval,
      detail: !hasClim
        ? "İklim verisi alınamadı"
        : smapUsed
          ? `Ekimde topraktaki yarayışlı su ≈ ${soilStore} mm (SMAP); yağış + toprak suyuyla karşılanmayan ihtiyaç ≈ ${deficit} mm`
          : `SMAP verisi yok, yalnız yağış: karşılanmayan ihtiyaç ≈ ${deficit} mm`,
      source: smapUsed
        ? "NASA SMAP L4 kök bölgesi nemi (9 km) + NASA POWER yağış + FAO-56 ETc"
        : "NASA POWER (PRECTOTCORR, T2M_MAX/MIN) + FAO-56 Kc · SMAP bekleniyor",
      status: "implemented",
      inTotal: true,
    },
    {
      key: "soil",
      label: "Toprak uyumu",
      score: soil,
      detail: `pH ${field.soil.ph.low}–${field.soil.ph.high} aralığının ürün aralığıyla örtüşmesi`,
      source: "SoilGrids 250 m (örnek değer) · model_estimate",
      status: "demo_static",
      inTotal: true,
    },
    {
      key: "continuity",
      label: "Rotasyon sürekliliği",
      score: cont.score,
      detail: cont.note,
      source: "Agronomik kural (familya tekrarı, baklagil)",
      status: "implemented",
      inTotal: true,
    },
    {
      key: "market",
      label: "Pazar (opsiyonel)",
      score: market,
      detail: "Toplama dahil değil",
      source: "Örnek değer",
      status: "demo_static",
      inTotal: false,
    },
  ];
}

export function totalScore(metrics: MetricResult[]) {
  const xs = metrics.filter((m) => m.inTotal && m.score != null).map((m) => m.score as number);
  return xs.length ? Math.round(xs.reduce((s, x) => s + x, 0) / xs.length) : null;
}
