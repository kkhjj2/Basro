/**
 * Demo senaryosu verisi: Doğanşehir/Malatya'da tek tarla, "bir çiftçinin bir haftası".
 * Status: demo_static — Supabase bağlanana kadar bu kayıtlar sabit örnektir.
 * NASA POWER sayıları burada YOK; onlar canlı/snapshot olarak hesaplanır.
 */

export type FeatureStatus = "implemented" | "demo_static" | "future_vision";

export const DEMO_DATE = "2026-07-13";

export const farm = {
  id: "farm_01",
  name: "Kuzey Bahçe",
  region: "Doğanşehir, Malatya",
  centroid: { lat: 38.05, lon: 37.88 },
  areaHa: 3.2,
};

export const crops = {
  tomato: { id: "tomato", name: "Domates", tbase: 10 },
} as const;

export const field = {
  id: "FIELD_102",
  name: "Dere kenarı parsel",
  farmId: farm.id,
  areaHa: 1.4,
  irrigation: "Damla sulama",
  soil: {
    source: "SoilGrids 250 m (model tahmini)",
    texture: "Killi tın",
    ph: { value: 7.6, low: 7.2, high: 8.0 }, // Q0.05–Q0.95
    status: "demo_static" as FeatureStatus,
  },
  season: {
    id: "season_2026",
    crop: crops.tomato,
    variety: "H-2274 (salçalık)",
    sowingDate: "2026-05-10", // fide dikimi
    previousObservationDate: "2026-07-06",
  },
};

/** Vision çıktısı örneği — şema brief §5.1 ile birebir. Status: demo_static (Groq bağlanınca implemented). */
export const latestVision = {
  observed_at: DEMO_DATE,
  image_quality: { usable: true, blur: "low", lighting: "acceptable", crop_visibility: 0.83 },
  abstain: false,
  abstain_reason: null,
  crop_match: { expected: "tomato", visible: true, confidence: 0.91 },
  phenology: { stage: "fruit_ripening", confidence: 0.76 },
  visible_signals: [{ type: "red_fruit_present", confidence: 0.84 }],
  cannot_infer: ["soil_ph", "exact_soil_moisture", "yield_kg"],
  request_followup_photo: false,
};

export const previousVision = {
  observed_at: field.season.previousObservationDate,
  phenology: { stage: "fruit_development", confidence: 0.72 },
};

export const phenologyLabels: Record<string, string> = {
  vegetative: "Vejetatif gelişim",
  flowering: "Çiçeklenme",
  fruit_development: "Meyve oluşumu",
  fruit_ripening: "Olgunlaşma başlangıcı",
};

/** Karar kapısı eşikleri (brief §7.1). Kalibre edilecek başlangıç değerleri. */
export const gate = { C_MIN: 0.7, Q_MIN: 0.6 };

export const missions = [
  {
    id: "m1",
    type: "weekly_check",
    title: "Bu hafta tarlanı kontrol et",
    detail: "Aynı açıdan 1 fotoğraf, gelişimi geçen haftayla karşılaştıralım.",
    reason: "7 gündür gelişim takibi yok",
    rewardXp: 50,
    status: "open" as const,
    IG: 0.8,
    DI: 0.9,
  },
  {
    id: "m2",
    type: "followup_photo",
    title: "Gelişim hızlandı; 3–4 gün içinde bir fotoğraf daha iyi olur",
    detail: "Olgunlaşma başladı. Kısa aralıklı takip, hasat zamanlamasını netleştirir.",
    reason: "Fenolojik geçişe yaklaşıldı",
    rewardXp: 30,
    status: "open" as const,
    IG: 0.7,
    DI: 0.8,
  },
];

/** IG ≈ (1 − current_confidence) × decision_weight — tam entropi değil, MVP proxy'si. */
export function priority(m: { IG: number; DI: number }, tu = 0.5, cg = 0.5, uf = 0.5, ub = 0.2) {
  return 0.3 * m.IG + 0.2 * m.DI + 0.15 * tu + 0.15 * cg + 0.1 * uf - 0.1 * ub;
}

export const xpLedger = [
  { id: "x1", date: "2026-06-29", label: "Haftalık kontrolü tamamladın", delta: 50 },
  { id: "x2", date: "2026-07-06", label: "Haftalık kontrolü tamamladın", delta: 50 },
  { id: "x3", date: "2026-07-13", label: "Haftalık kontrolü tamamladın", delta: 50 },
];
export const streakDays = 12;
export const trackingLevel = 7;

export const socialPost = {
  author: "Mehmet K.",
  region: "Doğanşehir",
  date: "2026-07-12",
  text: "Domateslerde ilk kızarmalar başladı, damlayı akşama aldık.",
  weeklyTrackedFields: 14,
  status: "demo_static" as FeatureStatus,
};

export const twinSeasons = [
  {
    id: "t1",
    label: "2024 · Yeşilyurt · domates (H-2274)",
    similarity: 0.82,
    note: "İlk olgunlaşma 498 GDD'de görüldü; hasat 21 gün sonra başladı.",
  },
  {
    id: "t2",
    label: "2025 · Doğanşehir · domates (farklı çeşit)",
    similarity: 0.71,
    note: "Temmuz sıcak dalgasında olgunlaşma hızlandı; sulama aralığı kısaltıldı.",
  },
];
