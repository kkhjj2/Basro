/**
 * Visual Observation şeması (brief §5.1) ve uygulama katmanı doğrulaması.
 * Groq JSON modu katı şema garantisi vermez; bu yüzden her çıktı burada doğrulanır.
 * Bu dosya bağımlılıksızdır; Node testleri doğrudan içe aktarır.
 */

export const VISION_SCHEMA_VERSION = "vision-v1";
export const PROMPT_VERSION = "prompt-v1";

export const PHENOLOGY_STAGES = [
  "vegetative",
  "flowering",
  "fruit_development",
  "fruit_ripening",
  "senescence",
  "unknown",
] as const;

export type VisionResult = {
  image_quality: {
    usable: boolean;
    blur: "low" | "medium" | "high";
    lighting: "poor" | "acceptable" | "good";
    crop_visibility: number;
  };
  abstain: boolean;
  abstain_reason: string | null;
  crop_match: { expected: string; visible: boolean; confidence: number };
  phenology: { stage: (typeof PHENOLOGY_STAGES)[number]; confidence: number };
  visible_signals: { type: string; confidence: number }[];
  cannot_infer: string[];
  request_followup_photo: boolean;
};

/** Gemini responseSchema (OpenAPI alt kümesi). */
export const GEMINI_RESPONSE_SCHEMA = {
  type: "OBJECT",
  properties: {
    image_quality: {
      type: "OBJECT",
      properties: {
        usable: { type: "BOOLEAN" },
        blur: { type: "STRING", enum: ["low", "medium", "high"] },
        lighting: { type: "STRING", enum: ["poor", "acceptable", "good"] },
        crop_visibility: { type: "NUMBER" },
      },
      required: ["usable", "blur", "lighting", "crop_visibility"],
    },
    abstain: { type: "BOOLEAN" },
    abstain_reason: { type: "STRING", nullable: true },
    crop_match: {
      type: "OBJECT",
      properties: { expected: { type: "STRING" }, visible: { type: "BOOLEAN" }, confidence: { type: "NUMBER" } },
      required: ["expected", "visible", "confidence"],
    },
    phenology: {
      type: "OBJECT",
      properties: { stage: { type: "STRING", enum: [...PHENOLOGY_STAGES] }, confidence: { type: "NUMBER" } },
      required: ["stage", "confidence"],
    },
    visible_signals: {
      type: "ARRAY",
      items: { type: "OBJECT", properties: { type: { type: "STRING" }, confidence: { type: "NUMBER" } }, required: ["type", "confidence"] },
    },
    cannot_infer: { type: "ARRAY", items: { type: "STRING" } },
    request_followup_photo: { type: "BOOLEAN" },
  },
  required: [
    "image_quality",
    "abstain",
    "abstain_reason",
    "crop_match",
    "phenology",
    "visible_signals",
    "cannot_infer",
    "request_followup_photo",
  ],
} as const;

/** Görüntünün asla desteklemediği değişkenler — model bunları sinyal olarak üretemez. */
export const NEVER_FROM_IMAGE = ["soil_ph", "exact_soil_moisture", "nutrient", "yield_kg", "yield"] as const;

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === "object" && v !== null && !Array.isArray(v);
const isProb = (v: unknown) => typeof v === "number" && Number.isFinite(v) && v >= 0 && v <= 1;
const oneOf = (v: unknown, xs: readonly string[]) => typeof v === "string" && xs.includes(v);

export type Validation = { ok: true; value: VisionResult } | { ok: false; errors: string[] };

export function validateVision(input: unknown): Validation {
  const e: string[] = [];
  if (!isObj(input)) return { ok: false, errors: ["kök bir nesne değil"] };
  const v = input;

  const q = v.image_quality;
  if (!isObj(q)) e.push("image_quality eksik");
  else {
    if (typeof q.usable !== "boolean") e.push("image_quality.usable boolean olmalı");
    if (!oneOf(q.blur, ["low", "medium", "high"])) e.push("image_quality.blur geçersiz");
    if (!oneOf(q.lighting, ["poor", "acceptable", "good"])) e.push("image_quality.lighting geçersiz");
    if (!isProb(q.crop_visibility)) e.push("image_quality.crop_visibility 0–1 olmalı");
  }

  if (typeof v.abstain !== "boolean") e.push("abstain boolean olmalı (zorunlu)");
  if (!("abstain_reason" in v)) e.push("abstain_reason alanı zorunlu");
  else if (v.abstain_reason !== null && typeof v.abstain_reason !== "string") e.push("abstain_reason string|null olmalı");
  if (v.abstain === true && (typeof v.abstain_reason !== "string" || v.abstain_reason.trim() === ""))
    e.push("abstain=true ise abstain_reason zorunlu");

  const c = v.crop_match;
  if (!isObj(c)) e.push("crop_match eksik");
  else {
    if (typeof c.expected !== "string") e.push("crop_match.expected string olmalı");
    if (typeof c.visible !== "boolean") e.push("crop_match.visible boolean olmalı");
    if (!isProb(c.confidence)) e.push("crop_match.confidence 0–1 olmalı");
  }

  const p = v.phenology;
  if (!isObj(p)) e.push("phenology eksik");
  else {
    if (!oneOf(p.stage, PHENOLOGY_STAGES)) e.push("phenology.stage geçersiz");
    if (!isProb(p.confidence)) e.push("phenology.confidence 0–1 olmalı");
  }

  if (!Array.isArray(v.visible_signals)) e.push("visible_signals dizi olmalı");
  else
    v.visible_signals.forEach((s, i) => {
      if (!isObj(s) || typeof s.type !== "string" || !isProb(s.confidence)) e.push(`visible_signals[${i}] geçersiz`);
      else if (NEVER_FROM_IMAGE.some((n) => (s.type as string).includes(n)))
        e.push(`visible_signals[${i}] görüntüden çıkarılamayacak bir değişken içeriyor (${s.type})`);
    });

  if (!Array.isArray(v.cannot_infer) || v.cannot_infer.length === 0) e.push("cannot_infer boş olamaz");
  else if (!v.cannot_infer.every((x) => typeof x === "string")) e.push("cannot_infer string dizisi olmalı");

  if (typeof v.request_followup_photo !== "boolean") e.push("request_followup_photo boolean olmalı");

  return e.length ? { ok: false, errors: e } : { ok: true, value: v as unknown as VisionResult };
}

/** Model JSON'u kod bloğu içinde döndürürse ayıklar. */
export function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = (fenced ? fenced[1] : text).trim();
  try {
    return JSON.parse(raw);
  } catch {
    const s = raw.indexOf("{");
    const t = raw.lastIndexOf("}");
    if (s >= 0 && t > s) {
      try {
        return JSON.parse(raw.slice(s, t + 1));
      } catch {}
    }
    return undefined;
  }
}

/** Kullanılabilir kanıt mı? Abstain veya düşük kalite karar motoruna girmez. */
export function isDecisionGrade(v: VisionResult, qMin = 0.6) {
  return v.image_quality.usable && !v.abstain && v.image_quality.crop_visibility >= qMin && v.crop_match.visible;
}
