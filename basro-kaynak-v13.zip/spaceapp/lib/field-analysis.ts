import { cumulativeGdd, KC, seasonalWaterNeed } from "./agro";
import { DEMO_DATE, farm, field } from "./demo-data";
import { getDailyClimate } from "./nasa-power";
import { evaluateRecommendation } from "./recommendation";
import { getSmapRootzone, SMAP_UNCERTAINTY, windowMean } from "./smap";

/** Tarla için sezon analizi: NASA POWER → GDD, ETc → karar kapısı. */
export async function analyzeField() {
  const { lat, lon } = farm.centroid;
  const [season, smap] = await Promise.all([getDailyClimate(lat, lon, field.season.sowingDate, DEMO_DATE), getSmapRootzone()]);
  // Son gözlem haftası (önceki fotoğraf → bu fotoğraf) kök bölgesi nemi
  const rz = smap.available ? windowMean(smap, field.season.previousObservationDate, DEMO_DATE) : null;
  const rootzone = rz == null ? null : { mean: rz, low: Math.max(0, rz - SMAP_UNCERTAINTY), high: rz + SMAP_UNCERTAINTY };
  const smapSeason = smap.daily.filter((d) => d.date >= field.season.sowingDate && d.date <= DEMO_DATE);
  const tbase = field.season.crop.tbase;
  const gdd = cumulativeGdd(season.days, tbase);
  const has = season.days.length > 0;
  const gddAt = (date: string) => (has ? (gdd.series.find((p) => p.date === date)?.value ?? null) : null);
  const gddPrev = gddAt(field.season.previousObservationDate);
  const gddNow = has ? gdd.total : null;
  const water = has ? seasonalWaterNeed(season.days, lat, KC.tomato) : null;
  const weekOfSeason = Math.floor((Date.parse(DEMO_DATE) - Date.parse(field.season.sowingDate)) / (7 * 86_400_000)) + 1;
  return {
    season,
    gdd,
    gddPrev,
    gddNow,
    water,
    weekOfSeason,
    smap,
    smapSeason,
    rootzone,
    decision: evaluateRecommendation(gddPrev, gddNow, rootzone),
  };
}
