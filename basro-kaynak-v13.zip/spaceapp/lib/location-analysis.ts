import { cumulativeGdd, KC, mean, seasonalWaterNeed } from "./agro";
import { haversineKm, SMAP_SAME_CELL_KM, seasonWindow, TBASE, type LocationInput } from "./location-input";
import { getClimatology, getDailyClimate } from "./nasa-power";
import { CROPS } from "./rotation";
import { availableFraction, getSmapRootzone, SMAP_UNCERTAINTY, windowMean } from "./smap";

/**
 * Haritadan seçilen herhangi bir nokta için analiz.
 * NASA POWER o nokta için canlı çağrılır (kayıtlı veri yalnızca kaydedildiği noktaya aittir).
 * SMAP L4 AppEEARS üzerinden asenkron geldiği için yalnızca kayıtlı hücre içindeyse gösterilir;
 * değilse "bu konum için kayıt yok" denir, başka noktanın verisi asla ödünç verilmez.
 */

const iso = (d: Date) => d.toISOString().slice(0, 10);

export const LOCATION_CROPS = Object.values(CROPS).map((c) => ({ id: c.id as string, name: c.name }));

export async function analyzeLocation(input: LocationInput) {
  const { lat, lon, crop, sowingDate } = input;
  const win = seasonWindow(crop, sowingDate);
  const sowingInFuture = win.end < win.start;

  const [season, clim, smap] = await Promise.all([
    sowingInFuture ? null : getDailyClimate(lat, lon, win.start, win.end),
    getClimatology(lat, lon),
    getSmapRootzone(),
  ]);

  const days = season?.days ?? [];
  const has = days.length > 0;
  const gdd = has ? cumulativeGdd(days, TBASE[crop]) : null;
  const water = has ? seasonalWaterNeed(days, lat, KC[crop]) : null;

  // SMAP: yalnızca kayıtlı hücre içindeyse
  const smapPoint = smap.provenance.lat != null && smap.provenance.lon != null ? { lat: smap.provenance.lat, lon: smap.provenance.lon } : null;
  const distanceKm = smapPoint ? haversineKm(lat, lon, smapPoint.lat, smapPoint.lon) : null;
  const sameCell = smap.available && distanceKm != null && distanceKm <= SMAP_SAME_CELL_KM;
  const lastDay = smap.daily.at(-1)?.date ?? null;
  let smapResult: {
    status: "recorded" | "not_recorded";
    distanceKm: number | null;
    recordedAt: string | null;
    window?: { start: string; end: string };
    mean?: number;
    low?: number;
    high?: number;
    availablePct?: number;
  } = { status: "not_recorded", distanceKm: distanceKm == null ? null : Math.round(distanceKm * 10) / 10, recordedAt: smap.provenance.recordedAt };
  if (sameCell && lastDay) {
    const start = iso(new Date(Date.parse(lastDay) - 6 * 86_400_000));
    const m = windowMean(smap, start, lastDay);
    if (m != null) {
      smapResult = {
        ...smapResult,
        status: "recorded",
        window: { start, end: lastDay },
        mean: m,
        low: Math.max(0, m - SMAP_UNCERTAINTY),
        high: m + SMAP_UNCERTAINTY,
        availablePct: Math.round(availableFraction(m) * 100),
      };
    }
  }

  const cropInfo = CROPS[crop];
  const goodMonths = clim.t2m.length
    ? clim.t2m.map((t, i) => ({ month: i, t, ok: t >= cropInfo.tRange[0] && t <= cropInfo.tRange[1] }))
    : [];

  return {
    input,
    window: win,
    sowingInFuture,
    power: {
      provenance: season?.provenance ?? clim.provenance,
      days: days.length,
      gddTotal: gdd ? Math.round(gdd.total) : null,
      etcMm: water?.etc ?? null,
      precipMm: water?.precip ?? null,
      meanTemp: has ? mean(days.map((d) => d.t2m)) : null,
    },
    climatology: {
      provenance: clim.provenance,
      annualMeanTemp: clim.t2m.length ? mean(clim.t2m) : null,
      annualPrecipMm: clim.precip.length ? Math.round(clim.precip.reduce((s, p, i) => s + p * [31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][i], 0)) : null,
      goodMonths,
      cropTRange: cropInfo.tRange,
    },
    smap: smapResult,
  };
}

export type LocationAnalysis = Awaited<ReturnType<typeof analyzeLocation>>;
