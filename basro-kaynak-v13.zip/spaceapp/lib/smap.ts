import { readFile } from "node:fs/promises";
import path from "node:path";
import { cacheLife } from "next/cache";

/**
 * SMAP L4 kök bölgesi nemi (SPL4SMGP). Kaynak türü: model_estimate —
 * SMAP gözlemleri + kara yüzeyi modeli asimilasyonu, 9 km grid, 3 saatlik.
 * AppEEARS görevleri asenkron (dakikalar sürer) olduğu için uygulama canlı çağırmaz;
 * `npm run snapshot:smap` ile kaydedilen veriyi "kayıtlı veri" etiketiyle kullanır.
 */

export type SmapDay = { date: string; mean: number; min: number; max: number; n: number };

export type SmapSeries = {
  available: boolean;
  daily: SmapDay[];
  provenance: {
    product: string;
    layer: string;
    via: string;
    recordedAt: string | null;
    resolution: string;
    lat: number | null;
    lon: number | null;
  };
};

/** SMAP L4 doğruluk gereksinimi: ubRMSE ≤ 0,04 m³/m³. Aralık bu bantla gösterilir. */
export const SMAP_UNCERTAINTY = 0.04;
export const SMAP_RESOLUTION = "9 km EASE-Grid 2.0, 3 saatlik (günlük ortalama)";

export async function getSmapRootzone(): Promise<SmapSeries> {
  "use cache";
  cacheLife("minutes");
  try {
    const raw = await readFile(path.join(process.cwd(), "data", "smap-snapshot.json"), "utf8");
    const s = JSON.parse(raw) as {
      recordedAt: string;
      product: string;
      layer: string;
      via: string;
      lat: number;
      lon: number;
      daily: SmapDay[];
    };
    return {
      available: s.daily.length > 0,
      daily: s.daily,
      provenance: { product: s.product, layer: s.layer, via: s.via, recordedAt: s.recordedAt, resolution: SMAP_RESOLUTION, lat: s.lat, lon: s.lon },
    };
  } catch {
    return {
      available: false,
      daily: [],
      provenance: { product: "SPL4SMGP", layer: "sm_rootzone", via: "NASA AppEEARS", recordedAt: null, resolution: SMAP_RESOLUTION, lat: null, lon: null },
    };
  }
}

/** Aylık ortalama kök bölgesi nemi (0 = Ocak). Verisi olmayan ay null. */
export function monthlyRootzone(s: SmapSeries) {
  const sums = Array.from({ length: 12 }, () => ({ s: 0, n: 0 }));
  for (const d of s.daily) {
    const m = Number(d.date.slice(5, 7)) - 1;
    sums[m].s += d.mean;
    sums[m].n += 1;
  }
  return sums.map((x) => (x.n ? x.s / x.n : null));
}

export function windowMean(s: SmapSeries, start: string, end: string) {
  const v = s.daily.filter((d) => d.date >= start && d.date <= end).map((d) => d.mean);
  return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
}

/** Toprak su sabitleri (m³/m³) — killi tın için FAO-56 Tablo 19 aralığından; demo_static. */
export const SOIL_WATER = { fieldCapacity: 0.34, wiltingPoint: 0.2 };

/** Bitkiye yarayışlı su oranı (0–1): (θ − WP) / (FC − WP). */
export function availableFraction(theta: number) {
  const { fieldCapacity: fc, wiltingPoint: wp } = SOIL_WATER;
  return Math.max(0, Math.min(1, (theta - wp) / (fc - wp)));
}

/** Kök bölgesindeki yarayışlı su (mm) = max(0, θ − WP) × kök derinliği × 1000. */
export function availableWaterMm(theta: number, rootDepthM: number) {
  return Math.max(0, Math.min(theta, SOIL_WATER.fieldCapacity) - SOIL_WATER.wiltingPoint) * rootDepthM * 1000;
}
