import type { VisionResult } from "./vision-schema";

/** Vision JSON'unu çiftçi diline çevirir (şablon; yeni sayı üretmez). */
const STAGE_TR: Record<string, string> = {
  vegetative: "yaprak ve gövde gelişimi",
  flowering: "çiçeklenme",
  fruit_development: "meyve oluşumu",
  fruit_ripening: "olgunlaşma başlangıcı",
  senescence: "sezon sonu sararma",
  unknown: "belirsiz",
};

const CANNOT_TR: Record<string, string> = {
  soil_ph: "toprak pH'ı",
  exact_soil_moisture: "kesin toprak nemi",
  yield_kg: "verim",
  yield: "verim",
  nutrient_levels: "besin düzeyleri",
  disease_diagnosis: "hastalık teşhisi",
};

function certainty(c: number) {
  return c >= 0.8 ? "net biçimde" : c >= 0.6 ? "büyük olasılıkla" : "zayıf da olsa";
}

export function farmerSummary(v: VisionResult, previousStage?: string | null) {
  const lines: string[] = [];
  if (v.abstain) {
    lines.push(`Bu fotoğraftan güvenilir bir sonuç çıkaramadık: ${v.abstain_reason}`);
    lines.push("Tahmin yürütmek yerine bunu açıkça söylüyoruz. İkinci bir açıdan bir fotoğraf daha iyi olur.");
  } else {
    const stage = STAGE_TR[v.phenology.stage] ?? v.phenology.stage;
    const changed = previousStage && previousStage !== v.phenology.stage;
    lines.push(
      changed
        ? `Bu hafta tarlanda ${certainty(v.phenology.confidence)} ${stage} görünüyor; geçen haftaki ${STAGE_TR[previousStage!] ?? previousStage} evresinden ilerlemiş.`
        : `Bu hafta tarlanda ${certainty(v.phenology.confidence)} ${stage} görünüyor.`,
    );
    if (!v.crop_match.visible) lines.push(`Fotoğrafta beklediğimiz ürünü (${v.crop_match.expected}) net göremedik.`);
    if (v.request_followup_photo) lines.push("Gelişimi netleştirmek için birkaç gün içinde bir fotoğraf daha iyi olur.");
  }
  const cannot = v.cannot_infer.map((c) => CANNOT_TR[c] ?? c.replaceAll("_", " "));
  lines.push(`Fotoğraftan çıkaramadıklarımız: ${cannot.join(", ")}. Bunları tahmin etmiyoruz.`);
  return lines;
}
