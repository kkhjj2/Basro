import {
  extractJson,
  GEMINI_RESPONSE_SCHEMA,
  PROMPT_VERSION,
  validateVision,
  VISION_SCHEMA_VERSION,
  type VisionResult,
} from "./vision-schema";

/**
 * Vision zinciri: Groq (birincil) → şema doğrulama → Gemini (yedek, responseSchema) →
 * hâlâ geçersizse needs_review. LLM burada ölçüm motoru değildir; yalnızca görünür sinyal çıkarır.
 */

export const GROQ_MODEL = process.env.GROQ_VISION_MODEL ?? "qwen/qwen3.8-27b";
/** Virgülle ayrılmış liste: biri yoğun/erişilemezse sıradakine geçilir. */
export const GEMINI_MODELS = (process.env.GEMINI_VISION_MODEL ?? "gemini-3.8-flash,gemini-3.6-flash,gemini-flash-latest,gemini-3.1-flash-lite")
  .split(",")
  .map((m) => m.trim())
  .filter(Boolean);
export const GEMINI_MODEL = GEMINI_MODELS[0];

export type VisionContext = {
  cropId: string;
  cropName: string;
  fieldId: string;
  observedAt: string;
  previous?: { stage: string; confidence: number } | null;
};

export type AiAttempt = {
  model_id: string;
  latency_ms: number;
  output_json: unknown;
  schema_valid: boolean;
  errors: string[];
};

export type VisionOutcome =
  | { status: "ok"; result: VisionResult; attempts: AiAttempt[]; usedFallback: boolean }
  | { status: "needs_review"; attempts: AiAttempt[] }
  | { status: "not_configured" };

const SYSTEM = `Sen Basro Visual Observation Engine'sin.
Yalnızca görüntünün doğrudan desteklediği özellikleri çıkar.
pH, kesin toprak nemi, besin konsantrasyonu, verim veya hastalık teşhisini görüntü tek başına desteklemiyorsa ASLA üretme.
Emin değilsen abstain=true yap ve nedenini abstain_reason alanına yaz.
cannot_infer listesi hiçbir zaman boş olamaz.
Yalnızca aşağıdaki JSON şemasına uyan tek bir JSON nesnesi döndür, başka metin yazma.`;

const SHAPE = `{
  "image_quality": {"usable": boolean, "blur": "low"|"medium"|"high", "lighting": "poor"|"acceptable"|"good", "crop_visibility": 0..1},
  "abstain": boolean,
  "abstain_reason": string|null,
  "crop_match": {"expected": string, "visible": boolean, "confidence": 0..1},
  "phenology": {"stage": "vegetative"|"flowering"|"fruit_development"|"fruit_ripening"|"senescence"|"unknown", "confidence": 0..1},
  "visible_signals": [{"type": string, "confidence": 0..1}],
  "cannot_infer": [string, ...],
  "request_followup_photo": boolean
}`;

function userPrompt(c: VisionContext) {
  return `CONTEXT:
Ürün: ${c.cropName} (${c.cropId})
Tarla: ${c.fieldId}
Gözlem tarihi: ${c.observedAt}
Önceki gözlem: ${c.previous ? `${c.previous.stage}, confidence=${c.previous.confidence}` : "yok"}

TASK:
1. Görüntü kalitesini değerlendir.
2. Görünür fenolojik aşamayı sınıflandır veya abstain et.
3. Önceki gözlemle karşılaştırılabilir görünür değişimleri çıkar.
4. Çıkarılamayan kritik değişkenleri listele.
5. Ek fotoğraf gerekiyorsa request_followup_photo=true yap.

JSON şeması:
${SHAPE}`;
}

/** 429/5xx için kısa beklemeli yeniden deneme (geçici yoğunluk). */
async function fetchRetry(url: string, init: RequestInit, tries = 3): Promise<Response> {
  let res: Response | null = null;
  for (let i = 0; i < tries; i++) {
    res = await fetch(url, { ...init, signal: AbortSignal.timeout(30_000) });
    if (res.status !== 429 && res.status < 500) return res;
    await new Promise((r) => setTimeout(r, 1500 * (i + 1)));
  }
  return res!;
}

async function callGroq(imageB64: string, mime: string, ctx: VisionContext): Promise<AiAttempt> {
  const t0 = Date.now();
  const res = await fetchRetry("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.GROQ_API_KEY}` },
    body: JSON.stringify({
      model: GROQ_MODEL,
      temperature: 0,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM },
        {
          role: "user",
          content: [
            { type: "text", text: userPrompt(ctx) },
            { type: "image_url", image_url: { url: `data:${mime};base64,${imageB64}` } },
          ],
        },
      ],
    }),
  });
  const latency_ms = Date.now() - t0;
  if (!res.ok) return { model_id: `groq:${GROQ_MODEL}`, latency_ms, output_json: null, schema_valid: false, errors: [`HTTP ${res.status}: ${(await res.text()).slice(0, 300)}`] };
  const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const parsed = extractJson(data.choices?.[0]?.message?.content ?? "");
  const v = validateVision(parsed);
  return { model_id: `groq:${GROQ_MODEL}`, latency_ms, output_json: parsed ?? null, schema_valid: v.ok, errors: v.ok ? [] : v.errors };
}

async function callGeminiModel(model: string, imageB64: string, mime: string, ctx: VisionContext): Promise<AiAttempt & { retryable: boolean }> {
  const t0 = Date.now();
  let res: Response;
  try {
    res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY ?? "" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM }] },
        contents: [{ role: "user", parts: [{ text: userPrompt(ctx) }, { inline_data: { mime_type: mime, data: imageB64 } }] }],
        generationConfig: { temperature: 0, responseMimeType: "application/json", responseSchema: GEMINI_RESPONSE_SCHEMA },
      }),
      signal: AbortSignal.timeout(45_000),
    });
  } catch (err) {
    return { model_id: `gemini:${model}`, latency_ms: Date.now() - t0, output_json: null, schema_valid: false, errors: [String(err)], retryable: true };
  }
  const latency_ms = Date.now() - t0;
  if (!res.ok) {
    const retryable = res.status === 404 || res.status === 429 || res.status >= 500;
    return { model_id: `gemini:${model}`, latency_ms, output_json: null, schema_valid: false, errors: [`HTTP ${res.status}: ${(await res.text()).slice(0, 200)}`], retryable };
  }
  const data = (await res.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
  const parsed = extractJson(data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "");
  const v = validateVision(parsed);
  return { model_id: `gemini:${model}`, latency_ms, output_json: parsed ?? null, schema_valid: v.ok, errors: v.ok ? [] : v.errors, retryable: false };
}

/** Gemini: model listesini sırayla dener (yoğunluk/erişim hatasında bir sonrakine geçer). */
async function callGemini(imageB64: string, mime: string, ctx: VisionContext): Promise<AiAttempt[]> {
  const out: AiAttempt[] = [];
  for (const model of GEMINI_MODELS) {
    const { retryable, ...a } = await callGeminiModel(model, imageB64, mime, ctx);
    out.push(a);
    if (!retryable) break;
  }
  return out;
}

export function visionConfigured() {
  return Boolean(process.env.GROQ_API_KEY || process.env.GEMINI_API_KEY);
}

export async function analyzeImage(imageB64: string, mime: string, ctx: VisionContext): Promise<VisionOutcome> {
  if (!visionConfigured()) return { status: "not_configured" };
  const attempts: AiAttempt[] = [];
  const providers: (() => Promise<AiAttempt[]>)[] = [];
  if (process.env.GROQ_API_KEY) providers.push(async () => [await callGroq(imageB64, mime, ctx)]);
  if (process.env.GEMINI_API_KEY) providers.push(() => callGemini(imageB64, mime, ctx));

  for (const [i, call] of providers.entries()) {
    try {
      for (const a of await call()) {
        attempts.push(a);
        if (a.schema_valid) {
          const r = validateVision(a.output_json);
          if (r.ok) return { status: "ok", result: r.value, attempts, usedFallback: i > 0 || attempts.length > 1 };
        }
      }
    } catch (err) {
      attempts.push({ model_id: `provider-${i}`, latency_ms: 0, output_json: null, schema_valid: false, errors: [String(err)] });
    }
  }
  return { status: "needs_review", attempts };
}

export const VERSIONS = { prompt: PROMPT_VERSION, schema: VISION_SCHEMA_VERSION };
