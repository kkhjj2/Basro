import cache from './forecast-cache.json';
import { buildForecast } from '../../public/forecast-core.mjs';
const memory=new Map<string,any>();
export async function forecastEvidence(c:{lat:number;lon:number}){
  const known=cache.records.find(p=>Math.abs(p.lat-c.lat)<.0001&&Math.abs(p.lon-c.lon)<.0001);
  let raw=known?.data,url=known?.url;
  try{
    if(!raw){url='https://power.larc.nasa.gov/api/temporal/monthly/point?'+new URLSearchParams({parameters:'T2M,PRECTOTCORR',community:'AG',longitude:String(c.lon),latitude:String(c.lat),start:String(cache.start),end:String(cache.end),format:'JSON'});raw=memory.get(url);if(!raw){const r=await fetch(url,{signal:AbortSignal.timeout(20000)});if(!r.ok)throw Error('NASA');raw=await r.json();if(memory.size>100)memory.clear();memory.set(url,raw);}}
    const r=buildForecast(raw,cache.targets);
    const summary=r.forecasts.map((f:any)=>`${f.year}: yıllık ortalama sıcaklık ${f.temperature.point.toFixed(1)} °C; geçmiş hatalardan aralık ${f.temperature.low.toFixed(1)}–${f.temperature.high.toFixed(1)} °C; ortalama mutlak sınama hatası ${f.temperature.mae.toFixed(1)} °C. Yıllık yağış referansı ${f.rain.point.toFixed(0)} mm; geçmiş hatalardan aralık ${f.rain.low.toFixed(0)}–${f.rain.high.toFixed(0)} mm; ortalama mutlak sınama hatası ${f.rain.mae.toFixed(0)} mm.`).join('\n');
    return {available:true,kind:r.kind,source:url,generated:cache.generated,trainingPeriod:`${r.firstYear}–${r.lastYear}`,dataCutoffYear:r.lastYear,forecasts:r.forecasts,intervalLabel:r.intervalLabel,summary:`İKİ ÖNGÖRÜNÜN DE EĞİTİM DÖNEMİ ${r.firstYear}–${r.lastYear}. 2026 gözlem verisi kullanılmadı. NASA geçmiş veri sağlar, öngörü Basro modeline aittir.\n${summary}\nOrtalama mutlak hata bir güven aralığı değildir; ± işaretiyle hata aralığı diye sunma. Yağış iki yılda aynı 15 yıllık iklim ortalamasıdır. Gelecekte gerçekleşeceği garanti edilmez.`};
  }catch{return {available:false,reason:'İstatistiksel öngörü için uzun dönem seri alınamadı veya yetersiz.'};}
}
