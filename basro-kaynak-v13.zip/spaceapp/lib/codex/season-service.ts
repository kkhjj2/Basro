import {fetchSeasonEvidence} from '../../public/season-data.mjs';
import {buildSeasonPlan,normalizeSeasonInputs,SEASON_SOURCES} from '../../public/season-core.mjs';

// Fetch evidence on the local server. A message cannot supply its own "verified" forecast.
export async function seasonalAssistantEvidence(c:any,weather:any){
 const data=await fetchSeasonEvidence(c.lat,c.lon),profile=c.profile||{};
 const farm={...profile,lat:c.lat,lon:c.lon};
 const plan=buildSeasonPlan({farm,inputs:normalizeSeasonInputs(profile),season:data.season,nasa:data.nasa,weather});
 const months=data.season.available?data.season.months.map((m:any)=>({month:m.month,validMembers:m.members,temperatureAnomalyC:m.temperature.anomaly,rainAnomalyPercent:m.rain.change,temperatureSignal:m.temperature.direction,rainSignal:m.rain.direction})):[];
 return {available:data.season.available,url:SEASON_SOURCES.seasonal,retrieved:data.retrievedAt,mode:'ECMWF SEAS5 mevsimlik öngörü + NASA POWER iklim geçmişi',
  modelContext:{source:'ECMWF SEAS5 via Open-Meteo; NASA gelecek tahmini değildir',retrieved:data.retrievedAt,months,
   limitation:'Yalnız listelenen gelecek aylar için mevsimlik öngörü var. Aylar sonrası gün/saat, 1–2 yıl sonraki belirli hava, kesin verim, böcek popülasyonu veya besin dozu tahmin edilmez. Senaryo payları doğruluk skoru değildir.',
   nasa:data.nasa.available?{source:'NASA POWER 1991–2020 geçmişi; gelecek tahmini değil',referenceForFirstMonth:plan.climate}:data.nasa.reason,
   preparation:plan.actions.slice(0,3).map((a:any)=>({title:a.title,why:a.why.slice(0,200),check:a.next})),
   rotation:plan.rotation.options.slice(0,2).map((o:any)=>({title:o.title,sequence:o.sequence,tradeoff:o.tradeoff})),
   noForecastReason:data.season.available?null:data.season.reason}};
}
