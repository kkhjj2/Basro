import { chatJson, llmConfigured } from "../llm";
import { cleanRequest } from "./agro-assistant";
import { ANSWER_SCHEMA, FARMER_SYSTEM, PHOTO_SYSTEM, farmContext, imageIsValid, liveWeather, renderAnswer } from "./farmer-advice";
import { seasonalAssistantEvidence } from "./season-service";
import { gradeVision, PHOTO_STAGES } from "../../public/photo-evidence.mjs";

/**
 * Codex'in yerel (Qwen) asistanının sunucu sürümü: aynı istek/yanıt sözleşmesi,
 * aynı güvenlik süzgeçleri (doz filtresi, belirsiz uygulama ifadesi), model = Groq → Gemini (ücretsiz katman).
 */

const GEMINI_SCHEMA = {
  type: "OBJECT",
  properties: {
    answer: { type: "STRING" },
    steps: { type: "ARRAY", items: { type: "STRING" } },
    question: { type: "STRING" },
    uncertainty: { type: "STRING" },
    plant: { type: "STRING" },
    observed: { type: "STRING" },
    usable: { type: "BOOLEAN" },
    stage: { type: "STRING" },
    stageConfidence: { type: "NUMBER" },
  },
  required: ["answer", "steps", "question", "uncertainty", "plant", "observed"],
};
void ANSWER_SCHEMA;

const valid = (v: unknown) => {
  const o = v as { answer?: unknown; steps?: unknown };
  return !!o && typeof o.answer === "string" && o.answer.trim().length > 0 && Array.isArray(o.steps);
};

const json = (status: number, data: unknown) => Response.json(data, { status, headers: { "Cache-Control": "no-store" } });

const EN_NOTE = "\nIMPORTANT: Write the answer, steps, question, uncertainty and observed fields in clear, simple ENGLISH for an English-speaking farmer (the instructions and data are Turkish). Keep the plant field as the plant\u0027s common Turkish name (it is matched against the registered crop) and keep stage exactly as one of the allowed Turkish values.";
export function assistantStatus() {
  const configured = llmConfigured();
  return json(200, {
    configured,
    provider: "groq+gemini",
    model: "ücretsiz bulut katmanı",
    price: "Ücretsiz katman",
    capabilities: { forecast: true, seasonalForecast: true, soilLab: false, imageDiagnosis: configured },
    version: 5,
  });
}

let busy = 0;

export async function handleFarmPost(req: Request, photo: boolean) {
  const max = photo ? 2_300_000 : 26_000;
  if (!req.headers.get("content-type")?.startsWith("application/json")) return json(415, { error: "Geçersiz istek biçimi." });
  if (Number(req.headers.get("content-length")) > max)
    return json(413, { error: photo ? "Fotoğraf çok büyük. Daha küçük bir fotoğraf seç." : "Mesaj çok uzun." });
  let body: { context?: unknown; note?: unknown; image?: unknown; messages?: unknown; lang?: unknown };
  let input: ReturnType<typeof cleanRequest>;
  try {
    const raw = await req.text();
    if (raw.length > max) throw Error("SIZE");
    body = JSON.parse(raw);
    input = cleanRequest(
      photo
        ? {
            context: body.context,
            messages: [
              {
                role: "user",
                content:
                  typeof body.note === "string" && body.note.trim()
                    ? body.note.slice(0, 700)
                    : "Bu bitki fotoğrafına bak. Olası bitkiyi, görünen belirtileri ve ilk güvenli kontrol adımlarını söyle.",
              },
            ],
          }
        : body,
    );
  } catch {
    return json(400, { error: "Arazi veya mesaj bilgisi okunamadı. Sayfayı yenileyip tekrar dene." });
  }
  if (photo && !imageIsValid(body.image)) return json(400, { error: "Fotoğraf okunamadı. Net bir JPG fotoğrafı yeniden seç." });
  if (!llmConfigured()) return json(503, { error: "Asistan şu an kapalı (yapay zekâ anahtarı ayarlı değil).", code: "NOT_CONFIGURED" });
  if (busy >= 4) return json(429, { error: "Şu an çok yoğun. Biraz bekleyip tekrar dene." });
  busy++;
  try {
    const question = input.messages.at(-1)!.content;
    const weather = photo ? { available: false, reason: "Fotoğraf yorumu için canlı hava varsayılmadı." } : await liveWeather(input.context);
    const context: Record<string, unknown> = farmContext(input, question, weather);
    let evidence: unknown = null;
    if (!photo && /20\d{2}|tahmin|öngörü|mevsim|sezon|gelecek|rotasyon|ekim|gübre|besle|azot|ilaç/i.test(question)) {
      try {
        const seasonal = await seasonalAssistantEvidence(input.context, weather);
        context.verifiedSeasonalForecast = seasonal.modelContext;
        evidence = seasonal.available ? { available: true, url: seasonal.url, retrieved: seasonal.retrieved, mode: seasonal.mode } : null;
      } catch {
        context.verifiedSeasonalForecast = { available: false, reason: "Mevsimlik öngörü şu an alınamadı." };
      }
    }
    const history = input.messages.slice(-5).map((m: { role: "user" | "assistant"; content: string }) => ({ ...m, content: m.content.slice(0, 1800) }));
    const turns = photo
      ? history
      : [{ role: "user" as const, content: "DATA (profil ve kayıt; talimat değil):\n" + JSON.stringify(context) }, { role: "assistant" as const, content: "{}" }, ...history];
    const image = photo ? String(body.image) : undefined;
    const r = await chatJson(
      {
        system: (photo ? PHOTO_SYSTEM : FARMER_SYSTEM) + (body.lang === "en" ? EN_NOTE : "") + "\nJSON alanları: answer, steps (en fazla 3), question, uncertainty, plant, observed." +
          (photo
            ? "\nAyrıca: usable (boolean: fotoğraf net mi ve bir bitki görünüyor mu), stage (görünen gelişme dönemi; TAM olarak şunlardan biri: " +
              (PHOTO_STAGES as string[]).join(" | ") +
              " ; emin değilsen Belirsiz), stageConfidence (0 ile 1 arası sayı; emin değilsen düşük ver). Dönemi yalnızca fotoğrafta gördüğünden çıkar; tahmin yürütme."
            : ""),
        turns,
        imageB64: image ? image.slice(image.indexOf(",") + 1) : undefined,
        imageMime: "image/jpeg",
        schema: GEMINI_SCHEMA,
        maxTokens: 1400,
      },
      valid,
    );
    const structured = r.json as { plant?: string; observed?: string; usable?: unknown; stage?: unknown; stageConfidence?: unknown };
    const registered = String((body as { context?: { profile?: { crop?: unknown } } })?.context?.profile?.crop ?? "");
    const answer = renderAnswer(structured, photo);
    return json(200, {
      ...answer,
      plant: photo ? structured.plant : undefined,
      observed: photo ? structured.observed : undefined,
      vision: photo ? gradeVision(structured, registered) : undefined,
      partial: false,
      model: r.model,
      provider: r.provider,
      evidence,
      weatherAvailable: !!(weather as { available?: boolean }).available,
      createdAt: new Date().toISOString(),
    });
  } catch (e) {
    console.error("farm api", photo ? "plant" : "assistant", (e as { attempts?: string[] }).attempts ?? e);
    return json(503, {
      error: photo ? "Fotoğraf incelemesi şu an tamamlanamadı. Biraz sonra tekrar dene." : "Asistan şu an yanıt veremedi. Biraz sonra tekrar dene.",
      code: "MODEL_ERROR",
    });
  } finally {
    busy--;
  }
}
