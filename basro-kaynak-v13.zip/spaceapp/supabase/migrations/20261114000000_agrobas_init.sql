-- AgroBas MVP şeması (brief §4). Supabase Postgres.
-- İlkeler: her exposed tabloda RLS; anon'a kullanıcı verisinde yazma yok;
-- social_posts ≠ ground_observations (fiziksel ayrım); xp_ledger append-only + idempotent.

create extension if not exists pgcrypto;

-- ───────────── Referans tablolar ─────────────
create table public.crops (
  id text primary key,                      -- 'tomato'
  name_tr text not null,
  family text not null,
  tbase_c numeric not null,                 -- GDD taban sıcaklığı (ürün parametresi)
  kc_ini numeric, kc_mid numeric, kc_end numeric
);

create table public.regions (
  id text primary key,                      -- 'dogansehir'
  name text not null,
  centroid_lat numeric not null,
  centroid_lon numeric not null
);

-- ───────────── Kullanıcı & tarla ─────────────
create table public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  region_id text references public.regions(id),
  privacy_level text not null default 'private' check (privacy_level in ('private','community','public')),
  preferred_language text not null default 'tr',
  created_at timestamptz not null default now()
);

create table public.farms (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  centroid_lat numeric, centroid_lon numeric,
  area_ha numeric check (area_ha > 0),
  created_at timestamptz not null default now()
);

create table public.fields (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade, -- RLS için denormalize
  name text not null,
  geometry jsonb,                           -- GeoJSON (MVP); PostGIS ileride
  area_ha numeric,
  soil_source text,                         -- 'soilgrids_250m' | 'lab' | 'farmer'
  irrigation_type text check (irrigation_type in ('drip','sprinkler','furrow','rainfed','other')),
  created_at timestamptz not null default now()
);

create table public.seasons (
  id uuid primary key default gen_random_uuid(),
  field_id uuid not null references public.fields(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  crop_id text not null references public.crops(id),
  variety text,
  sowing_date date not null,
  harvest_date date,
  check (harvest_date is null or harvest_date >= sowing_date)
);

create table public.farm_activities (
  id uuid primary key default gen_random_uuid(),
  season_id uuid not null references public.seasons(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  activity_type text not null,              -- 'irrigation','fertilizer','spray','harvest',...
  occurred_at timestamptz not null,
  source text not null default 'farmer',
  payload jsonb not null default '{}'
);

-- ───────────── Rıza (amaç bazlı, tek kutu yasak) ─────────────
create table public.consents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  purpose text not null check (purpose in ('personal_analysis','community_sharing','research_anonymized')),
  scope jsonb not null default '{}',        -- ör. {"media_id": "..."}
  version text not null,                    -- rıza metni sürümü
  granted_at timestamptz not null default now(),
  revoked_at timestamptz
);

-- ───────────── Medya ─────────────
create table public.media_objects (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  provider text not null default 'supabase' check (provider in ('supabase','r2')),
  storage_key text not null,
  sha256 text not null,
  perceptual_hash text,
  mime text not null,
  exif_scrubbed boolean not null default false,
  uploaded_at timestamptz not null default now(),   -- sunucu zamanı (EXIF tek kaynak değil)
  unique (owner_id, sha256)                         -- aynı fotoğraf iki kez analiz edilmez
);

-- ───────────── Bilimsel kanıt zinciri ─────────────
create table public.ground_observations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  field_id uuid not null references public.fields(id) on delete cascade,
  season_id uuid references public.seasons(id),
  media_id uuid references public.media_objects(id),
  observed_at timestamptz not null,
  method text not null default 'photo',
  raw_signal jsonb,
  protocol_version text not null,
  capture_angle text check (capture_angle in ('nadir','oblique','close_up')),
  capture_distance_m numeric,
  -- Aynı tarla + gün için tek analiz (idempotency)
  observed_day date generated always as ((observed_at at time zone 'UTC')::date) stored,
  unique (field_id, observed_day)
);

create table public.ai_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  model_id text not null,                   -- 'groq:qwen/...', 'gemini:...'
  prompt_version text not null,
  output_schema_version text not null,
  input_refs jsonb not null,
  input_hash text not null,
  output_json jsonb,
  schema_valid boolean,
  status text not null default 'ok' check (status in ('ok','invalid_json','fallback','needs_review','error')),
  latency_ms integer,
  created_at timestamptz not null default now()
);

create table public.validated_evidence (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  observation_id uuid not null references public.ground_observations(id) on delete cascade,
  ai_run_id uuid references public.ai_runs(id),
  evidence_type text not null,              -- 'phenology','visible_signal','image_quality'
  value jsonb not null,
  confidence numeric check (confidence between 0 and 1),
  validator_model text not null,
  validator_version text not null,
  abstain boolean not null,
  abstain_reason text,
  created_at timestamptz not null default now(),
  check (not abstain or abstain_reason is not null)   -- abstain=true ⇒ gerekçe zorunlu
);

create table public.model_estimates (
  id uuid primary key default gen_random_uuid(),
  field_id uuid not null references public.fields(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  variable text not null,                   -- 'gdd_cum','et0','precip_anomaly','soil_ph'
  value numeric,
  interval_low numeric,
  interval_high numeric,
  source text not null,                     -- 'nasa_power','soilgrids','engine'
  source_resolution text,                   -- '~0.5° (~55 km)'
  model_version text not null,
  valid_for date,
  created_at timestamptz not null default now(),
  check (interval_low is null or interval_high is null or interval_low <= interval_high)
);

create table public.farm_recommendations (
  id uuid primary key default gen_random_uuid(),
  field_id uuid not null references public.fields(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  recommendation text not null,
  confidence numeric check (confidence between 0 and 1),
  reason_codes text[] not null default '{}',
  supersedes_id uuid references public.farm_recommendations(id),
  superseded_at timestamptz,
  superseded_reason text,
  created_at timestamptz not null default now()
);

-- Karar değişse de değişmese de kayıt (old_id = new_id ⇒ değişmedi)
create table public.recommendation_changes (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  field_id uuid not null references public.fields(id) on delete cascade,
  old_id uuid references public.farm_recommendations(id),
  new_id uuid references public.farm_recommendations(id),
  changed boolean not null,
  evidence_ids uuid[] not null default '{}',
  trigger_reason text not null,
  gate_result jsonb not null default '{}',  -- {quality, confidence, contradiction, safety}
  created_at timestamptz not null default now()
);

-- ───────────── Sosyal (bilimsel kanıt DEĞİL) ─────────────
create table public.social_posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete cascade,
  season_id uuid references public.seasons(id) on delete set null,
  media_id uuid references public.media_objects(id),
  body text check (char_length(body) <= 1000),
  region_id text references public.regions(id),
  visibility text not null default 'community' check (visibility in ('private','community')),
  created_at timestamptz not null default now()
);

-- ───────────── Görevler & XP ─────────────
create table public.missions (
  id uuid primary key default gen_random_uuid(),
  type text not null,                       -- 'weekly_check','followup_photo','waterlogging_check','second_angle'
  title text not null,
  target_scope jsonb not null default '{}',
  valid_from timestamptz not null,
  valid_to timestamptz not null,
  reward_xp integer not null check (reward_xp between 0 and 200),
  required_protocol text not null default 'v1'
);

create table public.mission_assignments (
  id uuid primary key default gen_random_uuid(),
  mission_id uuid not null references public.missions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  field_id uuid references public.fields(id) on delete cascade,
  status text not null default 'open' check (status in ('open','done','expired','skipped')),
  priority_score numeric,
  reason text,
  created_at timestamptz not null default now(),
  unique (mission_id, user_id, field_id)
);

create table public.mission_completions (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null unique references public.mission_assignments(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  evidence_id uuid references public.validated_evidence(id),
  xp_status text not null default 'pending' check (xp_status in ('pending','granted','rejected')),
  created_at timestamptz not null default now()
);

create table public.xp_ledger (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  source_type text not null,                -- 'mission','streak','badge'
  source_id uuid,
  delta integer not null,
  label text not null,                      -- "Haftalık kontrolü tamamladın"
  idempotency_key text not null unique,
  created_at timestamptz not null default now()
);

-- Append-only: UPDATE/DELETE engellenir (servis rolü dahil)
create function public.forbid_mutation() returns trigger language plpgsql as $$
begin
  raise exception '% is append-only', tg_table_name;
end $$;
create trigger xp_ledger_append_only before update or delete on public.xp_ledger
  for each row execute function public.forbid_mutation();

-- ───────────── İndeksler ─────────────
create index on public.farms(owner_id);
create index on public.fields(owner_id);
create index on public.fields(farm_id);
create index on public.seasons(field_id);
create index on public.consents(user_id);
create index on public.media_objects(owner_id);
create index ground_obs_user_idx on public.ground_observations(user_id);
create index ground_obs_field_time_idx on public.ground_observations(field_id, observed_at desc);
create index on public.validated_evidence(observation_id);
create index on public.model_estimates(field_id, variable);
create index on public.farm_recommendations(field_id, created_at desc);
create index on public.recommendation_changes(field_id, created_at desc);
create index on public.mission_assignments(user_id, status);
create index on public.xp_ledger(user_id);
create index on public.social_posts(region_id, created_at desc);
create index on public.ai_runs(input_hash);

-- ───────────── RLS ─────────────
alter table public.crops enable row level security;
alter table public.regions enable row level security;
alter table public.profiles enable row level security;
alter table public.farms enable row level security;
alter table public.fields enable row level security;
alter table public.seasons enable row level security;
alter table public.farm_activities enable row level security;
alter table public.consents enable row level security;
alter table public.media_objects enable row level security;
alter table public.ground_observations enable row level security;
alter table public.ai_runs enable row level security;
alter table public.validated_evidence enable row level security;
alter table public.model_estimates enable row level security;
alter table public.farm_recommendations enable row level security;
alter table public.recommendation_changes enable row level security;
alter table public.social_posts enable row level security;
alter table public.missions enable row level security;
alter table public.mission_assignments enable row level security;
alter table public.mission_completions enable row level security;
alter table public.xp_ledger enable row level security;

-- Referans veriler: giriş yapmış herkes okur, kimse yazmaz (yalnızca service_role).
create policy "read crops" on public.crops for select to authenticated using (true);
create policy "read regions" on public.regions for select to authenticated using (true);
create policy "read missions" on public.missions for select to authenticated using (true);

-- Sahibi okur + yazar (owner_id / user_id)
create policy "own profile" on public.profiles for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "own farms" on public.farms for all to authenticated
  using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy "own fields" on public.fields for all to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id
              and exists (select 1 from public.farms f where f.id = farm_id and f.owner_id = (select auth.uid())));
create policy "own seasons" on public.seasons for all to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id
              and exists (select 1 from public.fields f where f.id = field_id and f.owner_id = (select auth.uid())));
create policy "own activities" on public.farm_activities for all to authenticated
  using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);

-- Rıza: sahibi okur, verir, geri çeker; silemez (denetim izi).
create policy "owner reads consents" on public.consents for select to authenticated
  using ((select auth.uid()) = user_id);
create policy "owner grants consents" on public.consents for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy "owner revokes consents" on public.consents for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

create policy "own media read" on public.media_objects for select to authenticated
  using ((select auth.uid()) = owner_id);
create policy "own media insert" on public.media_objects for insert to authenticated
  with check ((select auth.uid()) = owner_id);

-- Gözlem: sahibi okur/ekler, yalnızca kendi tarlasına.
create policy "owner reads observations" on public.ground_observations for select to authenticated
  using ((select auth.uid()) = user_id);
create policy "owner inserts observations" on public.ground_observations for insert to authenticated
  with check ((select auth.uid()) = user_id
              and exists (select 1 from public.fields f where f.id = field_id and f.owner_id = (select auth.uid())));

-- Worker'ın yazdığı tablolar: kullanıcı yalnızca okur; yazma service_role ile.
create policy "owner reads ai_runs" on public.ai_runs for select to authenticated
  using ((select auth.uid()) = user_id);
create policy "owner reads evidence" on public.validated_evidence for select to authenticated
  using ((select auth.uid()) = user_id);
create policy "owner reads estimates" on public.model_estimates for select to authenticated
  using ((select auth.uid()) = owner_id);
create policy "owner reads recommendations" on public.farm_recommendations for select to authenticated
  using ((select auth.uid()) = owner_id);
create policy "owner reads rec changes" on public.recommendation_changes for select to authenticated
  using ((select auth.uid()) = owner_id);
create policy "own assignments read" on public.mission_assignments for select to authenticated
  using ((select auth.uid()) = user_id);
create policy "own completions read" on public.mission_completions for select to authenticated
  using ((select auth.uid()) = user_id);
create policy "owner reads xp" on public.xp_ledger for select to authenticated
  using ((select auth.uid()) = user_id);

-- Sosyal: topluluk görünürlüğündeki gönderiler herkese (authenticated) açık,
-- yazar yalnızca community_sharing rızası aktifse paylaşabilir.
create policy "read community posts" on public.social_posts for select to authenticated
  using (visibility = 'community' or (select auth.uid()) = author_id);
create policy "author creates post with consent" on public.social_posts for insert to authenticated
  with check ((select auth.uid()) = author_id
              and exists (select 1 from public.consents c
                          where c.user_id = (select auth.uid())
                            and c.purpose = 'community_sharing'
                            and c.revoked_at is null));
create policy "author deletes post" on public.social_posts for delete to authenticated
  using ((select auth.uid()) = author_id);

-- anon rolüne hiçbir politika verilmedi ⇒ tüm tablolarda erişim yok.

-- ───────────── Storage ─────────────
insert into storage.buckets (id, name, public) values ('field-photos', 'field-photos', false)
  on conflict (id) do nothing;
-- Yol kuralı: field-photos/<user_id>/<uuid>.jpg
create policy "own photos upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'field-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "own photos read" on storage.objects for select to authenticated
  using (bucket_id = 'field-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);

-- ───────────── Seed ─────────────
insert into public.crops (id, name_tr, family, tbase_c, kc_ini, kc_mid, kc_end) values
  ('tomato','Domates','Solanaceae',10,0.6,1.15,0.8),
  ('wheat','Buğday','Poaceae',0,0.4,1.15,0.3),
  ('chickpea','Nohut','Fabaceae',5,0.4,1.0,0.35),
  ('sugar_beet','Şeker pancarı','Amaranthaceae',3,0.35,1.2,0.7)
on conflict do nothing;
insert into public.regions (id, name, centroid_lat, centroid_lon) values
  ('dogansehir','Doğanşehir, Malatya',38.05,37.88)
on conflict do nothing;
