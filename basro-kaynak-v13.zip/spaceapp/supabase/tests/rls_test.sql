-- RLS allow/deny testleri (brief §4.2). Çalıştırma: psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/rls_test.sql
-- Her şey bir transaction içinde yapılır ve sonunda geri alınır.
begin;

-- Supabase varsayılan tablo yetkileri (yerel test için; Supabase'de zaten var)
grant select, insert, update, delete on all tables in schema public to authenticated, anon;
grant usage on all sequences in schema public to authenticated, anon;

insert into auth.users(id) values
  ('00000000-0000-0000-0000-00000000000a'), ('00000000-0000-0000-0000-00000000000b');
insert into public.farms(id, owner_id, name) values
  ('10000000-0000-0000-0000-00000000000a','00000000-0000-0000-0000-00000000000a','A çiftliği'),
  ('10000000-0000-0000-0000-00000000000b','00000000-0000-0000-0000-00000000000b','B çiftliği');
insert into public.fields(id, farm_id, owner_id, name) values
  ('20000000-0000-0000-0000-00000000000a','10000000-0000-0000-0000-00000000000a','00000000-0000-0000-0000-00000000000a','A tarla'),
  ('20000000-0000-0000-0000-00000000000b','10000000-0000-0000-0000-00000000000b','00000000-0000-0000-0000-00000000000b','B tarla');
insert into public.ground_observations(user_id, field_id, observed_at, protocol_version) values
  ('00000000-0000-0000-0000-00000000000b','20000000-0000-0000-0000-00000000000b', now(), 'v1');
insert into public.xp_ledger(user_id, source_type, delta, label, idempotency_key) values
  ('00000000-0000-0000-0000-00000000000b','mission',50,'Haftalık kontrolü tamamladın','b-w1');

create temp table results(name text, ok boolean);
grant insert, select on results to authenticated, anon;

-- ── Kullanıcı A ──
set local role authenticated;
select set_config('request.jwt.claim.sub','00000000-0000-0000-0000-00000000000a', true);

insert into results select 'A, B''nin tarlasını göremez', count(*) = 0 from public.fields where owner_id = '00000000-0000-0000-0000-00000000000b';
insert into results select 'A kendi tarlasını görür', count(*) = 1 from public.fields;
insert into results select 'A, B''nin gözlemlerini göremez', count(*) = 0 from public.ground_observations;
insert into results select 'A, B''nin XP''sini göremez', count(*) = 0 from public.xp_ledger;

do $$ begin
  insert into public.ground_observations(user_id, field_id, observed_at, protocol_version)
  values ('00000000-0000-0000-0000-00000000000a','20000000-0000-0000-0000-00000000000b', now(), 'v1');
  insert into results values ('A, B''nin tarlasına gözlem ekleyemez', false);
exception when insufficient_privilege then insert into results values ('A, B''nin tarlasına gözlem ekleyemez', true);
end $$;

do $$ begin
  insert into public.ground_observations(user_id, field_id, observed_at, protocol_version)
  values ('00000000-0000-0000-0000-00000000000a','20000000-0000-0000-0000-00000000000a', now(), 'v1');
  insert into results values ('A kendi tarlasına gözlem ekler', true);
exception when others then insert into results values ('A kendi tarlasına gözlem ekler', false);
end $$;

do $$ begin
  insert into public.ground_observations(user_id, field_id, observed_at, protocol_version)
  values ('00000000-0000-0000-0000-00000000000a','20000000-0000-0000-0000-00000000000a', now(), 'v1');
  insert into results values ('Aynı tarla + gün için ikinci analiz reddedilir', false);
exception when unique_violation then insert into results values ('Aynı tarla + gün için ikinci analiz reddedilir', true);
end $$;

do $$ begin
  insert into public.xp_ledger(user_id, source_type, delta, label, idempotency_key)
  values ('00000000-0000-0000-0000-00000000000a','mission',9999,'hile','a-x');
  insert into results values ('A kendine XP yazamaz', false);
exception when insufficient_privilege then insert into results values ('A kendine XP yazamaz', true);
end $$;

do $$ begin
  insert into public.social_posts(author_id, body) values ('00000000-0000-0000-0000-00000000000a','rızasız');
  insert into results values ('Rıza olmadan toplulukta paylaşılamaz', false);
exception when insufficient_privilege then insert into results values ('Rıza olmadan toplulukta paylaşılamaz', true);
end $$;

insert into public.consents(user_id, purpose, version) values ('00000000-0000-0000-0000-00000000000a','community_sharing','v1');
do $$ begin
  insert into public.social_posts(author_id, body) values ('00000000-0000-0000-0000-00000000000a','rızalı');
  insert into results values ('Rıza varsa paylaşılır', true);
exception when others then insert into results values ('Rıza varsa paylaşılır', false);
end $$;

-- ── anon ──
reset role;
set local role anon;
select set_config('request.jwt.claim.sub','', true);
insert into results select 'anon hiçbir tarlayı göremez', count(*) = 0 from public.fields;
do $$ begin
  insert into public.farms(owner_id, name) values ('00000000-0000-0000-0000-00000000000a','x');
  insert into results values ('anon yazamaz', false);
exception when insufficient_privilege then insert into results values ('anon yazamaz', true);
end $$;

-- ── append-only ──
reset role;
do $$ begin
  update public.xp_ledger set delta = 1;
  insert into results values ('xp_ledger güncellenemez (servis rolü dahil)', false);
exception when raise_exception then insert into results values ('xp_ledger güncellenemez (servis rolü dahil)', true);
end $$;

do $$ begin
  insert into public.validated_evidence(user_id, observation_id, evidence_type, value, validator_model, validator_version, abstain)
  select user_id, id, 'phenology', '{}', 'test', 'v0', true from public.ground_observations limit 1;
  insert into results values ('abstain=true gerekçesiz kaydedilemez', false);
exception when check_violation then insert into results values ('abstain=true gerekçesiz kaydedilemez', true);
end $$;

select case when ok then 'PASS' else 'FAIL' end as result, name from results;
do $$ begin
  if exists (select 1 from results where not ok) then raise exception 'RLS testlerinde başarısızlık var'; end if;
end $$;

rollback;
